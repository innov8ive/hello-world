import { Component, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TableComponent } from '../../gridbase/table.component';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Message } from 'primeng/api';


@Component({
  templateUrl: 'drivers.component.html',
  styleUrl: 'drivers.component.scss'
})
export class DriversComponent {
  constructor(private _router: Router, private http: HttpClient) {
  }
  @ViewChild('myTable') myTable: TableComponent;
  cols = [
    { field: 'UserId', header: 'UserId' },
    { field: 'EmailId', header: 'EmailId' },
    { field: 'Mobile', header: 'Mobile' },
    { field: 'FirstName', header: 'First Name' },
    { field: 'LastName', header: 'Last Name' },
    { field: 'CityName', header: 'City' },
    { field: 'StatusDetails', header: 'Status' },
    { field: 'IsActive', header: 'IsActive' },
    { field: 'RegDate', header: 'Registration Date', format: 'dd-MMM-yyyy' }
  ];
  dataKey: string = 'UserId';
  searchText: string = '';
  msgs: Message[] = [];
  ngOnInit(): void {
  }

  searchFM() {
    this.myTable.loadData(this.searchText);
  }
  editFM() {

    if (this.myTable.selectedRow == null) {
      alert('Please select a row to view');
      return;
    }
    this._router.navigate(['/dashboard/drivers-profile', this.myTable.selectedRow.UserId]);
  }
}
