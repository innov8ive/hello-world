﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Public/PublicFlexy.Master" AutoEventWireup="true" CodeBehind="LoginFlexy.aspx.cs" Inherits="WebAppFlexy.LoginFlexy" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <asp:UpdatePanel ID="UpdatePanel1" runat="server" class="row justify-content-center w-100">
        <ContentTemplate>
            <div class="col-md-8 col-lg-6 col-xxl-3">
                <div class="card mb-0">
                    <div class="card-body">
                        <a href="./index.html" class="text-nowrap logo-img text-center d-block py-3 w-100">
                            <img src="../flexy_assets/images/logos/logo.svg" alt="">
                        </a>
                        <p class="text-center">Your Social Campaigns</p>
                        <div class="mb-3">
                            <label for="<%= txtEmail.ClientID %>" class="form-label">Username</label>
                            <asp:TextBox ID="txtEmail" runat="server" class="form-control"></asp:TextBox>
                            <asp:RegularExpressionValidator ID="RegularExpressionValidator1" runat="server"
                                ValidationExpression="^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
                                ErrorMessage="Invalid Email" ControlToValidate="txtEmail" Display="Dynamic" ForeColor="Red"></asp:RegularExpressionValidator>
                            <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ErrorMessage="Email is required"
                                ControlToValidate="txtEmail" Display="Dynamic" ForeColor="Red"></asp:RequiredFieldValidator>
                        </div>
                        <div class="mb-4">
                            <label for="exampleInputPassword1" class="form-label">Password</label>
                            <input type="password" class="form-control" id="exampleInputPassword1">
                        </div>
                        <div class="d-flex align-items-center justify-content-between mb-4">
                            <div class="form-check">
                                <input class="form-check-input primary" type="checkbox" value="" id="flexCheckChecked" checked>
                                <label class="form-check-label text-dark" for="flexCheckChecked">
                                    Remeber this Device
                                </label>
                            </div>
                            <a class="text-primary fw-bold" href="./index.html">Forgot Password ?</a>
                        </div>
                        <asp:Button ID="btnLogin" runat="server" class="btn btn-primary w-100 py-8 fs-4 mb-4 rounded-2" Text="Login" OnClick="btnLogin_Click" />
                        <div class="d-flex align-items-center justify-content-center">
                            <p class="fs-4 mb-0 fw-bold">New to MaterialM?</p>
                            <a class="text-primary fw-bold ms-2" href="./authentication-register.html">Create an account</a>
                        </div>
                    </div>
                </div>
            </div>
        </ContentTemplate>
        <Triggers>
            <asp:AsyncPostBackTrigger EventName="Click" ControlID="btnLogin" />
        </Triggers>
    </asp:UpdatePanel>

</asp:Content>
