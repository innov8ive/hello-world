﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebAppFlexy
{
    public partial class HomePageFlexy : System.Web.UI.Page
    {
        public static string GetConString(string keyName = "Main")
        {
            return ConfigurationManager.ConnectionStrings[keyName].ConnectionString;
        }
        public static DataTable GetDBResult(string query, string keyName = "Main")
        {
            SqlConnection con = new SqlConnection(GetConString(keyName));
            SqlCommand cmd = new SqlCommand(query, con);
            DataTable dt = new DataTable();
            con.Open();
            using (con)
            {
                dt.Load(cmd.ExecuteReader());
            }
            return dt;
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DataTable dataTable = GetDBResult("Select * from Forms");
                Literal1.Text = BuildSidebar(dataTable);
            }
        }

        public string BuildSidebar(DataTable formsTable)
        {
            var sb = new StringBuilder();

            // Start with roots (ParentFormID = 0)
            var roots = formsTable.AsEnumerable()
                .Where(r => r.Field<int>("ParentFormID") == 0)
                .OrderBy(r => r.Field<int>("SrNo"));

            foreach (var root in roots)
            {
                sb.AppendLine($@"
<li class=""nav-small-cap"">
    <span class=""hide-menu"">{root["FormName"]}</span>
</li>");

                AppendChildren(sb, formsTable, (int)root["FormID"]);
            }

            return sb.ToString();
        }

        private void AppendChildren(StringBuilder sb, DataTable formsTable, int parentId)
        {
            var children = formsTable.AsEnumerable()
                .Where(r => r.Field<int>("ParentFormID") == parentId)
                .OrderBy(r => r.Field<int>("SrNo"))
                .ToList();

            foreach (var child in children)
            {
                int formId = child.Field<int>("FormID");
                string formName = child.Field<string>("FormName");
                string formUrl = child.IsNull("FormUrl") ? null : child.Field<string>("FormUrl");
                string iconCss = child.Field<string>("IconCss");

                // Does this child have its own children?
                var grandChildren = formsTable.AsEnumerable()
                    .Where(r => r.Field<int>("ParentFormID") == formId)
                    .OrderBy(r => r.Field<int>("SrNo"))
                    .ToList();

                if (grandChildren.Count == 0)
                {
                    // Ultimate child
                    sb.AppendLine($@"
<li class=""sidebar-item"">
    <a class=""sidebar-link"" xhref=""{formUrl}"" onclick=""navigate('{formName}');"" aria-expanded=""false"">
        <i class=""{iconCss}""></i>
        <span class=""hide-menu"">{formName}</span>
    </a>
</li>");
                }
                else
                {
                    // Parent item → recurse for unlimited levels
                    sb.AppendLine($@"
<li class=""sidebar-item"">
    <a class=""sidebar-link justify-content-between has-arrow"" href=""javascript:void(0)"" aria-expanded=""false"">
        <div class=""d-flex align-items-center gap-3"">
            <span class=""d-flex"">
                <i class=""{iconCss}""></i>
            </span>
            <span class=""hide-menu"">{formName}</span>
        </div>
    </a>
    <ul aria-expanded=""false"" class=""collapse first-level"">");

                    // recursive call
                    AppendChildren(sb, formsTable, formId);

                    sb.AppendLine("</ul>\n</li>");
                }
            }
        }
    }
}