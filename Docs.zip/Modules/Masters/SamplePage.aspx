﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="SamplePage.aspx.cs" Inherits="WebAppFlexy.Modules.Masters.SamplePage" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body style="background-color:white;padding:20px;">
    <form id="form1" runat="server">
        <div class="card-body">
            <h5 class="card-title fw-semibold mb-4">
                <asp:Label ID="Label1" runat="server" Text="Label"></asp:Label></h5>
            <p class="mb-0">
                This is a sample page
                <asp:Label ID="Label2" runat="server" Text="Label"></asp:Label>
            </p>
            <table>
                <tr>
                    <td style="width: 150px">
                        <asp:Label ID="Label3" runat="server" Text="Name" CssClass="form-label"></asp:Label>
                    </td>
                    <td>
                        <asp:TextBox ID="TextBox1" runat="server" CssClass="form-control"></asp:TextBox>
                    </td>
                </tr>
                <tr>
                    <td style="width: 150px">
                        <asp:Label ID="Label4" runat="server" Text="Address" CssClass="form-label"></asp:Label>
                    </td>
                    <td>
                        <asp:TextBox ID="TextBox2" runat="server" CssClass="form-control"></asp:TextBox>
                    </td>
                </tr>
                <tr>
                    <td style="width: 150px">
                        <asp:Label ID="Label5" runat="server" Text="DOB" CssClass="form-label"></asp:Label>
                    </td>
                    <td>
                        <asp:TextBox ID="TextBox3" runat="server" CssClass="form-control"></asp:TextBox>
                    </td>
                </tr>
                <tr>
                    <td>

                    </td>
                    <td>
                        <asp:Button ID="btnLogin" runat="server" class="btn btn-primary w-100 py-8 fs-4 mb-4 rounded-2" Text="Save"  />
                    </td>
                </tr>
            </table>
        </div>
    </form>
</body>
</html>
