﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace WebAppFlexy.Modules.Masters
{
    public partial class SamplePage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string pageName = Request.QueryString["PageName"];
                Label1.Text = pageName;
                Label2.Text = pageName;
                System.Threading.Thread.Sleep(2000);
            }
        }
    }
}