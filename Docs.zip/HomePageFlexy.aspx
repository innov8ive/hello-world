﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="HomePageFlexy.aspx.cs" Inherits="WebAppFlexy.HomePageFlexy" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title></title>
    <link rel="shortcut icon" type="image/png" href="flexy_assets/images/logos/favicon.png" />
    <link rel="stylesheet" href="flexy_assets/css/styles.min.css" />
</head>

<body>
    <form id="form1" runat="server">
        <div class="page-wrapper" id="main-wrapper" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full"
            data-sidebar-position="fixed" data-header-position="fixed">

            <!-- Sidebar Start -->
            <aside class="left-sidebar">
                <!-- Sidebar scroll-->
                <div>
                    <div class="brand-logo d-flex align-items-center justify-content-between">
                        <a href="./index.html" class="text-nowrap logo-img">
                            <img src="flexy_assets/images/logos/logo.svg" alt="" />
                        </a>
                        <div class="close-btn d-xl-none d-block sidebartoggler cursor-pointer" id="sidebarCollapse">
                            <i class="ti ti-x fs-6"></i>
                        </div>
                    </div>
                    <!-- Sidebar navigation-->
                    <nav class="sidebar-nav scroll-sidebar" data-simplebar="">
                        <ul id="sidebarnav">
                            <asp:Literal ID="Literal1" runat="server"></asp:Literal>
                        </ul>
                    </nav>
                    <!-- End Sidebar navigation -->
                </div>
                <!-- End Sidebar scroll-->
            </aside>
            <!--  Sidebar End -->
            <!--  Main wrapper -->
            <div class="body-wrapper">
                <!--  Header Start -->
                <header class="app-header">
                    <nav class="navbar navbar-expand-lg navbar-light">
                        <ul class="navbar-nav">
                            <li class="nav-item d-block d-xl-none">
                                <a class="nav-link sidebartoggler " id="headerCollapse" href="javascript:void(0)">
                                    <i class="ti ti-menu-2"></i>
                                </a>
                            </li>
                        </ul>
                        <div>
                            <h3 id="h1FormName" style="float: left">Sample Page </h3>
                            <div id="loader" class="loader-page"></div>
                        </div>

                        <div class="navbar-collapse justify-content-end px-0" id="navbarNav">

                            <ul class="navbar-nav flex-row ms-auto align-items-center justify-content-end">

                                <li>
                                    <p style="margin: 0px;">Logged-In as : &nbsp;<strong>Admin (Mumbai)</strong></p>
                                    <p style="margin: 0px;">Working Period:  &nbsp;<strong>01-Apr-2025 to 31-Mar-2026</strong></p>
                                </li>
                                <li class="nav-item dropdown">
                                    <a class="nav-link " href="javascript:void(0)" id="drop2" data-bs-toggle="dropdown"
                                        aria-expanded="false">
                                        <img src="flexy_assets/images/profile/user-1.jpg" alt="" width="35" height="35" class="rounded-circle">
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-end dropdown-menu-animate-up" aria-labelledby="drop2">
                                        <div class="message-body">
                                            <a href="javascript:void(0)" class="d-flex align-items-center gap-2 dropdown-item">
                                                <i class="ti ti-user fs-6"></i>
                                                <p class="mb-0 fs-3">My Profile</p>
                                            </a>
                                            <a href="javascript:void(0)" class="d-flex align-items-center gap-2 dropdown-item">
                                                <i class="ti ti-mail fs-6"></i>
                                                <p class="mb-0 fs-3">Switch Location</p>
                                            </a>
                                            <a href="javascript:void(0)" class="d-flex align-items-center gap-2 dropdown-item">
                                                <i class="ti ti-list-check fs-6"></i>
                                                <p class="mb-0 fs-3">Change Password</p>
                                            </a>
                                            <a href="./authentication-login.html" class="btn btn-outline-primary mx-3 mt-2 d-block">Logout</a>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </header>
                <!--  Header End -->
                <div class="body-wrapper-inner">
                    <div class="container-fluid">
                        <iframe class="card card-wrapper" id="iframe" src="Modules/Masters/SamplePage.aspx"></iframe>
                    </div>
                </div>
                <footer>
                    <div class="app-footer">@Copyright 2025</div>
                </footer>
            </div>
        </div>
        <button type="button" id="aibutton"
            class="btn btn-primary rounded-circle position-fixed ai-button m-4 d-flex align-items-center justify-content-center"
            style="width: 56px; height: 56px; right: 100px">
            <i style="font-size: 40px" class="ti ti-bulb"></i>
        </button>
    </form>
    <!--  Body Wrapper -->

    <script src="flexy_assets/libs/jquery/dist/jquery.min.js"></script>
    <script src="flexy_assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="flexy_assets/js/sidebarmenu.js"></script>
    <script src="flexy_assets/js/app.min.js"></script>
    <script src="flexy_assets/libs/simplebar/dist/simplebar.js"></script>
    <script>
        var _formName = '';
        function navigate(formName) {
            const baseUrl = '<%= Page.ResolveUrl("~/Modules/Masters/SamplePage.aspx")%>';
            $('#iframe').attr('src', baseUrl + '?PageName=' + formName);
            _formName = formName;
            $('#h1FormName').html('Loading ' + formName + '...');
            document.getElementById("loader").style.display = "inline-block";
            if (formName.indexOf('ai') > -1) {
                $('#aibutton').hide();
            } else {
                $('#aibutton').show();
            }
        }
        $('#iframe').on('load', function () {
            document.getElementById("loader").style.display = "none";
            $('#h1FormName').html(_formName);
        });
    </script>
</body>

</html>
