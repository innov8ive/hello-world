﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using System.Web.UI;

namespace WebAppFlexy
{
    public class Global : System.Web.HttpApplication
    {
        protected void Application_Start(object sender, EventArgs e)
        {
            ScriptManager.ScriptResourceMapping.AddDefinition(
                "jquery",
                new ScriptResourceDefinition
                {
                    Path = "~/flexy_assets/libs/jquery/dist/jquery.min.js",   // local script
                    DebugPath = "~/flexy_assets/libs/jquery/dist/jquery.min.js",  // debug version
                    CdnPath = "https://code.jquery.com/jquery-3.7.1.min.js", // CDN fallback
                    CdnDebugPath = "https://code.jquery.com/jquery-3.7.1.js"
                });
        }
    }
}