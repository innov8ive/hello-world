

CREATE TABLE [dbo].[SetuInfo](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[BillerBillID] [varchar](50) NULL,
	[Amount] [decimal](18, 2) NULL,
	[LinkCreated] [datetime] NULL,
	[LinkExpired] [datetime] NULL,
	[EduclatPaymentId] [int] NULL,
	[PaymentNote] [varchar](500) NULL,
	[PlatformBillID] [varchar](50) NULL,
	[PaymentLinkUPIID] [varchar](500) NULL,
	[PaymentLinkUPILInk] [varchar](500) NULL,
	[LastStatus] [varchar](50) NULL,
	[LastStatusRecieved] [datetime] NULL,
	[StatusEventId] [varchar](50) NULL,
 CONSTRAINT [PK_SetuInfo] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

CREATE PROCEDURE [dbo].[Get_SetuInfo](
@ID int=0
) AS BEGIN
SELECT 
ID
,Amount
,BillerBillID
,EduclatPaymentId
,LastStatus
,LastStatusRecieved
,LinkCreated
,LinkExpired
,PaymentLinkUPIID
,PaymentLinkUPILInk
,PaymentNote
,PlatformBillID
,StatusEventId
FROM SetuInfo WHERE @ID=ID OR @ID = 0
END

GO

CREATE  PROCEDURE [dbo].[Insert_Update_SetuInfo](
@Amount decimal = NULL
,@BillerBillID varchar(50) = NULL
,@EduclatPaymentId int = NULL
,@ID int = NULL
 output
,@LastStatus varchar(50) = NULL
,@LastStatusRecieved datetime = NULL
,@LinkCreated datetime = NULL
,@LinkExpired datetime = NULL
,@PaymentLinkUPIID varchar(500) = NULL
,@PaymentLinkUPILInk varchar(500) = NULL
,@PaymentNote varchar(500) = NULL
,@PlatformBillID varchar(50) = NULL
,@StatusEventId varchar(50) = NULL
)AS  BEGIN
SET NOCOUNT ON;
IF(@ID IS NULL OR @ID <= 0)
BEGIN
INSERT INTO SetuInfo(
[Amount]
,[BillerBillID]
,[EduclatPaymentId]
,[LastStatus]
,[LastStatusRecieved]
,[LinkCreated]
,[LinkExpired]
,[PaymentLinkUPIID]
,[PaymentLinkUPILInk]
,[PaymentNote]
,[PlatformBillID]
,[StatusEventId]
)VALUES(
@Amount
,@BillerBillID
,@EduclatPaymentId
,@LastStatus
,@LastStatusRecieved
,@LinkCreated
,@LinkExpired
,@PaymentLinkUPIID
,@PaymentLinkUPILInk
,@PaymentNote
,@PlatformBillID
,@StatusEventId
)
set @ID=SCOPE_IDENTITY();
END
ELSE
BEGIN
UPDATE SetuInfo SET 
[Amount]=@Amount
,[BillerBillID]=@BillerBillID
,[EduclatPaymentId]=@EduclatPaymentId
,[LastStatus]=@LastStatus
,[LastStatusRecieved]=@LastStatusRecieved
,[LinkCreated]=@LinkCreated
,[LinkExpired]=@LinkExpired
,[PaymentLinkUPIID]=@PaymentLinkUPIID
,[PaymentLinkUPILInk]=@PaymentLinkUPILInk
,[PaymentNote]=@PaymentNote
,[PlatformBillID]=@PlatformBillID
,[StatusEventId]=@StatusEventId
 where 
 [ID]=@ID
END
END


GO

ALTER TABLE Soc Add SHA1 varchar(500)
ALTER TABLE Soc Add SHA2 varchar(500)
GO

ALTER TABLE Payments add PlatformBillID varchar(50)
GO

ALTER PROCEDURE [dbo].[Get_Payments](
@PaymentID int=0) AS BEGIN

SELECT 
PaymentID
,Amount
,EnrollID
,PaidGEGroupID
,PaidRefDate
,PaidRefNo
,PaidToGLID
,PaymentDate
,PaymentMode
,Remarks
,SocID
,CollectedBy
,PlatformBillID
FROM Payments WHERE @PaymentID=PaymentID
END

GO

ALTER PROCEDURE [dbo].[Insert_Update_Payments](


@Amount decimal = NULL
,@EnrollID int = NULL
,@PaidGEGroupID int = NULL
,@PaidRefDate datetime = NULL
,@PaidRefNo varchar(50) = NULL
,@PaidToGLID int = NULL
,@PaymentDate datetime = NULL
,@PaymentID int = NULL
 output
,@PaymentMode varchar(50) = NULL
,@Remarks varchar(250) = NULL
,@SocID int = NULL
,@CollectedBy int=NULL
,@PlatformBillID varchar(50)=NULL
)
AS  BEGIN

SET NOCOUNT ON;

IF(@PaymentID IS NULL OR @PaymentID <= 0)

BEGIN

INSERT INTO Payments(

[Amount]
,[EnrollID]
,[PaidGEGroupID]
,[PaidRefDate]
,[PaidRefNo]
,[PaidToGLID]
,[PaymentDate]
,[PaymentMode]
,[Remarks]
,[SocID]
,CollectedBy
,PlatformBillID
)
VALUES(
@Amount
,@EnrollID
,@PaidGEGroupID
,@PaidRefDate
,@PaidRefNo
,@PaidToGLID
,@PaymentDate
,@PaymentMode
,@Remarks
,@SocID
,@CollectedBy
,@PlatformBillID
)
set @PaymentID=Scope_identity();
END

ELSE

BEGIN

UPDATE Payments SET 

[Amount]=@Amount
,[EnrollID]=@EnrollID
,[PaidGEGroupID]=@PaidGEGroupID
,[PaidRefDate]=@PaidRefDate
,[PaidRefNo]=@PaidRefNo
,[PaidToGLID]=@PaidToGLID
,[PaymentDate]=@PaymentDate
,[PaymentMode]=@PaymentMode
,[Remarks]=@Remarks
,[SocID]=@SocID
,PlatformBillID=@PlatformBillID
 where 
 [PaymentID]=@PaymentID

END

END
GO