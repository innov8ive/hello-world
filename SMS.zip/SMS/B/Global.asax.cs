﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using System.Web.Security;
using System.Web.SessionState;
using System.Web.Http;
using SampleAngular;
using FirebaseAdmin;
using Google.Apis.Auth.OAuth2;

namespace SMSSpecial
{
    public class Global : HttpApplication
    {
        void Application_Start(object sender, EventArgs e)
        {
            // Code that runs on application startup
            AreaRegistration.RegisterAllAreas();
            GlobalConfiguration.Configure(WebApiConfig.Register);
            RouteConfig.RegisterRoutes(RouteTable.Routes);

            System.Reflection.Assembly assembly = System.Reflection.Assembly.GetExecutingAssembly();
            System.IO.FileInfo fileInfo = new System.IO.FileInfo(assembly.Location);
            DateTime lastModified = fileInfo.LastWriteTime;

            Application["builddate"] = lastModified.ToString("ddMMyyyyhhMMss");
            
            //Common.SendEmailSendGrid("sanjayg312@gmail.com", @"Dear Member,<br/>Thank you for showing your interest.<br/>","Welcome");
            //Common.CreateSchedule(16);
            //Common.CreateAccounts(16);
            //Common.GetDelayCharge(9, Common.ToDate("2017-08-15"));

            //Common.SendBillNotification(17, "SAI SHRUSHTI HEIGHTS");
            //PushNotification.AndroidPush("fDe3me2eaJg:APA91bGzYjjTNZScNpjAsUGe4AZgp_C8fIcc2PlvyPcvt8p_ZvzlV4z583g_-5YYG5rBn8Vljc-u8lZdcRWUMfxloDwVwOuDj_l0Zd70JDX54cgOX7lQkwPBiUrKyvdywRqOGbxfe3rTwcAAj7z0F3oqn1KWdcF5EQ",
            //  "test message4", "test4", "AIzaSyB1R4ZgA7zRw3cm_uOiukRKvT6eMtiDpzg");


            ////var credential = GoogleCredential.FromFile(Server.MapPath("~") + "/data.json");
            ////FirebaseApp.Create(new AppOptions()
            ////{

            ////    Credential = credential
            ////});

            //string b = StringCipher.Encrypt("b7c2703b-970c-417d-a924-04dfcf508f81", "");
            //string a = StringCipher.Encrypt("b55587fa-afd8-48fe-bbb7-aa2ef367264c", "");
        }

        private void Global_PostAuthenticateRequest(object sender, EventArgs e)
        {
            HttpContext.Current.SetSessionStateBehavior(SessionStateBehavior.Required);
        }

        protected void Application_PostAuthorizeRequest()
        {
            HttpContext.Current.SetSessionStateBehavior(SessionStateBehavior.Required);
        }
    }
}