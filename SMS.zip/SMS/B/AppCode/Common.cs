using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.Common;
using System.Data;
using System.Web.UI.HtmlControls;
using System.Web.UI;
using System.Collections;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.ComponentModel;
using System.Net.Mail;
using System.Net;
using System.IO;
using System.Web.Hosting;
using System.Text;
using System.Collections.ObjectModel;
using System.Web.Security;
using System.Text.RegularExpressions;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using System.Data.Linq;
using SampleAngularBL;
using SendGrid.SmtpApi;
using System.Web.Configuration;
using FluentValidation.Results;
using System.Web.SessionState;
using System.Reflection;

namespace SampleAngular
{
    public class PostResponse
    {
        public int ErrorCode { get; set; }
        public object data { get; set; }
        public string ErrorMessage { get; set; }
    }
    public class ConfigStatus
    {
        public bool AllDone
        {
            get
            {
                return AYDone && TeacherDone && SubjectDone && ClassDone && SectionDone && PeriodDone && TimeTableDone;
            }
        }
        public bool AYDone { get; set; }
        public bool TeacherDone { get; set; }
        public bool SubjectDone { get; set; }
        public bool ClassDone { get; set; }
        public bool SectionDone { get; set; }
        public bool PeriodDone { get; set; }
        public bool TimeTableDone { get; set; }
    }
    public class MenuItem
    {
        public int FormID { get; set; }
        public string FormName { get; set; }
        public string FormUrl { get; set; }
        public string MobileUrl { get; set; }
        public bool HasParent { get; set; }
        public string IconCss { get; set; }
        public bool IsModuleMenu { get; set; }
        public List<MenuItem> Children { get; set; }
    }
    public class ChangePassword
    {
        public int UserID { get; set; }
        public string OldPassword { get; set; }
        public string NewPassword { get; set; }
        public string ConfirmPassword { get; set; }
    }
    public class LoginUser
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string UserName { get; set; }
        public int UserID { get; set; }
        public bool IsActive { get; set; }
        public string EmailID { get; set; }
        public string Password { get; set; }
        public string Token { get; set; }
        public string ImageUrl { get; set; }
        public bool Verified { get; set; }
        public int CityID { get; set; }
        public int UserType { get; set; }
        public string SocName { get; set; }
        public List<MenuItem> MenuItems { get; set; }
        public List<MenuItem> MobileMenuItems { get; set; }
        public List<int> RMList { get; set; }
        public int WPID { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string WPName { get; set; }
        public List<AngularDropdownData> SocList { get; set; }
        public bool ForcedRMLogin { get; set; }
        public DataTable dtAds { get; set; }
    }
    public class LoggedUser
    {
        public int UserID { get; set; }
        public int UserType { get; set; }
        public List<int> FormIDs { get; set; }
        public int SocID { get; set; }
        public List<int> RoomID { get; set; }
        public int SPID { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string DateTimeFormat { get { return "dd-MMM-yyyy"; } }
        public string SocName { get; set; }
        public int WPID { get; set; }
        public string WPName { get; set; }
        public bool ForcedRMLogin { get; set; }
        public string MobileNo { get; set; }
        public int RoleID { get; set; }
        public string TokenString { get; set; }
    }

    public class Common
    {
        public static LoginUser IsValidUser(string userName, string password, int userType)
        {
            SqlConnection con = new SqlConnection(Common.GetConString());
            SqlCommand cmd = new SqlCommand(@"select * from Users where (EmailID=@UserName OR MobileNo=@UserName) and Password=@Password and IsActive=1", con);
            cmd.Parameters.Add("@UserName", SqlDbType.VarChar, 250).Value = userName;
            cmd.Parameters.Add("@Password", SqlDbType.VarChar, 250).Value = MD5Encrypt(password);
            DataTable dt = new DataTable();
            con.Open();
            using (con)
            {
                dt.Load(cmd.ExecuteReader());
            }

            if (dt.Rows.Count > 0)
            {
                if ((userType == 0 || userType == 2) && Common.ToInt(dt.Rows[0]["UserType"]) == 3)
                {
                    return null;
                }
                if (userType == 3)
                    return SetUserInSession(dt, 0, true);
                else
                    return SetUserInSession(dt, 0, false);
            }
            else
            {
                return null;
            }
        }
        public static LoginUser LoadUser(int userID)
        {
            SqlConnection con = new SqlConnection(Common.GetConString());
            SqlCommand cmd = new SqlCommand(@"select * from Users where UserID=@UserID", con);
            cmd.Parameters.Add("@UserID", SqlDbType.Int).Value = userID;
            DataTable dt = new DataTable();
            con.Open();
            using (con)
            {
                dt.Load(cmd.ExecuteReader());
            }

            if (dt.Rows.Count > 0)
            {
                return SetUserInSession(dt, 0, false);
            }
            else
            {
                return null;
            }
        }

        public static LoginUser SetUserInSession(DataTable dt, int SocID, bool forceToRoomView)
        {
            DataRow dr = dt.Rows[0];
            LoginUser objLoginUser = new LoginUser();
            LoggedUser objLoggedUser = new LoggedUser();
            objLoginUser.UserID = Common.ToInt(dr["UserID"]);
            objLoggedUser.RoleID = Common.ToInt(dr["RoleID"]);
            objLoggedUser.UserID = objLoginUser.UserID;
            objLoggedUser.MobileNo = Common.ToString(dr["MobileNo"]);

            objLoginUser.FirstName = Common.ToString(dr["FirstName"]);
            objLoginUser.UserName = Common.ToString(dr["UserName"]);
            objLoginUser.LastName = Common.ToString(dr["LastName"]);
            objLoginUser.IsActive = Common.ToBool(dr["IsActive"]);
            objLoginUser.EmailID = Common.ToString(dr["EmailID"]);
            objLoginUser.ImageUrl = Common.ToString(dr["ImageUrl"]);
            objLoginUser.Verified = Common.ToBool(dr["Verified"]);
            objLoginUser.CityID = Common.ToInt(dr["CityID"]);
            int roomID = Common.ToInt(dr["RoomID"]);
            objLoginUser.Token = CreateToken(objLoginUser.UserID);

            if (Common.ToInt(dr["UserType"]) == Constants.UserType.Admin && forceToRoomView == false)
            {
                objLoginUser.ForcedRMLogin = objLoggedUser.ForcedRMLogin = false;
                objLoginUser.UserType = 2;
                objLoggedUser.UserType = objLoginUser.UserType;

                DataTable dtSoc = Common.GetDBResult("Select SocID,SocName from Soc where UserID=" + objLoggedUser.UserID);
                if (dtSoc.Rows.Count > 0)
                {
                    objLoggedUser.SocID = Common.ToInt(dtSoc.Rows[0]["SocID"]);
                    objLoggedUser.SocName = Common.ToString(dtSoc.Rows[0]["SocName"]);
                    objLoginUser.SocName = objLoggedUser.SocName;
                }
                objLoggedUser.RoomID = new List<int>();
                objLoginUser.RMList = objLoggedUser.RoomID;

                //                List<AngularDropdownData> objSocList = new List<AngularDropdownData>();
                //                DataTable dtSocList = Common.GetDBResultParameterized(@"select * from 
                //Soc 
                //where exists (select 1 from Users U where U.CreatedBy=Soc.UserID and U.MobileNo=@MobileNo)",
                //                "@MobileNo", SqlDbType.VarChar, objLoggedUser.MobileNo);
                //                foreach (DataRow drSoc in dtSocList.Rows)
                //                {
                //                    objSocList.Add(new AngularDropdownData() { Key = Common.ToString(drSoc["SocID"]), Value = Common.ToString(drSoc["SocName"]) });
                //                }
                //                objLoginUser.SocList = objSocList;
                objLoginUser.MenuItems = GetUserMenuItems(objLoggedUser, 2);
                objLoginUser.MobileMenuItems = GetMobileMenuItems(objLoggedUser, 2);
                objLoginUser.MobileMenuItems.Insert(0, new MenuItem()
                {
                    FormID = 1,
                    FormName = "Dashboard",
                    FormUrl = "#/app/main",
                    IconCss = "fa fa-home"
                });
                FillFormID(objLoggedUser, 2);
            }
            else if (Common.ToInt(dr["UserType"]) == Constants.UserType.Normal && forceToRoomView == false)
            {
                objLoginUser.UserType = 1;
                objLoggedUser.UserType = 1;
                objLoginUser.ForcedRMLogin = objLoggedUser.ForcedRMLogin = forceToRoomView;
                objLoggedUser.UserType = objLoginUser.UserType;
                DataTable dtSoc = Common.GetDBResult(@"select * from 
Soc S
where 
UserID in (select CreatedBy from Users U where U.UserID=" + Common.ToInt(dr["UserID"]) + ")");

                if (dtSoc.Rows.Count > 0)
                {
                    objLoggedUser.SocID = Common.ToInt(dtSoc.Rows[0]["SocID"]);
                    objLoggedUser.SocName = Common.ToString(dtSoc.Rows[0]["SocName"]);
                    objLoginUser.SocName = objLoggedUser.SocName;
                }

                objLoggedUser.RoomID = new List<int>();

                //List<AngularDropdownData> objSocList = new List<AngularDropdownData>();
                ////                DataTable dtSocList = Common.GetDBResultParameterized(@"select * from 
                ////Soc 
                ////where exists (select 1 from Users U where U.CreatedBy=Soc.UserID and U.MobileNo=@MobileNo)",
                ////                "@MobileNo", SqlDbType.VarChar, objLoggedUser.MobileNo);
                //foreach (DataRow drSoc in dtSoc.Rows)
                //{
                //    objSocList.Add(new AngularDropdownData() { Key = Common.ToString(drSoc["SocID"]), Value = Common.ToString(drSoc["SocName"]) });
                //}
                //objLoginUser.SocList = objSocList;
                objLoginUser.dtAds = Common.GetDBResult("Select * from Carousel where CategoryID=" + objLoggedUser.SocID);
                objLoginUser.MenuItems = GetUserMenuItems(objLoggedUser, 1);
                objLoginUser.MobileMenuItems = GetMobileMenuItems(objLoggedUser, 1);
                objLoginUser.MobileMenuItems.Insert(0, new MenuItem()
                {
                    FormID = 1,
                    FormName = "Dashboard",
                    FormUrl = "#/app/main",
                    IconCss = "fa fa-home"
                });
                FillFormID(objLoggedUser, 1);
            }
            else if (Common.ToInt(dr["UserType"]) == Constants.UserType.Parent || forceToRoomView == true)
            {
                objLoginUser.UserType = 3;
                objLoggedUser.UserType = 3;
                objLoginUser.MenuItems = GetUserMenuItems(objLoggedUser, Constants.UserType.Parent);
                FillFormID(objLoggedUser, Constants.UserType.Parent);
                objLoginUser.MobileMenuItems = new List<MenuItem>();
                objLoginUser.MobileMenuItems.Insert(0, new MenuItem()
                {
                    FormID = 1,
                    FormName = "Dashboard",
                    FormUrl = "#/app/NormalStudentsList",
                    IconCss = "fa fa-home"
                });
                objLoggedUser.RoomID = new List<int>();
            }
            else if (Common.ToInt(dr["UserType"]) == Constants.UserType.GateKeeper)
            {
                objLoginUser.UserType = Constants.UserType.GateKeeper;
                objLoggedUser.UserType = objLoginUser.UserType;

                List<AngularDropdownData> objSocList = new List<AngularDropdownData>();
                DataTable dtSocList = Common.GetDBResultParameterized(@"select * from 
Soc 
where exists (select 1 from Users U where U.CreatedBy=Soc.UserID and U.MobileNo=@MobileNo)",
              "@MobileNo", SqlDbType.VarChar, objLoggedUser.MobileNo);
                foreach (DataRow drSoc in dtSocList.Rows)
                {
                    objSocList.Add(new AngularDropdownData() { Key = Common.ToString(drSoc["SocID"]), Value = Common.ToString(drSoc["SocName"]) });
                }
                objLoginUser.SocList = objSocList;

                if (dtSocList.Rows.Count > 0)
                {
                    objLoggedUser.SocID = Common.ToInt(dtSocList.Rows[0]["SocID"]);
                    objLoggedUser.SocName = Common.ToString(dtSocList.Rows[0]["SocName"]);
                    objLoginUser.SocName = objLoggedUser.SocName;
                }
                objLoginUser.MenuItems = GetUserMenuItems(objLoggedUser, Constants.UserType.GateKeeper);
            }
            else if (Common.ToInt(dr["UserType"]) == Constants.UserType.PayTM)
            {
                objLoginUser.UserType = Constants.UserType.PayTM;
                objLoggedUser.UserType = objLoginUser.UserType;
                objLoginUser.SocName = "SocietyInn: PayTM Control Panel";

                objLoginUser.MenuItems = GetUserMenuItems(objLoggedUser, Constants.UserType.PayTM);
            }

            DataTable dtWP = Common.GetDBResultParameterized("Select * from AY where SocID=@SocID and (1=1 OR @Date between StartDate and EndDate) order by StartDate desc",
                "@SocID", SqlDbType.Int, objLoggedUser.SocID,
                "@Date", SqlDbType.DateTime, DateTime.Today);
            if (dtWP.Rows.Count > 0)
            {
                DataRow drWP = dtWP.Rows[0];
                objLoginUser.WPID = Common.ToInt(drWP["AYID"]);
                objLoginUser.StartDate = Common.ToDate(drWP["StartDate"]);
                objLoginUser.EndDate = Common.ToDate(drWP["EndDate"]);
                objLoginUser.WPName = objLoginUser.StartDate.ToString("dd-MMM-yyyy") + " To " + objLoginUser.EndDate.ToString("dd-MMM-yyyy");

                objLoggedUser.WPID = objLoginUser.WPID;
                objLoggedUser.WPName = objLoginUser.WPName;
                objLoggedUser.StartDate = objLoginUser.StartDate;
                objLoggedUser.EndDate = objLoginUser.EndDate;
            }
            objLoginUser.Token = HttpContext.Current.Session.SessionID;
            HttpContext.Current.Session["LoggedUser"] = objLoggedUser;

            return objLoginUser;
        }
        public static string ChangePassword(ChangePassword objChangePassword)
        {
            SqlConnection con = new SqlConnection(Common.GetConString());
            SqlCommand cmd = new SqlCommand(@"Update Users set Password=@NewPassword where UserID=@UserID and Password=@Password", con);
            cmd.Parameters.Add("@UserID", SqlDbType.Int).Value = objChangePassword.UserID;
            cmd.Parameters.Add("@NewPassword", SqlDbType.VarChar, 250).Value = MD5Encrypt(objChangePassword.NewPassword);
            cmd.Parameters.Add("@Password", SqlDbType.VarChar, 250).Value = MD5Encrypt(objChangePassword.OldPassword);
            con.Open();
            int affectedRows = 0;
            using (con)
            {
                affectedRows = cmd.ExecuteNonQuery();
            }

            if (affectedRows > 0)
            {
                return "Changed";
            }
            else
            {
                return "Invalid";
            }
        }
        public static string CreateToken(int userID)
        {
            //delete previous tokens
            Common.ExecuteNonQuery("DELETE FROM UserTokens WHERE UserID=" + userID);

            //generate token
            string token = MD5Encrypt(userID.ToString()) + "-" + Guid.NewGuid().ToString();

            //insert
            Common.ExecuteNonQuery("INSERT INTO UserTokens(UserID,Token,ModifiedDate) values(@UserID,@Token,@ModifiedDate)",
                "@UserID", SqlDbType.Int, userID,
                "@Token", SqlDbType.VarChar, token,
                "@ModifiedDate", SqlDbType.DateTime, DateTime.UtcNow);
            return token;
        }
        private static SessionStateStoreData GetSessionById(string sessionId)
        {
            HttpApplication httpApplication = HttpContext.Current.ApplicationInstance;

            // Black magic #1: getting to SessionStateModule
            HttpModuleCollection httpModuleCollection = httpApplication.Modules;
            SessionStateModule sessionHttpModule = httpModuleCollection["Session"] as SessionStateModule;
            if (sessionHttpModule == null)
            {
                // Couldn't find Session module
                return null;
            }

            // Black magic #2: getting to SessionStateStoreProviderBase through reflection
            FieldInfo fieldInfo = typeof(SessionStateModule).GetField("_store", BindingFlags.NonPublic | BindingFlags.Instance);
            SessionStateStoreProviderBase sessionStateStoreProviderBase = fieldInfo.GetValue(sessionHttpModule) as SessionStateStoreProviderBase;
            if (sessionStateStoreProviderBase == null)
            {
                // Couldn't find sessionStateStoreProviderBase
                return null;
            }

            // Black magic #3: generating dummy HttpContext out of the thin air. sessionStateStoreProviderBase.GetItem in #4 needs it.
            SimpleWorkerRequest request = new SimpleWorkerRequest("dummy.html", null, new StringWriter());
            HttpContext context = new HttpContext(request);

            // Black magic #4: using sessionStateStoreProviderBase.GetItem to fetch the data from session with given Id.
            bool locked;
            TimeSpan lockAge;
            object lockId;
            SessionStateActions actions;
            SessionStateStoreData sessionStateStoreData = sessionStateStoreProviderBase.GetItem(
                context, sessionId, out locked, out lockAge, out lockId, out actions);
            return sessionStateStoreData;
        }
        public static LoggedUser GetLoggedUser(HttpRequestMessage Request)
        {
            LoggedUser objLoggedUser = null;
            string userID = String.Empty;
            string token = String.Empty;
            string key = String.Empty;
            int reqType = 0;
            IEnumerable<string> headerValues;
            if (Request.Headers.TryGetValues("Token", out headerValues))
            {
                token = headerValues.FirstOrDefault();
            }
            headerValues = null;
            var nameFilter = string.Empty;
            if (Request.Headers.TryGetValues("UserID", out headerValues))
            {
                userID = Common.ToString(headerValues.FirstOrDefault());
            }
            headerValues = null;
            nameFilter = string.Empty;
            if (Request.Headers.TryGetValues("Key", out headerValues))
            {
                key = Common.ToString(headerValues.FirstOrDefault());
            }
            headerValues = null;
            nameFilter = string.Empty;
            if (Request.Headers.TryGetValues("ReqType", out headerValues))
            {
                reqType = Common.ToInt(headerValues.FirstOrDefault());
            }

            if (!String.IsNullOrEmpty(token))
            {
                SessionStateStoreData session = GetSessionById(token);
                if (session != null)
                    objLoggedUser = session.Items["LoggedUser"] as LoggedUser;
            }
            if (objLoggedUser == null)
            {
                if (reqType == 0) reqType = 1;
                Common.IsValidUser(userID, key, reqType);
                objLoggedUser = HttpContext.Current.Session["LoggedUser"] as LoggedUser;
            }

            return objLoggedUser;
        }
        public static LoggedUser GetUserFromSession(HttpRequestMessage Request)
        {
            LoggedUser objLoggedUser = HttpContext.Current.Session["LoggedUser"] as LoggedUser;
            if (objLoggedUser != null)
                return objLoggedUser;
            else
            {
                string userID = String.Empty;
                string token = String.Empty;
                string key = String.Empty;
                string authkey = String.Empty;
                int reqType = 0;
                IEnumerable<string> headerValues;
                if (Request.Headers.TryGetValues("Token", out headerValues))
                {
                    token = headerValues.FirstOrDefault();
                }
                headerValues = null;
                var nameFilter = string.Empty;
                if (Request.Headers.TryGetValues("UserID", out headerValues))
                {
                    userID = Common.ToString(headerValues.FirstOrDefault());
                }
                headerValues = null;
                nameFilter = string.Empty;
                if (Request.Headers.TryGetValues("Key", out headerValues))
                {
                    key = Common.ToString(headerValues.FirstOrDefault());
                }
                headerValues = null;
                nameFilter = string.Empty;
                if (Request.Headers.TryGetValues("AuthKey", out headerValues))
                {
                    authkey = Common.ToString(headerValues.FirstOrDefault());
                }
                headerValues = null;
                nameFilter = string.Empty;
                if (Request.Headers.TryGetValues("ReqType", out headerValues))
                {
                    reqType = Common.ToInt(headerValues.FirstOrDefault());
                }
                if (!String.IsNullOrEmpty(token))
                {
                    SessionStateStoreData session = GetSessionById(token);
                    if (session != null)
                        objLoggedUser = session.Items["LoggedUser"] as LoggedUser;
                }
                if (objLoggedUser == null)
                {
                    if (reqType == 0) reqType = 1;
                    if (userID.Length > 0 && key.Length > 0)
                    {
                        LoginUser IsvalidUser = IsValidUser(userID, key, 1);
                        if (IsvalidUser != null)
                            objLoggedUser = HttpContext.Current.Session["LoggedUser"] as LoggedUser;

                    }
                    else if (authkey.Length > 0)
                    {
                        int payTMUserID = Common.ToInt(Common.GetDBScalar("Select UserID from Users where AuthKey=@AuthKey",
                            "@AuthKey", SqlDbType.VarChar, authkey));
                        LoginUser IsvalidUser = LoadUser(payTMUserID);
                        if (IsvalidUser != null)
                            objLoggedUser = HttpContext.Current.Session["LoggedUser"] as LoggedUser;
                    }
                }
                return objLoggedUser;
            }
        }
        public static bool IsValidToken(HttpRequestMessage Request)
        {
            bool IsValid = true;
            int userID = 0;
            string token = String.Empty;
            IEnumerable<string> headerValues;
            if (Request.Headers.TryGetValues("Token", out headerValues))
            {
                token = headerValues.FirstOrDefault();
            }
            headerValues = null;
            var nameFilter = string.Empty;
            if (Request.Headers.TryGetValues("UserID", out headerValues))
            {
                userID = Common.ToInt(headerValues.FirstOrDefault());
            }

            if (userID <= 0 || String.IsNullOrEmpty(token))
                IsValid = false;

            if (!token.StartsWith(MD5Encrypt(userID.ToString())))
                IsValid = false;

            int timeout = 20;
            //check token is valid or not
            int count = Common.ToInt(Common.GetDBScalar(@"SELECT COUNT(*) from UserTokens where UserID=@UserID and Token=@Token
	and DATEDIFF(MI,@Now,ModifiedDate) <= @TimeOut",
                "@UserID", SqlDbType.Int, userID,
                "@Token", SqlDbType.VarChar, token,
                "@Now", SqlDbType.DateTime, DateTime.UtcNow,
                "@TimeOut", SqlDbType.Int, timeout));

            //if valid
            if (count > 0)
            {
                //update date
                Common.ExecuteNonQuery("UPDATE UserTokens SET ModifiedDate=@Now WHERE UserID=@UserID",
                "@UserID", SqlDbType.Int, userID,
                "@Now", SqlDbType.DateTime, DateTime.UtcNow);
                return true;
            }
            else
            {
                Common.ExecuteNonQuery("DELETE FROM UserTokens WHERE UserID=@UserID",
                "@UserID", SqlDbType.Int, userID);
                IsValid = false;
            }

            if (IsValid == false)
            {
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            }
            return false;
        }
        public static bool IsValidForm(int formID, HttpRequestMessage Request)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            if (objLoggedUser == null) throw new HttpResponseException(HttpStatusCode.Unauthorized);

            if (objLoggedUser.FormIDs.Count(Obj => Obj == formID) <= 0) throw new HttpResponseException(HttpStatusCode.Unauthorized);

            return true;
        }
        public static string MD5Encrypt(string text)
        {
            return FormsAuthentication.HashPasswordForStoringInConfigFile(text, "MD5");
        }
        public static string Reverse(string s)
        {
            char[] charArray = s.ToCharArray();
            Array.Reverse(charArray);
            return new string(charArray);
        }
        private static void FillFormID(LoggedUser objLoggedUser, int userType)
        {
            DataTable dtMenu = Common.GetDBResultParameterized(@"
Select * from Forms F where F.IsActive=1 and exists(select 1 from UserForms UF where UF.FormID=F.FormID and UF.UserType=@UserType) Order By SrNo",
                    "@UserType", SqlDbType.Int, userType);

            objLoggedUser.FormIDs = new List<int>();
            //If Normal User has any Role Assigned
            if (objLoggedUser.UserType == 1 && objLoggedUser.RoleID > 0)
            {
                DataTable dtRole = Common.GetDBResultParameterized(@";with name_tree as 
(
   Select * from Forms F where F.IsActive=1 and 
exists(
select 1 from FormRoles FR where FR.FormID=F.FormID and FR.RoleID=@RoleID and FR.SocID=@SocID)
   union all
   select C.*
   from Forms c
   join name_tree p on C.FormID = P.ParentFormID  -- this is the recursion
  
) 
select distinct * from name_tree",
                  "@RoleID", SqlDbType.Int, objLoggedUser.RoleID,
                  "@SocID", SqlDbType.Int, objLoggedUser.SocID);

                //fill FormIDs
                foreach (DataRow dr in dtRole.Rows)
                {
                    objLoggedUser.FormIDs.Add(Common.ToInt(dr["FormID"]));
                }
            }

            //fill FormIDs
            foreach (DataRow dr in dtMenu.Rows)
            {
                objLoggedUser.FormIDs.Add(Common.ToInt(dr["FormID"]));
            }
        }
        public static List<MenuItem> GetMobileMenuItems(LoggedUser objLoggedUser, int userType)
        {
            List<MenuItem> menuList = new List<MenuItem>();
            DataTable dtMenu = new DataTable();

            //User is admin
            if (objLoggedUser.UserType == 2 || objLoggedUser.UserType == 3)
            {
                dtMenu = Common.GetDBResultParameterized(@"
Select * from Forms F where F.IsActive=1 and F.IsMobile=1 and exists(select 1 from UserForms UF where UF.FormID=F.FormID and UF.UserType=@UserType) Order By MobileSrNo",
                        "@UserType", SqlDbType.Int, userType);
            }
            //If Normal User has any Role Assigned
            if (objLoggedUser.UserType == 1 && objLoggedUser.RoleID > 0)
            {

                DataTable dtRole = Common.GetDBResultParameterized(@";with name_tree as 
(
   Select * from Forms F where F.IsActive=1 and F.IsMobile=1 and 
exists(
select 1 from FormRoles FR where FR.FormID=F.FormID and FR.RoleID=@RoleID and FR.SocID=@SocID)
   union all
   select C.*
   from Forms c
   join name_tree p on C.FormID = P.ParentFormID  -- this is the recursion
  
) 
select distinct * from name_tree",
                  "@RoleID", SqlDbType.Int, objLoggedUser.RoleID,
                  "@SocID", SqlDbType.Int, objLoggedUser.SocID);

                //fill parents
                foreach (DataRow drParent in dtRole.Select("ParentFormID IS NULL", "MobileSrNo ASC"))
                {
                    List<MenuItem> childMenuList = GetChildMenuItems(dtRole, Common.ToInt(drParent["FormID"]));
                    if (childMenuList != null || Common.ToString(drParent["FormUrl"]).Length > 0)
                        menuList.Add(new MenuItem()
                        {
                            FormID = Common.ToInt(drParent["FormID"]),
                            FormName = Common.ToString(drParent["MobileTitle"]),
                            FormUrl = Common.ToString(drParent["MobileUrl"]),
                            IconCss = Common.ToString(drParent["IconCss"]),
                            Children = childMenuList,
                            HasParent = false
                        });
                }
            }


            //Remove Service Menu from Normal Society Admin
            if (objLoggedUser.UserType == 2 && objLoggedUser.SocID != 1)
            {
                dtMenu = dtMenu.AsEnumerable()
                        .Where(r => (r.Field<int>("FormID") != 35))
                        .CopyToDataTable();
            }
            if (dtMenu.Rows.Count > 0)
            {
                //fill parents
                foreach (DataRow drParent in dtMenu.Select("1=1", "MobileSrNo ASC"))
                {
                    List<MenuItem> childMenuList = GetChildMenuItems(dtMenu, Common.ToInt(drParent["FormID"]));
                    if (childMenuList != null || Common.ToString(drParent["FormUrl"]).Length > 0)
                        menuList.Add(new MenuItem()
                        {
                            FormID = Common.ToInt(drParent["FormID"]),
                            FormName = Common.ToString(drParent["MobileTitle"]),
                            FormUrl = Common.ToString(drParent["MobileUrl"]),
                            IconCss = Common.ToString(drParent["IconCss"]),
                            Children = childMenuList,
                            HasParent = false
                        });
                }
            }

            return menuList;
        }
        public static List<MenuItem> GetUserMenuItems(LoggedUser objLoggedUser, int userType, int ModuleID = 0)
        {
            List<MenuItem> menuList = new List<MenuItem>();
            DataTable dtMenu = new DataTable();

            //User is admin
            if (objLoggedUser.UserType == 2 || objLoggedUser.UserType == 3)
            {
                dtMenu = Common.GetDBResultParameterized(@"
Select * from Forms F where F.IsActive=1 and F.ModuleID=@ModuleID and exists(select 1 from UserForms UF where UF.FormID=F.FormID and UF.UserType=@UserType) Order By SrNo",
                        "@UserType", SqlDbType.Int, userType,
                        "@ModuleID", SqlDbType.Int, ModuleID);
            }
            //If Normal User has any Role Assigned
            if (objLoggedUser.UserType == 1 && objLoggedUser.RoleID > 0)
            {

                DataTable dtRole = Common.GetDBResultParameterized(@";with name_tree as 
(
   Select * from Forms F where F.IsActive=1 and ModuleID=@ModuleID and 
exists(
select 1 from FormRoles FR where FR.FormID=F.FormID and FR.RoleID=@RoleID and FR.SocID=@SocID)
   union all
   select C.*
   from Forms c
   join name_tree p on C.FormID = P.ParentFormID  -- this is the recursion
  
) 
select distinct * from name_tree",
                  "@RoleID", SqlDbType.Int, objLoggedUser.RoleID,
                  "@SocID", SqlDbType.Int, objLoggedUser.SocID,
                  "@ModuleID", SqlDbType.Int, ModuleID);

                //fill parents
                foreach (DataRow drParent in dtRole.Select("ParentFormID IS NULL", "SrNo ASC"))
                {
                    List<MenuItem> childMenuList = GetChildMenuItems(dtRole, Common.ToInt(drParent["FormID"]));
                    if (childMenuList != null || Common.ToString(drParent["FormUrl"]).Length > 0)
                        menuList.Add(new MenuItem()
                        {
                            FormID = Common.ToInt(drParent["FormID"]),
                            FormName = Common.ToString(drParent["FormName"]),
                            FormUrl = Common.ToString(drParent["FormUrl"]),
                            MobileUrl = Common.ToString(drParent["MobileUrl"]),
                            IconCss = Common.ToString(drParent["IconCss"]),
                            Children = childMenuList,
                            HasParent = false
                        });
                }
            }


            //Remove Service Menu from Normal Society Admin
            if (objLoggedUser.UserType == 2 && objLoggedUser.SocID != 1)
            {
                dtMenu = dtMenu.AsEnumerable()
                        .Where(r => (r.Field<int>("FormID") != 35))
                        .CopyToDataTable();
            }
            if (dtMenu.Rows.Count > 0 || menuList.Count > 0)
            {
                menuList.Insert(0, new MenuItem()
                {
                    FormID = 1000,
                    FormName = "Educlat Launchpad",
                    FormUrl = "#/adminHome",
                    MobileUrl = "",
                    IconCss = "fa fa-arrow-left",
                    Children = null,
                    HasParent = false,
                    IsModuleMenu = true
                });
            }
            if (dtMenu.Rows.Count > 0)
            {
                //fill parents
                foreach (DataRow drParent in dtMenu.Select("ParentFormID IS NULL", "SrNo ASC"))
                {
                    List<MenuItem> childMenuList = GetChildMenuItems(dtMenu, Common.ToInt(drParent["FormID"]));
                    if (childMenuList != null || Common.ToString(drParent["FormUrl"]).Length > 0)
                        menuList.Add(new MenuItem()
                        {
                            FormID = Common.ToInt(drParent["FormID"]),
                            FormName = Common.ToString(drParent["FormName"]),
                            FormUrl = Common.ToString(drParent["FormUrl"]),
                            MobileUrl = Common.ToString(drParent["MobileUrl"]),
                            IconCss = Common.ToString(drParent["IconCss"]),
                            Children = childMenuList,
                            HasParent = false
                        });
                }
            }

            return menuList;
        }
        private static List<MenuItem> GetChildMenuItems(DataTable dtMenu, int formID)
        {
            List<MenuItem> menuList = new List<MenuItem>();

            //fill childs
            foreach (DataRow drChild in dtMenu.Select("ParentFormID=" + formID))
            {
                List<MenuItem> childMenuList = GetChildMenuItems(dtMenu, Common.ToInt(drChild["FormID"]));
                if (childMenuList != null || Common.ToString(drChild["FormUrl"]).Length > 0)
                    menuList.Add(new MenuItem()
                    {
                        FormID = Common.ToInt(drChild["FormID"]),
                        FormName = Common.ToString(drChild["FormName"]),
                        FormUrl = Common.ToString(drChild["FormUrl"]),
                        IconCss = Common.ToString(drChild["IconCss"]),
                        Children = childMenuList,
                        HasParent = true
                    });
            }
            if (menuList.Count == 0)
                return null;
            return menuList;
        }
        public static string SafeSubstring(string input, int startIndex, int length)
        {
            // Todo: Check that startIndex + length does not cause an arithmetic overflow
            if (input.Length >= (startIndex + length))
            {
                return input.Substring(startIndex, length);
            }
            else
            {
                if (input.Length > startIndex)
                {
                    return input.Substring(startIndex);
                }
                else
                {
                    return string.Empty;
                }
            }
        }
        public static string Serialize(object o)
        {
            ObjectStateFormatter objOSF = new ObjectStateFormatter();
            return objOSF.Serialize(o);
        }
        public static object DeSerialize(string s)
        {
            ObjectStateFormatter objOSF = new ObjectStateFormatter();
            return objOSF.Deserialize(s);
        }
        #region Value Conversions with null value check
        /// <summary>
        /// Convert any value to its boolean equivalent
        /// </summary>
        /// <param name="theValue"></param>
        /// <returns>A boolean value</returns>
        public static bool ToBool(object theValue)
        {
            try
            {
                if (Convert.IsDBNull(theValue)) return false;
                if (theValue is string)
                {
                    switch (theValue.ToString().ToLower())
                    {
                        case "yes":
                        case "on":
                            return true;
                    }
                    if (IsNumeric(theValue))
                        return Convert.ToBoolean((Convert.ToDouble(theValue)));
                }
                return Convert.ToBoolean(theValue);
            }
            catch
            {
                return false;
            }
        }
        public static string ToString(object theValue)
        {
            if (Convert.IsDBNull(theValue))
                return "";
            else
                return Convert.ToString(theValue);
        }
        public static string ConvToDateToString(object theValue, string Format)
        {
            if (Convert.IsDBNull(theValue) || theValue == null)
                return "";
            else
                return Common.ToDate(theValue).ToString(Format);
        }
        public static double ToDouble(object theValue)
        {
            double theResult = 0;
            if (theValue == null || Convert.IsDBNull(theValue) || !double.TryParse(theValue.ToString(), out theResult))
                theResult = 0;
            return theResult;
        }
        public static double? ToDouble(object theValue, double? defaultValue)
        {
            double theResult = 0;
            if (theValue == null || Convert.IsDBNull(theValue) || !double.TryParse(theValue.ToString(), out theResult))
                return defaultValue;
            return theResult;
        }
        public static int ToInt(object theValue)
        {
            int theResult = 0;
            if (theValue == null || Convert.IsDBNull(theValue) || !int.TryParse(theValue.ToString(), out theResult))
                theResult = 0;
            return theResult;
        }
        public static int? ToInt(object theValue, int? defaultValue)
        {
            int theResult = 0;
            if (theValue == null || Convert.IsDBNull(theValue) || !int.TryParse(theValue.ToString(), out theResult))
                return defaultValue;
            return theResult;
        }
        public static float ToFloat(object theValue)
        {
            float theResult = 0;
            if (theValue == null || Convert.IsDBNull(theValue) || !float.TryParse(theValue.ToString(), out theResult))
                theResult = 0;
            return theResult;
        }
        public static float? ToFloat(object theValue, float? defaultValue)
        {
            float theResult = 0;
            if (theValue == null || Convert.IsDBNull(theValue) || !float.TryParse(theValue.ToString(), out theResult))
                return defaultValue;
            return theResult;
        }
        public static decimal ToDecimal(object theValue)
        {
            decimal theResult = 0;
            if (theValue == null || Convert.IsDBNull(theValue) || !decimal.TryParse(theValue.ToString(), out theResult))
                theResult = 0;
            return theResult;
        }
        public static decimal? ToDecimal(object theValue, decimal? defaultValue)
        {
            decimal theResult = 0;
            if (theValue == null || Convert.IsDBNull(theValue) || !decimal.TryParse(theValue.ToString(), out theResult))
                return defaultValue;
            return theResult;
        }
        public static DateTime ToDate(object theValue)
        {
            DateTime theResult;
            if (theValue == null || Convert.IsDBNull(theValue) || !DateTime.TryParse(theValue.ToString(), out theResult))
                theResult = DateTime.UtcNow;
            return theResult;
        }
        public static DateTime? ToDate(object theValue, DateTime? defaultval)
        {
            DateTime theResult;
            if (theValue == null || Convert.IsDBNull(theValue) || !DateTime.TryParse(theValue.ToString(), out theResult))
                return defaultval;
            return theResult;
        }
        #endregion
        public static string GetConString()
        {
            return System.Configuration.ConfigurationManager.ConnectionStrings["Main"].ConnectionString;
        }
        public static bool IsNumeric(object theValue)
        {
            try
            {
                double theNum;
                if (Convert.IsDBNull(theValue))
                    return false;
                return double.TryParse(theValue.ToString(), out theNum);
            }
            catch
            {
                return false;
            }
        }
        public static void ShowMessage(string mess)
        {
            Page page = HttpContext.Current.Handler as Page;
            if (page != null)
            {
                page.ClientScript.RegisterStartupScript(page.GetType(), "shm", "alert('" + mess.Replace("'", "\"") + "');", true);
            }
        }
        public static DataTable GetDBResult(string query)
        {
            SqlConnection con = new SqlConnection(Common.GetConString());
            SqlCommand cmd = new SqlCommand(query, con);
            DataTable dt = new DataTable();
            con.Open();
            using (con)
            {
                dt.Load(cmd.ExecuteReader());
            }
            return dt;
        }
        public static DataTable GetDBResultParameterized(string query, params object[] argument)
        {
            SqlConnection con = new SqlConnection(Common.GetConString());
            SqlCommand cmd = new SqlCommand(query, con);

            for (var i = 0; i < argument.Length; i = i + 3)
            {
                cmd.Parameters.Add(Common.ToString(argument[i]), (SqlDbType)argument[i + 1]).Value = argument[i + 2];
            }
            DataTable dt = new DataTable();
            con.Open();
            using (con)
            {
                dt.Load(cmd.ExecuteReader());
            }
            return dt;
        }
        public static int ExecuteNonQuery(string query, params object[] argument)
        {
            SqlConnection con = new SqlConnection(Common.GetConString());
            SqlCommand cmd = new SqlCommand(query, con);
            if (argument != null)
                for (var i = 0; i < argument.Length; i = i + 3)
                {
                    cmd.Parameters.Add(Common.ToString(argument[i]), (SqlDbType)argument[i + 1]).Value = argument[i + 2];
                }
            con.Open();
            using (con)
            {
                return cmd.ExecuteNonQuery();
            }
        }
        public static object GetDBScalar(string query, params object[] argument)
        {
            SqlConnection con = new SqlConnection(Common.GetConString());
            SqlCommand cmd = new SqlCommand(query, con);
            if (argument != null)
                for (var i = 0; i < argument.Length; i = i + 3)
                {
                    cmd.Parameters.Add(Common.ToString(argument[i]), (SqlDbType)argument[i + 1]).Value = argument[i + 2];
                }
            con.Open();
            using (con)
            {
                return cmd.ExecuteScalar();
            }
        }
        public static void SetDDLByValue(DropDownList ddl, string value)
        {
            ddl.ClearSelection();
            ListItem itm = ddl.Items.FindByValue(value);
            if (itm != null)
                itm.Selected = true;
        }
        public static void SetDDLByText(DropDownList ddl, string text)
        {
            ddl.ClearSelection();
            ListItem itm = ddl.Items.FindByText(text);
            if (itm != null)
                itm.Selected = true;
        }
        public static string MakeLink(string txt)
        {
            Regex regx = new Regex("(http|https)://([\\w+?\\.\\w+])+([a-zA-Z0-9\\~\\!\\@\\#\\$\\%\\^\\&amp;\\*\\(\\)_\\-\\=\\+\\\\\\/\\?\\.\\:\\;\\'\\,]*)?", RegexOptions.IgnoreCase);
            MatchCollection mactches = regx.Matches(txt);
            foreach (Match match in mactches)
            {
                txt = txt.Replace(match.Value, "<a target='_blank' href='" + match.Value + "'>" + match.Value + "</a>");
            }
            return txt;
        }

        public static void UpdateEmailSettings(MailSettings objMailSettings)
        {
            SqlConnection con = new SqlConnection(Common.GetConString());
            SqlCommand cmd = new SqlCommand(@"Update MailSettings set Host=@Host,EnableSSL=@EnableSSL,UseDefaultCredentials=@UseDefaultCredentials,
UserName=@UserName,Port=@Port,FromName=@FromName", con);
            cmd.Parameters.Add("@Host", SqlDbType.VarChar, 100).Value = objMailSettings.Host;
            cmd.Parameters.Add("@EnableSSL", SqlDbType.Bit).Value = objMailSettings.EnableSSL;
            cmd.Parameters.Add("@UseDefaultCredentials", SqlDbType.Bit).Value = objMailSettings.UseDefaultCredentials;
            cmd.Parameters.Add("@Port", SqlDbType.Int).Value = objMailSettings.Port;
            cmd.Parameters.Add("@UserName", SqlDbType.VarChar, 100).Value = objMailSettings.UserName;
            cmd.Parameters.Add("@FromName", SqlDbType.VarChar, 100).Value = objMailSettings.FromName;

            con.Open();
            using (con)
            {
                cmd.ExecuteNonQuery();
            }
        }
        public static MailSettings LoadEmailSettings()
        {
            SqlConnection SqlCon = new SqlConnection(GetConString());
            MailSettings objMailSettings = new MailSettings();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get MailSettings
                var resultMailSettings = dc.ExecuteQuery<MailSettings>("select top 1 * from  MailSettings").ToList();
                if (resultMailSettings.Count > 0)
                {
                    objMailSettings = resultMailSettings[0];
                }
                dc.Dispose();
                return objMailSettings;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public static void UpdateEmailSettingPassword(string password)
        {
            SqlConnection con = new SqlConnection(Common.GetConString());
            SqlCommand cmd = new SqlCommand(@"Update MailSettings set Password=@Password", con);
            cmd.Parameters.Add("@Password", SqlDbType.VarChar, 500).Value = Common.Serialize(password);

            con.Open();
            using (con)
            {
                cmd.ExecuteNonQuery();
            }
        }
        public static bool SendEmailSendGrid(string toEmailIDs, string msg, string subject)
        {
            return SendEmailSendGrid(toEmailIDs, msg, subject, null);
        }
        public static bool SendEmailSendGrid(string toEmailIDs, string msg, string subject, Dictionary<string, string> attachmentBytes)
        {
            var mail = new MailMessage
            {
                From = new MailAddress("no-reply@educlat.com"),
                Subject = subject,
                Body = msg,
                IsBodyHtml = true
            };
            var header = new Header();

            var recipients = new List<String>();
            toEmailIDs = toEmailIDs.Replace(";", ",");
            foreach (string email in toEmailIDs.Split(','))
            {
                recipients.Add(email);
                mail.To.Add(new MailAddress(email));
            }
            header.SetTo(recipients);


            SmtpClient client = new SmtpClient();
            client.Port = 587;
            client.Host = "smtp-relay.sendinblue.com";
            client.Timeout = 10000;
            client.DeliveryMethod = SmtpDeliveryMethod.Network;
            client.UseDefaultCredentials = false;
            client.Credentials = new System.Net.NetworkCredential("sanjayg312@gmail.com", "xQ1Xr4TA3I5V7zLZ");

            mail.Headers.Add("X-SMTPAPI", Newtonsoft.Json.JsonConvert.SerializeObject(header));

            if (attachmentBytes != null)
            {
                foreach (KeyValuePair<string, string> attachData in attachmentBytes)
                {
                    if (!String.IsNullOrEmpty(attachData.Key) && !String.IsNullOrEmpty(attachData.Value))
                    {
                        //generate attachment
                        byte[] data = GenerateAttachment(attachData.Value);
                        if (data != null)
                        {
                            var ms = new MemoryStream(data);
                            var attachment = new Attachment(ms, attachData.Key, MimeTypeHelper.GetMimeType(attachData.Key));
                            attachment.ContentDisposition.CreationDate = DateTime.UtcNow;
                            attachment.ContentDisposition.ModificationDate = DateTime.UtcNow;
                            attachment.ContentDisposition.ReadDate = DateTime.UtcNow;
                            mail.Attachments.Add(attachment);
                        }
                    }
                }
            }

            try
            {
                // client.Timeout = 5000;
                client.Timeout = 20000;
                client.SendCompleted += client_SendCompleted;
                client.SendMailAsync(mail);
            }
            catch (Exception Ex)
            {
                WriteErrorLog(Ex);
            }
            return true;
        }

        static void client_SendCompleted(object sender, AsyncCompletedEventArgs e)
        {

        }
        public static string SendEmail(string toEmailID, string msg, string subject)
        {
            return SendEmail(toEmailID, msg, subject, null);
        }
        public static string SendEmail(string toEmailID, string msg, string subject, string attachmentName, string attachmentUrl)
        {
            Dictionary<string, string> attachments = new Dictionary<string, string>();
            attachments.Add(attachmentName, attachmentUrl);
            return SendEmail(toEmailID, msg, subject, attachments);
        }
        public static string SendEmail(string toEmailID, string msg, string subject, Dictionary<string, string> attachmentBytes)
        {

            DataTable dt = Common.GetDBResult("Select * from MailSettings");
            if (dt.Rows.Count > 0)
            {
                DataRow dr = dt.Rows[0];

                string fromemail = Common.ToString(dr["FromEmail"]);
                string fromeusername = Common.ToString(dr["UserName"]);
                string fromName = Common.ToString(dr["FromName"]);
                string password = Common.DeSerialize(Common.ToString(dr["Password"])).ToString();
                string host = Common.ToString(dr["Host"]);
                int port = Common.ToInt(dr["Port"]);
                bool enableSSL = Common.ToBool(dr["EnableSSL"]);
                bool useDefaultCred = Common.ToBool(dr["UseDefaultCredentials"]);

                var message = new MailMessage();
                //from, to, reply to
                message.From = new MailAddress(fromemail, fromName);
                foreach (string to in toEmailID.Replace(";", ",").Split(','))
                {
                    message.To.Add(new MailAddress(to));
                }

                //content
                message.Subject = subject;
                message.Body = msg;
                message.IsBodyHtml = true;



                if (attachmentBytes != null)
                {
                    foreach (KeyValuePair<string, string> attachData in attachmentBytes)
                    {
                        if (!String.IsNullOrEmpty(attachData.Key) && !String.IsNullOrEmpty(attachData.Value))
                        {
                            //generate attachment
                            byte[] data = GenerateAttachment(attachData.Value);
                            if (data != null)
                            {
                                var ms = new MemoryStream(data);
                                var attachment = new Attachment(ms, attachData.Key, MimeTypeHelper.GetMimeType(attachData.Key));
                                attachment.ContentDisposition.CreationDate = DateTime.UtcNow;
                                attachment.ContentDisposition.ModificationDate = DateTime.UtcNow;
                                attachment.ContentDisposition.ReadDate = DateTime.UtcNow;
                                message.Attachments.Add(attachment);
                            }
                        }
                    }
                }

                //send email
                using (var smtpClient = new SmtpClient())
                {
                    smtpClient.UseDefaultCredentials = useDefaultCred;
                    smtpClient.Host = host;
                    smtpClient.Port = port;
                    smtpClient.Timeout = 2000;

                    smtpClient.EnableSsl = enableSSL;
                    if (useDefaultCred)
                        smtpClient.Credentials = CredentialCache.DefaultNetworkCredentials;
                    else
                        smtpClient.Credentials = new NetworkCredential(fromeusername, password);
                    try
                    {
                        smtpClient.Send(message);
                        return String.Empty;
                    }
                    catch (Exception Ex)
                    {
                        WriteErrorLog(Ex);
                        return Ex.Message;
                    }
                }
            }
            else
            {
                return "Email Settings is not defined";
            }
        }
        private static byte[] GenerateAttachment(string attachmentUrl)
        {
            try
            {
                if (attachmentUrl.ToLower().StartsWith("http") || attachmentUrl.ToLower().StartsWith("https"))
                {
                    //execute the report
                    var request = WebRequest.Create(attachmentUrl);
                    var response = (HttpWebResponse)request.GetResponse();
                    var dataStream = response.GetResponseStream();
                    byte[] data = ReadFully(dataStream);
                    dataStream.Close();
                    response.Close();
                    return data;
                }
                else
                {
                    return File.ReadAllBytes(attachmentUrl);
                }
            }
            catch { return null; }
        }
        public static byte[] ReadFully(Stream input)
        {
            byte[] buffer = new byte[16 * 1024];
            using (MemoryStream ms = new MemoryStream())
            {
                int read;
                while ((read = input.Read(buffer, 0, buffer.Length)) > 0)
                {
                    ms.Write(buffer, 0, read);
                }
                return ms.ToArray();
            }
        }
        public static void WriteErrorLog(Exception Ex)
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine(Ex.Message).Append(" time ").Append(DateTime.UtcNow.ToString()).AppendLine(Ex.StackTrace);
                File.AppendAllText(HostingEnvironment.MapPath("~/ErrorLog.txt"), sb.ToString());
            }
            finally
            {

            }
        }
        public static void WriteErrorLog(string text)
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine(text);
                File.AppendAllText(HostingEnvironment.MapPath("~/ErrorLog.txt"), sb.ToString());
            }
            finally
            {

            }
        }
        public static bool IsUniqueInTable(string tableName, string fieldName, string fieldValue, string PrimaryField, string PrimaryFieldValue, string whereCond)
        {
            StringBuilder query = new StringBuilder();
            query.Append("Select COUNT(*) from ").Append(tableName).Append(" where ").Append(fieldName)
                .Append("='").Append(fieldValue.Replace("'", "''")).Append("' and ").Append(PrimaryField).Append("<>'").Append(PrimaryFieldValue).Append("'");
            if (!String.IsNullOrEmpty(whereCond))
                query.Append(" and ").Append(whereCond);
            int count = Common.ToInt(GetDBScalar(query.ToString()));
            return count == 0;
        }
        public static void CreateSchedule(int SocID)
        {
            DataTable dt = Common.GetDBResult("Select * from Schedule where SocID=0");
            ScheduleBL objScheduleBL = new ScheduleBL(Common.GetConString());
            Schedule objSchedule = new Schedule();
            foreach (DataRow dr in dt.Rows)
            {
                objScheduleBL.Load(0, SocID);
                objSchedule = objScheduleBL.Data;
                objSchedule.BPT = Common.ToString(dr["BPT"]);
                objSchedule.HasChild = Convert.IsDBNull(dr["HasChild"]) == true ? (bool?)null : Common.ToBool(dr["HasChild"]);
                objSchedule.ID = 0;
                objSchedule.Nature = Common.ToString(dr["Nature"]);
                objSchedule.ScheduleID = Common.ToInt(dr["ScheduleID"]);
                objSchedule.ScheduleName = Common.ToString(dr["ScheduleName"]);
                objSchedule.SchType = Common.ToString(dr["SchType"]);
                objSchedule.SocID = SocID;
                objSchedule.MasterScheduleID = Common.ToInt(dr["MasterScheduleID"]);
                objScheduleBL.Update();
            }
        }
        public static void CreateAccounts(int SocID)
        {
            DataTable dt = Common.GetDBResult("Select * from Accounts where SocID=0");
            AccountsBL objAccountsBL = new AccountsBL(Common.GetConString());
            Accounts objAccounts = new Accounts();
            foreach (DataRow dr in dt.Rows)
            {
                objAccountsBL.Load(0, SocID);
                objAccounts = objAccountsBL.Data;
                objAccounts.AccountID = Common.ToInt(dr["AccountID"]);
                objAccounts.ID = 0;
                objAccounts.AccountName = Common.ToString(dr["AccountName"]);
                objAccounts.AccountType = Common.ToString(dr["AccountType"]);
                objAccounts.ChgID = Common.ToInt(dr["ChgID"]);
                objAccounts.SocID = SocID;
                objAccounts.ScheduleID = Common.ToInt(dr["ScheduleID"]);
                objAccountsBL.Update();
            }
        }
        public static void CreateVType(int SocID)
        {
            DataTable dt = Common.GetDBResult("Select * from VoucherType where SocID=0");
            VoucherTypeBL objVoucherTypeBL = new VoucherTypeBL(Common.GetConString());
            VoucherType objVoucherType = new VoucherType();
            foreach (DataRow dr in dt.Rows)
            {
                objVoucherTypeBL.Load(0, SocID);
                objVoucherType = objVoucherTypeBL.Data;
                objVoucherType.CrScheduleID = Common.ToInt(dr["CrScheduleID"]);
                objVoucherType.DrScheduleID = Common.ToInt(dr["DrScheduleID"]);
                objVoucherType.VTID = 0;
                objVoucherType.IsSysDefined = Common.ToBool(dr["IsSysDefined"]);
                objVoucherType.VoucherTypeID = Common.ToInt(dr["VoucherTypeID"]);
                objVoucherType.VoucherTypeName = Common.ToString(dr["VoucherTypeName"]);
                objVoucherType.SocID = SocID;
                objVoucherTypeBL.Update();
            }
        }
        public static void CreateRoles(int SocID)
        {
            DataTable dt = Common.GetDBResult("Select * from Roles where SocID=0");
            DataTable dt2 = Common.GetDBResult("Select * from FormRoles where SocID=0");
            RolesBL objRolesBL = new RolesBL(Common.GetConString());

            foreach (DataRow dr in dt.Rows)
            {
                SampleAngularOM.Roles objRols = new SampleAngularOM.Roles();
                objRolesBL.Load(0, SocID);
                objRols = objRolesBL.Data;
                objRols.SocID = SocID;
                objRols.RoleName = Common.ToString(dr["RoleName"]);
                objRols.SelectedFormID = new List<int>();
                foreach (DataRow dr2 in dt2.Select("RoleId=" + Common.ToString(dr["RoleId"])))
                {
                    objRols.SelectedFormID.Add(Common.ToInt(dr2["FormId"]));
                }
                objRolesBL.Update();
            }
        }
        public static void CreateFeeMaster(int SocID)
        {
            DataTable dt = Common.GetDBResult("Select * from Chg where SocID=0");
            ChgBL objChgBL = new ChgBL(Common.GetConString());
            Chg objChg = new Chg();
            foreach (DataRow dr in dt.Rows)
            {
                objChgBL.Load(0);
                objChg = objChgBL.Data;
                objChg.ChgName = Common.ToString(dr["ChgName"]);
                objChg.ChgSysName = Common.ToString(dr["ChgSysName"]);
                objChg.SocID = SocID;
                objChgBL.Update();
            }
        }
        public static double GetDelayCharge2(int BillID, DateTime AsOnDate)
        {
            double delayCharge = 0;
            double dueAmount = 0;
            double LF = 0;
            DataTable dtPastpayment = Common.GetDBResultParameterized(@"select TotalBillAmount,PaidAmount,
ISNULL(TotalBillAmount,0)-ISNULL(PaidAmount,0) as Outstanding,
PaidDate,
DATEADD(dd,Term,BillDate) as DueDate,DATEADD(dd,Term+GraceDays,BillDate) as GraceDate
,RoomID,LF 
 from Bills where BillID=@BillID", "@BillID", SqlDbType.Int, BillID);
            if (dtPastpayment.Rows.Count == 0)
                return 0;
            LF = Common.ToDouble(dtPastpayment.Rows[0]["LF"]);
            if (Common.ToDate(dtPastpayment.Rows[0]["PaidDate"], null) == null)
            {
                dueAmount = Common.ToDouble(dtPastpayment.Rows[0]["TotalBillAmount"]);
            }
            else if (Common.ToDate(dtPastpayment.Rows[0]["PaidDate"]) > Common.ToDate(dtPastpayment.Rows[0]["GraceDate"]))
            {
                dueAmount = Common.ToDouble(dtPastpayment.Rows[0]["TotalBillAmount"]);
            }
            else if (Common.ToDate(dtPastpayment.Rows[0]["PaidDate"]) <= Common.ToDate(dtPastpayment.Rows[0]["GraceDate"]))
            {
                dueAmount = Common.ToDouble(dtPastpayment.Rows[0]["Outstanding"]);
            }
            if (dueAmount <= 0)
            {
                return 0;
            }
            DataTable dt = Common.GetDBResult(@"select B.TotalBillAmount,B.BillDate,
PN.* from Bills B 
left join BSU R ON B.BSID=R.BSID
left join Penalty PN ON R.PNID=PN.PNID where B.BillID=" + BillID);
            if (dt.Rows.Count > 0)
            {
                DataRow dr = dt.Rows[0];
                double InvAmount = dueAmount;
                DateTime BillDate = Common.ToDate(dr["BillDate"]);

                string ApplyOn = Common.ToString(dr["ApplyOn"]);
                string IntMethod = Common.ToString(dr["IntMethod"]);
                double PNAmount = Common.ToDouble(dr["PNAmount"]);
                string FixedOrInt = Common.ToString(dr["FixedOrInt"]);
                int RecalAfter = Common.ToInt(dr["RecalAfter"]);
                if (RecalAfter == 0) RecalAfter = 30;

                double delayDays = (AsOnDate - BillDate).TotalDays;
                if (delayDays == 31 || delayDays == 29 || delayDays == 28)
                    delayDays = 30;
                if (delayDays < 0)
                    delayDays = 0;
                if (delayDays > 0)
                {
                    double delaysChunks = (delayDays / RecalAfter) + ((delayDays % RecalAfter) > 0 ? 1 : 0);
                    double tempDelayCharge = 0;
                    double tempInvAmount = 0;

                    if (FixedOrInt == "Fixed")
                    {
                        delayCharge = delaysChunks * PNAmount;
                    }
                    else
                    {
                        if (IntMethod == "Normal")
                        {
                            delayCharge = (PNAmount / 365) * (delaysChunks * RecalAfter) * (InvAmount / 100);
                        }
                        else
                        {
                            //Compound
                            tempInvAmount = InvAmount;
                            for (int i = 0; i < delaysChunks; i++)
                            {
                                tempDelayCharge = (PNAmount / 365) * RecalAfter * (tempInvAmount / 100);
                                tempInvAmount = tempInvAmount + tempDelayCharge;
                            }
                            delayCharge = tempInvAmount - InvAmount;
                        }
                    }
                }
            }

            return Math.Round(delayCharge, 0);
        }
        public static double GetDelayCharge(int BillID, DateTime AsOnDate)
        {
            double delayCharge = 0;
            double dueAmount = 0;
            double LF = 0;
            bool ApplyLF = false;
            int afterAfterDueDays = 0;
            DataTable dtPastpayment = Common.GetDBResultParameterized(@"select TotalBillAmount,PaidAmount,
ISNULL(TotalBillAmount,0)-ISNULL(PaidAmount,0) as Outstanding,
PaidDate,
DATEADD(dd,Term,BillDate) as DueDate,DATEADD(dd,Term+GraceDays,BillDate) as GraceDate
,RoomID,LF 
 from Bills where BillID=@BillID", "@BillID", SqlDbType.Int, BillID);
            if (dtPastpayment.Rows.Count == 0)
                return 0;
            LF = Common.ToDouble(dtPastpayment.Rows[0]["LF"]);
            if (Common.ToDate(dtPastpayment.Rows[0]["PaidDate"], null) == null)
            {
                ApplyLF = true;
            }
            else if (Common.ToDate(dtPastpayment.Rows[0]["PaidDate"]) > Common.ToDate(dtPastpayment.Rows[0]["GraceDate"]))
            {
                afterAfterDueDays = (Common.ToDate(dtPastpayment.Rows[0]["PaidDate"]) - Common.ToDate(dtPastpayment.Rows[0]["GraceDate"])).Days;
                ApplyLF = true;
            }
            else if (Common.ToDate(dtPastpayment.Rows[0]["PaidDate"]) <= Common.ToDate(dtPastpayment.Rows[0]["GraceDate"]))
            {
                //It means, Payment is done but we will keep further checking that 
                //whether it was full payment or partial payment.
                ApplyLF = false;
            }

            StringBuilder sb = new StringBuilder(@" select ISNULL(SUM(Amount),0)-ISNULL(SUM(Discount),0) as TotalPrincipal
 ,SUM(LF) as TotalLF,SUM(PaidAmount) as TotalPaid
 ,ISNULL(SUM(Amount),0)+ISNULL(SUM(LF),0)-ISNULL(SUM(PaidAmount),0)
 -ISNULL(SUM(Discount),0) as Outstanding
  from Bills where BSID>0 and RoomID=");
            sb.Append(Common.ToInt(dtPastpayment.Rows[0]["RoomID"]));

            //Get Last Paid Amount
            double lastPaid = Common.ToDouble(Common.GetDBScalar("Select PaidAmount from Bills where BillID=" + BillID));


            DataTable dtAmount = Common.GetDBResult(sb.ToString());
            dueAmount = Common.ToDouble(dtAmount.Rows[0]["Outstanding"]);

            //Ignore his last payment
            if (ApplyLF)
                dueAmount = dueAmount + lastPaid;

            if (dueAmount <= 0)
                return 0;

            DataTable dt = Common.GetDBResult(@"select B.TotalBillAmount,B.BillDate,
PN.* from Bills B 
left join BSU R ON B.BSID=R.BSID
left join Penalty PN ON R.PNID=PN.PNID where B.BillID=" + BillID);
            if (dt.Rows.Count > 0)
            {
                DataRow dr = dt.Rows[0];
                double InvAmount = dueAmount;
                DateTime BillDate = Common.ToDate(dr["BillDate"]);

                string ApplyOn = Common.ToString(dr["ApplyOn"]);
                string IntMethod = Common.ToString(dr["IntMethod"]);
                double PNAmount = Common.ToDouble(dr["PNAmount"]);
                string FixedOrInt = Common.ToString(dr["FixedOrInt"]);
                int RecalAfter = Common.ToInt(dr["RecalAfter"]);
                if (RecalAfter == 0) RecalAfter = 30;

                double delayDays = (AsOnDate - BillDate).TotalDays;
                if (delayDays == 31 || delayDays == 29 || delayDays == 28)
                    delayDays = 30;
                if (delayDays < 0)
                    delayDays = 0;
                if (delayDays > 0)
                {
                    //If Penalty type is fixed and previous bill is paid but paid after due date
                    //Then the customer will pay only delay days penalty
                    if (afterAfterDueDays > 0 && FixedOrInt == "Fixed")
                        delayDays = afterAfterDueDays;

                    double delaysChunks = (delayDays / RecalAfter) + ((delayDays % RecalAfter) > 0 ? 1 : 0);
                    double tempDelayCharge = 0;
                    double tempInvAmount = 0;

                    if (FixedOrInt == "Fixed")
                    {
                        delayCharge = delaysChunks * PNAmount;
                    }
                    else
                    {
                        if (IntMethod == "Normal")
                        {
                            if ((InvAmount - LF) > 0)
                                delayCharge = (PNAmount / 365) * (delaysChunks * RecalAfter) * ((InvAmount - LF) / 100);
                        }
                        else
                        {
                            delayCharge = (PNAmount / 365) * (delaysChunks * RecalAfter) * (InvAmount / 100);
                        }
                    }
                }
            }

            return Math.Round(delayCharge, 0);
        }
        /// <summary>
        /// Multiple mobiles numbers separated by comma
        /// </summary>
        /// <param name="mobile"></param>
        /// <returns></returns>
        public static string SendSMS(string mobile, string messageText, int socID)
        {
            bool sendNot = Common.ToBool(WebConfigurationManager.AppSettings["SendNotification"]);
            if (!sendNot)
                return "Success";
            //if (socID <= 0)
            //{
            //    return "Success";
            //}
            //Your user name
            string user = "ConnectV";
            //Your authentication key
            string key = "8fc49a8f56XX";
            //Sender ID,While using route4 sender id should be 6 characters long.
            string senderid = "SOCINN";
            //Your message to send, Add URL encoding here.
            string message = HttpUtility.UrlEncode(messageText);

            //Prepare you post parameters
            StringBuilder sbPostData = new StringBuilder();
            sbPostData.AppendFormat("user={0}", user);
            sbPostData.AppendFormat("&key={0}", key);
            sbPostData.AppendFormat("&mobile={0}", mobile);
            sbPostData.AppendFormat("&message={0}", message);
            sbPostData.AppendFormat("&senderid={0}", senderid);
            sbPostData.AppendFormat("&accusage={0}", "1");

            try
            {
                //Call Send SMS API
                string sendSMSUri = "http://mobicomm.dove-sms.com/mobicomm/submitsms.jsp?";
                //Create HTTPWebrequest
                HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create(sendSMSUri);
                //Prepare and Add URL Encoded data
                UTF8Encoding encoding = new UTF8Encoding();
                byte[] data = encoding.GetBytes(sbPostData.ToString());
                //Specify post method
                httpWReq.Method = "POST";
                httpWReq.ContentType = "application/x-www-form-urlencoded";
                httpWReq.ContentLength = data.Length;
                using (Stream stream = httpWReq.GetRequestStream())
                {
                    stream.Write(data, 0, data.Length);
                }
                //Get the response
                HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
                StreamReader reader = new StreamReader(response.GetResponseStream());
                string responseString = reader.ReadToEnd();

                //Close the response
                reader.Close();
                response.Close();
                return responseString.Contains("success") ? "Success" : responseString;
            }
            catch (SystemException ex)
            {
                return "Failed:" + ex.Message;
            }

        }
        public static string GetMemberTypeCondition(string memberType)
        {
            string whereCond = String.Empty;
            switch (memberType)
            {
                case "ALL":
                    whereCond = @"Exists (Select 1 from Enrollments E 
left join Students S ON E.StudentID=S.StudentID where E.AYID=@AYID and 
MobileNo<>'' and MobileNo IS NOT NULL and S.MobileNo=Users.MobileNo)";
                    break;
                case "ALLTEACHER":
                    whereCond = "CreatedBy=@CreatedBy and MemberType='Teacher'";
                    break;
                case "ALLSTAFF":
                    whereCond = "CreatedBy=@CreatedBy and MemberType='Staff'";
                    break;
                case "ALLCOM":
                    whereCond = "CreatedBy=@CreatedBy and exists (select 1 from CM where CM.UserID=Users.UserID)";
                    break;
                default:
                    whereCond = "CreatedBy=@CreatedBy and 1=1";
                    break;
            }
            return whereCond;
        }
        public static string GetUnitTypeCondition(List<string> unitTypes)
        {
            StringBuilder whereCond = new StringBuilder();
            foreach (string unitType in unitTypes)
            {
                if (unitType == "ALL")
                {
                    return "";
                }
                else if (unitType.Contains("ALLWING_"))
                {
                    whereCond.Append(" or WingID=").Append(unitType.Replace("ALLWING_", ""));
                }
                else if (unitType.Contains("ALLUNITTYPE_"))
                {
                    whereCond.Append(" or UnitType='").Append(unitType.Replace("ALLUNITTYPE_", "")).Append("'");
                }
                else
                {
                    whereCond.Append(" or RoomID=").Append(unitType);
                }
            }
            if (whereCond.Length > 0)
            {
                return " and (" + whereCond.ToString().Substring(3) + ")";
            }
            return String.Empty;
        }
        public static string NumberToWords(int number)
        {
            if (number == 0)
                return "Zero";

            if (number < 0)
                return "Minus " + NumberToWords(Math.Abs(number));

            string words = "";

            if ((number / 100000) > 0)
            {
                words += NumberToWords(number / 1000000) + " Lakh ";
                number %= 100000;
            }

            if ((number / 1000) > 0)
            {
                words += NumberToWords(number / 1000) + " Thousand ";
                number %= 1000;
            }

            if ((number / 100) > 0)
            {
                words += NumberToWords(number / 100) + " Hundred ";
                number %= 100;
            }

            if (number > 0)
            {
                if (words != "")
                    words += "and ";

                var unitsMap = new[] { "Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen" };
                var tensMap = new[] { "Zero", "Ten", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety" };

                if (number < 20)
                    words += unitsMap[number];
                else
                {
                    words += tensMap[number / 10];
                    if ((number % 10) > 0)
                        words += "-" + unitsMap[number % 10];
                }
            }

            return words;
        }
        public static void InsertInSMSCredit(int credit, int socID, string remarks, string mobiles, string message, int sentBy)
        {
            SMSCreditBL objSMSCreditBL = new SMSCreditBL(GetConString());
            SMSCredit objSMSCredit = new SMSCredit();
            objSMSCredit.Credit = credit;
            objSMSCredit.CreditDate = DateTime.Today;
            objSMSCredit.ID = 0;
            objSMSCredit.Remarks = remarks;
            objSMSCredit.SocID = socID;
            objSMSCredit.MobileNos = mobiles;
            objSMSCredit.Message = message;
            objSMSCredit.SentBy = sentBy;
            objSMSCreditBL.Data = objSMSCredit;
            objSMSCreditBL.Update();
        }
        public static int GetSMSCredit(int socID)
        {
            return ToInt(GetDBScalar("Select SUM(Credit) from SMSCredit where SocID=" + socID));
        }
        public static string GetDefaulterQuery(int showTop)
        {
            StringBuilder sb = new StringBuilder();
            if (showTop > 0)
            {
                sb.Append("Select top ").Append(showTop);
            }
            else
            {
                sb.Append("Select ");
            }
            sb.Append(@" D.*,W.WingName+' '+R.RoomNo as RoomNo,
Usr.* from 
(select RoomID,ISNULL(SUM(Amount),0)+ISNULL(SUM(LF),0)-ISNULL(SUM(PaidAmount),0)-ISNULL(SUM(Discount),0) AS Outstanding from Bills 
where SocID=@SocID
group by RoomID
having ISNULL(SUM(Amount),0)+ISNULL(SUM(LF),0)-ISNULL(SUM(PaidAmount),0)-ISNULL(SUM(Discount),0)>0
) as D 
outer apply
(
select top 1 U.FirstName+ISNULL(' '+U.LastName,'') as PersonName,U.UserID,ISNULL(U.ImageUrl,'') as ImageUrl
,U.MobileNo,U.EmailID
from UserRooms UR
inner join Users U ON UR.UserID=U.UserID and UR.SocID=@SocID
where UR.RoomID=D.RoomID
 order by U.MemberType
) as Usr
inner join Rooms R ON D.RoomID=R.RoomID
inner join Wings W ON W.WingID=R.WingID");
            if (showTop > 0)
            {
                sb.Append(" order by D.Outstanding desc");
            }
            return sb.ToString();
        }
        public static DataTable GetDefaulters(int socID, int showTop)
        {
            return Common.GetDBResultParameterized(GetDefaulterQuery(showTop), "@SocID", SqlDbType.Int, socID);
        }

        public static void SendPaymentNotification(decimal paidAmount, string paidDate, int billNo, string billDate,
          decimal dueAmount, string socName, int roomID)
        {
            DataTable dt = Common.GetDBResult(@"select W.SocID, W.WingName+' '+R.RoomNo as RoomNo,
U.MobileNo,U.SendNotification,U.EmailID,U.FirstName+ISNULL(' '+U.LastName,'') as UserName,U.UserID from Rooms R 
inner join Wings W ON R.WingID=W.WingID
inner join UserRooms UR ON UR.RoomID=R.RoomID
inner join Users U ON UR.UserID=U.UserID
where U.SendNotification=1 and R.RoomID=" + roomID);

            foreach (DataRow dr in dt.Rows)
            {
                string mobileNo = Common.ToString(dr["MobileNo"]);
                string emailID = Common.ToString(dr["EmailID"]);
                string roomNo = Common.ToString(dr["RoomNo"]);
                string userName = Common.ToString(dr["UserName"]);
                int socID = Common.ToInt(dr["SocID"]);
                int UserID = Common.ToInt(dr["UserID"]);

                string billSMSFormat = @"Dear Member, Payment of Rs. {0} received towards your Bill No. {1} on {2}. Your Available Due is Rs. {3}. {4} Via Soceiytinn.";
                string subjectFormat = "SocietyInn: Payment for Unit {0}.";
                string emailFormat = @"Dear {0}
<br/>
Please find your Unit E-receipt linked along with this mail.
<br/>
Unit No. : <b>{1}</b><br/>
Bill No. : <b>{2}</b><br/>
Bill Date : <b>{3}</b><br/>
Amount Paid : <b>{4}</b><br/>
Total Outstanding amount as on {5} :<b>Rs. {6}</b><br/>
Please find your E-receipt <a href='{7}' target='_blank'>{8}</a>
<br/>
Regards,<br/>
{9}";
                string SiteUrl = WebConfigurationManager.AppSettings["SiteUrl"];

                if (mobileNo.Length > 0)
                {
                    string smsText = String.Format(billSMSFormat, paidAmount, billNo, paidDate, dueAmount, socName);
                    Common.SendSMS(mobileNo, smsText, 0);
                    Common.InsertIntoAlerts(smsText, socID, UserID, "PAYMENT");
                }
                if (emailID.Length > 0)
                {
                    string emailSubjectText = String.Format(subjectFormat, roomNo);
                    string emailText = String.Format(emailFormat, userName, roomNo,
                         billNo, billDate, paidAmount
                         , DateTime.Now.ToString("dd-MMM-yyyy"), dueAmount,
                         SiteUrl + "/PrintReciept.aspx?BillGUID=" + Common.Serialize(billNo),
                         "Reciept_" + billNo + ".pdf", socName);

                    Common.SendEmailSendGrid(emailID, emailText, emailSubjectText);
                }
            }
        }
        //        public static void UpdatePostPayment(int SocID, string SocName, Payments objPayments)
        //        {
        //            foreach (var obj in objPayments.PaymentDetailsList)
        //            {
        //                Common.ExecuteNonQuery(@"Update Bills set PaidDate=@PaymentDate,PaidAmount=@PaidAmount where BillID=@BillID",
        //               "@BillID", SqlDbType.Int, Common.ToInt(obj.BillID),
        //               "@PaidAmount", SqlDbType.Decimal, Common.ToDecimal(obj.Amount),
        //               "@PaymentDate", SqlDbType.DateTime, objPayments.PaymentDate);

        //                DateTime BillDate = Common.ToDate(Common.GetDBScalar("Select BillDate from Bills where BillID=" + obj.BillID));

        //                decimal totalDue = Common.ToDecimal(Common.GetDBScalar(@"Select ISNULL(SUM(Amount),0)+ISNULL(SUM(LF),0)-ISNULL(SUM(PaidAmount),0)
        //from Bills where RoomID=" + objPayments.EnrollID));
        //                Common.SendPaymentNotification(Common.ToDecimal(objPayments.Amount),
        //                    Common.ToDate(objPayments.PaymentDate).ToString("dd-MMM-yyyy"),
        //                    Common.ToInt(obj.BillID),
        //                    BillDate.ToString("dd-MMM-yyyy"),
        //                    totalDue, SocName, Common.ToInt(objPayments.EnrollID));
        //            }

        //            GECommon.GEEntryPayment(objPayments, SocID);


        //        }

        public static Hashtable GetPagedData(string Query, string ValueField, string OrderBy, string OrderDir
            , int PageIndex, int PageSize, params object[] argument)
        {
            string afterFrom = Query.ToLower().Contains(" from ") == true ? Query.Substring(Query.IndexOf(" from ", StringComparison.OrdinalIgnoreCase) + 6) : "";
            string count = Common.ToString(GetDBScalar("Select COUNT(" + ValueField + ") from " + afterFrom, argument));
            int TotalRecords = Common.ToInt(count);
            int TotalPages = count != String.Empty ? TotalRecords % PageSize == 0 ? TotalRecords / PageSize : TotalRecords / PageSize + 1 : 0;
            StringBuilder query = new StringBuilder();
            string orderBy = OrderBy.Contains(".") ? OrderBy.Substring(OrderBy.IndexOf(".") + 1) : OrderBy;
            query.Append(@"select * from(select TOP 100 PERCENT ROW_NUMBER() over(Order By innerT.").Append(orderBy).Append(" ").Append(OrderDir);
            query.Append(") as RSRNO,innerT.* from(").Append(Query).Append(") as InnerT ) as T  where T.RSRNO between ");
            query.Append((((PageIndex - 1) * PageSize) + 1)).Append(" and ").Append(PageIndex * PageSize);

            DataTable dt = GetDBResultParameterized(query.ToString(), argument);
            Hashtable ht = new Hashtable();
            ht["data"] = dt;
            ht["TotalPages"] = TotalPages;
            return ht;
        }


        public static bool InsertIntoAlerts(string Msg, int SocID, int UserID, string Type)
        {
            try
            {
                SqlConnection con = new SqlConnection(GetConString());
                SqlCommand cmd = new SqlCommand("Insert_Into_Alerts", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@AlertDate", SqlDbType.DateTime, 8).Value = DateTime.Now;
                cmd.Parameters.Add("@AlertID", SqlDbType.Int).Value = 0;
                cmd.Parameters["@AlertID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@IsRead", SqlDbType.Bit).Value = false;
                cmd.Parameters.Add("@Msg", SqlDbType.VarChar, 500).Value = Msg;
                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = SocID;
                cmd.Parameters.Add("@UserID", SqlDbType.Int).Value = UserID;
                cmd.Parameters.Add("@Type", SqlDbType.VarChar, 10).Value = Type;

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static void SendBillNotification(int socID, string socName)
        {
            DataTable dtNewBills = Common.GetDBResult(@"Select B.Amount, B.TotalBillAmount,DATEADD(dd,B.Term, B.BillDate) as DueDate,B.BillDate,
W.WingName+' '+R.RoomNo as RoomNo,U.MobileNo,U.SendNotification,
U.EmailID,U.FirstName+ISNULL(' '+U.LastName,'') as UserName,B.BillID,U.UserID
from Bills B 
inner join Rooms R ON B.RoomID=R.RoomID
inner join Wings W ON R.WingID=W.WingID
inner join UserRooms UR ON UR.RoomID=B.RoomID
inner join Users U ON UR.UserID=U.UserID
where B.IsNewBill=1 and (SMSSent=0 OR SMSSent IS NULL)
and U.SendNotification=1 and B.SocID=" + socID);
            string billSMSFormat = @"Unit {0} bill generated for {1} of Rs. {2}. Due Rs. {3} on {4}. Pay within due date to avoid late fee. Ignore if already paid. {5}";
            string subjectFormat = "SocietyInn: Your E-Bill for Unit {0} for the Month of {1}";
            string emailFormat = @"Dear {0}
<br/>
Please find your Unit E-bill linked along with this mail.
<br/>
Unit No.:<b>{1}</b><br/>
Bill No.:<b>{2}</b><br/>
Bill Date:<b>{3}</b><br/>
Amount:<b>{4}</b><br/>
Due Date:<b>{5}</b><br/>
Please find the link of your bill <a href='{7}' target='_blank'>{8}</a>
<br/>
Regards,<br/>
{6}";
            string SiteUrl = WebConfigurationManager.AppSettings["SiteUrl"];

            foreach (DataRow dr in dtNewBills.Rows)
            {
                string mobileNo = Common.ToString(dr["MobileNo"]);
                string emailID = Common.ToString(dr["EmailID"]);
                string billNo = Common.ToString(dr["BillID"]);
                int UserID = Common.ToInt(dr["UserID"]);
                bool smsSent = false;
                if (mobileNo.Length > 0)
                {

                    string smsText = String.Format(billSMSFormat, Common.ToString(dr["RoomNo"]),
                        Common.ToDate(dr["BillDate"]).ToString("MMM-yy"),
                        Common.ToDecimal(dr["Amount"]),
                        Common.ToDecimal(dr["TotalBillAmount"]),
                        Common.ToDate(dr["DueDate"]).ToString("dd-MMM-yyyy"), socName);
                    Common.SendSMS(mobileNo, smsText, 0);
                    Common.InsertIntoAlerts(smsText, socID, UserID, "BILL");
                    smsSent = true;
                }
                if (emailID.Length > 0)
                {
                    string emailSubjectText = String.Format(subjectFormat, Common.ToString(dr["RoomNo"]), Common.ToDate(dr["BillDate"]).ToString("MMM-yyyy"));
                    string emailText = String.Format(emailFormat, Common.ToString(dr["UserName"]), Common.ToString(dr["RoomNo"]),
                         billNo, Common.ToDate(dr["BillDate"]).ToString("dd-MMM-yyyy"), Common.ToDecimal(dr["TotalBillAmount"])
                         , Common.ToDate(dr["DueDate"]).ToString("dd-MMM-yyyy"), socName,
                         SiteUrl + "/PrintBill.aspx?BillGUID=" + Common.Serialize(billNo),
                         "Bill_" + billNo + ".pdf");

                    Common.SendEmailSendGrid(emailID, emailText, emailSubjectText);
                    smsSent = true;
                }
                Common.ExecuteNonQuery("Update Bills set SMSSent=@SMSSent where BillID=@BillID",
                    "@SMSSent", SqlDbType.Bit, smsSent,
                    "@BillID", SqlDbType.Int, Common.ToInt(billNo));
            }
        }
        public static string GetBillRegisterQuery()
        {
            return @"select W.WingName+' '+R.RoomNo as UnitNo,
R.Users as MemberName,B.BillID,B.BillTitle,B.BillDate,B.Amount,
ISNULL(B.LF,0) as Interest,ISNULL(B.Outstanding,0) as PreviousDue,B.TotalBillAmount
,B.PaidAmount,B.PaidDate,P.PaymentMode,P.PaidRefNo  from VW_Rooms R
inner join Bills B ON R.RoomID = B.RoomID
inner join Rooms RM ON R.RoomID=RM.RoomID
inner join Wings W ON W.WingID=RM.WingID
left join BillPayments BP ON B.BillID =BP.BillID
left join Payments P ON BP.PaymentID =P.PaymentID
where B.SocID=@SocID and MONTH(B.BillDate)=@Month and YEAR(B.BillDate)=@Year and
(R.Users like '%'+@Name+'%' OR R.RoomNo like '%'+@Name+'%')";
        }
        public static string ErrorToString(ValidationResult results)
        {
            StringBuilder sb = new StringBuilder();

            foreach (var r in results.Errors)
            {
                sb.Append(",").Append(r.ErrorMessage);
            }
            if (sb.Length > 0)
                sb = sb.Remove(0, 1);
            return sb.ToString();
        }
        public static void SendChatPush(int userID, string msg)
        {
            DataTable dt = Common.GetDBResult("Select DeviceRegID from Devices where UserID=" + userID);
            foreach (DataRow dr in dt.Rows)
            {
                //PushNotification.AndroidPush(Common.ToString(dr["DeviceRegID"]), msg, "SocietyInn", "chat");
            }
        }
        public static string GetExpListQuery()
        {
            return @"SELECT E.ExpID,E.RefDate,
E.RefNo,E.Amount,E.Remark,
F.AccountName as FromGL,T.AccountName as ToGL,
V.AccountName as VendorGL,
S.ScheduleName as GroupName FROM Exp E 
left outer join Accounts F ON E.FromGLID = F.AccountID and E.CompanyID=F.SocID
left outer join Accounts T ON E.ToGLID = T.AccountID and E.CompanyID=T.SocID
left outer join Accounts V ON E.VendorGLID = V.AccountID and E.CompanyID=V.SocID
left outer join Schedule S ON E.FromGroupID =S.ScheduleID and E.CompanyID=S.SocID where
(@FGL=0 OR E.FromGLID=@FGL) and E.CompanyID=@SocID and MONTH(E.RefDate)=@Month and YEAR(E.RefDate)=@Year
and (E.RefNo like '%'+@Name+'%' OR E.Remark like '%'+@Name+'%' OR V.AccountName like '%'+@Name+'%')";
        }
        public static DataTable GrandTotalReady(DataTable dt, string fieldNames)
        {
            if (dt != null && dt.Rows.Count > 0)
            {
                DataRow newRow = dt.NewRow();
                newRow[0] = "Total";
                Dictionary<string, decimal> totalRowCalculated = new Dictionary<string, decimal>();
                foreach (string col in fieldNames.Split(','))
                {
                    //totalRowCalculated[col] = Convert.ToDecimal(dt.Compute("SUM(" + col + ")", string.Empty));
                    newRow[col] = dt.Compute("SUM([" + col + "])", string.Empty);
                }
                dt.Rows.Add(newRow);
            }
            dt.AcceptChanges();
            return dt;
        }
        public static DataTable MergeReady(DataTable dt, string fieldName)
        {
            dt.Columns.Add("Rows", typeof(int));
            dt.Columns.Add("MatchPreviousRow", typeof(bool));

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                DataRow dr = dt.Rows[i];
                var field = dr[fieldName];
                int rows = 1;
                for (int j = i + 1; j < dt.Rows.Count; j++)
                {
                    if (Common.ToString(dt.Rows[j][fieldName]) == Common.ToString(field) && !Common.ToBool(dt.Rows[j]["MatchPreviousRow"]))
                    {
                        rows++;
                        dt.Rows[j]["MatchPreviousRow"] = true;
                    }
                    else
                    {
                        dt.Rows[j]["MatchPreviousRow"] = false;
                        break;
                    }
                }
                dt.Rows[i]["Rows"] = rows;
            }
            dt.AcceptChanges();
            return dt;
        }
        public static DataTable GetFeesDue(int enrollID)
        {
            int wpID = Common.ToInt(Common.GetDBScalar("Select AYID from Enrollments where EnrollID=" + enrollID));

            DataTable dt = Common.GetDBResultParameterized(String.Format(GetFeesQuery(), "and ISNULL(SFD.FeeAmount,0)+ISNULL(CFM.Amount,0)-ISNULL(SFD.Amount,0)-ISNULL(PAID.PaidAmount,0)>0"),
            "@AYID", SqlDbType.Int, wpID,
            "@EnrollID", SqlDbType.Int, enrollID);
            return dt;
        }
        public static DataTable GetFeesDueThisMonth(int enrollID)
        {
            int wpID = Common.ToInt(Common.GetDBScalar("Select AYID from Enrollments where EnrollID=" + enrollID));

            DataTable dt = Common.GetDBResultParameterized(String.Format(GetFeesQuery(), " and Month(CFM.DueDate)=Month(getDate())"),
            "@AYID", SqlDbType.Int, wpID,
            "@EnrollID", SqlDbType.Int, enrollID);
            return dt;
        }
        public static DataTable GetStatement(int enrollID)
        {
            int wpID = Common.ToInt(Common.GetDBScalar("Select AYID from Enrollments where EnrollID=" + enrollID));

            DataTable dt = Common.GetDBResultParameterized(String.Format(GetFeesQuery(), " and ISNULL(CFM.Amount,0)>0"),
            "@AYID", SqlDbType.Int, wpID,
            "@EnrollID", SqlDbType.Int, enrollID);
            return dt;
        }
        public static DataTable GetStatementForPayment(int enrollID)
        {
            int wpID = Common.ToInt(Common.GetDBScalar("Select AYID from Enrollments where EnrollID=" + enrollID));

            DataTable dt = Common.GetDBResultParameterized(String.Format(GetFeesQuery(), " and ISNULL(SFD.FeeAmount,0)+ISNULL(CFM.Amount,0)-ISNULL(SFD.Amount,0)-ISNULL(PAID.PaidAmount,0)>0"),
            "@AYID", SqlDbType.Int, wpID,
            "@EnrollID", SqlDbType.Int, enrollID);
            return dt;
        }
        private static string GetFeesQuery()
        {
            return @"select CFM.ClassFeeID,Chg.ChgName,CFM.DueDate,ISNULL(SFD.FeeAmount,0)+ISNULL(CFM.Amount,0) as Amount
,ISNULL(SFD.Amount,0) as Concession
,SFD.ID,PAID.PaidAmount as PreviousPaidAmount
,ISNULL(SFD.FeeAmount,0)+ISNULL(CFM.Amount,0)-ISNULL(SFD.Amount,0)-ISNULL(PAID.PaidAmount,0) as PayableAmount
,cast(0 as decimal(12,2)) as PaidAmount
,cast(0 as bit) as Selected
 from dbo.ClassFeeMaster CFM
left outer join StudentFeeDiscount SFD ON CFM.ClassFeeID=SFD.ClassFeeID AND SFD.EnrollID=@EnrollID
outer apply
(
	select SUM(PD.Amount) as PaidAmount from PaymentDetails PD 
	inner join Payments P ON P.PaymentID=PD.PaymentID
	where PD.ClassFeeID=CFM.ClassFeeID and P.EnrollID=@EnrollID
) as PAID
left join Chg ON CFM.FeeID=Chg.ChgID
where CFM.AYID=@AYID and exists (Select 1 from Enrollments E 
inner join SectionMaster SM ON E.SectionID=SM.SectionID where SM.ClassID=CFM.ClassID
and E.EnrollID=@EnrollID) {0}
order by CFM.SrNo";
        }
        public static int HasDependentRecord(int ID, string table)
        {

            StringBuilder sb = new StringBuilder();
            string deleteCondition = Common.ToString(Common.GetDBScalar("Select Dependents from DependentTables where TableName=@TableName",
                "@TableName", SqlDbType.VarChar, table));
            if (deleteCondition.Length <= 0) return 0;

            foreach (string condition in deleteCondition.Split('`'))
            {
                if (sb.Length > 0)
                    sb.AppendLine("UNION ALL");
                string[] tableColumn = condition.Split(':');
                sb.Append("select COUNT(*) as TOTAL from ").Append(tableColumn[0]).Append(" where ").Append(tableColumn[1])
                    .Append(" = ").AppendLine(ID.ToString());
            }

            if (sb.Length > 0)
            {
                sb.Insert(0, "SELECT SUM(TOTAL) from (");
                sb.AppendLine(") as T");
            }
            else
            {
                return 0;
            }
            int count = Common.ToInt(Common.GetDBScalar(sb.ToString()));
            return count;
        }

    }
}
