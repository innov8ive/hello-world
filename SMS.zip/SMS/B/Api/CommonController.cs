﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.Http.Cors;
using System.Text;

namespace SampleAngular.Api
{
    public class CommonController : ApiController
    {
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/Common/LoginMember/Login")]
        [HttpPost]
        public LoginUser LoginMemberLogin([FromBody]dynamic value)
        {
            JObject objJObject = value;
            LoginUser objLoginUser = objJObject.ToObject<LoginUser>();
            LoginUser objLoginUser2 = Common.IsValidUser(objLoginUser.UserName, objLoginUser.Password, 1);
            if (objLoginUser2 != null && value.DeviceID != null)
            {
                Common.ExecuteNonQuery("Update Devices set  UserID=@UserID where  DeviceID=@DeviceID",
                    "@UserID", SqlDbType.Int, objLoginUser2.UserID,
                    "@DeviceID", SqlDbType.VarChar, value.DeviceID);
            }
            return objLoginUser2;
        }

        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/Common/LoginAdmin/Login")]
        [HttpPost]
        public LoginUser LoginAdminLogin([FromBody]dynamic value)
        {
            JObject objJObject = value;
            LoginUser objLoginUser = objJObject.ToObject<LoginUser>();
            LoginUser objLoginUser2 = Common.IsValidUser(objLoginUser.UserName, objLoginUser.Password, objLoginUser.UserType);
            if (objLoginUser2 != null && value.DeviceID != null)
            {
                Common.ExecuteNonQuery("Update Devices set  UserID=@UserID where  DeviceID=@DeviceID",
                    "@UserID", SqlDbType.Int, objLoginUser2.UserID,
                    "@DeviceID", SqlDbType.VarChar, value.DeviceID);
            }
            return objLoginUser2;
        }

        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/Common/RegisterDevice")]
        [HttpPost]
        public void RegisterDevice([FromBody]dynamic value)
        {
            Common.ExecuteNonQuery("Exec Insert_Update_Devices @DeviceID,@DeviceRegID",
                   "@DeviceRegID", SqlDbType.VarChar, Common.ToString(value.regID),
                   "@DeviceID", SqlDbType.VarChar, Common.ToString(value.uniqueID));
        }

        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/Common/GeneratePaymentLink")]
        [HttpPost]
        public string GeneratePaymentLink([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            int enrollId = Common.ToInt(value.EnrollID);
            int socID = Common.ToInt(Common.GetDBScalar(@"select SC.SocID from Enrollments E
INNER JOIN SectionMaster SC ON E.SectionID=SC.SectionID where E.EnrollID=@EnrollID", "@EnrollID", SqlDbType.Int, enrollId));
            SetuHelper setuHelper = new SetuHelper(socID);
            setuHelper.Token = objLoggedUser.TokenString;
            var result = setuHelper.GenerateDeepLink(Common.ToInt(value.Amount), objLoggedUser.SocName, Common.ToString(value.ClassFeeIds));
            objLoggedUser.TokenString = setuHelper.Token;
            HttpContext.Current.Session["LoggedUser"] = objLoggedUser;
            return result;
        }

        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/Common/CheckLinkStatus")]
        [HttpPost]
        public string CheckLinkStatus([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            int enrollId = Common.ToInt(value.EnrollID);
            int socID = Common.ToInt(Common.GetDBScalar(@"select SC.SocID from Enrollments E
INNER JOIN SectionMaster SC ON E.SectionID=SC.SectionID where E.EnrollID=@EnrollID", "@EnrollID", SqlDbType.Int, enrollId));
            SetuHelper setuHelper = new SetuHelper(socID);
            setuHelper.Token = objLoggedUser.TokenString;
            var result = setuHelper.CheckLinkStatus(Common.ToString(value.RefNo));
            objLoggedUser.TokenString = setuHelper.Token;
            HttpContext.Current.Session["LoggedUser"] = objLoggedUser;
            return result;
        }

        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/Common/GetToken")]
        [HttpGet]
        public string GetToken()
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            return objLoggedUser.TokenString;
        }

        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/Common/ForgotPassword")]
        [HttpPost]
        public string ForgotPassword([FromBody]dynamic value)
        {
            string userName = Common.ToString(value.UserName);
            int count = Common.ToInt(Common.GetDBScalar("Select COUNT(*) from Users where (EmailID=@Username OR MobileNo=@Username)",
                "@Username", SqlDbType.VarChar, userName));
            if (count <= 0)
                return "Entered EmailID/Mobile No. is Invalid!";
            string Email = Common.ToString(Common.GetDBScalar("Select EmailID from Users where (EmailID=@Username OR MobileNo=@Username)",
                "@Username", SqlDbType.VarChar, userName));
            string Mobile = Common.ToString(Common.GetDBScalar("Select MobileNo from Users where (EmailID=@Username OR MobileNo=@Username)",
                "@Username", SqlDbType.VarChar, userName));
            string newPassword = Guid.NewGuid().ToString().Substring(0, 6);
            if (Email.Length > 0 && userName.Contains("@"))
            {
                bool emailSent = Common.SendEmailSendGrid(Email, "Your new password is " + newPassword, "Educlat: Your New Password has been Generated!");
                if (emailSent == true)
                {
                    Common.ExecuteNonQuery("Update Users set Password = @Password where EmailID=@UserName",
                        "@UserName", SqlDbType.VarChar, userName,
                        "@Password", SqlDbType.VarChar, Common.MD5Encrypt(newPassword));
                    return "Success";
                }
                else
                {
                    return "Email not Sent!";
                }
            }
            else if (Mobile.Length > 0)
            {
                string sent = Common.SendSMS(Mobile, "Educlat: Your New Password has been Generated! Your new password is " + newPassword, 0);
                if (sent == "Success")
                {
                    Common.ExecuteNonQuery("Update Users set Password = @Password where MobileNo=@UserName",
                        "@UserName", SqlDbType.VarChar, userName,
                        "@Password", SqlDbType.VarChar, Common.MD5Encrypt(newPassword));
                    return "Success";
                }
                return sent;
            }
            return "The User is not registered!";
        }
        [Route("api/Common/LoadUserFromSession")]
        [HttpPost]
        public LoginUser LoadUserFromSession([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = HttpContext.Current.Session["LoggedUser"] as LoggedUser;
            if (objLoggedUser == null) return null;
            return Common.LoadUser(objLoggedUser.UserID);
        }
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/Common/Login")]
        [HttpPost]
        public LoginUser Login([FromBody]dynamic value)
        {
            JObject objJObject = value;
            LoginUser objLoginUser = objJObject.ToObject<LoginUser>();
            if (objLoginUser == null) return null;
            return Common.IsValidUser(objLoginUser.UserName, objLoginUser.Password, 0);
        }


        [Route("api/Common/LoginMember")]
        [HttpPost]
        public LoginUser LoginMember([FromBody]dynamic value)
        {
            JObject objJObject = value;
            LoginUser objLoginUser = objJObject.ToObject<LoginUser>();
            if (objLoginUser == null) return null;
            LoginUser objLoginUser2 = Common.IsValidUser(objLoginUser.UserName, objLoginUser.Password, Constants.UserType.Normal);
            return objLoginUser2;
        }

        [Route("api/Common/Logout")]
        [HttpPost]
        public string Logout([FromBody]dynamic value)
        {
            HttpContext.Current.Session["LoggedUser"] = null;
            HttpContext.Current.Session.Abandon();
            HttpContext.Current.Session.Clear();
            return String.Empty;
        }

        [Route("api/Common/ChangePassword")]
        [HttpPost]
        public string ChangePassword([FromBody]dynamic value)
        {
            JObject objJObject = value;
            ChangePassword objChangePassword = objJObject.ToObject<ChangePassword>();
            if (objChangePassword == null) return null;
            return Common.ChangePassword(objChangePassword);
        }

        [Route("api/Common/ChangeWP")]
        [HttpPost]
        public LoginUser ChangeWP([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            DataTable dtWP = Common.GetDBResultParameterized("Select * from AY where SocID=@SocID and AYID=@WPID",
           "@SocID", SqlDbType.Int, objLoggedUser.SocID,
           "@WPID", SqlDbType.Int, Common.ToInt(value));
            LoginUser objLoginUser = new LoginUser();
            if (dtWP.Rows.Count > 0)
            {
                DataRow drWP = dtWP.Rows[0];
                objLoginUser.WPID = Common.ToInt(drWP["AYID"]);
                objLoginUser.StartDate = Common.ToDate(drWP["StartDate"]);
                objLoginUser.EndDate = Common.ToDate(drWP["EndDate"]);
                objLoginUser.WPName = objLoginUser.StartDate.ToString("dd-MMM-yyyy") + " To " + objLoginUser.EndDate.ToString("dd-MMM-yyyy");

                objLoggedUser.WPID = objLoginUser.WPID;
                objLoggedUser.WPName = objLoginUser.WPName;
                objLoggedUser.StartDate = objLoginUser.StartDate;
                objLoggedUser.EndDate = objLoginUser.EndDate;
                HttpContext.Current.Session["LoggedUser"] = objLoggedUser;
            }
            return objLoginUser;
        }

        [Route("api/Common/ChangeSoc")]
        [HttpPost]
        public LoginUser ChangeSoc([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            LoginUser objLoginUser = new LoginUser();

            DataTable dtSoc = Common.GetDBResultParameterized("Select * from Soc where SocID=@SocID",
                      "@SocID", SqlDbType.Int, Common.ToInt(value));
            if (dtSoc.Rows.Count > 0)
            {
                DataRow drSoc = dtSoc.Rows[0];

                DataTable dtUser = Common.GetDBResultParameterized(@"select * from 
Users U
where 
exists (select 1 from UserRooms S where U.UserID=S.UserID and S.SocID=@SocID)
and 
U.UserID=@UserID",
                    "@SocID", SqlDbType.Int, Common.ToInt(drSoc["SocID"]),
                    "@UserID", SqlDbType.Int, objLoggedUser.UserID);
                if (dtUser.Rows.Count > 0)
                {
                    objLoginUser = Common.SetUserInSession(dtUser, Common.ToInt(drSoc["SocID"]), false);
                    objLoggedUser = HttpContext.Current.Session["LoggedUser"] as LoggedUser;

                    objLoginUser.SocName = Common.ToString(drSoc["SocName"]);
                    objLoggedUser.SocID = Common.ToInt(drSoc["SocID"]);
                    objLoggedUser.SocName = objLoginUser.SocName;
                    HttpContext.Current.Session["LoggedUser"] = objLoggedUser;
                }
            }
            return objLoginUser;
        }
        [Route("api/Common/SwitchToRMView")]
        [HttpPost]
        public LoginUser SwitchToRMView([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            LoginUser objLoginUser = new LoginUser();

            DataTable dtUser = Common.GetDBResultParameterized(@"select * from 
Users U
where 
exists (select 1 from Soc S where (U.CreatedBy=S.UserID OR U.UserID=S.UserID)and S.SocID=@SocID)
and 
U.MobileNo=@MobileNo",
                "@SocID", SqlDbType.Int, objLoggedUser.SocID,
                "@MobileNo", SqlDbType.VarChar, objLoggedUser.MobileNo);
            if (dtUser.Rows.Count > 0)
            {
                objLoginUser = Common.SetUserInSession(dtUser, 0, true);
            }

            return objLoginUser;
        }

        [Route("api/Common/SwitchToAdminView")]
        [HttpPost]
        public LoginUser SwitchToAdminView([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            LoginUser objLoginUser = new LoginUser();

            DataTable dtUser = Common.GetDBResultParameterized(@"select * from 
Users U
where
U.MobileNo=@MobileNo and CreatedBy IS NULL",
                "@MobileNo", SqlDbType.VarChar, objLoggedUser.MobileNo);
            if (dtUser.Rows.Count > 0)
            {
                objLoginUser = Common.SetUserInSession(dtUser, 0, false);
            }

            return objLoginUser;
        }
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/Common/SendContactMail")]
        [HttpPost]
        public bool SendContactMail([FromBody]dynamic value)
        {
            string name = Common.ToString(value.name);
            string email = Common.ToString(value.email);
            string message = Common.ToString(value.message);
            Common.SendEmailSendGrid("support@societyinn.com",
                "You have received a new message <br/> Name: " + name + " <br/> Email: " + email + " <br/> Message: $message" + message, "Contact form submission:");

            return true;
        }
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/Common/SendFreeDemoMail")]
        [HttpPost]
        public bool SendFreeDemoMail([FromBody]dynamic value)
        {
            string fname = Common.ToString(value.fname);
            string lname = Common.ToString(value.lname);
            string email = Common.ToString(value.email);
            string phone = Common.ToString(value.phone);
            string sname = Common.ToString(value.sname);
            string uno = Common.ToString(value.uno);
            StringBuilder message = new StringBuilder();
            message.Append("You have received a new message<br/>");
            message.Append("Name: ").Append(fname).Append(" ").Append(lname).Append("<br/>");
            message.Append("Email: ").Append(email).Append("<br/>");
            message.Append("Phone Number: ").Append(phone).Append("<br/>");
            message.Append("Society Name: ").Append(sname).Append("<br/>");
            message.Append("Number of Units managed: ").Append(uno);
            Common.SendEmailSendGrid("support@societyinn.com",
                 message.ToString(), "Contact form Free demo:");

            return true;
        }
        // GET api/Person
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/Common/")]
        [HttpPost]
        public List<AngularDropdownData> GetDropdownData([FromBody]dynamic value)
        {
            JObject objJObject = value;
            AngularDropdown objAngularDropdown = objJObject.ToObject<AngularDropdown>();
            if (objAngularDropdown == null) return null;
            switch (objAngularDropdown.MethodName)
            {
                case "GetPersonList":
                    return GetPersonList(objAngularDropdown);
                case "GetStateList":
                    return GetStateList(objAngularDropdown);
                case "GetPageList":
                    return GetPageList(objAngularDropdown);
                case "GetCityList":
                    return GetCityList(objAngularDropdown);
                case "GetAllCityList":
                    return GetAllCityList(objAngularDropdown);
                case "GetOrgList":
                    return GetOrgList(objAngularDropdown);
                case "GetOrgBranchList":
                    return GetOrgBranchList(objAngularDropdown);
                case "GetSocList":
                    return GetSocList(objAngularDropdown);
                case "GetUserList":
                    return GetUserList(objAngularDropdown);
                case "GetCategoryList":
                    return GetCategoryList(objAngularDropdown);
                case "GetCategorySubCategoryList":
                    return GetCategorySubCategoryList(objAngularDropdown);
                case "GetGroupSubGroupList":
                    return GetGroupSubGroupList(objAngularDropdown);
                case "GetOverheadGLList":
                    return GetOverheadGLList(objAngularDropdown);
                case "GetExpenseGroupList":
                    return GetExpenseGroupList(objAngularDropdown);
                case "GetIncomeGroupList":
                    return GetIncomeGroupList(objAngularDropdown);
                case "GetContraGLList":
                    return GetContraGLList(objAngularDropdown);
                case "GetCMTypeList":
                    return GetCMTypeList(objAngularDropdown);
                case "GetChgList":
                    return GetChgList(objAngularDropdown);
                case "GetChgListAll":
                    return GetChgListAll(objAngularDropdown);
                case "GetVTypeList":
                    return GetVTypeList(objAngularDropdown);
                case "GetDrList":
                    return GetDrList(objAngularDropdown);
                case "GetCrList":
                    return GetCrList(objAngularDropdown);
                case "GetWingList":
                    return GetWingList(objAngularDropdown);
                case "GetRoomList":
                    return GetRoomList(objAngularDropdown);
                case "GetEmailList":
                    return GetEmailList(objAngularDropdown);
                case "GetMobileList":
                    return GetMobileList(objAngularDropdown);
                case "GetEmailListBulk":
                    return GetEmailListBulk(objAngularDropdown);
                case "GetMobileListBulk":
                    return GetMobileListBulk(objAngularDropdown);
                case "GetTimeList":
                    return GetTimeList(objAngularDropdown);
                case "GetTimeList2":
                    return GetTimeList2(objAngularDropdown);
                case "GetFCList":
                    return GetFCList(objAngularDropdown);
                case "GetYearList":
                    return GetYearList(objAngularDropdown);
                case "GetPNList":
                    return GetPNList(objAngularDropdown);
                case "GetCTTypeList":
                    return GetCTTypeList(objAngularDropdown);
                case "GetUserListByType":
                    return GetUserListByType(objAngularDropdown);
                case "GetUnitListForMiscBill":
                    return GetUnitListForMiscBill(objAngularDropdown);
                case "GetMyRoomList":
                    return GetMyRoomList(objAngularDropdown);
                case "GetMySocList":
                    return GetMySocList(objAngularDropdown);
                case "GetMonthList":
                    return GetMonthList(objAngularDropdown);
                case "GetVendorGLList":
                    return GetVendorGLList(objAngularDropdown);
                case "GetBillListOfBill":
                    return GetBillListOfBill(objAngularDropdown);
                case "GetRoles":
                    return GetRoles(objAngularDropdown);
                case "GetSubjectList":
                    return GetSubjectList(objAngularDropdown);
                case "GetClassList":
                    return GetClassList(objAngularDropdown);
                case "GetTeacherList":
                    return GetTeacherList(objAngularDropdown);
                case "GetSectionList":
                    return GetSectionList(objAngularDropdown);
                case "GetTeacherSectionList":
                    return GetTeacherSectionList(objAngularDropdown);
                case "GetNewStudentList":
                    return GetNewStudentList(objAngularDropdown);
                case "GetExamList":
                    return GetExamList(objAngularDropdown);
                case "GetExamSubjectList":
                    return GetExamSubjectList(objAngularDropdown);
                case "GetFeeList":
                    return GetFeeList(objAngularDropdown);
                case "GetVehicleList":
                    return GetVehicleList(objAngularDropdown);
                case "GetStudentList":
                    return GetStudentList(objAngularDropdown);
                case "GetTestSubjectList":
                    return GetTestSubjectList(objAngularDropdown);
                case "GetClassSubjectList":
                    return GetClassSubjectList(objAngularDropdown);
                case "GetMyTeacherList":
                    return GetMyTeacherList(objAngularDropdown);
                case "GetCalendarTeacherList":
                    return GetCalendarTeacherList(objAngularDropdown);
            }
            return null;
        }
        private List<AngularDropdownData> GetPersonList(AngularDropdown objAngularDropdown)
        {
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DataTable dt = Common.GetDBResult("Select top 10 PersonID,Name from Person where Name like '%" + Common.ToString(objAngularDropdown.query).Replace("'", "''") + "%'");
            foreach (DataRow dr in dt.Rows)
            {
                obj.Add(new AngularDropdownData() { Key = Common.ToString(dr["PersonID"]), Value = Common.ToString(dr["Name"]) });
            }
            return obj;
        }
        private List<AngularDropdownData> GetStateList(AngularDropdown objAngularDropdown)
        {
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DataTable dt = Common.GetDBResult("Select  StateID,StateName from State");
            foreach (DataRow dr in dt.Rows)
            {
                obj.Add(new AngularDropdownData() { Key = Common.ToString(dr["StateID"]), Value = Common.ToString(dr["StateName"]) });
            }
            return obj;
        }
        private List<AngularDropdownData> GetPageList(AngularDropdown objAngularDropdown)
        {
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DataTable dt = Common.GetDBResult("Select  PageID,PageName from Pages order by PageName");
            foreach (DataRow dr in dt.Rows)
            {
                obj.Add(new AngularDropdownData() { Key = Common.ToString(dr["PageID"]), Value = Common.ToString(dr["PageName"]) });
            }
            return obj;
        }
        private List<AngularDropdownData> GetSocList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser == null) throw new HttpResponseException(HttpStatusCode.Unauthorized);

            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DataTable dt = Common.GetDBResult("Select  SocID,SocName from Soc where UserID=" + objLoggedUser.UserID);
            foreach (DataRow dr in dt.Rows)
            {
                obj.Add(new AngularDropdownData() { Key = Common.ToString(dr["SocID"]), Value = Common.ToString(dr["SocName"]) });
            }
            return obj;
        }
        private List<AngularDropdownData> GetUserList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser == null) throw new HttpResponseException(HttpStatusCode.Unauthorized);

            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DataTable dt = Common.GetDBResultParameterized(@"Select  UserID,FirstName+ISNULL(' '+LastName,'') as Name from Users where 
(CreatedBy=@UserID OR UserID=@UserID) and UserType<>9", "@UserID", SqlDbType.Int, objLoggedUser.UserID);
            foreach (DataRow dr in dt.Rows)
            {
                obj.Add(new AngularDropdownData() { Key = Common.ToString(dr["UserID"]), Value = Common.ToString(dr["Name"]) });
            }
            return obj;
        }
        private List<AngularDropdownData> GetUserListByType(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser == null) throw new HttpResponseException(HttpStatusCode.Unauthorized);
            string userType = Common.ToString(objAngularDropdown.query);
            string query = "Select  UserID,FirstName+' '+LastName+'('+UserName+')' as Name from Users where CreatedBy=" + objLoggedUser.UserID;
            if (userType == "ALLCOM")
                query += " AND " + Common.GetMemberTypeCondition(userType);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DataTable dt = Common.GetDBResult(query);
            foreach (DataRow dr in dt.Rows)
            {
                obj.Add(new AngularDropdownData() { Key = Common.ToString(dr["UserID"]), Value = Common.ToString(dr["Name"]) });
            }
            return obj;
        }

        private List<AngularDropdownData> GetCategoryList(AngularDropdown objAngularDropdown)
        {
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DataTable dt = Common.GetDBResult("Select  CategoryID,CategoryName from Categories order by CategoryName");
            foreach (DataRow dr in dt.Rows)
            {
                obj.Add(new AngularDropdownData() { Key = Common.ToString(dr["CategoryID"]), Value = Common.ToString(dr["CategoryName"]) });
            }
            return obj;
        }
        private List<AngularDropdownData> GetCategorySubCategoryList(AngularDropdown objAngularDropdown)
        {
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DataTable dt = Common.GetDBResult(@"select SC.SubID, C.CategoryName+' - '+SC.SubCategoryName as CategoryName from SubCategories SC
inner join Categories C ON SC.CategoryID=C.CategoryID order by CategoryName,SubCategoryName");
            foreach (DataRow dr in dt.Rows)
            {
                obj.Add(new AngularDropdownData() { Key = Common.ToString(dr["SubID"]), Value = Common.ToString(dr["CategoryName"]) });
            }
            return obj;
        }
        private List<AngularDropdownData> GetOverheadGLList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DataTable dt = Common.GetDBResult(@"select * from Accounts where ScheduleID =" + Common.ToInt(objAngularDropdown.query) + " and SocID=" + objLoggedUser.SocID + " and ISNULL(AccountType,'')='' order by AccountName ");
            foreach (DataRow dr in dt.Rows)
            {
                obj.Add(new AngularDropdownData() { Key = Common.ToString(dr["AccountID"]), Value = Common.ToString(dr["AccountName"]) });
            }
            return obj;
        }
        private List<AngularDropdownData> GetVendorGLList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DataTable dt = Common.GetDBResultParameterized(@"select * from Accounts where ScheduleID=
(select top 1 ScheduleID from Schedule where SchType='SundryCreditors' and SocID=@SocID)
and SocID=@SocID order by AccountName", "@SocID", SqlDbType.Int, objLoggedUser.SocID);
            foreach (DataRow dr in dt.Rows)
            {
                obj.Add(new AngularDropdownData() { Key = Common.ToString(dr["AccountID"]), Value = Common.ToString(dr["AccountName"]) });
            }
            return obj;
        }
        private List<AngularDropdownData> GetGroupSubGroupList(AngularDropdown objAngularDropdown)
        {
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DataTable dtGroup = Common.GetDBResult(@"select * from Groups where ParentGroupID is null Order by GroupName");
            foreach (DataRow dr in dtGroup.Rows)
            {
                DataTable dtSubGroup = Common.GetDBResult(@"select * from Groups where ParentGroupID =" + Common.ToInt(dr["GroupID"]) + " Order by GroupName");
                if (dtSubGroup.Rows.Count == 0)
                    obj.Add(new AngularDropdownData() { Key = Common.ToString(dr["GroupID"]), Value = Common.ToString(dr["GroupName"]) });
                else
                {
                    foreach (DataRow drSubGroup in dtSubGroup.Rows)
                    {
                        obj.Add(new AngularDropdownData() { Key = Common.ToString(drSubGroup["GroupID"]), Value = Common.ToString(dr["GroupName"]) + " - " + Common.ToString(drSubGroup["GroupName"]) });
                    }
                }
            }
            return obj;
        }
        private List<AngularDropdownData> GetOrgList(AngularDropdown objAngularDropdown)
        {
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DataTable dt = Common.GetDBResult("Select  OrgID,OrgName from OrgMaster");
            foreach (DataRow dr in dt.Rows)
            {
                obj.Add(new AngularDropdownData() { Key = Common.ToString(dr["OrgID"]), Value = Common.ToString(dr["OrgName"]) });
            }
            return obj;
        }
        private List<AngularDropdownData> GetOrgBranchList(AngularDropdown objAngularDropdown)
        {
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DataTable dt = Common.GetDBResult("Select  BranchID,BranchName from OrgBranch where OrgID=" + Common.ToInt(objAngularDropdown.query));
            foreach (DataRow dr in dt.Rows)
            {
                obj.Add(new AngularDropdownData() { Key = Common.ToString(dr["BranchID"]), Value = Common.ToString(dr["BranchName"]) });
            }
            return obj;
        }
        private List<AngularDropdownData> GetCityList(AngularDropdown objAngularDropdown)
        {
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DataTable dt = Common.GetDBResult("Select  CityID,CityName from City inner join State on City.StateID=State.StateID where City.StateID=" + Common.ToInt(objAngularDropdown.query));
            foreach (DataRow dr in dt.Rows)
            {
                obj.Add(new AngularDropdownData() { Key = Common.ToString(dr["CityName"]), Value = Common.ToString(dr["CityName"]) });
            }
            return obj;
        }
        private List<AngularDropdownData> GetAllCityList(AngularDropdown objAngularDropdown)
        {
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DataTable dt = Common.GetDBResult("Select  CityID,CityName+' - '+State.StateName as CityName from City inner join State on City.StateID=State.StateID Order By CityName");
            foreach (DataRow dr in dt.Rows)
            {
                obj.Add(new AngularDropdownData() { Key = Common.ToString(dr["CityID"]), Value = Common.ToString(dr["CityName"]) });
            }
            return obj;
        }
        private List<AngularDropdownData> GetExpenseGroupList(AngularDropdown objAngularDropdown)
        {
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            obj.Add(new AngularDropdownData() { Key = ((int)GroupNo.AdministrativeExpenses).ToString(), Value = "Common Expenses" });
            obj.Add(new AngularDropdownData() { Key = ((int)GroupNo.FixedAsset).ToString(), Value = "Fixed Assets Purchased" });
            return obj;
        }
        private List<AngularDropdownData> GetIncomeGroupList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DataTable dt = Common.GetDBResultParameterized(@"select S.ScheduleID,S.ScheduleName from Schedule S where 
S.MasterScheduleID=1 and S.SocID=@SocID 
and ISNULL(S.SchType,'')='' and exists (Select 1 from Accounts A where A.ScheduleID=S.ScheduleID and A.SocID=S.SocID)
Order By S.ScheduleName",
                "@SocID", SqlDbType.Int, objLoggedUser.SocID);
            foreach (DataRow dr in dt.Rows)
            {
                obj.Add(new AngularDropdownData() { Key = Common.ToString(dr["ScheduleID"]), Value = Common.ToString(dr["ScheduleName"]) });
            }

            return obj;
        }
        private List<AngularDropdownData> GetContraGLList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DataTable dt = Common.GetDBResultParameterized("Exec GetSchccounts @ScheduleID,@SocID",
                "@ScheduleID", SqlDbType.Int, ((int)GroupNo.CashAndBank),
                "@SocID", SqlDbType.Int, objLoggedUser.SocID);
            foreach (DataRow dr in dt.Rows)
            {
                obj.Add(new AngularDropdownData() { Key = Common.ToString(dr["AccountID"]), Value = Common.ToString(dr["AccountName"]) });
            }
            return obj;
        }
        private List<AngularDropdownData> GetCMTypeList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DataTable dt = Common.GetDBResult(@"select * from CMType");
            foreach (DataRow dr in dt.Rows)
            {
                obj.Add(new AngularDropdownData() { Key = Common.ToString(dr["CMTypeID"]), Value = Common.ToString(dr["CMTypeName"]) });
            }
            return obj;
        }
        private List<AngularDropdownData> GetChgList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DataTable dt = Common.GetDBResult("select * from Accounts where (ISNULL(AccountType,'')='' OR AccountType='Occupation') and SocID=" + objLoggedUser.SocID + " and ScheduleID=" + ((int)GroupNo.MembersContribution).ToString());
            foreach (DataRow dr in dt.Rows)
            {
                obj.Add(new AngularDropdownData() { Key = Common.ToString(dr["AccountID"]), Value = Common.ToString(dr["AccountName"]) });
            }
            return obj;
        }
        private List<AngularDropdownData> GetFeeList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DataTable dt = Common.GetDBResult("select * from Chg where ISNULL(ChgSysName,'')='' and SocID=" + objLoggedUser.SocID);
            foreach (DataRow dr in dt.Rows)
            {
                obj.Add(new AngularDropdownData() { Key = Common.ToString(dr["ChgID"]), Value = Common.ToString(dr["ChgName"]) });
            }
            return obj;
        }
        private List<AngularDropdownData> GetChgListAll(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DataTable dt = Common.GetDBResult("select * from Accounts where ISNULL(AccountType,'')='' and SocID=" + objLoggedUser.SocID + " and ScheduleID IN(" + ((int)GroupNo.MembersContribution).ToString() + "," + ((int)GroupNo.MiscellaneousIncome).ToString() + ") order by AccountName");
            foreach (DataRow dr in dt.Rows)
            {
                obj.Add(new AngularDropdownData() { Key = Common.ToString(dr["AccountID"]), Value = Common.ToString(dr["AccountName"]) });
            }
            return obj;
        }
        private List<AngularDropdownData> GetVTypeList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DataTable dt = Common.GetDBResult("select VoucherTypeID,VoucherTypeName from VoucherType where SocID=" + objLoggedUser.SocID);
            foreach (DataRow dr in dt.Rows)
            {
                obj.Add(new AngularDropdownData() { Key = Common.ToString(dr["VoucherTypeID"]), Value = Common.ToString(dr["VoucherTypeName"]) });
            }
            return obj;
        }
        private List<AngularDropdownData> GetDrList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DataTable dt = Common.GetDBResultParameterized("Exec GetVTAccounts @VTypeID,@DrCr,@SocID",
                "@VTypeID", SqlDbType.Int, Common.ToInt(objAngularDropdown.query),
                "@DrCr", SqlDbType.VarChar, "Dr",
                "@SocID", SqlDbType.Int, objLoggedUser.SocID);
            foreach (DataRow dr in dt.Rows)
            {
                obj.Add(new AngularDropdownData() { Key = Common.ToString(dr["AccountID"]), Value = Common.ToString(dr["AccountName"]) });
            }
            return obj;
        }
        private List<AngularDropdownData> GetCrList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DataTable dt = Common.GetDBResultParameterized("Exec GetVTAccounts @VTypeID,@DrCr,@SocID",
                "@VTypeID", SqlDbType.Int, Common.ToInt(objAngularDropdown.query),
                "@DrCr", SqlDbType.VarChar, "Cr",
                "@SocID", SqlDbType.Int, objLoggedUser.SocID);
            foreach (DataRow dr in dt.Rows)
            {
                obj.Add(new AngularDropdownData() { Key = Common.ToString(dr["AccountID"]), Value = Common.ToString(dr["AccountName"]) });
            }
            return obj;
        }
        private List<AngularDropdownData> GetWingList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DataTable dt = Common.GetDBResultParameterized("Select WingID,WingName from Wings where SocID=@SocID",
                "@SocID", SqlDbType.Int, objLoggedUser.SocID);
            foreach (DataRow dr in dt.Rows)
            {
                obj.Add(new AngularDropdownData() { Key = Common.ToString(dr["WingID"]), Value = Common.ToString(dr["WingName"]) });
            }
            return obj;
        }
        private List<AngularDropdownData> GetRoomList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DataTable dt = Common.GetDBResultParameterized(@"select E.EnrollID as RoomID, S.FirstName+ISNULL(' '+S.MiddleName,'')+ISNULL(' '+S.LastName,'')
 +' - '+CM.ClassName+' '+SM.SectionName as RoomNo from Enrollments E
inner join Students S ON S.StudentID=E.StudentID
inner join SectionMaster SM ON SM.SectionID=E.SectionID
inner join ClassMaster CM ON SM.SectionID=CM.ClassID
where exists
(
select 1 from Users U where U.MobileNo=S.MobileNo and U.UserID=@UserID
)
and exists
(
select 1 from AY where AY.StartDate> @Date and @Date < AY.EndDate  
and AY.AYID=E.AYID
)",
                "@Date", SqlDbType.DateTime, DateTime.Now,
                "@UserID", SqlDbType.Int, objLoggedUser.UserID);
            foreach (DataRow dr in dt.Rows)
            {
                obj.Add(new AngularDropdownData() { Key = Common.ToString(dr["RoomID"]), Value = Common.ToString(dr["RoomNo"]) });
            }
            return obj;
        }
        private List<AngularDropdownData> GetMyRoomList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DataTable dt = Common.GetDBResultParameterized(@"select E.EnrollID as RoomID, S.FirstName+ISNULL(' '+S.MiddleName,'')+ISNULL(' '+S.LastName,'')
 +' - '+CM.ClassName+' '+SM.SectionName as RoomNo from Enrollments E
inner join Students S ON S.StudentID=E.StudentID
inner join SectionMaster SM ON SM.SectionID=E.SectionID
inner join ClassMaster CM ON SM.SectionID=CM.ClassID
where E.AYID=@AYID and exists
(
select 1 from Users U where U.MobileNo=S.MobileNo and U.UserID=@UserID
)",
               "@AYID", SqlDbType.Int, objLoggedUser.WPID,
               "@UserID", SqlDbType.Int, objLoggedUser.UserID);
            foreach (DataRow dr in dt.Rows)
            {
                obj.Add(new AngularDropdownData() { Key = Common.ToString(dr["RoomID"]), Value = Common.ToString(dr["RoomNo"]) });
            }
            return obj;
        }
        private List<AngularDropdownData> GetMySocList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DataTable dt = Common.GetDBResultParameterized(@"select * from 
Soc U
where 
exists (select 1 from UserRooms S where U.SocID=S.SocID and S.UserID=@UserID)",
                "@UserID", SqlDbType.VarChar, objLoggedUser.UserID);
            foreach (DataRow dr in dt.Rows)
            {
                obj.Add(new AngularDropdownData() { Key = Common.ToString(dr["SocID"]), Value = Common.ToString(dr["SocName"]) });
            }
            return obj;
        }
        private List<AngularDropdownData> GetEmailList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DataTable dt = Common.GetDBResultParameterized(@"select FirstName+' '+LastName+'('+ISNULL(W.WingName,'')+' '+ISNULL(R.RoomNo,'')+')' as Name, EmailID 
from Users U left join Rooms R ON U.RoomID=R.RoomID 
left join Wings W ON R.WingID=W.WingID where EmailID<>'' and EmailID IS NOT NULL and CreatedBy=@CreatedBy Order By EmailID",
                "@CreatedBy", SqlDbType.Int, objLoggedUser.UserID);
            foreach (DataRow dr in dt.Rows)
            {
                obj.Add(new AngularDropdownData() { Key = Common.ToString(dr["EmailID"]), Value = Common.ToString(dr["Name"]) });
            }
            return obj;
        }
        private List<AngularDropdownData> GetEmailListBulk(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DataTable dt = Common.GetDBResultParameterized(@"select 'ALL' as Type
,'All Members ('+Convert(varchar, COUNT(*))+')' as Total from Users 
where EmailID<>'' and EmailID IS NOT NULL and IsActive=1 and CreatedBy=@CreatedBy
UNION ALL
select 'ALLRES' as Type
,'All Residing Members ('+Convert(varchar, COUNT(*))+')' as Total from Users 
where EmailID<>'' and EmailID IS NOT NULL and IsActive=1 and CreatedBy=@CreatedBy and Residing=1
UNION ALL
select 'ALLOWNER' as Type
,'All Owners ('+Convert(varchar, COUNT(*))+')' as Total from Users 
where EmailID<>'' and EmailID IS NOT NULL and IsActive=1 and CreatedBy=@CreatedBy and MemberType='Owner'
UNION ALL
select 'ALLTENANT' as Type
,'All Tenants ('+Convert(varchar, COUNT(*))+')' as Total from Users 
where EmailID<>'' and EmailID IS NOT NULL and IsActive=1 and CreatedBy=@CreatedBy and MemberType='Tenant'
UNION ALL
select 'ALLRESOWNER' as Type
,'All Residing Owners ('+Convert(varchar, COUNT(*))+')' as Total from Users 
where EmailID<>'' and EmailID IS NOT NULL and IsActive=1 and CreatedBy=@CreatedBy and MemberType='Tenant' and Residing=1
UNION ALL
select 'ALLCOM' as Type
,'All Commitee Members ('+Convert(varchar, COUNT(*))+')' as Total from Users 
inner join CM ON Users.UserID=CM.USerID
where EmailID<>'' and EmailID IS NOT NULL and IsActive=1 and CreatedBy=@CreatedBy",
                "@CreatedBy", SqlDbType.Int, objLoggedUser.UserID);
            foreach (DataRow dr in dt.Rows)
            {
                obj.Add(new AngularDropdownData() { Key = Common.ToString(dr["Type"]), Value = Common.ToString(dr["Total"]) });
            }
            return obj;
        }
        private List<AngularDropdownData> GetMobileList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DataTable dt = Common.GetDBResultParameterized(@"select FirstName+ISNULL(' '+U.LastName,'')+ISNULL(' ('+U.MobileNo +')','') as Name, MobileNo 
from Users U where (MobileNo<>'' and MobileNo IS NOT NULL and CreatedBy=@CreatedBy) OR Exists (Select 1 from Enrollments E 
left join Students S ON E.StudentID=S.StudentID where E.AYID=@AYID and 
MobileNo<>'' and MobileNo IS NOT NULL and S.MobileNo=U.MobileNo) Order By MobileNo",
                "@CreatedBy", SqlDbType.Int, objLoggedUser.UserID,
                "@AYID", SqlDbType.Int, objLoggedUser.WPID);
            foreach (DataRow dr in dt.Rows)
            {
                obj.Add(new AngularDropdownData() { Key = Common.ToString(dr["MobileNo"]), Value = Common.ToString(dr["Name"]) });
            }
            return obj;
        }
        private List<AngularDropdownData> GetMobileListBulk(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DataTable dt = Common.GetDBResultParameterized(@"select 'ALL' as Type
,'All Parents ('+Convert(varchar, COUNT(*))+')' as Total from Users where Exists (Select 1 from Enrollments E 
left join Students S ON E.StudentID=S.StudentID where E.AYID=@AYID and 
MobileNo<>'' and MobileNo IS NOT NULL and S.MobileNo=Users.MobileNo)
UNION ALL
select 'ALLTEACHER' as Type
,'All Teachers ('+Convert(varchar, COUNT(*))+')' as Total from Users 
where MobileNo<>'' and MobileNo IS NOT NULL and IsActive=1 and CreatedBy=@CreatedBy and MemberType='Teacher'
UNION ALL
select 'ALLSTAFF' as Type
,'All Staffs ('+Convert(varchar, COUNT(*))+')' as Total from Users 
where MobileNo<>'' and MobileNo IS NOT NULL and IsActive=1 and CreatedBy=@CreatedBy and MemberType='Staff'
UNION ALL
select 'ALLCOM' as Type
,'All Executive Members ('+Convert(varchar, COUNT(*))+')' as Total from Users 
inner join CM ON Users.UserID=CM.USerID
where MobileNo<>'' and MobileNo IS NOT NULL and IsActive=1 and CreatedBy=@CreatedBy",
                "@CreatedBy", SqlDbType.Int, objLoggedUser.UserID,
                "@AYID", SqlDbType.Int, objLoggedUser.WPID);
            foreach (DataRow dr in dt.Rows)
            {
                obj.Add(new AngularDropdownData() { Key = Common.ToString(dr["Type"]), Value = Common.ToString(dr["Total"]) });
            }
            return obj;
        }
        private List<AngularDropdownData> GetTimeList(AngularDropdown objAngularDropdown)
        {
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            int time = 360;
            while (time < 1080) //loop to add next 60 days
            {
                obj.Add(new AngularDropdownData() { Key = time.ToString(), Value = DateTime.Today.AddMinutes(time).ToString("hh:mm tt") });
                time = time + 5;
            }
            return obj;
        }
        private List<AngularDropdownData> GetTimeList2(AngularDropdown objAngularDropdown)
        {
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            int time = 360;
            while (time < 1080) //loop to add next 60 days
            {
                obj.Add(new AngularDropdownData() { Key = time.ToString(), Value = DateTime.Today.AddMinutes(time).ToString("hh:mm tt") });
                time = time + 30;
            }
            return obj;
        }
        private List<AngularDropdownData> GetFCList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DataTable dt = Common.GetDBResultParameterized("Select * from FC where SocID=@SocID",
                "@SocID", SqlDbType.Int, objLoggedUser.SocID);
            foreach (DataRow dr in dt.Rows)
            {
                obj.Add(new AngularDropdownData() { Key = Common.ToString(dr["FCID"]), Value = Common.ToString(dr["FCName"]) });
            }
            return obj;
        }
        private List<AngularDropdownData> GetYearList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            if (objLoggedUser != null)
            {
                DataTable dt = Common.GetDBResultParameterized("Select * from AY where SocID=@SocID Order By StartDate desc",
                    "@SocID", SqlDbType.Int, objLoggedUser.SocID);
                foreach (DataRow dr in dt.Rows)
                {
                    obj.Add(new AngularDropdownData()
                    {
                        Key = Common.ToString(dr["AYID"]),
                        Value = Common.ToDate(dr["StartDate"]).ToString("dd-MMM-yyyy") + " To " + Common.ToDate(dr["EndDate"]).ToString("dd-MMM-yyyy")
                    });
                }
            }
            return obj;
        }
        private List<AngularDropdownData> GetPNList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            if (objLoggedUser != null)
            {
                DataTable dt = Common.GetDBResultParameterized("Select * from Penalty where SocID=@SocID Order By PNName",
                    "@SocID", SqlDbType.Int, objLoggedUser.SocID);
                obj.Add(new AngularDropdownData()
                {
                    Key = "0",
                    Value = "None"
                });
                foreach (DataRow dr in dt.Rows)
                {
                    obj.Add(new AngularDropdownData()
                    {
                        Key = Common.ToString(dr["PNID"]),
                        Value = Common.ToString(dr["PNName"])
                    });
                }
            }
            return obj;
        }
        private List<AngularDropdownData> GetCTTypeList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            if (objLoggedUser != null)
            {
                DataTable dt = Common.GetDBResultParameterized("Select * from ComplainType");
                foreach (DataRow dr in dt.Rows)
                {
                    obj.Add(new AngularDropdownData()
                    {
                        Key = Common.ToString(dr["CTType"]),
                        Value = Common.ToString(dr["CTName"])
                    });
                }
            }
            return obj;
        }
        private List<AngularDropdownData> GetUnitListForMiscBill(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            if (objLoggedUser != null)
            {
                obj.Add(new AngularDropdownData()
                {
                    Key = "ALL",
                    Value = "All Units"
                });
                DataTable dt = Common.GetDBResultParameterized("Select * from Wings where SocID=@SocID"
                    , "@SocID", SqlDbType.Int, objLoggedUser.SocID);
                foreach (DataRow dr in dt.Rows)
                {
                    obj.Add(new AngularDropdownData()
                    {
                        Key = "ALLWING_" + Common.ToInt(dr["WingID"]),
                        Value = "All Units of Block/Wing " + Common.ToString(dr["WingName"])
                    });
                }

                dt = Common.GetDBResultParameterized("Select distinct UnitType from Rooms where SocID=@SocID"
                    , "@SocID", SqlDbType.Int, objLoggedUser.SocID);
                foreach (DataRow dr in dt.Rows)
                {
                    obj.Add(new AngularDropdownData()
                    {
                        Key = "ALLUNITTYPE_" + Common.ToString(dr["UnitType"]),
                        Value = "All Units of " + Common.ToString(dr["UnitType"]) + " Type"
                    });
                }

                dt = Common.GetDBResultParameterized(@"Select W.WingName+' '+R.RoomNo as UnitNo,R.RoomID from Rooms R inner Join Wings W ON 
                 W.WingID=R.WingID where R.SocID=@SocID"
                    , "@SocID", SqlDbType.Int, objLoggedUser.SocID);
                foreach (DataRow dr in dt.Rows)
                {
                    obj.Add(new AngularDropdownData()
                    {
                        Key = Common.ToInt(dr["RoomID"]),
                        Value = Common.ToString(dr["UnitNo"])
                    });
                }
            }
            return obj;
        }
        private List<AngularDropdownData> GetMonthList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            DateTime curDate = objLoggedUser.StartDate;
            for (int i = 0; i < 60; i++)
            {
                obj.Add(new AngularDropdownData()
                {
                    Key = Common.ToString(curDate.ToString("dd-MMM-yyyy")),
                    Value = Common.ToString(curDate.ToString("MMM-yyyy"))
                });
                curDate = curDate.AddMonths(-1);
            }

            return obj;
        }
        private List<AngularDropdownData> GetBillListOfBill(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            if (objLoggedUser != null)
            {
                DataTable dt = Common.GetDBResultParameterized(@"select TotalBillAmount,BillID from Bills where PaidDate is NULL and IsNewBill=1 and RoomID=@RoomID
and SocID=@SocID", "@RoomID", SqlDbType.Int, Common.ToInt(objAngularDropdown.query),
                 "@SocID", SqlDbType.Int, objLoggedUser.SocID);
                foreach (DataRow dr in dt.Rows)
                {
                    obj.Add(new AngularDropdownData()
                    {
                        Key = Common.ToString(dr["BillID"]),
                        Data = Common.ToString(dr["TotalBillAmount"]),
                        Selected = true,
                        Value = Common.ToString(dr["BillID"]) + " - " + Common.ToDecimal(dr["TotalBillAmount"]).ToString("0.00")
                    });
                }
            }
            return obj;
        }
        private List<AngularDropdownData> GetRoles(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            if (objLoggedUser != null)
            {
                DataTable dt = Common.GetDBResultParameterized(@"Select ID,RoleID,RoleName from Roles where SocID=@SocID",
                 "@SocID", SqlDbType.Int, objLoggedUser.SocID);
                obj.Add(new AngularDropdownData()
                {
                    Key = "0",
                    Selected = false,
                    Value = "(No Additional Role)"
                });
                foreach (DataRow dr in dt.Rows)
                {
                    obj.Add(new AngularDropdownData()
                    {
                        Key = Common.ToString(dr["RoleID"]),
                        Selected = false,
                        Value = Common.ToString(dr["RoleName"])
                    });
                }
            }
            return obj;
        }
        private List<AngularDropdownData> GetSubjectList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            if (objLoggedUser != null)
            {
                DataTable dt = Common.GetDBResultParameterized(@"Select * from Subjects where SocID=@SocID",
                 "@SocID", SqlDbType.Int, objLoggedUser.SocID);

                foreach (DataRow dr in dt.Rows)
                {
                    obj.Add(new AngularDropdownData()
                    {
                        Key = Common.ToString(dr["SubjectID"]),
                        Selected = false,
                        Value = Common.ToString(dr["SubjectName"])
                    });
                }
            }
            return obj;
        }
        private List<AngularDropdownData> GetClassList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            if (objLoggedUser != null)
            {
                DataTable dt = Common.GetDBResultParameterized(@"Select * from ClassMaster where SocID=@SocID",
                 "@SocID", SqlDbType.Int, objLoggedUser.SocID);

                foreach (DataRow dr in dt.Rows)
                {
                    obj.Add(new AngularDropdownData()
                    {
                        Key = Common.ToString(dr["ClassID"]),
                        Selected = false,
                        Value = Common.ToString(dr["ClassName"])
                    });
                }
            }
            return obj;
        }
        private List<AngularDropdownData> GetTeacherList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            if (objLoggedUser != null)
            {
                DataTable dt = Common.GetDBResultParameterized(@"Select UserID,FirstName+ISNULL(' '+LastName,'') as Name from Users where MemberType='Teacher' and IsActive=1 and CreatedBy in (Select UserID FROM Soc where SocID=@SocID)",
                 "@SocID", SqlDbType.Int, objLoggedUser.SocID);

                foreach (DataRow dr in dt.Rows)
                {
                    obj.Add(new AngularDropdownData()
                    {
                        Key = Common.ToString(dr["UserID"]),
                        Selected = false,
                        Value = Common.ToString(dr["Name"])
                    });
                }
            }
            return obj;
        }
        private List<AngularDropdownData> GetSectionList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            if (objLoggedUser != null)
            {
                DataTable dt = Common.GetDBResultParameterized(@"select CM.ClassName+' - '+SM.SectionName as SectionName,SM.SectionID from SectionMaster SM
left join ClassMaster CM ON SM.ClassID=CM.ClassID
where SM.SocID=@SocID and SM.AYID=@AYID and (@UserType=2 OR SM.ClassTeacherID=@UserID)
order by CM.ClassID",
                 "@SocID", SqlDbType.Int, objLoggedUser.SocID,
                 "@AYID", SqlDbType.Int, objLoggedUser.WPID,
                 "@UserType", SqlDbType.Int, objLoggedUser.UserType,
                 "@UserID", SqlDbType.Int, objLoggedUser.UserID);

                foreach (DataRow dr in dt.Rows)
                {
                    obj.Add(new AngularDropdownData()
                    {
                        Key = Common.ToString(dr["SectionID"]),
                        Selected = false,
                        Value = Common.ToString(dr["SectionName"])
                    });
                }
            }
            return obj;
        }
        private List<AngularDropdownData> GetTeacherSectionList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            if (objLoggedUser != null)
            {
                DataTable dt = Common.GetDBResultParameterized(@"select CM.ClassName+' - '+SM.SectionName as SectionName,SM.SectionID from SectionMaster SM
left join ClassMaster CM ON SM.ClassID=CM.ClassID
where SM.SocID=@SocID and SM.AYID=@AYID and exists
(select 1 from TimePeriods TP where TP.TeacherID=@UserID and TP.SectionID=SM.SectionID)",
                 "@SocID", SqlDbType.Int, objLoggedUser.SocID,
                 "@AYID", SqlDbType.Int, objLoggedUser.WPID,
                 "@UserID", SqlDbType.Int, objLoggedUser.UserID);

                foreach (DataRow dr in dt.Rows)
                {
                    obj.Add(new AngularDropdownData()
                    {
                        Key = Common.ToString(dr["SectionID"]),
                        Selected = false,
                        Value = Common.ToString(dr["SectionName"])
                    });
                }
            }
            return obj;
        }
        private List<AngularDropdownData> GetExamList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            if (objLoggedUser != null)
            {
                DataTable dt = Common.GetDBResultParameterized(@"Select ExamID,ExamTitle from Exams where AYID=@AYID
and SocID=@SocID order by ExamTitle",
                 "@SocID", SqlDbType.Int, objLoggedUser.SocID,
                 "@AYID", SqlDbType.Int, objLoggedUser.WPID);

                foreach (DataRow dr in dt.Rows)
                {
                    obj.Add(new AngularDropdownData()
                    {
                        Key = Common.ToString(dr["ExamID"]),
                        Selected = false,
                        Value = Common.ToString(dr["ExamTitle"])
                    });
                }
            }
            return obj;
        }
        private List<AngularDropdownData> GetNewStudentList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            if (objLoggedUser != null)
            {
                DataTable dt = Common.GetDBResultParameterized(@"select S.StudentID, S.FirstName+ISNULL(' '+S.MiddleName,'')+ISNULL(' '+S.LastName,'')+ISNULL('S/O '+S.FatherName,'') as StudentName
from Students S
where not exists(Select StudentID from Enrollments where Enrollments.StudentID=S.StudentID and Enrollments.AYID=@AYID)
and S.SocID=@SocID
order by S.FirstName",
                 "@SocID", SqlDbType.Int, objLoggedUser.SocID,
                 "@AYID", SqlDbType.Int, objLoggedUser.WPID);

                foreach (DataRow dr in dt.Rows)
                {
                    obj.Add(new AngularDropdownData()
                    {
                        Key = Common.ToString(dr["StudentID"]),
                        Selected = false,
                        Value = Common.ToString(dr["StudentName"])
                    });
                }
            }
            return obj;
        }
        private List<AngularDropdownData> GetExamSubjectList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            int examID = Common.ToInt(Common.GetDBScalar("select * from Exams where SocID=@SocID and AYID=@AYID",
                "@SocID", SqlDbType.Int, objLoggedUser.SocID,
                "@AYID", SqlDbType.Int, objLoggedUser.WPID));
            int sectionID = Common.ToInt(objAngularDropdown.query);


            if (objLoggedUser != null)
            {
                DataTable dt = Common.GetDBResultParameterized(@"select ES.MaxMarks, ES.ExamSubjectID
,S.SubjectName+case when ISNULL(ES.PaperName,'')='' then '' else ' - '+ES.PaperName end as SubjectName 
from ExamSubjects ES
left join Subjects S ON ES.SubjectID=S.SubjectID
 where ExamID=@ExamID
and exists
(select 1 from ExamSubjectClass ESC
inner join SectionMaster SC ON ESC.ClassID=SC.ClassID
 where ESC.ExamSubjectID = ES.ExamSubjectID
and SC.SectionID=@SectionID) 
and exists (Select 1 from TimePeriods TP where 
TP.SectionID=@SectionID and (TP.TeacherID=@UserID OR @UserType=2) and TP.AYID=@AYID
and TP.SubjectID=ES.SubjectID) order by S.SubjectName",
                 "@ExamID", SqlDbType.Int, examID,
                 "@SectionID", SqlDbType.Int, sectionID,
                 "@UserID", SqlDbType.Int, objLoggedUser.UserID,
                 "@UserType", SqlDbType.Int, objLoggedUser.UserType,
                 "@AYID", SqlDbType.Int, objLoggedUser.WPID);

                foreach (DataRow dr in dt.Rows)
                {
                    obj.Add(new AngularDropdownData()
                    {
                        Key = Common.ToString(dr["ExamSubjectID"]),
                        Selected = false,
                        Value = Common.ToString(dr["SubjectName"]),
                        Data = Common.ToInt(dr["MaxMarks"])
                    });
                }
            }
            return obj;
        }
        private List<AngularDropdownData> GetVehicleList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
        
            if (objLoggedUser != null)
            {
                DataTable dt = Common.GetDBResultParameterized(@"select VehID,VehicleType+' - '+ RegNo as RegNo from Vehicles where SocID=@SocID order by VehicleType,RegNo",
                 "@SocID", SqlDbType.Int, objLoggedUser.SocID);

                foreach (DataRow dr in dt.Rows)
                {
                    obj.Add(new AngularDropdownData()
                    {
                        Key = Common.ToString(dr["VehID"]),
                        Selected = false,
                        Value = Common.ToString(dr["RegNo"])
                    });
                }
            }
            return obj;
        }
        private List<AngularDropdownData> GetStudentList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            if (objLoggedUser != null)
            {
                DataTable dt = Common.GetDBResultParameterized(@"Select E.EnrollID, S.FirstName+ISNULL(' '+S.MiddleName,'')+ISNULL(' '+S.LastName,'') as StudentName from 
Enrollments E
left join Students S ON E.StudentID=S.StudentID
where E.SectionID=@SectionID order by S.FirstName",
                 "@SectionID", SqlDbType.Int, Common.ToInt(objAngularDropdown.query));

                foreach (DataRow dr in dt.Rows)
                {
                    obj.Add(new AngularDropdownData()
                    {
                        Key = Common.ToString(dr["EnrollID"]),
                        Selected = false,
                        Value = Common.ToString(dr["StudentName"])
                    });
                }
            }
            return obj;
        }
        private List<AngularDropdownData> GetTestSubjectList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            if (objLoggedUser != null)
            {
                DataTable dt = Common.GetDBResultParameterized(@"Select TS.MaxMarks,TS.TestName+' - '+S.SubjectName as TestName,TS.TestID
from Tests TS
left join Subjects S ON TS.SubjectID=S.SubjectID
where TS.SectionID=@SectionID 
and exists (Select 1 from TimePeriods TP where 
TP.SectionID=@SectionID and (TP.TeacherID=@UserID OR @UserType=2) and TP.AYID=@AYID
and TP.SubjectID=TS.SubjectID) order by TS.TestName",
                 "@SectionID", SqlDbType.Int, Common.ToInt(objAngularDropdown.query),
                 "@UserID", SqlDbType.Int, objLoggedUser.UserID,
                 "@UserType", SqlDbType.Int, objLoggedUser.UserType,
                 "@AYID", SqlDbType.Int, objLoggedUser.WPID); ;

                foreach (DataRow dr in dt.Rows)
                {
                    obj.Add(new AngularDropdownData()
                    {
                        Key = Common.ToString(dr["TestID"]),
                        Selected = false,
                        Value = Common.ToString(dr["TestName"]),
                        Data = Common.ToInt(dr["MaxMarks"])
                    });
                }
            }
            return obj;
        }
        private List<AngularDropdownData> GetClassSubjectList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            int sectionID = Common.ToInt(objAngularDropdown.query);

            if (objLoggedUser != null)
            {
                DataTable dt = Common.GetDBResultParameterized(@"select S.SubjectID
,S.SubjectName
from Subjects S
 where exists
(select 1 from ClassSubjects CS
inner join SectionMaster SM ON CS.ClassID=SM.ClassID
 where S.SubjectID=CS.SubjectID and SM.SectionID=@SectionID) 
and exists (Select 1 from TimePeriods TP where 
TP.SectionID=@SectionID and (TP.TeacherID=@UserID OR @UserType=2) and TP.AYID=@AYID
and TP.SubjectID=S.SubjectID) order by S.SubjectName",
                 "@SectionID", SqlDbType.Int, sectionID,
                 "@UserID", SqlDbType.Int, objLoggedUser.UserID,
                 "@UserType", SqlDbType.Int, objLoggedUser.UserType,
                 "@AYID", SqlDbType.Int, objLoggedUser.WPID);

                foreach (DataRow dr in dt.Rows)
                {
                    obj.Add(new AngularDropdownData()
                    {
                        Key = Common.ToString(dr["SubjectID"]),
                        Selected = false,
                        Value = Common.ToString(dr["SubjectName"])
                    });
                }
            }
            return obj;
        }
        private List<AngularDropdownData> GetMyTeacherList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            if (objLoggedUser != null)
            {
                DataTable dt = Common.GetDBResultParameterized(@"Select UserID,FirstName+ISNULL(' '+LastName,'') as Name from Users 
where MemberType='Teacher' and (CreatedBy=@UserID OR UserID=@UserID) and IsActive=1",
                 "@UserID", SqlDbType.Int, objLoggedUser.UserID);

                foreach (DataRow dr in dt.Rows)
                {
                    obj.Add(new AngularDropdownData()
                    {
                        Key = Common.ToString(dr["UserID"]),
                        Selected = false,
                        Value = Common.ToString(dr["Name"])
                    });
                }
            }
            return obj;
        }
        private List<AngularDropdownData> GetCalendarTeacherList(AngularDropdown objAngularDropdown)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            List<AngularDropdownData> obj = new List<AngularDropdownData>();
            int EnrollID = Common.ToInt(objAngularDropdown.query);
            if (objLoggedUser != null)
            {
                DataTable dt = Common.GetDBResultParameterized(@"Select distinct * from
(select UserID,FirstName+ISNULL(' '+LastName,'') as Name
 from Users U where exists
(select 1 from
Enrollments E 
inner join SectionMaster SM ON E.SectionID = SM.SectionID
 where SM.ClassTeacherID = U.UserID and E.EnrollID=@EnrollID)
UNION ALL
Select UserID,FirstName+ISNULL(' '+LastName,'') as Name from Users U
where exists(select 1 from
Enrollments E 
inner join TimePeriods TP ON E.SectionID=TP.SectionID
where TP.TeacherID=U.UserID and E.EnrollID=@EnrollID)
) as T",
                 "@EnrollID", SqlDbType.Int, EnrollID);

                foreach (DataRow dr in dt.Rows)
                {
                    obj.Add(new AngularDropdownData()
                    {
                        Key = Common.ToString(dr["UserID"]),
                        Selected = false,
                        Value = Common.ToString(dr["Name"])
                    });
                }
            }
            return obj;
        }
    }
}
