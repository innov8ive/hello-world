using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

    [Serializable]
    [Table(Name = "dbo.Enrollments")]
    public class Enrollments
    {

        private System.Nullable<int> _AYID;
        private System.Nullable<int> _EnrollID;
        private string _RollNo;
        private System.Nullable<int> _SectionID;
        private System.Nullable<int> _StudentID;
        private string _StudentName;
        private Nullable<int> _TotalSubjects;
        private string _SectionName;

        [Column(Storage = "_SectionName")]
        public string SectionName
        {
            get { return _SectionName; }
            set { _SectionName = value; }
        }

        [Column(Storage = "_TotalSubjects")]
        public Nullable<int> TotalSubjects
        {
            get { return _TotalSubjects; }
            set { _TotalSubjects = value; }
        }

        [Column(Storage = "_StudentName")]
        public string StudentName
        {
            get { return _StudentName; }
            set { _StudentName = value; }
        }

        [Column(Storage = "_AYID")]
        public System.Nullable<int> AYID
        {
            get
            {
                return _AYID;
            }
            set
            {
                _AYID = value;
            }
        }

        [Column(Storage = "_EnrollID")]
        public System.Nullable<int> EnrollID
        {
            get
            {
                return _EnrollID;
            }
            set
            {
                _EnrollID = value;
            }
        }

        [Column(Storage = "_RollNo")]
        public string RollNo
        {
            get
            {
                return _RollNo;
            }
            set
            {
                _RollNo = value;
            }
        }

        [Column(Storage = "_SectionID")]
        public System.Nullable<int> SectionID
        {
            get
            {
                return _SectionID;
            }
            set
            {
                _SectionID = value;
            }
        }

        [Column(Storage = "_StudentID")]
        public System.Nullable<int> StudentID
        {
            get
            {
                return _StudentID;
            }
            set
            {
                _StudentID = value;
            }
        }


        public System.Collections.Generic.List<EnrollmentSubjects> EnrollmentSubjectsList { get; set; }
        public Hashtable Types { get; set; }
    }


    [Serializable]
    [Table(Name = "dbo.EnrollmentSubjects")]
    public class EnrollmentSubjects
    {

        private System.Nullable<int> _EnrollID;
        private System.Nullable<int> _SubjectID;
        private string _SubjectName;
        private bool? _IsMandatory;
        private bool? _Selected;

        [Column(Storage = "_Selected")]
        public bool? Selected
        {
            get { return _Selected; }
            set { _Selected = value; }
        }

        [Column(Storage = "_IsMandatory")]
        public bool? IsMandatory
        {
            get { return _IsMandatory; }
            set { _IsMandatory = value; }
        }

        [Column(Storage = "_SubjectName")]
        public string SubjectName
        {
            get { return _SubjectName; }
            set { _SubjectName = value; }
        }



        [Column(Storage = "_EnrollID")]
        public System.Nullable<int> EnrollID
        {
            get
            {
                return _EnrollID;
            }
            set
            {
                _EnrollID = value;
            }
        }



        [Column(Storage = "_SubjectID")]
        public System.Nullable<int> SubjectID
        {
            get
            {
                return _SubjectID;
            }
            set
            {
                _SubjectID = value;
            }
        }

    }

    public class EnrollmentsACPerformance
    {
        public string TestName { get; set; }
       public List<EnrollmentsACPerformanceSubject> Subjects { get; set; }
    }
    public class EnrollmentsACPerformanceSubject
    {
        public string SubjectName { get; set; }
        public DateTime TestDate { get; set; }
        public decimal Marks { get; set; }
        public int MaxMarks { get; set; }
    }
}
