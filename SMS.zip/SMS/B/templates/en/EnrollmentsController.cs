using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;

namespace SampleAngular.Api
{
    public class EnrollmentsController : ApiController
    {
        [Route("api/Enrollments/GetStudentExamTimeTableDetails/")]
        [HttpPost]
        public string GetStudentExamTimeTableDetails([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            int EnrollID = Common.ToInt(value.EnrollID);
            DataTable dt = Common.GetDBResultParameterized(@"select SM.ClassID,SM.SocID,EX.ExamID from Enrollments E
left join SectionMaster SM ON E.SectionID=E.SectionID
left join Exams EX ON SM.AYID=EX.AYID and SM.SocID=EX.SocID
where E.EnrollID=@EnrollID",
                           "@EnrollID", SqlDbType.Int, EnrollID);
            if (dt.Rows.Count > 0)
            {
                int classID = Common.ToInt(dt.Rows[0]["ClassID"]);
                int examID = Common.ToInt(dt.Rows[0]["ExamID"]);
                DataTable dtStudent = Common.GetDBResultParameterized(@"
select ETT.ExamType, ETT.ExamTimeID, ETT.ExamDate,
SUBSTRING(CONVERT(varchar,DATEADD(MI,ETT.FromTime,'2017-01-01'),100),13,7) as FromTime,
SUBSTRING(CONVERT(varchar,DATEADD(MI,ETT.ToTime,'2017-01-01'),100),13,7) ToTime,
S.SubjectName+case when ES.PaperName='' then '' else ' - '+ES.PaperName end as SubjectName
,ES.SubjectID,ES.ExamSubjectID
 from ExamTimeTable ETT
right outer join ExamSubjects ES ON ES.ExamSubjectID = ETT.ExamSubjectID and ETT.ClassID=@classID
left join Subjects S ON ES.SubjectID=S.SubjectID
where exists
(Select 1 from ExamSubjectClass ESC where ESC.ClassID=@classID and ES.ExamSubjectID=ESC.ExamSubjectID)
and ES.ExamID=@examID order by ETT.ExamDate",
                "@classID", SqlDbType.VarChar, classID,
                "@examID", SqlDbType.Int, examID);
                return JsonConvert.SerializeObject(dtStudent, Formatting.Indented);
            }
            return String.Empty;
        }
        [Route("api/Enrollments/GetStudentTimeTableDetails/")]
        [HttpPost]
        public string GetStudentTimeTableDetails([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            int SectionID = Common.ToInt(Common.GetDBScalar("Select SectionID from Enrollments where EnrollID=" + Common.ToInt(value.EnrollID)));
            DataTable dtStudent = Common.GetDBResultParameterized(@"select TP.Day, TP.TimeID, P.PeriodID,P.PeriodName,P.StartTime,
SUBSTRING(CONVERT(varchar,DATEADD(MI,P.StartTime,'2017-01-01'),100),13,7) as StartTimeDesc
,SUBSTRING(CONVERT(varchar,DATEADD(MI,P.EndTime,'2017-01-01'),100),13,7) as EndTimeDesc 
,U.FirstName+ISNULL(' '+U.LastName,'') as TeacherName
,S.SubjectName,TP.SubjectID,TP.TeacherID from TimePeriods TP
right outer join Periods P ON TP.PeriodID =P.PeriodID
and ISNULL(SectionID,@SectionID)=@SectionID
left join Users U ON TP.TeacherID = U.UserID
left join Subjects S ON TP.SubjectID=S.SubjectID
order by PeriodName",
                          "@SectionID", SqlDbType.Int, SectionID);
            return JsonConvert.SerializeObject(dtStudent, Formatting.Indented);
        }
        [Route("api/Enrollments/GetStudentTestDetails/")]
        [HttpPost]
        public List<EnrollmentsACPerformance> GetStudentTestDetails([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            List<EnrollmentsACPerformance> result = new List<EnrollmentsACPerformance>();

            int enrollID = Common.ToInt(value.EnrollID);
            DataTable dtStudent = Common.GetDBResultParameterized(@"Select T.TestDate,T.TestName,S.SubjectName,TM.Marks,T.MaxMarks from TestMarks TM
left join Tests T ON TM.TestID=T.TestID
left join Subjects S ON S.SubjectID=T.SubjectID
 where EnrollID=@EnrollID order by TestName,TestDate", "@EnrollID", SqlDbType.Int, enrollID);

            string tempTestName = string.Empty;
            string testName = string.Empty;
            EnrollmentsACPerformance res = null;
            foreach (DataRow dr in dtStudent.Rows)
            {
                testName = Common.ToString(dr["TestName"]);
                if (testName != tempTestName)
                {
                    res = new EnrollmentsACPerformance();
                    res.TestName = testName;
                    res.Subjects = new List<EnrollmentsACPerformanceSubject>();
                    res.Subjects.Add(new EnrollmentsACPerformanceSubject()
                    {
                        SubjectName = Common.ToString(dr["SubjectName"]),
                        Marks= Common.ToDecimal(dr["Marks"]),
                        MaxMarks= Common.ToInt(dr["MaxMarks"]),
                        TestDate= Common.ToDate(dr["TestDate"])
                    });
                    result.Add(res);
                }
                else
                {
                    res.Subjects.Add(new EnrollmentsACPerformanceSubject()
                    {
                        SubjectName = Common.ToString(dr["SubjectName"]),
                        Marks = Common.ToDecimal(dr["Marks"]),
                        MaxMarks = Common.ToInt(dr["MaxMarks"]),
                        TestDate = Common.ToDate(dr["TestDate"])
                    });
                }
                tempTestName = testName;
            }

           dtStudent = Common.GetDBResultParameterized(@"Select ET.ExamDate,TM.ExamType,S.SubjectName+ISNULL(' '+ES.PaperName,'') as SubjectName,TM.Marks,ES.MaxMarks from ExamMarks TM
left join Enrollments E ON TM.EnrollID=E.EnrollID
left join SectionMaster SC ON SC.SectionID=E.SectionID
 left join ExamSubjects ES ON TM.ExamSubjectID=ES.ExamSubjectID
 LEFT join ExamTimeTable ET ON TM.ExamSubjectID=ET.ExamSubjectID 
 and SC.ClassID=ET.ClassID 
left join Subjects S ON S.SubjectID=ES.SubjectID
 where TM.EnrollID=@EnrollID
 order by ExamType,ExamDate",
                          "@EnrollID", SqlDbType.Int, enrollID);
            tempTestName = string.Empty;
            testName = string.Empty;
            foreach (DataRow dr in dtStudent.Rows)
            {
                testName = Common.ToString(dr["ExamType"]);
                if (testName != tempTestName)
                {
                    res = new EnrollmentsACPerformance();
                    res.TestName = testName;
                    res.Subjects = new List<EnrollmentsACPerformanceSubject>();
                    res.Subjects.Add(new EnrollmentsACPerformanceSubject()
                    {
                        SubjectName = Common.ToString(dr["SubjectName"]),
                        Marks = Common.ToDecimal(dr["Marks"]),
                        MaxMarks = Common.ToInt(dr["MaxMarks"]),
                        TestDate = Common.ToDate(dr["ExamDate"])
                    });
                    result.Add(res);
                }
                else
                {
                    res.Subjects.Add(new EnrollmentsACPerformanceSubject()
                    {
                        SubjectName = Common.ToString(dr["SubjectName"]),
                        Marks = Common.ToDecimal(dr["Marks"]),
                        MaxMarks = Common.ToInt(dr["MaxMarks"]),
                        TestDate = Common.ToDate(dr["ExamDate"])
                    });
                }
                tempTestName = testName;
            }

            return result;
        }
        [Route("api/Enrollments/GetStudentAbsenceDetails/")]
        [HttpPost]
        public string GetStudentAbsenceDetails([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            int enrollID = Common.ToInt(value.EnrollID);
            DataTable dtStudent = Common.GetDBResultParameterized(@"select * from Attendance where EnrollID=" + enrollID
                + " and IsPresent=0 Order By LogDate Desc");
            return JsonConvert.SerializeObject(dtStudent, Formatting.Indented);
        }

        [Route("api/Enrollments/GetStudentStatement/")]
        [HttpPost]
        public string GetStudentStatement([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            int enrollID = Common.ToInt(value.EnrollID);
            DataTable dtStatement = Common.GetStatement(enrollID);
            return JsonConvert.SerializeObject(dtStatement, Formatting.Indented);
        }

        [Route("api/Enrollments/GetStudentStatementForPayment/")]
        [HttpPost]
        public string GetStudentStatementForPayment([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            int enrollID = Common.ToInt(value.EnrollID);
            DataTable dtStatement = Common.GetStatementForPayment(enrollID);
            return JsonConvert.SerializeObject(dtStatement, Formatting.Indented);
        }
        [Route("api/Enrollments/GetStudentDetails/")]
        [HttpPost]
        public string GetStudentDetails([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            StudentsBL objStudentBL = new StudentsBL(Common.GetConString());
            EnrollmentsBL objEnrollmentsBL = new EnrollmentsBL(Common.GetConString());

            int enrollID = Common.ToInt(value.EnrollID);
            objEnrollmentsBL.Load(enrollID);
            Enrollments objEnrollments = objEnrollmentsBL.Data;
            objStudentBL.Load(Common.ToInt(objEnrollments.StudentID));
            Hashtable ht = new Hashtable();
            ht["Enrollments"] = objEnrollments;
            ht["Students"] = objStudentBL.Data;
            return JsonConvert.SerializeObject(ht, Formatting.Indented);
        }
        [Route("api/Enrollments/GetEnrollmentDetails/")]
        [HttpPost]
        public string GetEnrollmentDetails([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            StudentsBL objStudentBL = new StudentsBL(Common.GetConString());
            EnrollmentsBL objEnrollmentsBL = new EnrollmentsBL(Common.GetConString());

            int enrollID = Common.ToInt(value.EnrollID);
            objEnrollmentsBL.Load(enrollID);
            Enrollments objEnrollments = objEnrollmentsBL.Data;
            objStudentBL.Load(Common.ToInt(objEnrollments.StudentID));

            Hashtable ht = new Hashtable();
           

            ht["Present"] = Common.GetDBResultParameterized(@"Select Present,Absent,CASE WHEN (Present+Absent)>0 THEN (Present*100)/(Present+Absent) ELSE 0 END as Perc from
(
Select COUNT(Case when IsPresent=1 then NULL else 1 end) as Absent,
COUNT(Case when IsPresent=0 then NULL else 1 end) as Present
 from Attendance where EnrollID=@EnrollID
 ) as T", "@EnrollID", SqlDbType.Int, enrollID);

            DataTable dtFeesThisMonth = Common.GetFeesDueThisMonth(enrollID);
            DataTable dtFees = Common.GetFeesDue(enrollID);
            ht["MonthDue"] = Common.ToDouble(dtFeesThisMonth.Compute("SUM(PayableAmount)", String.Empty));
            ht["TotalDue"] = Common.ToDouble(dtFees.Compute("SUM(PayableAmount)", String.Empty));


            return JsonConvert.SerializeObject(ht, Formatting.Indented);
        }

        // GET api/Enrollments
        [Route("api/EnrollmentsList/")]
        [HttpPost]
        public AngularGridData GetEnrollments([FromBody]dynamic value)
        {
            //Common.IsValidForm(Constants.Forms.Enrollments, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = @"Select Soc.SocName,S.ImageUrl,S.FirstName+ISNULL(' '+S.MiddleName,'')+ISNULL(' '+S.LastName,'') as StudentName,
S.FatherName,S.MobileNo,E.EnrollID,E.RollNo
,CM.ClassName+' '+SM.SectionName as SectionName,
Convert(Varchar,DatePart(YY,AY.StartDate))+'-'+Convert(Varchar,DatePart(YY,AY.EndDate)) as ACYear,AY.AYID from Enrollments E 
left join SectionMaster SM ON E.SectionID = SM.SectionID
left join AY ON AY.AYID = SM.AYID
left join Soc ON SM.SocID= Soc.SocID
left join ClassMaster CM ON CM.ClassID = SM.ClassID
left join Students S ON E.StudentID = S.StudentID where 1=1 ";

            Hashtable ht = new Hashtable();
           
            int sectionID = Common.ToInt(value.OtherFilter.Section);
            if (objLoggedUser.UserType == 2 || objLoggedUser.UserType == 1)
            {
                ht["@AYID"] = objLoggedUser.WPID;
                ht["@SectionID"] = sectionID;
                objAngularDataBinder.Query += " and E.AYID=@AYID and E.SectionID=@SectionID";
            }
            else
            {
                objAngularDataBinder.Query += @" and exists ( select 1 from Students S 
 inner join Enrollments EN ON S.StudentID=EN.StudentID
where S.MobileNo=@MobileNo and EN.EnrollID=E.EnrollID)";
                ht["@MobileNo"] = objLoggedUser.MobileNo;
            }

           
            string name = Common.ToString(value.OtherFilter.Name);
            if (name.Length > 0)
            {
                objAngularDataBinder.Query += @" and (S.FirstName like '%'+@Name+'%' OR E.RollNo like '%'+@Name+'%' OR S.MiddleName like '%'+@Name+'%' OR 
S.LastName like '%'+@Name+'%' OR S.FatherName like '%'+@Name+'%' OR S.MobileNo like '%'+@Name+'%')";
                ht["@Name"] = name;
            }
            objAngularDataBinder.OrderDir = "Desc";
            objAngularDataBinder.OrderBy = "AY.AYID";
            objAngularDataBinder.Parameters = ht;
            objAngularDataBinder.ValueField = "E.EnrollID";
            return objAngularDataBinder.GetData();
        }

        [Route("api/Enrollments/FetchSubjects")]
        [HttpPost]
        public string FetchSubjects([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.Enrollments, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            JObject objJObject = value;
            Enrollments objEnrollments = objJObject.ToObject<Enrollments>();
            EnrollmentsBL objEnrollmentsBL = new EnrollmentsBL(Common.GetConString());
            if (Common.ToInt(objEnrollments.SectionID) <= 0)
            {
                throw new Exception("Please select Section");
            }
            objEnrollmentsBL.LoadTempSubjects(objEnrollments, Common.ToInt(objEnrollments.SectionID));
            return JsonConvert.SerializeObject(objEnrollments);
        }

        [Route("api/Enrollments/LoadEnrollments")]
        [HttpPost]
        public string LoadEnrollments([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.Enrollments, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            DataTable dt = Common.GetDBResultParameterized(@"Select S.FirstName+ISNULL(' '+S.MiddleName,'')+ISNULL(' '+S.LastName,'') as StudentName,
S.FatherName,S.MobileNo,E.EnrollID,E.RollNo from Enrollments E 
left join Students S ON E.StudentID=S.StudentID where E.SectionID=@SectionID Order By S.FirstName",
            "@SectionID", SqlDbType.Int, Common.ToInt(value.Section));

            return JsonConvert.SerializeObject(dt, Formatting.Indented);
        }

        [Route("api/Enrollments/UpdateRollNo")]
        [HttpPost]
        public string UpdateRollNo([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.UpdateRollNo, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JArray objJObject = value;
            DataTable dt = objJObject.ToObject<DataTable>();

            foreach (DataRow dr in dt.Rows)
            {
                Common.ExecuteNonQuery("Update Enrollments set RollNo=@RollNo where EnrollID=@EnrollID",
                    "@RollNo", SqlDbType.VarChar, Common.ToString(dr["RollNo"]),
                    "@EnrollID", SqlDbType.Int, Common.ToInt(dr["EnrollID"]));
            }

            return String.Empty;
        }
        // GET api/Enrollments/Id
        [Route("api/Enrollments/{Id}")]
        public string GetEnrollments(int Id)
        {
            Common.IsValidForm(Constants.Forms.Enrollments, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            EnrollmentsBL objEnrollmentsBL = new EnrollmentsBL(Common.GetConString());
            objEnrollmentsBL.Load(Id);
            Enrollments objEnrollments = objEnrollmentsBL.Data;

            if (Common.ToInt(objEnrollments.AYID) > 0 && objEnrollments.AYID != objLoggedUser.WPID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            return JsonConvert.SerializeObject(objEnrollmentsBL.Data);
        }


        // GET api/Enrollments/Id
        [Route("api/Enrollments/Students/{Id}")]
        public string GetEnrollmentStudents(int Id)
        {
            Common.IsValidForm(Constants.Forms.Enrollments, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            int enrollID = Common.ToInt(Common.GetDBScalar("select EnrollID from Enrollments where StudentID =@StudentID and AYID=@AYID",
                "@StudentID", SqlDbType.Int, Id,
                "@AYID", SqlDbType.Int, objLoggedUser.WPID));

            EnrollmentsBL objEnrollmentsBL = new EnrollmentsBL(Common.GetConString());
            objEnrollmentsBL.Load(enrollID);
            Enrollments objEnrollments = objEnrollmentsBL.Data;

            if (Common.ToInt(objEnrollments.AYID) > 0 && objEnrollments.AYID != objLoggedUser.WPID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            objEnrollments.StudentID = Id;
            return JsonConvert.SerializeObject(objEnrollmentsBL.Data);
        }

        // POST api/Enrollments/
        public string Post([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.Enrollments, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser.WPID <= 0)
            {
                throw new Exception("Please define Academic Year");
            }
            JObject objJObject = value;
            Enrollments objEnrollments = objJObject.ToObject<Enrollments>();
            EnrollmentsBL objEnrollmentsBL = new EnrollmentsBL(Common.GetConString());
            objEnrollmentsBL.Data = objEnrollments;

            if (Common.ToInt(objEnrollments.AYID) > 0 && objEnrollments.AYID != objLoggedUser.WPID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            EnrollmentsValidator validator = new EnrollmentsValidator();
            ValidationResult results = validator.Validate(objEnrollments);


            //RollNo validation
            DataTable dt = Common.GetDBResultParameterized(@"Select 1 from Enrollments where RollNo=@RollNo and SectionID=@SectionID
and EnrollID<>@EnrollID"
                , "@RollNo", SqlDbType.VarChar, Common.ToString(objEnrollments.RollNo)
                , "@SectionID", SqlDbType.Int, Common.ToString(objEnrollments.SectionID)
                , "@EnrollID", SqlDbType.Int, Common.ToInt(objEnrollments.EnrollID));
            if (dt.Rows.Count > 0)
            {
                ValidationFailure emailError = new ValidationFailure("RollNo", "Roll No. is already assigned, please choose another Roll No.");
                results.Errors.Add(emailError);
            }

            //Subject validation
            int totalSubjects = Common.ToInt(Common.GetDBScalar("select TotalSubjects from ClassMaster where ClassID in (Select ClassID from SectionMaster where SectionID=@SectionID)",
                "@SectionID", SqlDbType.Int, objEnrollments.SectionID));

            if (totalSubjects != objEnrollments.EnrollmentSubjectsList.Count(Obj => Obj.Selected == true))
            {
                ValidationFailure subError = new ValidationFailure("SectionID", "Total Selected Subject must be " + totalSubjects + ".");
                results.Errors.Add(subError);
            }

            if (results.IsValid)
            {
                if (objEnrollmentsBL.IsNew)
                {
                    objEnrollments.AYID = objLoggedUser.WPID;
                }
                objEnrollmentsBL.Update();
                return JsonConvert.SerializeObject(objEnrollmentsBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        // DELETE api/Enrollments/5
        [Route("api/Enrollments/{Id}")]
        [HttpDelete]
        public string Delete(int Id)
        {
            Common.IsValidForm(Constants.Forms.Enrollments, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            EnrollmentsBL objEnrollmentsBL = new EnrollmentsBL(Common.GetConString());
            objEnrollmentsBL.Load(Id);
            Enrollments objEnrollments = objEnrollmentsBL.Data;

            if (Common.ToInt(objEnrollments.AYID) > 0 && objEnrollments.AYID != objLoggedUser.WPID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            int count = Common.HasDependentRecord(Id, "Enrollments");
            if (count > 0)
                return "You cannot delete this row, some transctions has already made";
            objEnrollmentsBL.Delete(Id);
            return String.Empty;
        }
    }
    public class EnrollmentsValidator : AbstractValidator<Enrollments>
    {
        public EnrollmentsValidator()
        {
            RuleFor(obj => obj.RollNo).NotEmpty();
            RuleFor(obj => obj.SectionID).NotEmpty();
            RuleFor(obj => obj.StudentID).NotEmpty();
        }
    }
}

