using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;

namespace SampleAngular.Api
{
    public class ExamTimeTableController : ApiController
    {
        // GET api/ExamTimeTable
        [Route("api/ExamTimeTable/GetTimeTableList/")]
        [HttpPost]
        public string GetExamTimeTable([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.ExamTimeTable, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser.WPID <= 0)
            {
                throw new Exception("Please define Academic Year");
            }
            int classID = Common.ToInt(value.Class);
            int examID = Common.ToInt(Common.GetDBScalar("select * from Exams where SocID=@SocID and AYID=@AYID",
                "@SocID", SqlDbType.Int, objLoggedUser.SocID,
                "@AYID", SqlDbType.Int, objLoggedUser.WPID));
            string examType = Common.ToString(value.ExamType);

            DataTable dt = Common.GetDBResultParameterized(@"select ETT.ExamTimeID, ETT.ExamDate,
ETT.FromTime,
ETT.ToTime
,S.SubjectName+case when ISNULL(ES.PaperName,'')='' then '' else ' - '+ES.PaperName end as SubjectName
,ES.SubjectID,ES.ExamSubjectID
 from ExamTimeTable ETT
right outer join ExamSubjects ES ON ES.ExamSubjectID = ETT.ExamSubjectID and ETT.ClassID=@classID and ETT.ExamType=@ExamType
left join Subjects S ON ES.SubjectID=S.SubjectID
where exists
(Select 1 from ExamSubjectClass ESC where ESC.ClassID=@classID and ES.ExamSubjectID=ESC.ExamSubjectID)
and ES.ExamID=@examID order by ETT.ExamDate",
            "@classID", SqlDbType.VarChar, classID,
            "@examID", SqlDbType.Int, examID,
            "@ExamType", SqlDbType.VarChar, examType);
            return JsonConvert.SerializeObject(dt, Formatting.Indented);
        }

        [Route("api/ExamTimeTable/SaveTimeTableList")]
        [HttpPost]
        public string SaveTimeTableList([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.ExamTimeTable, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser.WPID <= 0)
            {
                throw new Exception("Please define Academic Year");
            }

            JArray objJObject = value.Val;
            DataTable dtTP = objJObject.ToObject<DataTable>();
            int classID = Common.ToInt(value.Class);
            int examID = Common.ToInt(Common.GetDBScalar("select * from Exams where SocID=@SocID and AYID=@AYID",
                "@SocID", SqlDbType.Int, objLoggedUser.SocID,
                "@AYID", SqlDbType.Int, objLoggedUser.WPID));
            string examType = Common.ToString(value.ExamType);

            ExamTimeTableBL objExamTimeTableBL = new ExamTimeTableBL(Common.GetConString());

            foreach (DataRow drTP in dtTP.Rows)
            {
                if (Common.ToDate(drTP["ExamDate"], null) != null)
                {
                    ExamTimeTable objExamTimeTable = new ExamTimeTable();
                    objExamTimeTable.ClassID = classID;
                    objExamTimeTable.ExamDate = Common.ToDate(drTP["ExamDate"]);
                    objExamTimeTable.ExamSubjectID = Common.ToInt(drTP["ExamSubjectID"]);
                    objExamTimeTable.ExamTimeID = Common.ToInt(drTP["ExamTimeID"]);
                    objExamTimeTable.FromTime = Common.ToInt(drTP["FromTime"]);
                    objExamTimeTable.ToTime = Common.ToInt(drTP["ToTime"]);
                    objExamTimeTable.ExamType = examType;

                    objExamTimeTableBL.Data = objExamTimeTable;
                    objExamTimeTableBL.Update();
                }
            }

            return String.Empty;
        }

        [Route("api/ExamTimeTable/CopyTimeTable")]
        [HttpPost]
        public string CopyTimeTable([FromBody]dynamic value)
        {
            try
            {
                Common.IsValidForm(Constants.Forms.ExamTimeTable, Request);
                LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
                if (objLoggedUser.WPID <= 0)
                {
                    throw new Exception("Please define Academic Year");
                }
                int fromClassID = Common.ToInt(value.Class);
                int toClassID = Common.ToInt(value.ToClass);
                int examID = Common.ToInt(Common.GetDBScalar("select * from Exams where SocID=@SocID and AYID=@AYID",
               "@SocID", SqlDbType.Int, objLoggedUser.SocID,
               "@AYID", SqlDbType.Int, objLoggedUser.WPID));
                string examType = Common.ToString(value.ExamType);

                if (fromClassID == toClassID)
                {
                    return "'From' Class and 'To' must not be same";
                }
                //Load To Class all data
                DataTable dt = Common.GetDBResultParameterized(@"select ETT.ExamTimeID, ETT.ExamDate,
ETT.FromTime,
ETT.ToTime
,S.SubjectName+case when ES.PaperName='' then '' else ' - '+ES.PaperName end as SubjectName
,ES.SubjectID,ES.ExamSubjectID
 from ExamTimeTable ETT
right outer join ExamSubjects ES ON ES.ExamSubjectID = ETT.ExamSubjectID and ETT.ClassID=@classID and ETT.ExamType=@ExamType
left join Subjects S ON ES.SubjectID=S.SubjectID
where exists
(Select 1 from ExamSubjectClass ESC where ESC.ClassID=@classID and ES.ExamSubjectID=ESC.ExamSubjectID)
and ES.ExamID=@examID order by ETT.ExamDate",
                "@classID", SqlDbType.VarChar, toClassID,
                "@examID", SqlDbType.Int, examID,
                "@ExamType", SqlDbType.VarChar, examType);

                //Load Frop Class all data
                DataTable dtTP = Common.GetDBResultParameterized(@"select ETT.ExamTimeID, ETT.ExamDate,
ETT.FromTime,
ETT.ToTime
,S.SubjectName+case when ES.PaperName='' then '' else ' - '+ES.PaperName end as SubjectName
,ES.SubjectID,ES.ExamSubjectID
 from ExamTimeTable ETT
right outer join ExamSubjects ES ON ES.ExamSubjectID = ETT.ExamSubjectID and ETT.ClassID=@classID and ETT.ExamType=@ExamType
left join Subjects S ON ES.SubjectID=S.SubjectID
where exists
(Select 1 from ExamSubjectClass ESC where ESC.ClassID=@classID and ES.ExamSubjectID=ESC.ExamSubjectID)
and ES.ExamID=@examID order by ETT.ExamDate",
                "@classID", SqlDbType.VarChar, fromClassID,
                "@examID", SqlDbType.Int, examID,
                "@ExamType", SqlDbType.VarChar, examType);

                ExamTimeTableBL objExamTimeTableBL = new ExamTimeTableBL(Common.GetConString());

                foreach (DataRow dr in dt.Rows)
                {
                    DataRow[] drArray =  dtTP.Select("ExamSubjectID=" + Common.ToInt(dr["ExamSubjectID"]));
                    if (drArray.Length <= 0)
                        continue;

                    DataRow drTP = drArray[0];
                    if (Common.ToDate(drTP["ExamDate"], null) != null)
                    {
                        ExamTimeTable objExamTimeTable = new ExamTimeTable();
                        objExamTimeTable.ClassID = toClassID;
                        objExamTimeTable.ExamDate = Common.ToDate(drTP["ExamDate"]);
                        objExamTimeTable.ExamSubjectID = Common.ToInt(drTP["ExamSubjectID"]);
                        objExamTimeTable.ExamTimeID = Common.ToInt(dr["ExamTimeID"]);
                        objExamTimeTable.FromTime = Common.ToInt(drTP["FromTime"]);
                        objExamTimeTable.ToTime = Common.ToInt(drTP["ToTime"]);
                        objExamTimeTable.ExamType = examType;

                        objExamTimeTableBL.Data = objExamTimeTable;
                        objExamTimeTableBL.Update();
                    }

                }

                return String.Empty;
            }
            catch (Exception Ex)
            {
                return Ex.Message;
            }
        }


        // POST api/ExamTimeTable/
        public string Post([FromBody]dynamic value)
        {
            JObject objJObject = value;
            ExamTimeTable objExamTimeTable = objJObject.ToObject<ExamTimeTable>();
            ExamTimeTableBL objExamTimeTableBL = new ExamTimeTableBL(Common.GetConString());
            objExamTimeTableBL.Data = objExamTimeTable;

            ExamTimeTableValidator validator = new ExamTimeTableValidator();
            ValidationResult results = validator.Validate(objExamTimeTable);

            if (results.IsValid)
            {
                objExamTimeTableBL.Update();
                return JsonConvert.SerializeObject(objExamTimeTableBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        // DELETE api/ExamTimeTable/5
        [Route("api/ExamTimeTable/{Id}")]
        [HttpDelete]
        public string Delete(int Id)
        {
            Common.IsValidForm(Constants.Forms.ExamTimeTable, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            ExamTimeTableBL objExamTimeTableBL = new ExamTimeTableBL(Common.GetConString());
            objExamTimeTableBL.Load(Id);
            ExamTimeTable objExamTimeTable = objExamTimeTableBL.Data;

            int count = Common.HasDependentRecord(Common.ToInt(objExamTimeTable.ExamSubjectID), "ExamTimeTable");
            if (count > 0)
                return "You cannot delete this row, some transctions has already made";

            objExamTimeTableBL.Delete(Id);
            return String.Empty;
        }
    }
    public class ExamTimeTableValidator : AbstractValidator<ExamTimeTable>
    {
        public ExamTimeTableValidator()
        {

            RuleFor(obj => obj.ClassID).NotEmpty();
            RuleFor(obj => obj.ExamDate).NotEmpty();
            RuleFor(obj => obj.ExamSubjectID).NotEmpty();
            RuleFor(obj => obj.FromTime).NotEmpty();
            RuleFor(obj => obj.ToTime).NotEmpty();
        }
    }
}

