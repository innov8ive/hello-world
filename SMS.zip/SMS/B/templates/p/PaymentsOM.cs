using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

    [Serializable]
    [Table(Name = "dbo.Payments")]
    public class Payments
    {

        private System.Nullable<decimal> _Amount;
        private System.Nullable<int> _EnrollID;
        private System.Nullable<int> _PaidGEGroupID;
        private System.Nullable<DateTime> _PaidRefDate;
        private string _PaidRefNo;
        private System.Nullable<int> _PaidToGLID;
        private System.Nullable<DateTime> _PaymentDate;
        private System.Nullable<int> _PaymentID;
        private string _PaymentMode;
        private string _Remarks;
        private System.Nullable<int> _SocID;
        private Nullable<int> _CollectedBy;
        private string _PlatformBillID;

        [Column(Storage = "_PlatformBillID")]
        public string PlatformBillID
        {
            get
            {
                return _PlatformBillID;
            }
            set
            {
                _PlatformBillID = value;
            }
        }

        [Column(Storage = "_CollectedBy")]
        public Nullable<int> CollectedBy
        {
            get { return _CollectedBy; }
            set { _CollectedBy = value; }
        }

        [Column(Storage = "_Amount")]
        public System.Nullable<decimal> Amount
        {
            get
            {
                return _Amount;
            }
            set
            {
                _Amount = value;
            }
        }

        [Column(Storage = "_EnrollID")]
        public System.Nullable<int> EnrollID
        {
            get
            {
                return _EnrollID;
            }
            set
            {
                _EnrollID = value;
            }
        }

        [Column(Storage = "_PaidGEGroupID")]
        public System.Nullable<int> PaidGEGroupID
        {
            get
            {
                return _PaidGEGroupID;
            }
            set
            {
                _PaidGEGroupID = value;
            }
        }

        [Column(Storage = "_PaidRefDate")]
        public System.Nullable<DateTime> PaidRefDate
        {
            get
            {
                return _PaidRefDate;
            }
            set
            {
                _PaidRefDate = value;
            }
        }

        [Column(Storage = "_PaidRefNo")]
        public string PaidRefNo
        {
            get
            {
                return _PaidRefNo;
            }
            set
            {
                _PaidRefNo = value;
            }
        }

        [Column(Storage = "_PaidToGLID")]
        public System.Nullable<int> PaidToGLID
        {
            get
            {
                return _PaidToGLID;
            }
            set
            {
                _PaidToGLID = value;
            }
        }

        [Column(Storage = "_PaymentDate")]
        public System.Nullable<DateTime> PaymentDate
        {
            get
            {
                return _PaymentDate;
            }
            set
            {
                _PaymentDate = value;
            }
        }

        [Column(Storage = "_PaymentID")]
        public System.Nullable<int> PaymentID
        {
            get
            {
                return _PaymentID;
            }
            set
            {
                _PaymentID = value;
            }
        }

        [Column(Storage = "_PaymentMode")]
        public string PaymentMode
        {
            get
            {
                return _PaymentMode;
            }
            set
            {
                _PaymentMode = value;
            }
        }

        [Column(Storage = "_Remarks")]
        public string Remarks
        {
            get
            {
                return _Remarks;
            }
            set
            {
                _Remarks = value;
            }
        }

        [Column(Storage = "_SocID")]
        public System.Nullable<int> SocID
        {
            get
            {
                return _SocID;
            }
            set
            {
                _SocID = value;
            }
        }


        public System.Collections.Generic.List<PaymentDetails> PaymentDetailsList { get; set; }
        public Hashtable Types { get; set; }
    }


    [Serializable]
    [Table(Name = "dbo.PaymentDetails")]
    public class PaymentDetails
    {

        private System.Nullable<decimal> _Amount;
        private System.Nullable<decimal> _PayableAmount;
        private System.Nullable<int> _ClassFeeID;
        private System.Nullable<int> _PaymentID;
        private string _ChgName;
        private System.Nullable<DateTime> _DueDate;

        [Column(Storage = "_DueDate")]
        public System.Nullable<DateTime> DueDate
        {
            get { return _DueDate; }
            set { _DueDate = value; }
        }

        [Column(Storage = "_ChgName")]
        public string ChgName
        {
            get { return _ChgName; }
            set { _ChgName = value; }
        }


        [Column(Storage = "_Amount")]
        public System.Nullable<decimal> Amount
        {
            get
            {
                return _Amount;
            }
            set
            {
                _Amount = value;
            }
        }


        [Column(Storage = "_PayableAmount")]
        public System.Nullable<decimal> PayableAmount
        {
            get
            {
                return _PayableAmount;
            }
            set
            {
                _PayableAmount = value;
            }
        }

        [Column(Storage = "_ClassFeeID")]
        public System.Nullable<int> ClassFeeID
        {
            get
            {
                return _ClassFeeID;
            }
            set
            {
                _ClassFeeID = value;
            }
        }



        [Column(Storage = "_PaymentID")]
        public System.Nullable<int> PaymentID
        {
            get
            {
                return _PaymentID;
            }
            set
            {
                _PaymentID = value;
            }
        }

    }


}
