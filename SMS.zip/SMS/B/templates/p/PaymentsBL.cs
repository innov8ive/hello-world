using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
    [Serializable]
    public class PaymentsBL
    {

        #region Declaration
        private string connectionString;
        Payments _Payments;
        public Payments Data
        {
            get { return _Payments; }
            set { _Payments = value; }
        }
        public bool IsNew
        {
            get { return (_Payments.PaymentID <= 0 || _Payments.PaymentID == null); }
        }
        #endregion

        #region Constructor
        public PaymentsBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private PaymentsDL CreateDL()
        {
            return new PaymentsDL(connectionString);
        }
        public void New()
        {
            _Payments = new Payments();
        }
        public void Load(int PaymentID)
        {
            var PaymentsObj = this.CreateDL();
            _Payments = PaymentID <= 0 ? PaymentsObj.Load(-1) : PaymentsObj.Load(PaymentID);
        }
        public void Load(string platformBillID)
        {
            var PaymentsObj = this.CreateDL();
            _Payments = PaymentsObj.Load(platformBillID);
        }
        public DataTable LoadAllPayments()
        {
            var PaymentsDLObj = CreateDL();
            return PaymentsDLObj.LoadAllPayments();
        }
        public bool Update()
        {
            var PaymentsDLObj = CreateDL();
            return PaymentsDLObj.Update(this.Data);
        }
        public bool Delete(int PaymentID)
        {
            var PaymentsDLObj = CreateDL();
            return PaymentsDLObj.Delete(PaymentID);
        }
        public bool CreatePayment(int enrollID, int socID, DataTable dtTP, string platformBillID)
        {
            PaymentsBL objPaymentsBL = new PaymentsBL(connectionString);
            objPaymentsBL.Load(platformBillID);
            Payments objPayments = objPaymentsBL.Data;
            objPayments.EnrollID = enrollID;
            objPayments.SocID = socID;
            objPayments.CollectedBy = 0;
            objPayments.PlatformBillID = platformBillID;
            objPayments.PaymentMode = "Online";
            objPayments.PaidRefNo = platformBillID;
            objPayments.PaidRefDate = DateTime.Today;
            objPayments.PaymentDate = DateTime.Today;
            objPayments.Remarks = "Online Payment through UPI - " + platformBillID;
            objPayments.PaymentDetailsList = new List<PaymentDetails>();
            foreach (DataRow dr in dtTP.Rows)
            {
                if (Convert.ToDecimal(dr["Amount"]) > 0)
                {
                    PaymentDetails objPaymentDetails = new PaymentDetails();
                    objPaymentDetails.Amount = Convert.ToDecimal(dr["Amount"]);
                    objPaymentDetails.ClassFeeID = Convert.ToInt32(dr["ClassFeeID"]);
                    objPayments.PaymentDetailsList.Add(objPaymentDetails);
                }
            }
            objPayments.Amount = objPayments.PaymentDetailsList.Sum(Obj => Obj.Amount);
            objPaymentsBL.Data = objPayments;
            if (objPaymentsBL.Update() == true)
            {
                return true;
            }
            else
            {
                return false;
            }

        }
        #endregion
    }
}
