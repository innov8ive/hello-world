using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
    public class PaymentsDL
    {

        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public PaymentsDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public Payments Load(string platformBillID)
        {
            int paymentID = 0;
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("Select PaymentID from Payments where platformBillID=@platformBillID", con);
            cmd.Parameters.Add("@platformBillID", SqlDbType.VarChar, 50).Value = platformBillID;

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            if (dt.Rows.Count > 0)
            {
                paymentID = Convert.ToInt32(dt.Rows[0]["PaymentID"]);
            }
            return Load(paymentID);
        }
        public Payments Load(int PaymentID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            Payments objPayments = new Payments();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get Payments
                var resultPayments = dc.ExecuteQuery<Payments>("exec Get_Payments {0}", PaymentID).ToList();
                if (resultPayments.Count > 0)
                {
                    objPayments = resultPayments[0];
                }
                //Get PaymentDetails
                var resultPaymentDetails = dc.ExecuteQuery<PaymentDetails>("exec Get_PaymentDetails {0}", PaymentID).ToList();
                objPayments.PaymentDetailsList = resultPaymentDetails;
                objPayments.Types = new System.Collections.Hashtable();
                objPayments.Types["PaymentDetailsList"] = new PaymentDetails();
                dc.Dispose();
                return objPayments;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllPayments()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_Payments", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(Payments objPayments)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update Payments
                UpdatePayments(objPayments, trn);
                if (objPayments.PaymentID > 0)
                {

                    //Update PaymentDetails
                    DeletePaymentDetails(Convert.ToInt32(objPayments.PaymentID), trn);
                    foreach (PaymentDetails objPaymentDetails in objPayments.PaymentDetailsList)
                    {
                        objPaymentDetails.PaymentID = objPayments.PaymentID;
                        InsertIntoPaymentDetails(objPaymentDetails, trn);
                    }
                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int PaymentID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete PaymentDetails
                DeletePaymentDetails(PaymentID, trn);
                //Delete Payments
                DeletePayments(PaymentID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdatePayments(Payments objPayments, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_Payments", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@Amount", SqlDbType.Decimal).Value = objPayments.Amount;
                cmd.Parameters.Add("@EnrollID", SqlDbType.Int).Value = objPayments.EnrollID;
                cmd.Parameters.Add("@PaidGEGroupID", SqlDbType.Int).Value = objPayments.PaidGEGroupID;
                cmd.Parameters.Add("@PaidRefDate", SqlDbType.DateTime).Value = objPayments.PaidRefDate;
                cmd.Parameters.Add("@PaidRefNo", SqlDbType.VarChar, 50).Value = objPayments.PaidRefNo;
                cmd.Parameters.Add("@PaidToGLID", SqlDbType.Int).Value = objPayments.PaidToGLID;
                cmd.Parameters.Add("@PaymentDate", SqlDbType.DateTime).Value = objPayments.PaymentDate;
                cmd.Parameters.Add("@PaymentID", SqlDbType.Int).Value = objPayments.PaymentID;
                cmd.Parameters["@PaymentID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@PaymentMode", SqlDbType.VarChar, 50).Value = objPayments.PaymentMode;
                cmd.Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = objPayments.Remarks;
                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = objPayments.SocID;
                cmd.Parameters.Add("@CollectedBy", SqlDbType.Int).Value = objPayments.CollectedBy;
                cmd.Parameters.Add("@PlatformBillID", SqlDbType.VarChar, 50).Value = objPayments.PlatformBillID;

                cmd.ExecuteNonQuery();

                //after updating the Payments, update PaymentID
                objPayments.PaymentID = Convert.ToInt32(cmd.Parameters["@PaymentID"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeletePayments(int PaymentID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from Payments where PaymentID=@PaymentID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@PaymentID", SqlDbType.Int).Value = PaymentID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        public bool DeletePaymentDetails(int PaymentID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from PaymentDetails where PaymentID=@PaymentID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@PaymentID", SqlDbType.Int).Value = PaymentID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        public bool InsertIntoPaymentDetails(PaymentDetails objPaymentDetails, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Into_PaymentDetails", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Transaction = trn;


                cmd.Parameters.Add("@Amount", SqlDbType.Decimal).Value = objPaymentDetails.Amount;
                cmd.Parameters.Add("@ClassFeeID", SqlDbType.Int).Value = objPaymentDetails.ClassFeeID;
                cmd.Parameters.Add("@PaymentID", SqlDbType.Int).Value = objPaymentDetails.PaymentID;

                cmd.ExecuteNonQuery();

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        #endregion
    }
}
