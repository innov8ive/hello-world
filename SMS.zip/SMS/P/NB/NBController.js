var app = angular.module('starter');

app.controller('NBListCtrl', function ($scope, $http, $location, $state, $ionicFilterBar, User) {
    $scope.UserType = User.UserType;
    $scope = readyAngularGrid($scope, $http, 'api/NBList', 'NBID', 'NB');
    $scope.totalPages = 1;
    $scope.pagingOptions.pageSize = 10;
    $scope.searchNB = function () {
        $scope.pagingOptions.currentPage = 1;
        $scope.totalPages = 1;
        $scope.allData = [];
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };

    window.setTimeout(function () { $scope.searchNB(); }, 200);

    $scope.newNB = function () {
        $state.go('app.NBEdit', { 'NBID': 0 });
    };
    $scope.editNB = function (NBID) {
        $state.go('app.NBEdit', { 'NBID': NBID });
    };

    $scope.showFilterBar = function () {
        filterBarInstance = $ionicFilterBar.show({
            items: null,
            update: function (a, b) {
                if (b != null) {
                    $scope.filterOptions.filterText = b;
                    $scope.searchNB();
                }
            },
            delay: 500
        });
        window.setTimeout(function () { $('.filter-bar-search').val($scope.filterOptions.filterText); }, 200);
    };
    $scope.doRefresh = function () {
        //simulate async response
        $scope.searchNB();
    };
})
.controller('NBCtrl', function ($scope, $http, $location, $stateParams, $state) {
    var NBID = $stateParams.NBID;
    $scope.NB = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.NBSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.NBSubmitted = true;
        if ($scope.formNB.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/NB', $scope.NB, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.NB = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/NBList');
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/NB/' + NBID
        }).success(function (NB) {
            $scope.NB = JSON.parse(NB);
        });
    }, 100);

    $scope.toMarkup = function (text) {
        return toMarkup(text);
    };
    $scope.deleteNB = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        $http({
            method: 'DELETE',
            url: 'api/NB/' + $scope.NB.NBID
        }).success(function (result) {
            if (result == true)
                $state.go('app.NB');
        });
    };
});
app.controller('VLController', function ($scope, $http, $location, $state, $ionicFilterBar, User) {
    var EnrollID;
    if (localStorage["EnrollID"] != null)
        EnrollID = parseInt(localStorage["EnrollID"]);
    $scope.Filter = { EnrollID: EnrollID };

    $scope.UserType = User.UserType;
    $scope = readyAngularGrid($scope, $http, 'api/VehiclesList', 'VehID', 'Vehicles');
    $scope.totalPages = 1;
    $scope.pagingOptions.pageSize = 10;
    $scope.searchCP = function () {
        $scope.pagingOptions.currentPage = 1;
        $scope.totalPages = 1;
        $scope.allData = [];
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };

    window.setTimeout(function () { $scope.searchCP(); }, 200);

    $scope.showFilterBar = function () {
        filterBarInstance = $ionicFilterBar.show({
            items: null,
            update: function (a, b) {
                if (b != null) {
                    $scope.filterOptions.filterText = b;
                    $scope.searchCP();
                }
            },
            delay: 500
        });
        window.setTimeout(function () { $('.filter-bar-search').val($scope.filterOptions.filterText); }, 200);
    };
    $scope.doRefresh = function () {
        //simulate async response
        $scope.searchCP();
    };
    $scope.getDetails = function (CPID) {
        $state.go('app.VLDetails', { 'CPID': CPID });
    };
})
app.controller('VLDetailsController', function ($scope, $http, $location, $state, $stateParams) {
    var CPID = $stateParams.CPID;
    $scope.CP = {};
    $scope.searchCP = function () {
        $http({
            method: 'GET',
            url: 'api/Vehicles/'+CPID
        }).success(function (result) {
            $scope.CP = JSON.parse(result);
        });
    };

    window.setTimeout(function () { $scope.searchCP(); }, 200);
})

app.controller('NBListingCtrl', function ($scope, $http, $location, $state, User) {
    var EnrollID;
    if (localStorage["EnrollID"] != null)
        EnrollID = parseInt(localStorage["EnrollID"]);

    $scope.UserType = User.UserType;
    $scope.NBs = [];
    setTimeout(function () {
        $scope.searchNB();
    }, 100);
    $scope.searchNB = function () {
        $http({
            method: 'POST',
            url: 'api/NB/GetAllNBs',
            data: JSON.stringify({ EnrollID: EnrollID })
        }).success(function (NBs) {
           
            $scope.NBs = NBs;
            for (var j = 0; j < $scope.NBs.length; j++) {
                $scope.NBs[j].DetailsShort = $scope.NBs[j].Details.length > 100
                    ? $scope.NBs[j].Details.substring(0, 100) + '...' : $scope.NBs[j].Details;
            }
            $scope.$broadcast('scroll.refreshComplete');
        });
    };
    $scope.toMarkup = function (text) {
        return toMarkup(text);
    };
    $scope.doRefresh = function () {
        //simulate async response
        $scope.searchNB();
    };
    $scope.viewNB = function (NBID) {
        $state.go('app.NBDetails', { 'NBID': NBID });
    };
});

app.controller('AlertListingCtrl', function ($scope, $http, $location, $state, User) {

    $scope.UserType = User.UserType;
    $scope.NBs = [];
    setTimeout(function () {
        $scope.searchNB();
    }, 100);
  $scope.searchNB = function () {
    if (localStorage['alerts']) {
      $scope.NBs = JSON.parse(localStorage['alerts']);
    }
    $scope.$broadcast('scroll.refreshComplete');
    };
    $scope.toMarkup = function (text) {
        return toMarkup(text);
    };
    $scope.doRefresh = function () {
        //simulate async response
        $scope.searchNB();
    };
    $scope.deleteThis = function (itm) {
      const index = $scope.NBs.indexOf(itm);
      if (index > -1) { // only splice array when item is found
        $scope.NBs.splice(index, 1); // 2nd parameter means remove one item only
        localStorage['alerts'] = JSON.stringify($scope.NBs);
      }
    };
});
app.controller('NBDetailsCtrl', function ($scope, $http, $location, $stateParams, $state, $ionicModal) {
    var NBID = $stateParams.NBID;
    $scope.NB = {};

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/NB/' + NBID
        }).success(function (NB) {
            $scope.NB = JSON.parse(NB);
        });
    }, 100);

    $scope.toMarkup = function (text) {
        return toMarkup(text);
    };
  $ionicModal.fromTemplateUrl('image-modal.html', {
    scope: $scope,
    animation: 'slide-in-up'
  }).then(function (modal) {
    $scope.modal = modal;
  });

  $scope.openModal = function (Obj, $event) {
    if (Obj != '' && Obj != null) {
      $scope.imageSrc = Obj.startsWith('http') === true ? Obj : baseUrl + 'Download.aspx?type=profile&filepath=images/profile/' + Obj;
      $scope.modal.show();
      $event.stopPropagation();
    }
  };

  $scope.closeModal = function () {
    $scope.modal.hide();
  };
  $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
    if ($scope.modal.isShown()) {
      event.preventDefault();
      $scope.closeModal();
    }
  });
});
