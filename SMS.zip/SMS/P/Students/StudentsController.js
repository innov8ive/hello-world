var app = angular.module('starter');
app.value("PaymentData", {});
app.controller('StudentsListCtrl', function ($scope, $http, $location, $state, $ionicFilterBar, $ionicModal, User) {
  $scope.UserType = User.UserType;
  $scope.Filter = { Section: '', Name: '', SectionName: '' };
  $scope.baseUrl = baseUrl;
  $scope = readyAngularGrid($scope, $http, 'api/EnrollmentsList', 'EnrollID', 'Enrollments');
  $scope.totalPages = 1;
  $scope.pagingOptions.pageSize = 10;
  $scope.searchEnrollments = function () {
    $scope.pagingOptions.currentPage = 1;
    $scope.totalPages = 1;
    $scope.allData = [];
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
  };
  if (User.UserType == 3)
    window.setTimeout(function () { $scope.searchEnrollments(); }, 200);

  $scope.editEnrollments = function (EnrollID) {
    $state.go('app.Enrollments', { 'EnrollID': EnrollID });
  };

  $scope.showFilterBar = function () {
    filterBarInstance = $ionicFilterBar.show({
      items: null,
      update: function (a, b) {
        if (b != null) {
          $scope.Filter.Name = b;
          $scope.searchEnrollments();
        }
      },
      delay: 500
    });
    window.setTimeout(function () { $('.filter-bar-search').val($scope.filterOptions.filterText); }, 200);
  };
  $scope.doRefresh = function () {
    //simulate async response
    $scope.searchEnrollments();
  };
  $scope.bindSection = function () {
    $http({
      method: 'POST',
      url: 'api/Common/',
      data: JSON.stringify({ MethodName: 'GetSectionList', Data: null })
    }).success(function (data) {
      $scope.sectionlist = data;
    });
  }
  $scope.bindSection();

  $ionicModal.fromTemplateUrl('image-modal.html', {
    scope: $scope,
    animation: 'slide-in-up'
  }).then(function (modal) {
    $scope.modal = modal;
  });
  $scope.openModal = function (Obj, $event) {
    if (Obj != null && Obj != '') {
      $scope.imageSrc = baseUrl + 'Download.aspx?type=profile&filepath=images/profile/' + Obj;
      $scope.modal.show();
      $event.stopPropagation();
    }
  };

  $scope.closeModal = function () {
    $scope.modal.hide();
  };
  $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
    if ($scope.modal.isShown()) {
      event.preventDefault();
      $scope.closeModal();
    }
  });
  localStorage.removeItem("EnrollID");
});
app.controller('EnrollCtrl', function ($scope, $http, $location, $state, $stateParams, User) {
  var EnrollID = $stateParams.EnrollID;
  if (EnrollID != null)
    localStorage["EnrollID"] = EnrollID;
  else if (localStorage["EnrollID"] != null)
    EnrollID = parseInt(localStorage["EnrollID"]);

  $scope.fetchData = function () {
    sessionStorage.removeItem("dashboard");
    $scope.loadData();
    $http({
      method: 'POST',
      url: 'api/Enrollments/GetStudentDetails/',
      data: JSON.stringify({ EnrollID: EnrollID })
    }).success(function (data) {
      $scope.data = JSON.parse(data);
      $scope.data.Students.ImageUrl = baseUrl + '/Download.aspx?type=profile&filepath=images/profile/' + $scope.data.Students.ImageUrl;

    });
    $http({
      method: 'POST',
      url: 'api/Enrollments/GetEnrollmentDetails/',
      data: JSON.stringify({ EnrollID: EnrollID })
    }).success(function (data) {
      $scope.Main = JSON.parse(data);

    });
  };

  window.setTimeout(function () { $scope.fetchData() }, 200);

  $scope.openAbsence = function () {
    $state.go('app.Absence', { 'EnrollID': EnrollID });
  };
  $scope.openStatement = function () {
    $state.go('app.Statement', { 'EnrollID': EnrollID });
  };
  $scope.openAcademyPerfomance = function () {
    $state.go('app.AcademyPerfomance', { 'EnrollID': EnrollID });
  };
  $scope.openOtherDetails = function () {
    $state.go('app.OtherDetails', { 'EnrollID': EnrollID });
  };
  $scope.openTimeTable = function () {
    $state.go('app.TimeTable', { 'EnrollID': EnrollID });
  };
  $scope.openHomework = function () {
    $state.go('app.StudentHomeworks', { 'EnrollID': EnrollID });
  };

  $scope.UserType = User.UserType;
  $scope.loadData = function () {

    if (sessionStorage["dashboard"] != null) {
      var result = JSON.parse(sessionStorage["dashboard"]);
      $scope.setData(result);
    }
    else {
      $http({
        method: 'POST',
        url: 'api/Home/DashBoard',
        data: JSON.stringify({ EnrollID: EnrollID })
      }).success(function (result) {
        sessionStorage["dashboard"] = JSON.stringify(result);
        $scope.setData(result);

      }).error(function () {
        sessionStorage.removeItem("dashboard");
        if (navigator.splashscreen != null) {
          navigator.splashscreen.hide();
        }
        $scope.$broadcast('scroll.refreshComplete');
      });
    }
  };
  $scope.setData = function (result) {
    $scope.Vehicles = result.Vehicles;
    $scope.Polls = result.Polls;
    $scope.ParentMeetings = result.ParentMeetings;
    $scope.NB = result.NB;
    $scope.Calendar = result.Calendar;
    $scope.NewCalendar = result.NewCalendar;
    $scope.RecentForum = JSON.parse(result.RecentForum);
    if (navigator.splashscreen != null) {
      navigator.splashscreen.hide();
    }
    $scope.$broadcast('scroll.refreshComplete');

  };
  $scope.doRefresh = function () {
    $scope.fetchData();
  };

});
app.controller('AbsenceCtrl', function ($scope, $http, $location, $state, $stateParams) {
  var EnrollID = $stateParams.EnrollID;

  $scope.fetchData = function () {

    $http({
      method: 'POST',
      url: 'api/Enrollments/GetStudentAbsenceDetails/',
      data: JSON.stringify({ EnrollID: EnrollID })
    }).success(function (data) {
      $scope.data = JSON.parse(data);
    });
  };
  $scope.fetchData();
});
app.controller('StatementCtrl', function ($scope, $http, $location, $state, $stateParams) {
  var EnrollID = $stateParams.EnrollID;
  $scope.totalPayable = 0;
  $scope.fetchData = function () {

    $http({
      method: 'POST',
      url: 'api/Enrollments/GetStudentStatement/',
      data: JSON.stringify({ EnrollID: EnrollID })
    }).success(function (data) {
      $scope.data = JSON.parse(data);
      $scope.totalPayable = $scope.data.map(a => a.PayableAmount).reduce(function (a, b) {
        return a + b;
      });
    });
  };
  $scope.fetchData();
  $scope.payNow = function () {
    $state.go("app.Payment", { 'EnrollID': EnrollID });
  }
});
app.controller('PaymentCtrl', function ($scope, $http, $location, $state, $stateParams, PaymentData) {
  var EnrollID = $stateParams.EnrollID;
  $scope.cards = [];
  $scope.fetchData = function () {

    $http({
      method: 'POST',
      url: 'api/Enrollments/GetStudentStatementForPayment/',
      data: JSON.stringify({ EnrollID: EnrollID })
    }).success(function (data) {
      $scope.cards = JSON.parse(data);
    });
  };
  $scope.fetchData();

  $scope.FeeSelected = '';
  $scope.ClassFeeIDSelected = '';

  $scope.totalAmountSelected = function () {
    var totalAmount = 0;
    $scope.FeeSelected = '';
    $scope.ClassFeeIDSelected = '';
    for (var j = 0; j < $scope.cards.length; j++) {
      if ($scope.cards[j].Selected) {
        totalAmount += $scope.cards[j].Amount;
        $scope.FeeSelected += $scope.FeeSelected.length > 0 ? ', ' : '';
        $scope.FeeSelected += $scope.cards[j].ChgName + ' - ' + $scope.formatDate($scope.cards[j].DueDate);

        $scope.ClassFeeIDSelected += $scope.ClassFeeIDSelected.length > 0 ? ',' : '';
        $scope.ClassFeeIDSelected += $scope.cards[j].ClassFeeID;
      }
    }
    return totalAmount;
  };
  $scope.formatDate = function (date) {
    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    var d = new Date(date),
      month = '' + months[d.getMonth()],
      day = '' + d.getDate(),
      year = d.getFullYear();
    if (day.length < 2)
      day = '0' + day;

    return [month, year].join('/');
  };

  $scope.checkboxClick = function (c, $index) {
    var selected = c.Selected;
    for (var j = 0; j < $scope.cards.length; j++) {
      if (j <= $index && selected) {
        $scope.cards[j].Selected = selected;
      } else if (j > $index && !selected) {
        $scope.cards[j].Selected = selected;
      }
    }

  };

  $scope.payNow = function () {
    PaymentData.Amount = $scope.totalAmountSelected();
    PaymentData.Note = $scope.FeeSelected;
    PaymentData.ClassFeeIds = EnrollID + ':' + $scope.ClassFeeIDSelected;
    $state.go("app.PaymentStart", { 'EnrollID': EnrollID });
  };
});
app.controller('PaymentStartCtrl', function ($scope, $http, PaymentData, $interval, $state, $stateParams, $ionicHistory, PaymentData) {
  var EnrollID = $stateParams.EnrollID;
  $scope.PaymentData = PaymentData;
  $scope.PaymentData.EnrollID = EnrollID;
  $scope.payData = [1];
  $scope.lastStatus = '';
  $scope.payNow = function () {
    $http.post('api/Common/GeneratePaymentLink', JSON.stringify($scope.PaymentData)).then(function (response) {
      $scope.payData = [];
      $scope.lastStatus = 'BILL_CREATED';
      if (response && response.data) {
        $scope.payData = response.data.split('`');
        console.log($scope.payData[0]);
        console.log($scope.payData[1]);
        $scope.checkStatus();
      }
    }, function (response) {
      $scope.payData = [];
      alert('Something went wrong!!');
    });


  }

  var stop;
  $scope.checkStatus = function () {
    if (angular.isDefined(stop)) return;
    $http.get('api/Common/GetToken').then(function (response) {
      if (response && response.data) {
        console.log(response.data);
      }
    }, function (response) {
      $scope.stopStatus();
    });
    stop = $interval(function () {
      $scope.PaymentData.RefNo = $scope.payData[0];      
      $http.post('api/Common/CheckLinkStatus', JSON.stringify($scope.PaymentData)).then(function (response) {
        if (response && response.data) {
          $scope.lastStatus = response.data;
          if (response.data == 'PAYMENT_FAILED' || response.data == 'SETTLEMENT_SUCCESSFUL'
            || response.data == 'SETTLEMENT_FAILED' || response.data == 'BILL_EXPIRED') {
            $scope.stopStatus();
            if (response.data == 'SETTLEMENT_SUCCESSFUL' || response.data == 'PAYMENT_FAILED') {
              $ionicHistory.nextViewOptions({
                disableBack: true
              });
              window.setTimeout(function () { $state.go("app.NormalStudentsList"); }, 3000);
            }
          }
        }
      }, function (response) {
        $scope.stopStatus();
      });
    }, 10000);
  };
  $scope.stopStatus = function () {
    if (angular.isDefined(stop)) {
      $interval.cancel(stop);
      stop = undefined;
    }
  };
  $scope.payNow();
  $scope.check = function () {
    $scope.PaymentData.RefNo = $scope.payData[0];
    $http.post('api/Common/CheckLinkStatus', JSON.stringify($scope.PaymentData)).then(function (response) {
      if (response && response.data) {
        $scope.lastStatus = response.data;
        if (response.data == 'PAYMENT_FAILED' || response.data == 'SETTLEMENT_SUCCESSFUL'
          || response.data == 'SETTLEMENT_FAILED' || response.data == 'BILL_EXPIRED') {
         
          if (response.data == 'SETTLEMENT_SUCCESSFUL' || response.data == 'PAYMENT_FAILED') {
            window.setTimeout(function () { $state.go('app.NormalStudentsList'); }, 2000);
          }
        }
      }
    }, function (response) {
      
    });
  };
});
app.controller('AcademyPerfomanceCtrl', function ($scope, $http, $location, $state, $stateParams) {
  var EnrollID = $stateParams.EnrollID;
  $scope.fetchData = function () {

    $http({
      method: 'POST',
      url: 'api/Enrollments/GetStudentTestDetails/',
      data: JSON.stringify({ EnrollID: EnrollID })
    }).success(function (data) {
      $scope.data = data;
    });
  };
  $scope.fetchData();

  $scope.getTotal = function (itm) {
    var totalMarks = itm.Subjects.map(a => a.Marks).reduce(function (a, b) {
      return a + b;
    });
    var totalMaxMarks = itm.Subjects.map(a => a.MaxMarks).reduce(function (a, b) {
      return a + b;
    });

    return totalMarks + '/' + totalMaxMarks;
  };
});
app.controller('OtherDetailsCtrl', function ($scope, $http, $location, $state, $stateParams) {
  var EnrollID = $stateParams.EnrollID;

  $scope.fetchData = function () {

    $http({
      method: 'POST',
      url: 'api/Enrollments/GetStudentDetails/',
      data: JSON.stringify({ EnrollID: EnrollID })
    }).success(function (data) {
      $scope.data = JSON.parse(data);
    });
  };
  $scope.fetchData();
});
app.controller('TimeTableCtrl', function ($scope, $http, $location, $state, $stateParams) {
  var EnrollID = $stateParams.EnrollID;
  $scope.alldata = [];


  $scope.fetchData = function () {

    $http({
      method: 'POST',
      url: 'api/Enrollments/GetStudentTimeTableDetails/',
      data: JSON.stringify({ EnrollID: EnrollID })
    }).success(function (data) {
      $scope.alldata = JSON.parse(data);
      $scope.days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    });
  };
  $scope.fetchData();

  $scope.getData = function (day) {
    return findByValue($scope.alldata, 'Day', day);
  }
});
