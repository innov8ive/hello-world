var app = angular.module('starter');
app.controller('HomeworksListCtrl', function ($scope, $http, $location, $state, $filter, $ionicFilterBar, User) {

  $scope = readyAngularGrid($scope, $http, 'api/HomeworksList', 'ID', 'Homeworks');
  $scope.Filter = { day: 0, LogDate: '', Section: '', SectionName: '' };
  var date = new Date();
  $scope.Filter.LogDate = $filter('date')(date, 'dd-MMM-yyyy');
  $scope.date = new Date();
  $scope.date.setDate($scope.date.getDate() + $scope.Filter.day);
  $scope.totalPages = 1;
  $scope.pagingOptions.pageSize = 100;
  $scope.searchHomeworks = function () {
    $scope.pagingOptions.currentPage = 1;
    $scope.totalPages = 1;
    $scope.allData = [];
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
  };


  $scope.newHomeworks = function () {
    $state.go('app.HomeworksEdit', { 'ID': 0 });
  };
  $scope.editHomeworks = function (ID) {
    $state.go('app.HomeworksEdit', { 'ID': ID });
  };
  $scope.nextMonth = function () {
    $scope.Filter.day++;
    $scope.searchHomeworks();
    $scope.date = new Date();
    $scope.date.setDate($scope.date.getDate() + $scope.Filter.day);
    $scope.Filter.LogDate = $filter('date')($scope.date, 'dd-MMM-yyyy');
  };
  $scope.preMonth = function () {
    $scope.Filter.day--;
    $scope.searchHomeworks();
    $scope.date = new Date();
    $scope.date.setDate($scope.date.getDate() + $scope.Filter.day);
    $scope.Filter.LogDate = $filter('date')($scope.date, 'dd-MMM-yyyy');
  };
  $scope.showFilterBar = function () {
    filterBarInstance = $ionicFilterBar.show({
      items: null,
      update: function (a, b) {
        if (b != null) {
          $scope.filterOptions.filterText = b;
          $scope.searchMT();
        }
      },
      delay: 500
    });
    window.setTimeout(function () { $('.filter-bar-search').val($scope.filterOptions.filterText); }, 200);
  };
  $scope.doRefresh = function () {
    //simulate async response
    $scope.searchHomeworks();
  };
  $scope.bindSection = function () {
    var methodName = 'GetTeacherSectionList';
    if (User.UserType == 2)
      methodName = 'GetSectionList';
    $http({
      method: 'POST',
      url: 'api/Common/',
      data: JSON.stringify({ MethodName: methodName, Data: null })
    }).success(function (data) {
      $scope.sectionlist = data;

    });
  }
  $scope.bindSection();

  $scope.$watch('Filter.Section', function (newVal, oldVal) {
    if (newVal != oldVal) {
      if ($scope.Filter.Section != '') {
        $scope.searchHomeworks();
      }
    }
  });
  $scope.resolveURL = function (imageUrl) {
    return imageUrl.startsWith('http') ? imageUrl : baseUrl + 'Download.aspx?fileID=' + imageUrl;
  }
});

app.controller('HomeworksCtrl', function ($scope, $http, $location, $filter, $stateParams, User) {
  var ID = $stateParams.ID;
  $scope.Filter = { SectionID: '', HDate: '', SubjectID: '' };
  $scope.Imgs = [];
  $scope.images = [];
  $scope.Data = {};
  var date = new Date();
  $scope.Filter.HDate = $filter('date')(date, 'dd-MMM-yyyy');
  $scope.$watch('Filter.SectionID', function (newVal, oldVal) {
    $scope.onSectionChanged();
  });
  $scope.onSectionChanged = function () {
    $scope.Filter.SubjectID = '';
    if ($scope.Filter.SectionID != '') {

      $http({
        method: 'POST',
        url: 'api/Common/',
        data: JSON.stringify({ MethodName: 'GetClassSubjectList', query: $scope.Filter.SectionID })
      }).success(function (data) {
        $scope.subjectlist = data;

        if ($scope.Homeworks.ID > 0) {
          $scope.Filter.SubjectID = $scope.Homeworks.SubjectID.toString();
        }
      });
    }
  };
  $scope.onSubjectChanged = function () {
    if ($scope.Filter.SectionID != '' && $scope.Filter.SubjectID != '') {
      $http({
        method: 'POST',
        url: 'api/Homeworks/LoadHomeworks',
        data: JSON.stringify($scope.Filter)
      }).success(function (data) {
        $scope.Homeworks = JSON.parse(data);
      });
    }
  };
  $scope.bindSection = function () {
    var methodName = 'GetTeacherSectionList';
    if (User.UserType == 2)
      methodName = 'GetSectionList';
    $http({
      method: 'POST',
      url: 'api/Common/',
      data: JSON.stringify({ MethodName: methodName, Data: null })
    }).success(function (data) {
      $scope.sectionlist = data;

    });
  }
  $scope.bindSection();

  $scope.saveHomework = function () {

    $http({
      method: 'POST',
      url: 'api/Homeworks/UpdateHomeworks',
      data: JSON.stringify({
        Data: $scope.Homeworks, HDate: $scope.Filter.HDate
        , SectionID: $scope.Filter.SectionID, SubjectID: $scope.Filter.SubjectID
      })
    }).success(function (data) {
      $scope.Data = JSON.parse(data);
      if ($scope.Data.ID > 0) {
        swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
      }
      else {
        swal({ title: "Data not saved successfully!", type: "error", timer: 3000, showConfirmButton: false });
      }
    });
  };

  setTimeout(function () {
    $http({
      method: 'GET',
      url: 'api/Homeworks/' + ID
    }).success(function (Homeworks) {
      $scope.Homeworks = JSON.parse(Homeworks);
      if ($scope.Homeworks.ID > 0) {
        $scope.Filter.SectionID = $scope.Homeworks.SectionID;
        $scope.Filter.SectionName = $scope.Homeworks.SectionName;
        $scope.searchImg();
      }
      $scope.onSectionChanged();
    });
  }, 100);
  $scope.resolveURL = function (imageUrl) {
    return imageUrl.startsWith('http') ? imageUrl : baseUrl + 'Download.aspx?fileID=' + imageUrl;
  };
  $scope.searchImg = function () {
    $http({
      method: 'POST',
      url: 'api/Homeworks/ImgList/',
      data: JSON.stringify({ HWID: $scope.Homeworks.ID })
    }).success(function (Imgs) {
      $scope.Imgs = Imgs;
      $scope.images = [];
      for (var j = 0; j < Imgs.length; j++) {
        var objImg = Imgs[j];
        $scope.images.push({ Id: objImg.ImgID, img: objImg.ImageUrl.startsWith('http') ? objImg.ImageUrl : baseImageUrl + objImg.ImageUrl });
      }
    });
  };
  $scope.deleteFile = function (Id) {
    if (confirm('Are you sure want to delete?')) {
      $http({
        method: 'POST',
        url: 'api/Homeworks/DeleteImg/',
        data: JSON.stringify({ HWID: Id })
      }).success(function () {
        $scope.searchImg();
      });
    }
  };
  $scope.choosePhoto = function () {
    try {
      Capacitor.Plugins.Camera.getPhoto({
        quality: 75,
        allowEditing: true,
        resultType: 'Base64'
      }).then(function (img) {
        if (img == null) return;
        showLoading();
        $.post(baseUrl + 'FileUploadHandler.ashx', {
          type: 'ImageFile', data: img.base64String
          , contentType: 'image/jpeg', HWID: $scope.Homeworks.ID, DataType: 'HW'
        }, function (result, a, b, c) {
          hideLoading();
          fuResult = result.split('|');
          if (fuResult.length == 3) {
            alert('Image attached successfully');
            $scope.searchImg();
          }
          else {
            alert(result);
          }
        });

      });

    } catch (e) { alert(e); }
  };
});
app.controller('StudentHomeworksListCtrl', function ($scope, $http, $ionicModal, $state, $ionicFilterBar, $stateParams) {
  var EnrollID = $stateParams.EnrollID;
  $scope.EnrollID = EnrollID;
  $scope.baseUrl = baseUrl;
  $scope.Imgs = [];
  $scope.images = [];
  $scope.allData = [];
  $scope.pageIndex = 1;
  $scope.pageSize = 10;
  $scope.loadMore = false;
  $scope.filterOptions = { EnrollID: EnrollID, PageIndex: $scope.pageIndex, PageSize: $scope.pageSize, filterText: '' };
  $scope.bindHW = function () {
    $http({
      method: 'POST',
      url: 'api/HomeworksList2',
      data: JSON.stringify($scope.filterOptions)
    }).success(function (data) {
      let d = JSON.parse(data.Data);
      for (var j = 0; j < d.length; j++) {
        d[j].Images = ['https://picsum.photos/500/400?random=' + j.toString(), 'https://picsum.photos/500/400?random=' + (j + 1).toString()];
      }

      $scope.loadMore = d.length === $scope.pageSize;

      $scope.allData = $scope.allData.concat(d);
    });
  };


  $scope.showFilterBar = function () {
    filterBarInstance = $ionicFilterBar.show({
      items: null,
      update: function (a, b) {
        if (b != null) {
          $scope.filterOptions.PageIndex = 1;
          $scope.filterOptions.filterText = b;
          $scope.bindHW();
        }
      },
      delay: 500
    });
    window.setTimeout(function () { $('.filter-bar-search').val($scope.filterOptions.filterText); }, 200);
  };
  $scope.doRefresh = function () {
    //simulate async response
    $scope.filterOptions.PageIndex = 1;
    $scope.bindHW();
  };
  $scope.loadMoreHW = function () {
    $scope.filterOptions.PageIndex++;
    $scope.bindHW();
  }
  $scope.resolveURL = function (imageUrl) {
    return imageUrl.startsWith('http') ? imageUrl : baseUrl + 'Download.aspx?fileID=' + imageUrl;
  };
  $scope.bindHW();


  $ionicModal.fromTemplateUrl('image-modal.html', {
    scope: $scope,
    animation: 'slide-in-up'
  }).then(function (modal) {
    $scope.modal = modal;
  });

  $scope.openModal = function (Obj, $event) {
    if (Obj != '' && Obj != null) {
      $scope.imageSrc = Obj.startsWith('http') === true ? Obj : baseUrl + 'Download.aspx?type=profile&filepath=images/profile/' + Obj;
      $scope.modal.show();
      $event.stopPropagation();
    }
  };

  $scope.closeModal = function () {
    $scope.modal.hide();
  };
  $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
    if ($scope.modal.isShown()) {
      event.preventDefault();
      $scope.closeModal();
    }
  });
});
