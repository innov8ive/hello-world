// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.controllers' is found in controllers.js
angular.element(document).ready(function () {
  if (window.cordova) {
    window.plugins = {};
    document.addEventListener('deviceready', function () {
      successDeviceID();
            /////StatusBar.backgroundColorByHexString("#f96332");
            if (window.plugins.uniqueDeviceID != null) {
                window.plugins.uniqueDeviceID.get(successDeviceID);
            }
            angular.bootstrap(document.body, ['starter']);

        }, false);
    }
    else {
        angular.bootstrap(document.body, ['starter']);
    }
});
var baseUrl = 'https://localhost:44359/';// 'http://educlat.azurewebsites.net/';
var SocName = '';
var loginDone = false;
var uniqueID = '';
var regID = '';
var groupHub;
var app = angular.module('starter', ['ionic', 'starter.controllers', 'pascalprecht.translate',
'ionic-datepicker', 'ui.select', 'yaru22.angular-timeago', 'jett.ionic.filter.bar', 'ion-floating-menu'
, 'ngCordova', 'angular-preload-image'])
.factory('RequestsErrorHandler', ['$q', 'Globals', function ($q, Globals) {
    return {
        // --- The user's API for claiming responsiblity for requests ---
        specificallyHandled: function (specificallyHandledBlock) {
            specificallyHandleInProgress = true;
            try {
                return specificallyHandledBlock();
            } finally {
                specificallyHandleInProgress = false;
            }
        },
        request: function (config) {
            if (config.url.indexOf('SocRegister') == -1)
                config.timeout = 5000;
            if (config.url.indexOf('api/') != -1) {
                config.url = baseUrl + config.url;
                config.headers.Token = localStorage["token"]
                config.headers.ReqType = localStorage["reqType"];
            }
            return config;
        },
        // --- Response interceptor for handling errors generically ---
        responseError: function (rejection) {

            if (rejection.status == 401 || rejection.status == 405 || rejection.status == 400 || rejection.status == 500) {

                window.location = '#/app/login';
            }
            else {
              if (window.plugins && window.plugins.toast)
                Capacitor.Plugins.Toast.show({ 'text': 'Something went wrong, please check your internet connection.', 'duration': 5000, 'position': 'bottom' });
                else
                    alert('Something went wrong, please check your internet connection.');
            }
            //document.getElementById('loader1').style.display = 'none';
            //document.getElementById('loader2').style.display = 'none';
            return $q.reject(rejection);
        }
    };
}])

.run(function ($ionicPlatform, $ionicHistory, $state) {
    $ionicPlatform.ready(function () {
        // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
        // for form inputs)
        ////if (window.cordova && window.cordova.plugins.Keyboard) {
        ////    cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
        ////    cordova.plugins.Keyboard.disableScroll(true);

        ////}
        if (window.StatusBar) {
            // org.apache.cordova.statusbar required
            StatusBar.styleDefault();
        }
        $state.go('app.login');
    });
    $ionicPlatform.registerBackButtonAction(function (e) {
        if ($ionicHistory.currentStateName() == 'app.main' || $ionicHistory.currentStateName() == 'app.login'
            || ($ionicHistory.currentStateName() == 'app.NormalStudentsList' && localStorage["usertype"] == '3')) {
          if (confirm("Are you sure you want to exit ?")){
              Capacitor.Plugins.App.exitApp();// Otherwise we quit the app.
            }
        }
        else {
            $ionicHistory.nextViewOptions({
                disableBack: true
            });
            switch ($ionicHistory.currentStateName()) {
                case 'app.FMEdit':
                    $state.go('app.FM', { 'FMType': 'FM' });
                    break;
                case 'app.ForumsEdit':
                case 'app.ForumsView':
                    $state.go('app.Forums');
                    break;
                case 'app.CBoxEdit':
                case 'app.CBoxView':
                    $state.go('app.CBox');
                    break;
                case 'app.CatView':
                    $state.go('app.categories');
                    break;
                case 'app.Details':
                    $state.go('app.Chat');
                    break;
                case 'app.DirectoryEdit':
                    $state.go('app.Directory');
                    break;
                case 'app.BillsEdit':
                case 'app.PendingBills':
                    $state.go('app.Bills');
                    break;
                case 'app.PR':
                    $state.go('app.Bills');
                    break;
                case 'app.CP':
                    $state.go('app.profile');
                    break;
                case 'app.VLDetails':
                    $state.go('app.VL');
                    break;
                case 'app.VMDetails':
                    $state.go('app.VM');
                    break;
                case 'app.FP':
                    $state.go('app.login');
                    break;
                case 'app.ALView':
                    $state.go('app.AL');
                    break;
                case 'app.UsersEdit':
                    $state.go('app.Users');
                    break;
                case 'app.PLEdit':
                case 'app.PLView':
                    $state.go('app.PL');
                    break;
                case 'app.NBEdit':
                    $state.go('app.NB');
                    break;
                case 'app.RoomsView':
                    $state.go('app.Rooms');
                    break;
                case 'app.PaymentReqEdit':
                    $state.go('app.PaymentReq');
                    break;
                case 'app.MTEdit':
                case 'app.MOM':
                    $state.go('app.MT');
                    break;
                case 'app.VMEdit':
                    $state.go('app.VM');
                    break;
                case 'app.Register':
                    $state.go('app.login');
                    break;
                case 'app.terms':
                case 'app.privacy':
                    $state.go('app.Register');
                    break;
                case 'app.CalendarEdit':
                    $state.go('app.Calendar');
                    break;
                case 'app.Calendar':
                    if (localStorage["usertype"] == '3')
                        $state.go('app.Enrollments');
                    else
                        if (localStorage['EnrollID'] != null)
                            $state.go('app.Enrollments');
                        else
                            $state.go('app.CalendarTeacher');
                    break;
                case 'app.NBListing':
                case 'app.ParentMeetings':
                case 'app.PLListing':
                case 'app.VL':
                case 'app.CBox':
                    if (localStorage["usertype"] == '3')
                        $state.go('app.Enrollments');
                    else
                        $state.go('app.main');
                    break;
                case 'app.Absence':
                case 'app.Statement':
                case 'app.Payment':
                case 'app.AcademyPerfomance':
                case 'app.OtherDetails':
                case 'app.TimeTable':
                case 'app.StudentHomeworks':
                    $state.go('app.Enrollments');
                    break;
                case 'app.CalendarTeacherEdit':
                    $state.go('app.CalendarTeacher');
                    break;
                default:
                    if (localStorage["usertype"] == '3')
                        $state.go('app.NormalStudentsList');
                    else
                        $state.go('app.main');
                    break;
            }
        }
    }, 1000);
})

.config(function ($stateProvider, $urlRouterProvider, $translateProvider, $httpProvider, $ionicFilterBarConfigProvider) {
    $stateProvider

      .state('app', {
          url: '/app',
          abstract: true,
          templateUrl: 'templates/menu.html',
          controller: 'AppCtrl'
      })
  .state('app.login', {
      url: '/login',
      views: {
          'menuContent': {
              templateUrl: 'templates/login.html',
              controller: 'LoginController'
          }
      }
  }).state('app.PR', {
      url: '/PR?BillID&RoomID&ReqID',
      views: {
          'menuContent': {
              templateUrl: 'templates/Bills/PR.html',
              controller: 'PRCtrl',
              params: { 'BillID': '0', 'RoomID': '0', 'ReqID': '0' }
          }
      }
  }).state('app.Defaulters', {
      url: '/Defaulters',
      views: {
          'menuContent': {
              templateUrl: 'templates/Bills/Defaulters.html',
              controller: 'DefaultersCtrl',
          }
      }
  })
    .state('app.search', {
        url: '/search',
        views: {
            'menuContent': {
                templateUrl: 'templates/search.html'
            }
        }
    })
      .state('app.main', {
          url: '/main',
          views: {
              'menuContent': {
                  templateUrl: 'templates/main.html',
                  controller: 'MainCtrl'
              }
          }
      }).state('app.terms', {
          url: '/terms',
          views: {
              'menuContent': {
                  templateUrl: 'templates/terms.html'
              }
          }
      })
    .state('app.privacy', {
        url: '/privacy',
        views: {
            'menuContent': {
                templateUrl: 'templates/privacy.html'
            }
        }
    })
     .state('app.Register', {
         url: '/Register',
         views: {
             'menuContent': {
                 templateUrl: 'templates/Soc/Register.html',
                 controller: 'SocRegisterCtrl'
             }
         }
     }).state('app.CP', {
         url: '/CP',
         views: {
             'menuContent': {
                 templateUrl: 'templates/changepassword.html',
                 controller: 'CPController'
             }
         }
     }).state('app.VL', {
         url: '/VL',
         views: {
             'menuContent': {
                 templateUrl: 'templates/NB/VL.html',
                 controller: 'VLController'
             }
         }
     }).state('app.VLDetails', {
         url: '/VLDetails?CPID',
         views: {
             'menuContent': {
                 templateUrl: 'templates/NB/VLDetails.html',
                 controller: 'VLDetailsController'
             }
         }
     })
        .state('app.FP', {
            url: '/FP',
            views: {
                'menuContent': {
                    templateUrl: 'templates/FP.html',
                    controller: 'FPController'
                }
            }
        }).state('app.PendingBills', {
            url: '/PendingBills',
            views: {
                'menuContent': {
                    templateUrl: 'templates/Bills/PendingBills.html',
                    controller: 'PendingBillsController'
                }
            }
        })
    .state('app.profile', {
        url: '/profile',
        views: {
            'menuContent': {
                templateUrl: 'templates/profile.html',
                controller: 'ddCtrl'
            }
        }
    }).state('app.FM', {
        url: '/FM',
        views: {
            'menuContent': {
                templateUrl: 'templates/FM/FMList.html',
                controller: 'FMListCtrl'
            }
        }
    }).state('app.FMEdit', {
        url: '/FM?FMID',
        views: {
            'menuContent': {
                templateUrl: 'templates/FM/FM.html',
                controller: 'FMCtrl',
                params: { 'FMID': '0' }
            }
        }
    }).state('app.Forums', {
        url: '/Forums',
        views: {
            'menuContent': {
                templateUrl: 'templates/Forums/ForumsList.html',
                controller: 'ForumsListCtrl'
            }
        }
    }).state('app.CBox', {
        url: '/CBox',
        views: {
            'menuContent': {
                templateUrl: 'templates/Forums/CBoxList.html',
                controller: 'CBoxListCtrl'
            }
        }
    }).state('app.ForumsEdit', {
        url: '/Forums?ForumID',
        views: {
            'menuContent': {
                templateUrl: 'templates/Forums/Forums.html',
                controller: 'ForumsCtrl',
                params: { 'ForumID': '0' }
            }
        }
    }).state('app.CBoxEdit', {
        url: '/CBox?ForumID',
        views: {
            'menuContent': {
                templateUrl: 'templates/Forums/CBox.html',
                controller: 'CBoxCtrl',
                params: { 'ForumID': '0' }
            }
        }
    }).state('app.CBoxView', {
        url: '/Forums?ForumID',
        views: {
            'menuContent': {
                templateUrl: 'templates/Forums/ForumsView.html',
                controller: 'ForumsViewCtrl',
                params: { 'ForumID': '0' }
            }
        }
    }).state('app.ForumsView', {
        url: '/Forums?ForumID',
        views: {
            'menuContent': {
                templateUrl: 'templates/Forums/ForumsView.html',
                controller: 'ForumsViewCtrl',
                params: { 'ForumID': '0' }
            }
        }
    }).state('app.Chat', {
        url: '/Chat',
        views: {
            'menuContent': {
                templateUrl: 'templates/Chat/ChatList.html',
                controller: 'ChatListCtrl'
            }
        }
    }).state('app.Details', {
        url: '/Chat?ToUserID',
        views: {
            'menuContent': {
                templateUrl: 'templates/Chat/ChatDetails.html',
                controller: 'ChatCtrl',
                params: { 'ToUserID': '0' }
            }
        }
    }).state('app.Users', {
        url: '/Users',
        views: {
            'menuContent': {
                templateUrl: 'templates/Users/UsersIonicList.html',
                controller: 'UsersListCtrl'
            }
        }
    }).state('app.UsersEdit', {
        url: '/Users?UserID',
        views: {
            'menuContent': {
                templateUrl: 'templates/Users/Users.html',
                controller: 'UsersCtrl',
                params: { 'UserID': '0' }
            }
        }
    }).state('app.Rooms', {
        url: '/Rooms',
        views: {
            'menuContent': {
                templateUrl: 'templates/Rooms/RoomsIonicList.html',
                controller: 'RoomsListCtrl'
            }
        }
    }).state('app.RoomsView', {
        url: '/Rooms?RoomID',
        views: {
            'menuContent': {
                templateUrl: 'templates/Rooms/RoomsView.html',
                controller: 'RoomsViewCtrl',
                params: { 'RoomID': '0' }
            }
        }
    }).state('app.Directory', {
        url: '/Directory',
        views: {
            'menuContent': {
                templateUrl: 'templates/Directory/DirectoryIonicList.html',
                controller: 'DirectoryListCtrl'
            }
        }
    }).state('app.DirectoryEdit', {
        url: '/Directory?ID',
        views: {
            'menuContent': {
                templateUrl: 'templates/Directory/Directory.html',
                controller: 'DirectoryCtrl',
                params: { 'ID': '0' }
            }
        }
    }).state('app.PL', {
        url: '/PL',
        views: {
            'menuContent': {
                templateUrl: 'templates/PL/PLIonicList.html',
                controller: 'PLListCtrl'
            }
        }
    }).state('app.PLEdit', {
        url: '/PL?PLID',
        views: {
            'menuContent': {
                templateUrl: 'templates/PL/PL.html',
                controller: 'PLCtrl',
                params: { 'PLID': '0' }
            }
        }
    }).state('app.PLListing', {
        url: '/PLListing',
        views: {
            'menuContent': {
                templateUrl: 'templates/PL/PLListing.html',
                controller: 'PLListingCtrl'
            }
        }
    })
   .state('app.PLView', {
       url: '/PL?PLID',
       views: {
           'menuContent': {
               templateUrl: 'templates/PL/PLResult.html',
               controller: 'PLResultCtrl',
               params: { 'PLID': '0' }
           }
       }
   })
.state('app.financial', {
    url: '/financial',
    views: {
        'menuContent': {
            templateUrl: 'templates/financial.html',
            controller: 'MainCtrl'
        }
    }
}).state('app.logout', {
    url: '/logout',
    views: {
        'menuContent': {
            templateUrl: 'templates/logout.html',
            controller: 'LogoutCtrl'
        }
    }
}).state('app.NB', {
    url: '/NB',
    views: {
        'menuContent': {
            templateUrl: 'templates/NB/NBIonicList.html',
            controller: 'NBListCtrl'
        }
    }
}).state('app.NBEdit', {
    url: '/NB?NBID',
    views: {
        'menuContent': {
            templateUrl: 'templates/NB/NB.html',
            controller: 'NBCtrl',
            params: { 'NBID': '0' }
        }
    }
}).state('app.NBListing', {
    url: '/NBListing',
    views: {
        'menuContent': {
            templateUrl: 'templates/NB/NBListing.html',
            controller: 'NBListingCtrl'
        }
    }
}).state('app.AlertListing', {
  url: '/AlertListing',
  views: {
    'menuContent': {
      templateUrl: 'templates/NB/AlertListing.html',
      controller: 'AlertListingCtrl'
    }
  }
}).state('app.NBDetails', {
    url: '/NB?NBID',
    views: {
        'menuContent': {
            templateUrl: 'templates/NB/NBDetails.html',
            controller: 'NBDetailsCtrl',
            params: { 'NBID': '0' }
        }
    }
}).state('app.sendEmail', {
    url: '/sendEmail',
    views: {
        'menuContent': {
            templateUrl: 'templates/Msg/MsgList.html',
            controller: 'EmailMsgCtrl'
        }
    }
}).state('app.sendSMS', {
    url: '/sendSMS',
    views: {
        'menuContent': {
            templateUrl: 'templates/Msg/SMSList.html',
            controller: 'SMSCtrl'
        }
    }
}).state('app.sendNotification', {
  url: '/sendNotification',
    views: {
        'menuContent': {
        templateUrl: 'templates/Msg/NotificationList.html',
        controller: 'NotificationCtrl'
        }
    }
}).state('app.Bills', {
    url: '/Bills',
    views: {
        'menuContent': {
            templateUrl: 'templates/Bills/BillsIonicList.html',
            controller: 'BillsListCtrl'
        }
    }
}).state('app.BillsEdit', {
    url: '/Bills?BillID',
    views: {
        'menuContent': {
            templateUrl: 'templates/Bills/Bills.html',
            controller: 'BillsCtrl',
            params: { 'BillID': '0' }
        }
    }
}).state('app.PaymentReq', {
    url: '/PaymentReq',
    views: {
        'menuContent': {
            templateUrl: 'templates/PaymentReq/PaymentReqIonicList.html',
            controller: 'PaymentReqListCtrl'
        }
    }
}).state('app.PaymentReqEdit', {
    url: '/PaymentReq?ReqID&RoomID',
    views: {
        'menuContent': {
            templateUrl: 'templates/PaymentReq/Payments.html',
            controller: 'PaymentReqCtrl',
            params: { 'ReqID': '0', 'RoomID': '0' }
        }
    }
}).state('app.VM', {
    url: '/VM',
    views: {
        'menuContent': {
            templateUrl: 'templates/VM/VMIonicList.html',
            controller: 'VMListCtrl'
        }
    }
}).state('app.VMDetails', {
    url: '/VMDetails?VMID',
    views: {
        'menuContent': {
            templateUrl: 'templates/VM/VMDetails.html',
            controller: 'VMDetailsCtrl'
        }
    }
}).state('app.VMEdit', {
    url: '/VM?VMID',
    views: {
        'menuContent': {
            templateUrl: 'templates/VM/VM.html',
            controller: 'VMCtrl',
            params: { 'VMID': '0' }
        }
    }
}).state('app.MT', {
    url: '/MT',
    views: {
        'menuContent': {
            templateUrl: 'templates/MT/MTIonicList.html',
            controller: 'MTListCtrl'
        }
    }
}).state('app.MTListing', {
    url: '/MTListing',
    views: {
        'menuContent': {
            templateUrl: 'templates/MT/MTListing.html',
            controller: 'MTListCtrl'
        }
    }
}).state('app.MTEdit', {
    url: '/MT?MTID',
    views: {
        'menuContent': {
            templateUrl: 'templates/MT/MT.html',
            controller: 'MTCtrl',
            params: { 'MTID': '0' }
        }
    }
}).state('app.MOM', {
    url: '/MOM?MTID',
    views: {
        'menuContent': {
            templateUrl: 'templates/MT/MOM.html',
            controller: 'MOMCtrl',
            params: { 'MTID': '0' }
        }
    }
}).state('app.Folder', {
    url: '/Folder',
    views: {
        'menuContent': {
            templateUrl: 'templates/Folder/FolderList.html',
            controller: 'FolderListCtrl'
        }
    }
}).state('app.AL', {
    url: '/AL',
    views: {
        'menuContent': {
            templateUrl: 'templates/AL/ALList.html',
            controller: 'ALListCtrl'
        }
    }
}).state('app.ALView', {
    url: '/AL?ALID&ALName',
    views: {
        'menuContent': {
            templateUrl: 'templates/AL/ALView2.html',
            controller: 'ALView2Ctrl',
            params: { 'ALID': '0', 'ALName': '' }
        }
    }
}).state('app.ATList', {
    url: '/ATList',
    views: {
        'menuContent': {
            templateUrl: 'templates/Attendance/ATList.html',
            controller: 'ATListCtrl'
        }
    }
}).state('app.StudentsList', {
    url: '/StudentsList',
    views: {
        'menuContent': {
            templateUrl: 'templates/Students/StudentsList.html',
            controller: 'StudentsListCtrl'
        }
    }
}).state('app.NormalStudentsList', {
    url: '/NormalStudentsList',
    views: {
        'menuContent': {
            templateUrl: 'templates/Students/NormalStudentsList.html',
            controller: 'StudentsListCtrl'
        }
    }
}).state('app.ATSMS', {
    url: '/ATSMS',
    views: {
        'menuContent': {
            templateUrl: 'templates/Attendance/ATSMS.html',
            controller: 'ATSMSCtrl'
        }
    }
}).state('app.Enrollments', {
    url: '/Enrollments?EnrollID',
    views: {
        'menuContent': {
            templateUrl: 'templates/Students/profile.html',
            controller: 'EnrollCtrl',
            params: { 'EnrollID': '0' }
        }
    }
}).state('app.Absence', {
    url: '/Absence?EnrollID',
    views: {
        'menuContent': {
            templateUrl: 'templates/Students/Absence.html',
            controller: 'AbsenceCtrl',
            params: { 'EnrollID': '0' }
        }
    }
}).state('app.Statement', {
    url: '/Statement?EnrollID',
    views: {
        'menuContent': {
            templateUrl: 'templates/Students/Statement.html',
            controller: 'StatementCtrl',
            params: { 'EnrollID': '0' }
        }
    }
}).state('app.Payment', {
    url: '/Payment?EnrollID',
    views: {
        'menuContent': {
            templateUrl: 'templates/Students/Payment.html',
            controller: 'PaymentCtrl',
            params: { 'EnrollID': '0' }
        }
    }
}).state('app.PaymentStart', {
    url: '/PaymentStart?EnrollID',
    views: {
        'menuContent': {
            templateUrl: 'templates/Students/PaymentStart.html',
            controller: 'PaymentStartCtrl',
            params: { 'EnrollID': '0' }
        }
    }
}).state('app.AcademyPerfomance', {
    url: '/AcademyPerfomance?EnrollID',
    views: {
        'menuContent': {
            templateUrl: 'templates/Students/AcademyPerfomance.html',
            controller: 'AcademyPerfomanceCtrl',
            params: { 'EnrollID': '0' }
        }
    }
}).state('app.OtherDetails', {
    url: '/OtherDetails?EnrollID',
    views: {
        'menuContent': {
            templateUrl: 'templates/Students/OtherDetails.html',
            controller: 'OtherDetailsCtrl',
            params: { 'EnrollID': '0' }
        }
    }
}).state('app.TimeTable', {
    url: '/TimeTable?EnrollID',
    views: {
        'menuContent': {
            templateUrl: 'templates/Students/TimeTable.html',
            controller: 'TimeTableCtrl',
            params: { 'EnrollID': '0' }
        }
    }
}).state('app.ParentMeetings', {
    url: '/ParentMeetings',
    views: {
        'menuContent': {
            templateUrl: 'templates/MT/ParentMeetings.html',
            controller: 'ParentMeetingsCtrl'
        }
    }
}).state('app.TeacherTimeTable', {
    url: '/TeacherTimeTable',
    views: {
        'menuContent': {
            templateUrl: 'templates/Users/TeacherTimeTable.html',
            controller: 'TeacherTimeTableCtrl'
        }
    }
}).state('app.Homeworks', {
    url: '/Homeworks',
    views: {
        'menuContent': {
            templateUrl: 'templates/Homeworks/HomeworksIonicList.html',
            controller: 'HomeworksListCtrl'
        }
    }
}).state('app.HomeworksEdit', {
    url: '/Homeworks?ID',
    views: {
        'menuContent': {
            templateUrl: 'templates/Homeworks/Homeworks.html',
            controller: 'HomeworksCtrl',
            params: { 'ID': '0' }
        }
    }
}).state('app.StudentHomeworks', {
    url: '/StudentHomeworks?EnrollID',
    views: {
        'menuContent': {
            templateUrl: 'templates/Homeworks/StudentHomeworksList.html',
            controller: 'StudentHomeworksListCtrl',
            params: { 'EnrollID': '0' }
        }
    }
}).state('app.Calendar', {
    url: '/Calendar',
    views: {
        'menuContent': {
            templateUrl: 'templates/Calendar/CalendarIonicList.html',
            controller: 'CalendarListCtrl'
        }
    }
}).state('app.CalendarEdit', {
    url: '/Calendar?CalID',
    views: {
        'menuContent': {
            templateUrl: 'templates/Calendar/Calendar.html',
            controller: 'CalendarCtrl',
            params: { 'CalID': '0' }
        }
    }
}).state('app.CalendarTeacher', {
    url: '/CalendarTeacher',
    views: {
        'menuContent': {
            templateUrl: 'templates/Calendar/CalendarTeacherIonicList.html',
            controller: 'CalendarListCtrl'
        }
    }
}).state('app.CalendarTeacherEdit', {
    url: '/CalendarTeacher?CalID',
    views: {
        'menuContent': {
            templateUrl: 'templates/Calendar/CalendarTeacher.html',
            controller: 'CalendarTeacherCtrl',
            params: { 'CalID': '0' }
        }
    }
});
    // if none of the above states are matched, use this as the fallback
    $urlRouterProvider.otherwise('/app/main');
    $httpProvider.interceptors.push('RequestsErrorHandler');
    $translateProvider
    .useStaticFilesLoader({ prefix: 'templates/locales/', suffix: '.json' })
    .registerAvailableLanguageKeys(['en', 'br'], {
        'en': 'en', 'br': 'br'
    })
    .preferredLanguage('br')
    .fallbackLanguage('en')
    .determinePreferredLanguage()
    .useSanitizeValueStrategy('escapeParameters');
    $ionicFilterBarConfigProvider.theme = function () {
        return 'positive';
    };
}).directive('loading', ['$http', function ($http) {
    return {
        restrict: 'A',
        link: function (scope, elm, attrs) {
            scope.isLoading = function () {
                return $http.pendingRequests.length > 0;
            };

            scope.$watch(scope.isLoading, function (v) {

                if (v) {
                    elm.css("display", "");
                } else {
                    elm.css("display", "none");
                }
            });
        }
    };

}]).directive('jqdatepicker', function ($filter) {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, element, attrs, ngModelCtrl) {
            element.datepicker({
                dateFormat: 'dd-M-yy',
                changeYear: true,
                changeMonth: true,
                onSelect: function (date) {
                    //var ar = date.split("/");
                    //date = new Date(ar[2] + "-" + ar[1] + "-" + ar[0]);
                    ngModelCtrl.$setViewValue(date);
                    scope.$apply();
                }
            });
            ngModelCtrl.$formatters.unshift(function (v) {
                return $filter('date')(v, 'dd-MMM-yyyy');
            });

        }
    };
})
.directive('jqmonthpicker', function ($filter) {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, element, attrs, ngModelCtrl) {
            element.datepicker({
                dateFormat: 'dd-M-yy',
                changeYear: true,
                changeMonth: true,
                onSelect: function (date) {
                    //var ar = date.split("/");
                    //date = new Date(ar[2] + "-" + ar[1] + "-" + ar[0]);
                    ngModelCtrl.$setViewValue(date);
                    scope.$apply();
                },
                beforeShow: function () {
                    $('#ui-datepicker-div').addClass('hide-calendar');
                },
                onClose: function (dateText, inst) {
                    var month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
                    var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
                    var date = new Date(year, month, 1);
                    $(this).datepicker('setDate', date);
                    ngModelCtrl.$setViewValue(date);
                    scope.$apply();
                }
            });
            ngModelCtrl.$formatters.unshift(function (v) {
                return $filter('date')(v, 'dd-MMM-yyyy');
            });

        }
    };
}).directive('imageuploader', function () {
    return {
        restrict: 'E',
        replace: true,
        templateUrl: 'templates/image-uploader.html'
    }
}).directive('modal', function () {
    return {
        template: '<div class="modal fade">' +
            '<div class="modal-dialog">' +
              '<div class="modal-content">' +
                '<div class="modal-header">' +
                  '<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>' +
                  '<h4 class="modal-title"></h4>' +
                '</div>' +
                '<div class="modal-body" ng-transclude></div>' +
              '</div>' +
            '</div>' +
          '</div>',
        restrict: 'E',
        transclude: true,
        replace: true,
        scope: true,
        link: function postLink(scope, element, attrs) {
            scope.$watch(attrs.title, function (value) {
                $(element).find('.modal-title').html(value);
            });
            scope.$watch(attrs.type, function (value) {
                $(element).addClass(value);
            });
            scope.$watch(attrs.visible, function (value) {

                if (value == true)
                    $(element).modal('show');
                else
                    $(element).modal('hide');
            });

            $(element).on('shown.bs.modal', function () {
                scope.$apply(function () {
                    scope.$parent[attrs.visible] = true;
                });
            });

            $(element).on('hidden.bs.modal', function () {
                scope.$apply(function () {
                    scope.$parent[attrs.visible] = false;
                });
            });
        }
    };
}).directive('fileModel', ['$parse', function ($parse) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;

            element.bind('change', function () {

                scope.$apply(function () {
                    modelSetter(scope, element[0].files[0]);
                    debugger;
                });
            });
        }
    };
}]).directive('ionMultipleSelect', ['$ionicModal', '$ionicGesture', function ($ionicModal, $ionicGesture) {
    return {
        restrict: 'E',
        scope: {
            options: "=",
            modelKey: "=",
            modelValue: "="
        },
        controller: function ($scope, $element, $attrs, $filter) {

            $scope.multipleSelect = {
                title: $attrs.title || "Select Options",
                tempOptions: [],
                keyProperty: $attrs.keyProperty || "id",
                valueProperty: $attrs.valueProperty || "value",
                selectedProperty: $attrs.selectedProperty || "selected",
                templateUrl: $attrs.templateUrl || 'templates/multipleSelect.html',
                renderCheckbox: $attrs.renderCheckbox ? $attrs.renderCheckbox == "true" : true,
                animation: $attrs.animation || 'slide-in-up'
            };

            $scope.OpenModalFromTemplate = function (templateUrl) {
                $ionicModal.fromTemplateUrl(templateUrl, {
                    scope: $scope,
                    animation: $scope.multipleSelect.animation
                }).then(function (modal) {
                    $scope.modalSelect = modal;
                    $scope.modalSelect.show();
                });
            };

            $ionicGesture.on('tap', function (e) {
                $scope.multipleSelect.tempOptions = $scope.options.map(function (option) {
                    var tempOption = {};
                    tempOption[$scope.multipleSelect.keyProperty] = option[$scope.multipleSelect.keyProperty];
                    tempOption[$scope.multipleSelect.valueProperty] = option[$scope.multipleSelect.valueProperty];
                    tempOption[$scope.multipleSelect.selectedProperty] = option[$scope.multipleSelect.selectedProperty];

                    if ($scope.modelKey != null) {
                        for (var j = 0; j < $scope.modelKey.length; j++) {
                            if ($scope.modelKey[j] == tempOption[$scope.multipleSelect.keyProperty]) {
                                tempOption[$scope.multipleSelect.selectedProperty] = true;
                                break;
                            }
                        }
                    }

                    return tempOption;
                });
                $scope.OpenModalFromTemplate($scope.multipleSelect.templateUrl);
            }, $element);

            $scope.saveOptions = function () {
                for (var i = 0; i < $scope.multipleSelect.tempOptions.length; i++) {
                    var tempOption = $scope.multipleSelect.tempOptions[i];
                    for (var j = 0; j < $scope.options.length; j++) {
                        var option = $scope.options[j];
                        if (tempOption[$scope.multipleSelect.keyProperty] == option[$scope.multipleSelect.keyProperty]) {
                            option[$scope.multipleSelect.selectedProperty] = tempOption[$scope.multipleSelect.selectedProperty];
                            break;
                        }
                    }
                }
                $scope.modelKey = $scope.getKeysSelected($scope.options, $scope.multipleSelect.keyProperty, $scope.multipleSelect.selectedProperty);
                $scope.modelValue = $scope.getOptionsSelected($scope.options, $scope.multipleSelect.valueProperty, $scope.multipleSelect.selectedProperty);
                $scope.closeModalSelect();
            };
            $scope.closeModalSelect = function () {
                $scope.modalSelect.remove();
            };
            $scope.$on('$destroy', function () {
                if ($scope.modalSelect) {
                    $scope.modalSelect.remove();
                }
            });
            $scope.$watch('options', function () {

                if ($scope.options != null && $scope.modelKey != null) {
                    var optionsSelected = $filter('filter')($scope.options, function (option) {
                        for (var j = 0; j < $scope.modelKey.length; j++) {
                            if (option[$scope.multipleSelect.keyProperty] == $scope.modelKey[j]) {
                                return true;
                            }
                        }
                        return false;
                    });
                    $scope.modelValue = optionsSelected.map(function (group) { return group[$scope.multipleSelect.valueProperty]; }).join(", ");
                }
            });
            $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
                if ($scope.modalSelect != null)
                    if ($scope.modalSelect.isShown()) {
                        event.preventDefault();
                        $scope.closeModalSelect();
                    }
            });
            $scope.getOptionsSelected = function (options, valueProperty, selectedProperty) {
                if (options == null) return '';
                var optionsSelected = $filter('filter')(options, function (option) { return option[selectedProperty] == true; });
                return optionsSelected.map(function (group) { return group[valueProperty]; }).join(", ");
            };
            //https://codepen.io/jdnichollsc/pen/qOrqqK
            $scope.getKeysSelected = function (options, keyProperty, selectedProperty) {
                if (options == null) return '';
                var optionsSelected = $filter('filter')(options, function (option) { return option[selectedProperty] == true; });
                return optionsSelected.map(function (group) { return group[keyProperty]; });
            };
        }
    };
}]).directive('ionSingleSelect', ['$ionicModal', '$ionicGesture', function ($ionicModal, $ionicGesture) {
    return {
        restrict: 'AE',
        scope: {
            options: "=",
            modelKey: "=",
            modelValue: "="
        },

        controller: function ($scope, $element, $attrs) {

            $scope.singleSelect = {
                title: $attrs.title || "Select Options",
                tempOptions: [],
                keyProperty: $attrs.keyProperty || "id",
                valueProperty: $attrs.valueProperty || "value",
                selectedProperty: $attrs.selectedProperty || "selected",
                templateUrl: $attrs.templateUrl || 'templates/singleSelect.html',
                renderCheckbox: $attrs.renderCheckbox ? $attrs.renderCheckbox == "true" : true,
                animation: $attrs.animation || 'slide-in-up'
            };

            $scope.OpenModalFromTemplate = function (templateUrl) {
                $ionicModal.fromTemplateUrl(templateUrl, {
                    scope: $scope,
                    animation: $scope.singleSelect.animation
                }).then(function (modal) {
                    $scope.modalSelect = modal;
                    $scope.modalSelect.show();
                });
            };

            $ionicGesture.on('tap', function (e) {
                $scope.singleSelect.tempOptions = $scope.options.map(function (option) {
                    var tempOption = {};
                    tempOption[$scope.singleSelect.keyProperty] = option[$scope.singleSelect.keyProperty];
                    tempOption[$scope.singleSelect.valueProperty] = option[$scope.singleSelect.valueProperty];
                    tempOption[$scope.singleSelect.selectedProperty] = option[$scope.singleSelect.selectedProperty];
                    if ($scope.modelKey != null)
                        if ($scope.modelKey == tempOption[$scope.singleSelect.keyProperty]) {
                            tempOption[$scope.singleSelect.selectedProperty] = true;
                            $scope.modelValue = tempOption[$scope.singleSelect.valueProperty];
                        }
                        else
                            tempOption[$scope.singleSelect.selectedProperty] = false;
                    return tempOption;
                });
                $scope.OpenModalFromTemplate($scope.singleSelect.templateUrl);
            }, $element);

            $scope.saveOptions = function () {
                for (var j = 0; j < $scope.options.length; j++) {
                    $scope.options[j][$scope.singleSelect.selectedProperty] = false;
                }
                for (var i = 0; i < $scope.singleSelect.tempOptions.length; i++) {
                    var tempOption = $scope.singleSelect.tempOptions[i];
                    if (tempOption[$scope.singleSelect.selectedProperty] == true) {
                        for (var j = 0; j < $scope.options.length; j++) {
                            var option = $scope.options[j];
                            if (tempOption[$scope.singleSelect.keyProperty] == option[$scope.singleSelect.keyProperty]) {
                                option[$scope.singleSelect.selectedProperty] = tempOption[$scope.singleSelect.selectedProperty];
                                $scope.modelKey = tempOption[$scope.singleSelect.keyProperty];
                                $scope.modelValue = tempOption[$scope.singleSelect.valueProperty];
                                break;
                            }
                        }
                    }
                }
                $scope.closeModalSelect();
            };
            $scope.closeModalSelect = function () {
                $scope.modalSelect.remove();

            };
            $scope.singleSelected = function (opt) {
                for (var i = 0; i < $scope.singleSelect.tempOptions.length; i++) {
                    var tempOption = $scope.singleSelect.tempOptions[i];
                    if (tempOption[$scope.singleSelect.keyProperty] == opt[$scope.singleSelect.keyProperty])
                        tempOption[$scope.singleSelect.selectedProperty] = true;
                    else
                        tempOption[$scope.singleSelect.selectedProperty] = false;
                }
            };
            $scope.$on('$destroy', function () {
                if ($scope.modalSelect) {
                    $scope.modalSelect.remove();
                }
            });
            $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
                if ($scope.modalSelect != null)
                    if ($scope.modalSelect.isShown()) {
                        event.preventDefault();
                        $scope.closeModalSelect();
                    }
            });
            $scope.$watch('options', function () {

                if ($scope.options != null) {
                    for (var i = 0; i < $scope.options.length; i++) {
                        var opt = $scope.options[i];
                        if (opt[$scope.singleSelect.keyProperty] == $scope.modelKey) {
                            $scope.modelValue = opt[$scope.singleSelect.valueProperty];
                            break;
                        }
                    }
                }
            });
        }
    };
}]).factory('User', function () {
    var self = this;
    self.UserID = 0;
    self.Token = '';
    self.UserName = '';
    self.FirstName = '';
    self.LastName = '';
    self.ImageUrl = '';
    self.MenuItems = [];
    self.SocName = '';
    self.WPID = 0;
    self.WPName = '';
    self.Verified = false;
    self.SocList = [];
    self.RMList = [];
    self.ForcedRMLogin = false;
    self.ShowAd = true;
    self.SelectedModuleID = 0;
    self.SelectedModuleName = '';
    return self;
});

function successHandler(result) {
    //alert('Callback Success! Result = ' + result);
};
function errorHandler(result) {
    //alert('Callback Success! Result = ' + result);
};

async function successDeviceID() {
  var dInfo = await Capacitor.Plugins.Device.getId();
  uniqueID = dInfo.uuid;
  if (Capacitor.Plugins.PushNotifications) {
        setupPush();
    }
};

function setupPush() {
  //Capacitor.Plugins.PushNotifications
  //Capacitor.Plugins.Toast.show({'text':'test message','duration':5000,'position':'top'})
  Capacitor.Plugins.PushNotifications.requestPermissions().then(function (permission) {
    if (permission.receive === 'granted') {
      Capacitor.Plugins.PushNotifications.register();
    }
    else {
      Capacitor.Plugins.Toast.show({ 'text': 'Permission is not granted for Notification', 'duration': 5000, 'position': 'top' })
    }
  });
  Capacitor.Plugins.PushNotifications.getDeliveredNotifications().then(function (notifications) {
    if (notifications && notifications.length>0) {
      var existingAlerts = [];
      if (localStorage['alerts']) {
        existingAlerts = JSON.parse(localStorage['alerts']);
      }
      for (var j = 0; j < notifications.length; j++) {
        existingAlerts.unshift({ title: notifications[j].title, body: notifications[j].body,dt: notifications[j].data.deliveryDate });
      }
      localStorage['alerts'] = JSON.stringify(existingAlerts);
    }   
  });
  Capacitor.Plugins.PushNotifications.addListener('registration', function (token) {
    if (token.value.length > 0) {
      regID = token.value;
      $.ajax({
        type: "POST",
        url: baseUrl + "api/Common/RegisterDevice",
        data: JSON.stringify({ uniqueID: uniqueID, regID: regID }),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
          //alert('registration successs');
        },
        error: function () {
          //alert('registration failed');
        }
      });
    }
  });
  Capacitor.Plugins.PushNotifications.addListener('registrationError', function (err)  {
    console.log(error);
  });
  Capacitor.Plugins.PushNotifications.addListener('pushNotificationReceived', function (notifications)  {
    var existingAlerts = [];
    if (localStorage['alerts']) {
      existingAlerts = JSON.parse(localStorage['alerts']);
    }
    existingAlerts.unshift({ title: notifications.title, body: notifications.body,dt: notifications.data.deliveryDate });
    localStorage['alerts'] = JSON.stringify(existingAlerts);
  });
}
