using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using OM;

namespace DL
{
    public class RideRequestsDL
    {

        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public RideRequestsDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public RideRequests Load(int RideRequestId)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            RideRequests objRideRequests = new RideRequests();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get RideRequests
                var resultRideRequests = dc.ExecuteQuery<RideRequests>("exec Get_RideRequests {0}", RideRequestId).ToList();
                if (resultRideRequests.Count > 0)
                {
                    objRideRequests = resultRideRequests[0];
                }
                dc.Dispose();
                return objRideRequests;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllRideRequests()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_RideRequests", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(RideRequests objRideRequests)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update RideRequests
                UpdateRideRequests(objRideRequests, trn);
                if (objRideRequests.RideRequestId > 0)
                {

                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int RideRequestId)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete RideRequests
                DeleteRideRequests(RideRequestId, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateRideRequests(RideRequests objRideRequests, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_RideRequests", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@CommTxnId", SqlDbType.Int).Value = objRideRequests.CommTxnId;
                cmd.Parameters.Add("@DistanceKM", SqlDbType.Decimal).Value = objRideRequests.DistanceKM;
                cmd.Parameters.Add("@EstimatedFare", SqlDbType.Decimal).Value = objRideRequests.EstimatedFare;
                cmd.Parameters.Add("@FromUserId", SqlDbType.Int).Value = objRideRequests.FromUserId;
                cmd.Parameters.Add("@PickTime", SqlDbType.DateTime).Value = objRideRequests.PickTime;
                cmd.Parameters.Add("@RequestDate", SqlDbType.DateTime).Value = objRideRequests.RequestDate;
                cmd.Parameters.Add("@RideRequestId", SqlDbType.Int).Value = objRideRequests.RideRequestId;
                cmd.Parameters["@RideRequestId"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@StatusId", SqlDbType.Int).Value = objRideRequests.StatusId;
                cmd.Parameters.Add("@ToUserId", SqlDbType.Int).Value = objRideRequests.ToUserId;
                cmd.Parameters.Add("@StartLat", SqlDbType.Decimal).Value = objRideRequests.StartLat;
                cmd.Parameters.Add("@StartLocationText", SqlDbType.VarChar, 5000).Value = objRideRequests.StartLocationText;
                cmd.Parameters.Add("@StartLong", SqlDbType.Decimal).Value = objRideRequests.StartLong;
                cmd.Parameters.Add("@EndLat", SqlDbType.Decimal).Value = objRideRequests.EndLat;
                cmd.Parameters.Add("@EndLocationText", SqlDbType.VarChar, 5000).Value = objRideRequests.EndLocationText;
                cmd.Parameters.Add("@EndLong", SqlDbType.Decimal).Value = objRideRequests.EndLong;

                cmd.ExecuteNonQuery();

                //after updating the RideRequests, update RideRequestId
                objRideRequests.RideRequestId = Convert.ToInt32(cmd.Parameters["@RideRequestId"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteRideRequests(int RideRequestId, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from RideRequests where RideRequestId=@RideRequestId", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@RideRequestId", SqlDbType.Int).Value = RideRequestId;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        #endregion
    }
}
