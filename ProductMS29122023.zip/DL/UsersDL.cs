﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using OM;

namespace DL
{
    public class UsersDL
    {

        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public UsersDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public Users Load(int UserId)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            Users objUsers = new Users();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get Users
                var resultUsers = dc.ExecuteQuery<Users>("exec Get_Users {0}", UserId).ToList();
                if (resultUsers.Count > 0)
                {
                    objUsers = resultUsers[0];
                }
                dc.Dispose();
                return objUsers;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }

        public List<string> GetUserDeviceIds(string UserIds)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            List<string> deviceRegIds = new List<string>();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get Users
                var resultUsers = dc.ExecuteQuery<string>("exec ('select DeviceRegId from Users where UserId in('{0}') and DeviceRegId is not null')", UserIds).ToList();
                if (resultUsers.Count > 0)
                {
                    deviceRegIds = resultUsers;
                }
                dc.Dispose();
                return deviceRegIds;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllUsers()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_Users", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(Users objUsers)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update Users
                UpdateUsers(objUsers, trn);
                if (objUsers.UserId > 0)
                {

                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int UserId)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete Users
                DeleteUsers(UserId, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateUsers(Users objUsers, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_Users", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;
                cmd.Parameters.Add("@EmailId", SqlDbType.VarChar, 250).Value = objUsers.EmailId;
                cmd.Parameters.Add("@FirstName", SqlDbType.VarChar, 500).Value = objUsers.FirstName;
                cmd.Parameters.Add("@IsActive", SqlDbType.Bit).Value = objUsers.IsActive;
                cmd.Parameters.Add("@LastName", SqlDbType.VarChar, 500).Value = objUsers.LastName;
                cmd.Parameters.Add("@Mobile", SqlDbType.VarChar, 15).Value = objUsers.Mobile;
                cmd.Parameters.Add("@MobileVerified", SqlDbType.VarChar, 15).Value = objUsers.MobileVerified;
                cmd.Parameters.Add("@Password", SqlDbType.VarChar, 250).Value = objUsers.Password;
                cmd.Parameters.Add("@RegDate", SqlDbType.DateTime).Value = objUsers.RegDate;
                cmd.Parameters.Add("@StatusId", SqlDbType.Int).Value = objUsers.StatusId;
                cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = objUsers.UserId;
                cmd.Parameters["@UserId"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@UserTypeId", SqlDbType.Int).Value = objUsers.UserTypeId;

                cmd.ExecuteNonQuery();

                //after updating the Users, update UserId
                objUsers.UserId = Convert.ToInt32(cmd.Parameters["@UserId"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteUsers(int UserId, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from Users where UserId=@UserId", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = UserId;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        #endregion
    }
}
