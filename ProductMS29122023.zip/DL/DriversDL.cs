using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using OM;

namespace DL
{
    public class DriversDL
    {

        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public DriversDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public Drivers Load(int UserId)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            Drivers objDrivers = new Drivers();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get Drivers
                var resultDrivers = dc.ExecuteQuery<Drivers>("exec Get_Drivers {0}", UserId).ToList();
                if (resultDrivers.Count > 0)
                {
                    objDrivers = resultDrivers[0];
                }
                dc.Dispose();
                return objDrivers;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllDrivers()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_Drivers", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(Drivers objDrivers)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update Drivers
                UpdateDrivers(objDrivers, trn);
                if (objDrivers.DriverId > 0)
                {

                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int DriverId)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete Drivers
                DeleteDrivers(DriverId, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateDrivers(Drivers objDrivers, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_Drivers", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@CityId", SqlDbType.Int).Value = objDrivers.CityId;
                cmd.Parameters.Add("@DLExpiryDate", SqlDbType.DateTime).Value = objDrivers.DLExpiryDate;
                cmd.Parameters.Add("@DLNo", SqlDbType.VarChar, 50).Value = objDrivers.DLNo;
                cmd.Parameters.Add("@DriverId", SqlDbType.Int).Value = objDrivers.DriverId;
                cmd.Parameters["@DriverId"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@FullAddress", SqlDbType.VarChar, 5000).Value = objDrivers.FullAddress;
                cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = objDrivers.UserId;
                cmd.Parameters.Add("@VehicleTypeId", SqlDbType.Int).Value = objDrivers.VehicleTypeId;
                cmd.Parameters.Add("@Zipcode", SqlDbType.VarChar, 6).Value = objDrivers.Zipcode;

                cmd.ExecuteNonQuery();

                //after updating the Drivers, update DriverId
                objDrivers.DriverId = Convert.ToInt32(cmd.Parameters["@DriverId"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteDrivers(int DriverId, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from Drivers where DriverId=@DriverId", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@DriverId", SqlDbType.Int).Value = DriverId;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        #endregion
    }
}
