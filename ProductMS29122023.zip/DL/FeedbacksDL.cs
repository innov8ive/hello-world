using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using OM;

namespace DL
{
    public class FeedbacksDL
    {

        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public FeedbacksDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public Feedbacks Load(int FeedbackId)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            Feedbacks objFeedbacks = new Feedbacks();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get Feedbacks
                var resultFeedbacks = dc.ExecuteQuery<Feedbacks>("exec Get_Feedbacks {0}", FeedbackId).ToList();
                if (resultFeedbacks.Count > 0)
                {
                    objFeedbacks = resultFeedbacks[0];
                }
                dc.Dispose();
                return objFeedbacks;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }

        public List<Feedbacks> LoadForUser(int UserId)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            List<Feedbacks> objFeedbacks = new List<Feedbacks>();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get Feedbacks
                var resultFeedbacks = dc.ExecuteQuery<Feedbacks>(@"select U.FirstName+' '+U.LastName as AddedByUser,D.FirstName+' '+D.LastName as DriverName, F.* from Feedbacks F 
INNER JOIN Users U ON F.UserId = U.UserId
INNER JOIN Users D ON F.DriverUserId = D.UserId where F.UserId={0}", UserId).ToList();
                if (resultFeedbacks.Count > 0)
                {
                    objFeedbacks = resultFeedbacks;
                }
                dc.Dispose();
                return objFeedbacks;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }

        public List<Feedbacks> LoadForDriver(int DriverUserId)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            List<Feedbacks> objFeedbacks = new List<Feedbacks>();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get Feedbacks
                var resultFeedbacks = dc.ExecuteQuery<Feedbacks>(@"select U.FirstName+' '+U.LastName as AddedByUser,D.FirstName+' '+D.LastName as DriverName, F.* from Feedbacks F 
INNER JOIN Users U ON F.UserId = U.UserId
INNER JOIN Users D ON F.DriverUserId = D.UserId where F.DriverUserId={0}", DriverUserId).ToList();
                if (resultFeedbacks.Count > 0)
                {
                    objFeedbacks = resultFeedbacks;
                }
                dc.Dispose();
                return objFeedbacks;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }

        public DataTable LoadAllFeedbacks()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_Feedbacks", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(Feedbacks objFeedbacks)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update Feedbacks
                UpdateFeedbacks(objFeedbacks, trn);
                if (objFeedbacks.FeedbackId > 0)
                {

                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int FeedbackId, int UserId, int UserTypeId)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete Feedbacks
                DeleteFeedbacks(FeedbackId, UserId, UserTypeId, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateFeedbacks(Feedbacks objFeedbacks, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_Feedbacks", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@DriverUserId", SqlDbType.Int).Value = objFeedbacks.DriverUserId;
                cmd.Parameters.Add("@EntryDate", SqlDbType.DateTime).Value = objFeedbacks.EntryDate;
                cmd.Parameters.Add("@Feedback", SqlDbType.VarChar, -1).Value = objFeedbacks.Feedback;
                cmd.Parameters.Add("@FeedbackId", SqlDbType.Int).Value = objFeedbacks.FeedbackId;
                cmd.Parameters["@FeedbackId"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@Rate", SqlDbType.Int).Value = objFeedbacks.Rate;
                cmd.Parameters.Add("@StatusId", SqlDbType.Int).Value = objFeedbacks.StatusId;
                cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = objFeedbacks.UserId;

                cmd.ExecuteNonQuery();

                //after updating the Feedbacks, update FeedbackId
                objFeedbacks.FeedbackId = Convert.ToInt32(cmd.Parameters["@FeedbackId"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteFeedbacks(int FeedbackId, int UserId, int UserTypeId, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from Feedbacks where FeedbackId=@FeedbackId and (UserId=@UserId OR @UserTypeId=3)", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@FeedbackId", SqlDbType.Int).Value = FeedbackId;
                cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = UserId;
                cmd.Parameters.Add("@UserTypeId", SqlDbType.Int).Value = UserTypeId;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        #endregion
    }
}
