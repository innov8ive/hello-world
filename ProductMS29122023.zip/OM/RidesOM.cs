using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace OM
{

    [Serializable]
    [Table(Name = "dbo.Rides")]
    public class Rides
    {

        private System.Nullable<decimal> _ActualFare;
        private System.Nullable<decimal> _EstimatedFare;
        private System.Nullable<decimal> _EstimatedDistanceKM;
        private System.Nullable<decimal> _ActualDistanceKM;
        private System.Nullable<DateTime> _EndTime;
        private System.Nullable<decimal> _PaidFare;
        private string _PaidMode;
        private System.Nullable<DateTime> _PickTime;
        private System.Nullable<int> _RideId;
        private System.Nullable<int> _RideRequestId;
        private System.Nullable<int> _StatusId;
        private string _StatusUpdatedBy;
        private System.Nullable<int> _StatusUpdatedById;
        private System.Nullable<DateTime> _StatusUpdatedOn;
        private string _PlatformBillID;

        [Column(Storage = "_PlatformBillID")]
        public string PlatformBillID
        {
            get
            {
                return _PlatformBillID;
            }
            set
            {
                _PlatformBillID = value;
            }
        }

        [Column(Storage = "_ActualFare")]
        public System.Nullable<decimal> ActualFare
        {
            get
            {
                return _ActualFare;
            }
            set
            {
                _ActualFare = value;
            }
        }

        [Column(Storage = "_EstimatedFare")]
        public System.Nullable<decimal> EstimatedFare
        {
            get
            {
                return _EstimatedFare;
            }
            set
            {
                _EstimatedFare = value;
            }
        }

        [Column(Storage = "_ActualDistanceKM")]
        public System.Nullable<decimal> ActualDistanceKM
        {
            get
            {
                return _ActualDistanceKM;
            }
            set
            {
                _ActualDistanceKM = value;
            }
        }
        [Column(Storage = "_EstimatedDistanceKM")]
        public System.Nullable<decimal> EstimatedDistanceKM
        {
            get
            {
                return _EstimatedDistanceKM;
            }
            set
            {
                _EstimatedDistanceKM = value;
            }
        }

        [Column(Storage = "_EndTime")]
        public System.Nullable<DateTime> EndTime
        {
            get
            {
                return _EndTime;
            }
            set
            {
                _EndTime = value;
            }
        }

        [Column(Storage = "_PaidFare")]
        public System.Nullable<decimal> PaidFare
        {
            get
            {
                return _PaidFare;
            }
            set
            {
                _PaidFare = value;
            }
        }

        [Column(Storage = "_PaidMode")]
        public string PaidMode
        {
            get
            {
                return _PaidMode;
            }
            set
            {
                _PaidMode = value;
            }
        }

        [Column(Storage = "_PickTime")]
        public System.Nullable<DateTime> PickTime
        {
            get
            {
                return _PickTime;
            }
            set
            {
                _PickTime = value;
            }
        }

        [Column(Storage = "_RideId")]
        public System.Nullable<int> RideId
        {
            get
            {
                return _RideId;
            }
            set
            {
                _RideId = value;
            }
        }

        [Column(Storage = "_RideRequestId")]
        public System.Nullable<int> RideRequestId
        {
            get
            {
                return _RideRequestId;
            }
            set
            {
                _RideRequestId = value;
            }
        }

        [Column(Storage = "_StatusId")]
        public System.Nullable<int> StatusId
        {
            get
            {
                return _StatusId;
            }
            set
            {
                _StatusId = value;
            }
        }

        [Column(Storage = "_StatusUpdatedBy")]
        public string StatusUpdatedBy
        {
            get
            {
                return _StatusUpdatedBy;
            }
            set
            {
                _StatusUpdatedBy = value;
            }
        }

        [Column(Storage = "_StatusUpdatedById")]
        public System.Nullable<int> StatusUpdatedById
        {
            get
            {
                return _StatusUpdatedById;
            }
            set
            {
                _StatusUpdatedById = value;
            }
        }

        [Column(Storage = "_StatusUpdatedOn")]
        public System.Nullable<DateTime> StatusUpdatedOn
        {
            get
            {
                return _StatusUpdatedOn;
            }
            set
            {
                _StatusUpdatedOn = value;
            }
        }


        public System.Collections.Generic.List<RideLocations> RideLocationsList { get; set; }
        public Hashtable Types { get; set; }
    }


    [Serializable]
    [Table(Name = "dbo.RideLocations")]
    public class RideLocations
    {

        private System.Nullable<DateTime> _CaptureDate;
        private System.Nullable<decimal> _Lat;
        private System.Nullable<decimal> _Long;
        private System.Nullable<int> _RideId;
        private System.Nullable<int> _RideLocationId;



        [Column(Storage = "_CaptureDate")]
        public System.Nullable<DateTime> CaptureDate
        {
            get
            {
                return _CaptureDate;
            }
            set
            {
                _CaptureDate = value;
            }
        }



        [Column(Storage = "_Lat")]
        public System.Nullable<decimal> Lat
        {
            get
            {
                return _Lat;
            }
            set
            {
                _Lat = value;
            }
        }



        [Column(Storage = "_Long")]
        public System.Nullable<decimal> Long
        {
            get
            {
                return _Long;
            }
            set
            {
                _Long = value;
            }
        }



        [Column(Storage = "_RideId")]
        public System.Nullable<int> RideId
        {
            get
            {
                return _RideId;
            }
            set
            {
                _RideId = value;
            }
        }



        [Column(Storage = "_RideLocationId")]
        public System.Nullable<int> RideLocationId
        {
            get
            {
                return _RideLocationId;
            }
            set
            {
                _RideLocationId = value;
            }
        }

    }}
