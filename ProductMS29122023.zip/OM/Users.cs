﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace OM
{
    [Serializable]
    [Table(Name = "dbo.Users")]
    public class Users
    {
        private decimal? _CurrentLat;
        private decimal? _CurrentLong;
        private string _EmailId;
        private string _FirstName;
        private System.Nullable<bool> _IsActive;
        private string _LastName;
        private string _Mobile;
        private string _MobileVerified;
        private string _Password;
        private System.Nullable<DateTime> _RegDate;
        private System.Nullable<int> _StatusId;
        private System.Nullable<int> _UserId;
        private System.Nullable<int> _UserTypeId;
       
        [Column(Storage = "_CurrentLat")]
        public decimal? CurrentLat
        {
            get
            {
                return _CurrentLat;
            }
            set
            {
                _CurrentLat = value;
            }
        }

        [Column(Storage = "_CurrentLong")]
        public decimal? CurrentLong
        {
            get
            {
                return _CurrentLong;
            }
            set
            {
                _CurrentLong = value;
            }
        }

        [Column(Storage = "_EmailId")]
        public string EmailId
        {
            get
            {
                return _EmailId;
            }
            set
            {
                _EmailId = value;
            }
        }

        [Column(Storage = "_FirstName")]
        public string FirstName
        {
            get
            {
                return _FirstName;
            }
            set
            {
                _FirstName = value;
            }
        }

        [Column(Storage = "_IsActive")]
        public System.Nullable<bool> IsActive
        {
            get
            {
                return _IsActive;
            }
            set
            {
                _IsActive = value;
            }
        }

        [Column(Storage = "_LastName")]
        public string LastName
        {
            get
            {
                return _LastName;
            }
            set
            {
                _LastName = value;
            }
        }

        [Column(Storage = "_Mobile")]
        public string Mobile
        {
            get
            {
                return _Mobile;
            }
            set
            {
                _Mobile = value;
            }
        }

        [Column(Storage = "_MobileVerified")]
        public string MobileVerified
        {
            get
            {
                return _MobileVerified;
            }
            set
            {
                _MobileVerified = value;
            }
        }

        [Column(Storage = "_Password")]
        public string Password
        {
            get
            {
                return _Password;
            }
            set
            {
                _Password = value;
            }
        }

        [Column(Storage = "_RegDate")]
        public System.Nullable<DateTime> RegDate
        {
            get
            {
                return _RegDate;
            }
            set
            {
                _RegDate = value;
            }
        }

        [Column(Storage = "_StatusId")]
        public System.Nullable<int> StatusId
        {
            get
            {
                return _StatusId;
            }
            set
            {
                _StatusId = value;
            }
        }

        [Column(Storage = "_UserId")]
        public System.Nullable<int> UserId
        {
            get
            {
                return _UserId;
            }
            set
            {
                _UserId = value;
            }
        }

        [Column(Storage = "_UserTypeId")]
        public System.Nullable<int> UserTypeId
        {
            get
            {
                return _UserTypeId;
            }
            set
            {
                _UserTypeId = value;
            }
        }
    }


}
