using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace OM
{

    [Serializable]
    [Table(Name = "dbo.RideRequests")]
    public class RideRequests
    {

        private System.Nullable<int> _CommTxnId;
        private System.Nullable<decimal> _DistanceKM;
        private System.Nullable<decimal> _EstimatedFare;
        private System.Nullable<int> _FromUserId;
        private System.Nullable<DateTime> _PickTime;
        private System.Nullable<DateTime> _RequestDate;
        private System.Nullable<int> _RideRequestId;
        private System.Nullable<int> _StatusId;
        private System.Nullable<int> _ToUserId;
        private System.Nullable<decimal> _StartLat;
        private string _StartLocationText;
        private System.Nullable<decimal> _StartLong;
        private System.Nullable<decimal> _EndLat;
        private string _EndLocationText;
        private System.Nullable<decimal> _EndLong;



        [Column(Storage = "_EndLat")]
        public System.Nullable<decimal> EndLat
        {
            get
            {
                return _EndLat;
            }
            set
            {
                _EndLat = value;
            }
        }

        [Column(Storage = "_EndLocationText")]
        public string EndLocationText
        {
            get
            {
                return _EndLocationText;
            }
            set
            {
                _EndLocationText = value;
            }
        }

        [Column(Storage = "_EndLong")]
        public System.Nullable<decimal> EndLong
        {
            get
            {
                return _EndLong;
            }
            set
            {
                _EndLong = value;
            }
        }

        [Column(Storage = "_StartLat")]
        public System.Nullable<decimal> StartLat
        {
            get
            {
                return _StartLat;
            }
            set
            {
                _StartLat = value;
            }
        }

        [Column(Storage = "_StartLocationText")]
        public string StartLocationText
        {
            get
            {
                return _StartLocationText;
            }
            set
            {
                _StartLocationText = value;
            }
        }

        [Column(Storage = "_StartLong")]
        public System.Nullable<decimal> StartLong
        {
            get
            {
                return _StartLong;
            }
            set
            {
                _StartLong = value;
            }
        }

        [Column(Storage = "_CommTxnId")]
        public System.Nullable<int> CommTxnId
        {
            get
            {
                return _CommTxnId;
            }
            set
            {
                _CommTxnId = value;
            }
        }



        [Column(Storage = "_DistanceKM")]
        public System.Nullable<decimal> DistanceKM
        {
            get
            {
                return _DistanceKM;
            }
            set
            {
                _DistanceKM = value;
            }
        }



        [Column(Storage = "_EstimatedFare")]
        public System.Nullable<decimal> EstimatedFare
        {
            get
            {
                return _EstimatedFare;
            }
            set
            {
                _EstimatedFare = value;
            }
        }



        [Column(Storage = "_FromUserId")]
        public System.Nullable<int> FromUserId
        {
            get
            {
                return _FromUserId;
            }
            set
            {
                _FromUserId = value;
            }
        }



        [Column(Storage = "_PickTime")]
        public System.Nullable<DateTime> PickTime
        {
            get
            {
                return _PickTime;
            }
            set
            {
                _PickTime = value;
            }
        }



        [Column(Storage = "_RequestDate")]
        public System.Nullable<DateTime> RequestDate
        {
            get
            {
                return _RequestDate;
            }
            set
            {
                _RequestDate = value;
            }
        }



        [Column(Storage = "_RideRequestId")]
        public System.Nullable<int> RideRequestId
        {
            get
            {
                return _RideRequestId;
            }
            set
            {
                _RideRequestId = value;
            }
        }



        [Column(Storage = "_StatusId")]
        public System.Nullable<int> StatusId
        {
            get
            {
                return _StatusId;
            }
            set
            {
                _StatusId = value;
            }
        }



        [Column(Storage = "_ToUserId")]
        public System.Nullable<int> ToUserId
        {
            get
            {
                return _ToUserId;
            }
            set
            {
                _ToUserId = value;
            }
        }

    }}
