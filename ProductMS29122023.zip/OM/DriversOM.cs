using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace OM
{

    [Serializable]
    [Table(Name = "dbo.Drivers")]
    public class Drivers
    {

        private System.Nullable<int> _CityId;
        private System.Nullable<DateTime> _DLExpiryDate;
        private string _DLNo;
        private System.Nullable<int> _DriverId;
        private string _FullAddress;
        private System.Nullable<int> _UserId;
        private System.Nullable<int> _VehicleTypeId;
        private string _Zipcode;



        [Column(Storage = "_CityId")]
        public System.Nullable<int> CityId
        {
            get
            {
                return _CityId;
            }
            set
            {
                _CityId = value;
            }
        }



        [Column(Storage = "_DLExpiryDate")]
        public System.Nullable<DateTime> DLExpiryDate
        {
            get
            {
                return _DLExpiryDate;
            }
            set
            {
                _DLExpiryDate = value;
            }
        }



        [Column(Storage = "_DLNo")]
        public string DLNo
        {
            get
            {
                return _DLNo;
            }
            set
            {
                _DLNo = value;
            }
        }



        [Column(Storage = "_DriverId")]
        public System.Nullable<int> DriverId
        {
            get
            {
                return _DriverId;
            }
            set
            {
                _DriverId = value;
            }
        }



        [Column(Storage = "_FullAddress")]
        public string FullAddress
        {
            get
            {
                return _FullAddress;
            }
            set
            {
                _FullAddress = value;
            }
        }



        [Column(Storage = "_UserId")]
        public System.Nullable<int> UserId
        {
            get
            {
                return _UserId;
            }
            set
            {
                _UserId = value;
            }
        }



        [Column(Storage = "_VehicleTypeId")]
        public System.Nullable<int> VehicleTypeId
        {
            get
            {
                return _VehicleTypeId;
            }
            set
            {
                _VehicleTypeId = value;
            }
        }



        [Column(Storage = "_Zipcode")]
        public string Zipcode
        {
            get
            {
                return _Zipcode;
            }
            set
            {
                _Zipcode = value;
            }
        }

    }}
