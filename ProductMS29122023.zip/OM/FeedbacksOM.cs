using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace OM
{

    [Serializable]
    [Table(Name = "dbo.Feedbacks")]
    public class Feedbacks
    {

        private System.Nullable<int> _DriverUserId;
        private System.Nullable<DateTime> _EntryDate;
        private string _Feedback;
        private System.Nullable<int> _FeedbackId;
        private System.Nullable<int> _Rate;
        private System.Nullable<int> _StatusId;
        private System.Nullable<int> _UserId;
        private string _AddedByUser;
        private string _DriverName;

        [Column(Storage = "_DriverName")]
        public string DriverName
        {
            get
            {
                return _DriverName;
            }
            set
            {
                _DriverName = value;
            }
        }

        [Column(Storage = "_AddedByUser")]
        public string AddedByUser
        {
            get
            {
                return _AddedByUser;
            }
            set
            {
                _AddedByUser = value;
            }
        }

        [Column(Storage = "_DriverUserId")]
        public System.Nullable<int> DriverUserId
        {
            get
            {
                return _DriverUserId;
            }
            set
            {
                _DriverUserId = value;
            }
        }



        [Column(Storage = "_EntryDate")]
        public System.Nullable<DateTime> EntryDate
        {
            get
            {
                return _EntryDate;
            }
            set
            {
                _EntryDate = value;
            }
        }



        [Column(Storage = "_Feedback")]
        public string Feedback
        {
            get
            {
                return _Feedback;
            }
            set
            {
                _Feedback = value;
            }
        }



        [Column(Storage = "_FeedbackId")]
        public System.Nullable<int> FeedbackId
        {
            get
            {
                return _FeedbackId;
            }
            set
            {
                _FeedbackId = value;
            }
        }



        [Column(Storage = "_Rate")]
        public System.Nullable<int> Rate
        {
            get
            {
                return _Rate;
            }
            set
            {
                _Rate = value;
            }
        }



        [Column(Storage = "_StatusId")]
        public System.Nullable<int> StatusId
        {
            get
            {
                return _StatusId;
            }
            set
            {
                _StatusId = value;
            }
        }



        [Column(Storage = "_UserId")]
        public System.Nullable<int> UserId
        {
            get
            {
                return _UserId;
            }
            set
            {
                _UserId = value;
            }
        }

    }}
