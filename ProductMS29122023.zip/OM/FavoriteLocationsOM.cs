using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace OM
{

    [Serializable]
    [Table(Name = "dbo.FavoriteLocations")]
    public class FavoriteLocations
    {

        private string _GMapName;
        private string _Lat;
        private System.Nullable<int> _LocationId;
        private string _LocationName;
        private System.Nullable<int> _LocationTypeId;
        private string _Long;
        private int _UserId;

        [Column(Storage = "_UserId")]
        public int UserId
        {
            get
            {
                return _UserId;
            }
            set
            {
                _UserId = value;
            }
        }

        [Column(Storage = "_GMapName")]
        public string GMapName
        {
            get
            {
                return _GMapName;
            }
            set
            {
                _GMapName = value;
            }
        }



        [Column(Storage = "_Lat")]
        public string Lat
        {
            get
            {
                return _Lat;
            }
            set
            {
                _Lat = value;
            }
        }



        [Column(Storage = "_LocationId")]
        public System.Nullable<int> LocationId
        {
            get
            {
                return _LocationId;
            }
            set
            {
                _LocationId = value;
            }
        }



        [Column(Storage = "_LocationName")]
        public string LocationName
        {
            get
            {
                return _LocationName;
            }
            set
            {
                _LocationName = value;
            }
        }



        [Column(Storage = "_LocationTypeId")]
        public System.Nullable<int> LocationTypeId
        {
            get
            {
                return _LocationTypeId;
            }
            set
            {
                _LocationTypeId = value;
            }
        }



        [Column(Storage = "_Long")]
        public string Long
        {
            get
            {
                return _Long;
            }
            set
            {
                _Long = value;
            }
        }

    }}
