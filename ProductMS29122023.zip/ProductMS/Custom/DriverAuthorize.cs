﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using ProductMS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace ProductMS.Custom
{
    public class DriverAuthorizeFilter: IAuthorizationFilter
    {
        private readonly IEnumerable<Claim> _claims;
        private readonly ClaimsIdentity _identity;
        public DriverAuthorizeFilter(IHttpContextAccessor httpContextAccessor)
        {
            _claims = httpContextAccessor.HttpContext.User.Claims;
            _identity = httpContextAccessor.HttpContext.User.Identity as ClaimsIdentity;
        }

        public void OnAuthorization(AuthorizationFilterContext context)
        {
            if (context != null)
            {
                if (Common.ToInt(_identity.FindFirst("UserTypeId").Value) != (int)UserType.Driver)
                {
                    context.Result = new UnauthorizedResult();
                    return;
                }
            }
        }
    }

    public class DriverAuthorizeAttribute : TypeFilterAttribute
    {
        public DriverAuthorizeAttribute() : base(typeof(DriverAuthorizeFilter))
        {
        }
    }
}
