﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Threading.Tasks;
using BL;
using FluentValidation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using OM;
using ProductMS.Custom;
using ProductMS.Models;

namespace ProductMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController, DriverAuthorize]
    public class DriverController : ControllerBase
    {
        IConfiguration _appSettings;
        private readonly IHubContext<ChatHub> _hubContext;
        public DriverController(IConfiguration configuration, IHubContext<ChatHub> hubContext)
        {
            _appSettings = configuration;
            _hubContext = hubContext;
        }

        [HttpPost, DisableRequestSizeLimit]
        public async Task<IActionResult> UploadImage()
        {
            try
            {
                var formCollection = await Request.ReadFormAsync();
                var file = formCollection.Files.First();
                var folderName = Path.Combine("Resources", "Images");
                var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), folderName);
                if (file.Length > 0)
                {
                    string extension = Path.GetExtension(ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName).ToLower();
                    if (extension != "jpg" && extension != "jpeg" && extension != "png")
                    {
                        return BadRequest();
                    }
                    string fileData = file.Name;
                    if (string.IsNullOrEmpty(fileData))
                    {
                        return BadRequest();
                    }
                    string docType = fileData.Substring(0, fileData.IndexOf("`"));
                    var fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
                    var newFileName = Guid.NewGuid().ToString() + extension;
                    var fullPath = Path.Combine(pathToSave, newFileName);
                    var dbPath = Path.Combine(folderName, newFileName);
                    using (var stream = new FileStream(fullPath, FileMode.Create))
                    {
                        file.CopyTo(stream);
                    }
                    var identity = HttpContext.User.Identity as ClaimsIdentity;
                    int UserId = Common.ToInt(identity.FindFirst("UserId").Value);

                    DriverDocsBL objDriverDocsBL = new DriverDocsBL(Common.GetConString(_appSettings));
                    DriverDocs driverDocs = new DriverDocs();
                    driverDocs.FileGUID = dbPath;
                    driverDocs.UploadedOn = DateTime.Now;
                    driverDocs.DocTypeId = Common.ToInt(docType);
                    driverDocs.StatusId = (int)Status.Pending;
                    driverDocs.UserId = UserId;
                    objDriverDocsBL.Data = driverDocs;
                    objDriverDocsBL.Update();

                    Common.ChangeDriverStatus(UserId, Status.Pending, "Pending, because new document(s) uploaded.", _appSettings);

                    return Ok(new { dbPath });
                }
                else
                {
                    return BadRequest();
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex}");
            }
        }

        [HttpPost("deleteDocument", Name = "DeleteDocument")]
        public IActionResult DeleteDocument([FromBody] dynamic user)
        {
            if (user is null || Common.ToInt(user.DriverDocId) <= 0)
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                DriverDocsBL objDriverDocsBL = new DriverDocsBL(Common.GetConString(_appSettings));
                objDriverDocsBL.Load(Common.ToInt(user.DriverDocId));
                if (objDriverDocsBL.Data != null && !string.IsNullOrEmpty(objDriverDocsBL.Data.FileGUID))
                {
                    try
                    {
                        var pathToDelete = Path.Combine(Directory.GetCurrentDirectory(), objDriverDocsBL.Data.FileGUID);
                        System.IO.File.Delete(pathToDelete);
                    }
                    catch
                    {

                    }
                }
                objDriverDocsBL.Delete(Common.ToInt(user.DriverDocId));
                return Ok("Success");
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("getDocuments", Name = "GetDocuments")]
        public IActionResult GetDocuments([FromBody] dynamic user)
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int UserId = Common.ToInt(identity.FindFirst("UserId").Value);
            try
            {
                return Ok(Common.GetDriverDocuments(UserId, _appSettings));
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("setOnDuty", Name = "SetOnDuty")]
        public IActionResult SetOnDuty([FromBody] dynamic user)
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int UserId = Common.ToInt(identity.FindFirst("UserId").Value);
            try
            {
                return Ok(Common.ChangeOnOffDuty(UserId, true, _appSettings));
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("setOffDuty", Name = "SetOffDuty")]
        public IActionResult SetOffDuty([FromBody] dynamic user)
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int UserId = Common.ToInt(identity.FindFirst("UserId").Value);
            try
            {
                return Ok(Common.ChangeOnOffDuty(UserId, false, _appSettings));
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpGet("getDetails", Name = "GetDetails")]
        public IActionResult GetDetails()
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int UserId = Common.ToInt(identity.FindFirst("UserId").Value);
            try
            {
                DriversBL objDriversBL = new DriversBL(Common.GetConString(_appSettings));
                objDriversBL.Load(UserId);
                var result = objDriversBL.Data;
                return Ok(result);
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("updateDetails", Name = "UpdateDetails")]
        public IActionResult UpdateDetails([FromBody] dynamic value)
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int UserId = Common.ToInt(identity.FindFirst("UserId").Value);
            try
            {
                JObject objJObject = value;
                Drivers objDrivers = objJObject.ToObject<Drivers>();
                DriversBL objDriversBL = new DriversBL(Common.GetConString(_appSettings));
                objDriversBL.Data = objDrivers;
                objDriversBL.Data.UserId = UserId;

                DriversValidator validator = new DriversValidator();
                var results = validator.Validate(objDrivers);

                if (results.IsValid)
                {
                    objDriversBL.Update();
                    Common.ChangeDriverStatus(UserId, Status.Pending, "Pending, because details updated.", _appSettings);
                    return Ok(objDriversBL.Data);
                }

                return BadRequest(results.Errors);
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("acceptRequest", Name = "AcceptRequest")]
        public IActionResult AcceptRequest([FromBody] dynamic user)
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            string userName = Common.ToString(identity.FindFirst("FirstName").Value) + " " + Common.ToString(identity.FindFirst("LastName").Value);
            if (user is null || Common.ToInt(user.RideRequestId) <= 0)
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                string result = Common.ChangeRequestStatus(Common.ToInt(user.RideRequestId), Status.Accepted, _appSettings);
                _hubContext.Clients.Group(Common.ToString(user.RideRequestId)).SendAsync("RequestAccepted", "Accepted", userName);
                return Ok(result);
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("rejectRequest", Name = "RejectRequest")]
        public IActionResult RejectRequest([FromBody] dynamic user)
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            string userName = Common.ToString(identity.FindFirst("FirstName").Value) + " " + Common.ToString(identity.FindFirst("LastName").Value);
            if (user is null || Common.ToInt(user.RideRequestId) <= 0)
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                string result = Common.ChangeRequestStatus(Common.ToInt(user.RideRequestId), Status.Rejected, _appSettings);
                _hubContext.Clients.Group(Common.ToString(user.RideRequestId)).SendAsync("RequestRejected", "Rejected", userName);
                return Ok(result);
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("startRide", Name = "StartRide")]
        public IActionResult StartRide([FromBody] dynamic value)
        {
            RidesBL objRidesBL = new RidesBL(Common.GetConString(_appSettings));

            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int userId = Common.ToInt(identity.FindFirst("UserId").Value);
            string userName = Common.ToString(identity.FindFirst("FirstName").Value) + " " + Common.ToString(identity.FindFirst("LastName").Value);
            if (value is null || Common.ToDecimal(value.EstimatedDistanceKM) == 0 || Common.ToDecimal(value.EstimatedFare) == 0
                || Common.ToInt(value.RideRequestId) == 0)
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                objRidesBL.Load(0);
                Rides rides = objRidesBL.Data;
                rides.EstimatedDistanceKM = Common.ToDecimal(value.EstimatedDistanceKM);
                rides.EstimatedFare = Common.ToDecimal(value.EstimatedFare);
                rides.PickTime = DateTime.Now;
                rides.RideRequestId = Common.ToInt(value.RideRequestId);
                rides.RideId = 0;
                rides.StatusId = (int)Status.InTransit;
                rides.StatusUpdatedOn = DateTime.Now;
                rides.StatusUpdatedById = userId;
                rides.StatusUpdatedBy = "Driver";
                objRidesBL.Update();
                _hubContext.Clients.Group(Common.ToString(value.RideRequestId)).SendAsync("RideStarted", "Started", userName);
                return Ok("Success");
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("updateRideLocation", Name = "UpdateRideLocation")]
        public IActionResult UpdateRideLocation([FromBody] dynamic value)
        {
            try
            {
                JObject objJObject = value;
                RideLocations objRideLocations = objJObject.ToObject<RideLocations>();
                RidesBL objRidesBL = new RidesBL(Common.GetConString(_appSettings));
                objRidesBL.InsertIntoRideLocations(objRideLocations);
                return Ok("Success");
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("endRide", Name = "EndRide")]
        public IActionResult EndRide([FromBody] dynamic value)
        {
            RidesBL objRidesBL = new RidesBL(Common.GetConString(_appSettings));

            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int userId = Common.ToInt(identity.FindFirst("UserId").Value);
            string userName = Common.ToString(identity.FindFirst("FirstName").Value) + " " + Common.ToString(identity.FindFirst("LastName").Value);
            if (value is null || Common.ToInt(value.RideId) == 0 || 
                Common.ToDecimal(value.ActualDistanceKM) == 0 || Common.ToDecimal(value.ActualFare) == 0)
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                objRidesBL.Load(Common.ToInt(value.RideId));
                Rides rides = objRidesBL.Data;
                if (rides.StatusUpdatedById != userId)
                {
                    return BadRequest("Invalid user request!!!");
                }
                rides.ActualDistanceKM = Common.ToDecimal(value.ActualDistanceKM);
                rides.ActualFare = Common.ToDecimal(value.ActualFare);
                rides.EndTime = DateTime.Now;
                rides.StatusId = (int)Status.Completed;
                rides.StatusUpdatedOn = DateTime.Now;
                rides.StatusUpdatedById = userId;
                rides.StatusUpdatedBy = "Driver";
                objRidesBL.Update();
                _hubContext.Clients.Group(Common.ToString(rides.RideRequestId)).SendAsync("RideCompleted", "Completed", userName);
                return Ok("Success");
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("ridePayment", Name = "RidePayment")]
        public IActionResult RidePayment([FromBody] dynamic value)
        {
            RidesBL objRidesBL = new RidesBL(Common.GetConString(_appSettings));

            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int userId = Common.ToInt(identity.FindFirst("UserId").Value);
            string userName = Common.ToString(identity.FindFirst("FirstName").Value) + " " + Common.ToString(identity.FindFirst("LastName").Value);
            if (value is null || Common.ToInt(value.RideId) == 0 ||
                Common.ToDecimal(value.PaidFare) == 0 || Common.ToString(value.PaidMode).Length == 0
                || Common.ToString(value.PlatformBillID).Length == 0)
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                objRidesBL.Load(Common.ToInt(value.RideId));
                Rides rides = objRidesBL.Data;
                if (rides.StatusUpdatedById != userId)
                {
                    return BadRequest("Invalid user request!!!");
                }
                rides.PaidFare = Common.ToDecimal(value.PaidFare);
                rides.PaidMode = Common.ToString(value.PaidMode);
                rides.PlatformBillID = Common.ToString(value.PlatformBillID);
                rides.StatusUpdatedOn = DateTime.Now;
                rides.StatusUpdatedById = userId;
                rides.StatusUpdatedBy = "Driver";
                objRidesBL.Update();
                _hubContext.Clients.Group(Common.ToString(rides.RideRequestId)).SendAsync("RidePaid", "Paid", userName);
                return Ok("Success");
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("generatePaymentLink", Name = "GeneratePaymentLink")]
        public IActionResult GeneratePaymentLink([FromBody] dynamic value)
        {
            RidesBL objRidesBL = new RidesBL(Common.GetConString(_appSettings));

            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int userId = Common.ToInt(identity.FindFirst("UserId").Value);
            string userName = Common.ToString(identity.FindFirst("FirstName").Value) + " " + Common.ToString(identity.FindFirst("LastName").Value);
            if (value is null || Common.ToInt(value.RideId) == 0 ||
                Common.ToInt(value.ActualFare) == 0 || Common.ToInt(value.RideRequestId) == 0)
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                objRidesBL.Load(Common.ToInt(value.RideId));
                Rides rides = objRidesBL.Data;
                if (rides.StatusUpdatedById != userId)
                {
                    return BadRequest("Invalid user request!!!");
                }

                SetuHelper setuHelper = new SetuHelper(1, Common.GetConString(_appSettings));
                setuHelper.Token = setuHelper.GetExistingToken();
                string link = setuHelper.GenerateDeepLink(Common.ToInt(value.ActualFare), "ApnaCab", Common.ToInt(value.RideId));
                if(!string.IsNullOrEmpty(link) && link.Contains("`"))
                {
                    rides.PlatformBillID = link.Split('`')[0];
                    objRidesBL.Update();
                    _hubContext.Clients.Group(Common.ToString(value.RideRequestId)).SendAsync("PaymentLinkGenerated", "LinkGenerated", userName);
                    return Ok(link);
                }
                return BadRequest("Error occurred in generating payment link!!!");
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("checkLinkStatus", Name = "CheckLinkStatus")]
        public IActionResult CheckLinkStatus([FromBody] dynamic value)
        {
            RidesBL objRidesBL = new RidesBL(Common.GetConString(_appSettings));

            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int userId = Common.ToInt(identity.FindFirst("UserId").Value);
            string userName = Common.ToString(identity.FindFirst("FirstName").Value) + " " + Common.ToString(identity.FindFirst("LastName").Value);
            if (value is null || Common.ToInt(value.RideId) == 0 ||
                Common.ToString(value.PlatformBillID).Length == 0 || Common.ToInt(value.RideRequestId) == 0)
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                objRidesBL.Load(Common.ToInt(value.RideId));
                Rides rides = objRidesBL.Data;
                if (rides.StatusUpdatedById != userId)
                {
                    return BadRequest("Invalid user request!!!");
                }

                SetuHelper setuHelper = new SetuHelper(1, Common.GetConString(_appSettings));
                setuHelper.Token = setuHelper.GetExistingToken();
                string status = setuHelper.CheckLinkStatus(Common.ToString(value.PlatformBillID));
                _hubContext.Clients.Group(Common.ToString(value.RideRequestId)).SendAsync("PaymentStatus", status, userName);
                if (!string.IsNullOrEmpty(status) && status == "SETTLEMENT_SUCCESSFUL")
                {
                    return Ok("Success");
                }
                return BadRequest("Error occurred in checking Link Status!!!");
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }
    }

    public class DriversValidator : AbstractValidator<Drivers>
    {
        public DriversValidator()
        {

            RuleFor(obj => obj.CityId).NotEmpty();
            RuleFor(obj => obj.DLExpiryDate).NotEmpty();
            RuleFor(obj => obj.DLNo).NotEmpty();
            RuleFor(obj => obj.FullAddress).NotEmpty();
            RuleFor(obj => obj.UserId).NotEmpty();
            RuleFor(obj => obj.VehicleTypeId).NotEmpty();
            RuleFor(obj => obj.Zipcode).NotEmpty();
        }
    }
}
