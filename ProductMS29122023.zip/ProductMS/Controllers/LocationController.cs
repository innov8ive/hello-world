﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using BL;
using FluentValidation;
using FluentValidation.Results;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using OM;
using ProductMS.Models;

namespace ProductMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LocationController : ControllerBase
    {
        IConfiguration _appSettings;
        public LocationController(IConfiguration configuration)
        {
            _appSettings = configuration;
        }

        [HttpGet("{id}"), Authorize]
        public IActionResult Get(int id)
        {
            try
            {
                FavoriteLocationsBL objFavoriteLocationsBL = new FavoriteLocationsBL(Common.GetConString(_appSettings));
                objFavoriteLocationsBL.Load(id);
                return Ok(objFavoriteLocationsBL.Data);
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }


        // POST api/FavoriteLocations/
        [HttpPost, Authorize]
        public IActionResult Post([FromBody]dynamic value)
        {
            try
            {
                JObject objJObject = value;
                FavoriteLocations objFavoriteLocations = objJObject.ToObject<FavoriteLocations>();
                FavoriteLocationsBL objFavoriteLocationsBL = new FavoriteLocationsBL(Common.GetConString(_appSettings));

                var identity = HttpContext.User.Identity as ClaimsIdentity;
                int UserId = Common.ToInt(identity.FindFirst("UserId").Value);
                int UserTypeId = Common.ToInt(identity.FindFirst("UserTypeId").Value);
                if (objFavoriteLocationsBL.Data.LocationId != null && objFavoriteLocationsBL.Data.LocationId <= 0)
                {
                    objFavoriteLocationsBL.Data.UserId = UserId;
                }
                if (objFavoriteLocationsBL.Data.UserId != UserId && UserTypeId != (int)UserType.Admin)
                {
                    return BadRequest("Invalid FeedbackId!");
                }

                objFavoriteLocationsBL.Data.UserId = UserId;

                FavoriteLocationsValidator validator = new FavoriteLocationsValidator();
                ValidationResult results = validator.Validate(objFavoriteLocations);

                if (results.IsValid)
                {
                    objFavoriteLocationsBL.Update();
                    return Ok(objFavoriteLocationsBL.Data);
                }

                return BadRequest(results.Errors);
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        // DELETE api/FavoriteLocations/5
        [Route("{id}")]
        [HttpDelete, Authorize]
        public IActionResult Delete(int id)
        {
            try
            {
                var identity = HttpContext.User.Identity as ClaimsIdentity;
                FavoriteLocationsBL objFavoriteLocationsBL = new FavoriteLocationsBL(Common.GetConString(_appSettings));
                return Ok(objFavoriteLocationsBL.Delete(id, Common.ToInt(identity.FindFirst("UserId").Value)) ? "Success" : "Failed");
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }           
        }

        [HttpGet("getUserLocations/{id}", Name = "GetUserLocations"), Authorize]
        public IActionResult GetUserLocations(int id)
        {
            try
            {
                FavoriteLocationsBL objLocBL = new FavoriteLocationsBL(Common.GetConString(_appSettings));
                return Ok(objLocBL.LoadForUser(id));
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }
    }
    public class FavoriteLocationsValidator : AbstractValidator<FavoriteLocations>
    {
        public FavoriteLocationsValidator()
        {

            RuleFor(obj => obj.GMapName).NotEmpty();
            RuleFor(obj => obj.Lat).NotEmpty();
            RuleFor(obj => obj.LocationName).NotEmpty();
            RuleFor(obj => obj.LocationTypeId).NotEmpty();
            RuleFor(obj => obj.Long).NotEmpty();
        }
    }
}