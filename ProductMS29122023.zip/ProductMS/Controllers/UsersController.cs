﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using BL;
using FluentValidation;
using FluentValidation.Results;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using OM;
using ProductMS.Models;

namespace ProductMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        IConfiguration _appSettings;
        private readonly IHubContext<ChatHub> _hubContext;
        public UsersController(IConfiguration configuration, IHubContext<ChatHub> hubContext)
        {
            _appSettings = configuration;
            _hubContext = hubContext;
        }

        [HttpGet("getUserProfile", Name = "GetUserProfile"), Authorize]
        public IActionResult GetUserProfile()
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            if (identity != null)
            {
                int userId = Common.ToInt(identity.FindFirst("UserId").Value);
                try
                {
                    var result = Common.GetDBResultParameterized(_appSettings, "Select U.UserId,U.EmailId,U.Mobile,U.FirstName,U.LastName,U.CurrentLat,U.CurrentLong,U.RegDate FROM Users U where U.UserId=@UserId",
                        "@UserId", SqlDbType.Int, userId);
                    //UsersBL objUsersBL = new UsersBL(Common.GetConString(_appSettings));
                    //objUsersBL.Load(userId);
                    //return Ok(objUsersBL.Data);
                    return Ok(result);
                }
                catch (Exception Ex)
                {
                    return StatusCode(500, Ex.Message);
                }
            }
            else
            {
                return Unauthorized();
            }
        }

        [HttpPost("register", Name = "Register")]
        public IActionResult Register([FromBody] dynamic value)
        {
            return RegisterUser(value, 1);
        }

        [HttpPost("registerDriver", Name = "RegisterDriver")]
        public IActionResult RegisterDriver([FromBody] dynamic value)
        {
            return RegisterUser(value, 2);
        }

        private IActionResult RegisterUser(dynamic value, int userTypeId)
        {
            JObject objJObject = value;
            Users objUsers = objJObject.ToObject<Users>();
            UsersBL objUsersBL = new UsersBL(Common.GetConString(_appSettings));
            objUsersBL.Data = objUsers;
            objUsers.UserTypeId = userTypeId;

            objUsers.RegDate = DateTime.Now;
            objUsers.StatusId = objUsers.UserTypeId == (int)UserType.Rider ? (int)Status.Approved : (int)Status.Pending;
            objUsers.Password = string.IsNullOrEmpty(objUsers.Password) ? null : Common.MD5Encryption(objUsers.Password);
            objUsers.MobileVerified = "YES";
            objUsers.IsActive = true;

            UsersValidator validator = new UsersValidator();
            ValidationResult results = validator.Validate(objUsers);
            if (objUsers.Mobile.Length != 10)
            {
                results.Errors.Add(new ValidationFailure("Mobile", "Mobile No. should be 10 digit only"));
            }
            if (Common.ToString(objUsers.Mobile).Length > 0)
            {
                bool isAvailable = Common.CheckUserIsAvailable(objUsers.Mobile, 0, _appSettings);
                if (!isAvailable)
                {
                    ValidationFailure emailError = new ValidationFailure("Mobile", "Mobile is already registered, please choose another Mobile");
                    results.Errors.Add(emailError);
                }
            }
            if (results.IsValid)
            {
                objUsersBL.Update();
                return Ok(objUsersBL.Data);
            }

            return StatusCode(500, results.Errors);
        }

        [HttpPost("saveDeviceRegId", Name = "SaveDeviceRegId"), Authorize]
        public IActionResult SaveDeviceRegId([FromBody] dynamic value)
        {
            if (value is null || string.IsNullOrEmpty(value.DeviceRegId))
            {
                return BadRequest("Invalid user request!!!");
            }
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            if (identity != null)
            {
                int userId = Common.ToInt(identity.FindFirst("UserId").Value);
               
                try
                {
                    string result = Common.SaveDeviceRegId(userId, value.DeviceRegId, _appSettings);
                    return Ok(result);
                }
                catch (Exception Ex)
                {
                    return StatusCode(500, Ex.Message);
                }
            }
            else
            {
                return Unauthorized();
            }           
        }

        [HttpPost("saveProfile", Name = "SaveProfile"), Authorize]
        public IActionResult SaveProfile([FromBody] dynamic value)
        {
            JObject objJObject = value;
            Users objUsers = objJObject.ToObject<Users>();
            UsersBL objUsersBL = new UsersBL(Common.GetConString(_appSettings));

            objUsersBL.Data.EmailId = objUsers.EmailId;
            objUsersBL.Data.FirstName = objUsers.FirstName;
            objUsersBL.Data.LastName = objUsers.LastName;

            UsersValidator validator = new UsersValidator();
            ValidationResult results = validator.Validate(objUsers);

            if (results.IsValid)
            {
                objUsersBL.Update();
                return Ok(objUsersBL.Data);
            }

            return StatusCode(500, results.Errors);
        }

        [HttpPost("updateCurrentLocation", Name = "UpdateCurrentLocation"), Authorize]
        public IActionResult UpdateCurrentLocation([FromBody] dynamic value)
        {
            if (value is null || string.IsNullOrEmpty(value.Lat) || string.IsNullOrEmpty(value.Long))
            {
                return BadRequest("Invalid user request!!!");
            }

            var identity = HttpContext.User.Identity as ClaimsIdentity;
            if (identity != null)
            {
                int userId = Common.ToInt(identity.FindFirst("UserId").Value);

                try
                {
                    string result = Common.UpdateCurrentLocation(userId, Common.ToDecimal(value.Lat), Common.ToDecimal(value.Long), _appSettings);
                    return Ok(result);
                }
                catch (Exception Ex)
                {
                    return StatusCode(500, Ex.Message);
                }
            }
            else
            {
                return Unauthorized();
            }
        }

        [HttpPost("updateMobile", Name = "UpdateMobile"), Authorize]
        public IActionResult UpdateMobile([FromBody] dynamic value)
        {
            if (value is null || string.IsNullOrEmpty(value.Mobile))
            {
                return BadRequest("Invalid user request!!!");
            }
            if (Common.ToString(value.Mobile).Length != 10)
            {
                return BadRequest("Mobile No. should be 10 digit only");
            }

            var identity = HttpContext.User.Identity as ClaimsIdentity;
            if (identity != null)
            {
                int userId = Common.ToInt(identity.FindFirst("UserId").Value);

                try
                {
                    bool isAvailable = Common.CheckUserIsAvailable(Common.ToString(value.Mobile), userId, _appSettings);
                    if (!isAvailable)
                    {
                        return BadRequest("Mobile is already registered, please choose another Mobile.");
                    }

                    string result = Common.UpdateMobile(userId, Common.ToString(value.Mobile), _appSettings);
                    return Ok(result);
                }
                catch (Exception Ex)
                {
                    return StatusCode(500, Ex.Message);
                }
            }
            else
            {
                return Unauthorized();
            }
        }

        [HttpPost("getNearByDrivers", Name = "GetNearByDrivers"), Authorize]
        public IActionResult GetNearByDrivers([FromBody] dynamic value)
        {
            if (value is null || Common.ToDecimal(value.Lat) == 0 || Common.ToDecimal(value.Long) == 0)
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                var result = Common.GetNearByDrivers(Common.ToDecimal(value.Lat), Common.ToDecimal(value.Long), _appSettings);
                return Ok(result);
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("sendRideRequest", Name = "SendRideRequest"), Authorize]
        public IActionResult SendRideRequest([FromBody] dynamic value)
        {
            JArray objJObject = value.DriverIds;
            List<int> drivers = objJObject.ToObject<List<int>>();
            List<string> driverDeviceRegIds = new List<string>();
            string driverIds = string.Join(",", drivers.Select(n => n.ToString()).ToArray());
            RideRequestsBL objRideRequestsBL = new RideRequestsBL(Common.GetConString(_appSettings));

            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int userId = Common.ToInt(identity.FindFirst("UserId").Value);
            if (value is null || Common.ToDecimal(value.DistanceKM) == 0 || Common.ToDecimal(value.EstimatedFare) == 0)
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                foreach (int driverId in drivers)
                {
                    objRideRequestsBL.Load(0);
                    RideRequests rideRequests = objRideRequestsBL.Data;
                    rideRequests.DistanceKM = Common.ToDecimal(value.DistanceKM);
                    rideRequests.EstimatedFare = Common.ToDecimal(value.EstimatedFare);
                    rideRequests.StartLat = Common.ToDecimal(value.StartLat);
                    rideRequests.StartLong = Common.ToDecimal(value.StartLong);
                    rideRequests.EndLat = Common.ToDecimal(value.EndLat);
                    rideRequests.EndLong = Common.ToDecimal(value.EndLong);
                    rideRequests.StartLocationText = Common.ToString(value.StartLocationText);
                    rideRequests.EndLocationText = Common.ToString(value.EndLocationText);
                    rideRequests.FromUserId = userId;
                    rideRequests.RequestDate = DateTime.Now;
                    rideRequests.RideRequestId = 0;
                    rideRequests.StatusId = (int)Status.Pending;
                    rideRequests.ToUserId = driverId;
                    objRideRequestsBL.Update();
                }

                UsersBL objUsersBL = new UsersBL(Common.GetConString(_appSettings));
                var userDevices = objUsersBL.GetUserDeviceIds(driverIds);
                //Send Push Notifications

                return Ok("Success");
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("cancelRequest", Name = "CancelRequest")]
        public IActionResult CancelRequest([FromBody] dynamic user)
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            string userName = Common.ToString(identity.FindFirst("FirstName").Value)+" "+ Common.ToString(identity.FindFirst("LastName").Value);
            if (user is null || Common.ToInt(user.RideRequestId) <= 0)
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                string result = Common.ChangeRequestStatus(Common.ToInt(user.RideRequestId), Status.Cancelled, _appSettings);
                _hubContext.Clients.Group(Common.ToString(user.RideRequestId)).SendAsync("RequestCancelled", "Cancelled", userName);
                return Ok(result);
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }
    }
    public class UsersValidator : AbstractValidator<Users>
    {
        public UsersValidator()
        {
            RuleFor(obj => obj.EmailId).NotEmpty();
            RuleFor(obj => obj.FirstName).NotEmpty();
            RuleFor(obj => obj.LastName).NotEmpty();
            RuleFor(obj => obj.Mobile).NotEmpty();
            RuleFor(obj => obj.Password).NotEmpty();
            RuleFor(obj => obj.RegDate).NotEmpty();
            RuleFor(obj => obj.StatusId).NotEmpty();
            RuleFor(obj => obj.UserTypeId).NotEmpty();
        }
    }
}