﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using ProductMS.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Authorization;
using ProductMS.Custom;
using BL;

namespace ProductMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController, AdminAuthorize]
    public class AdminController : ControllerBase
    {
        IConfiguration _appSettings;
        public AdminController(IConfiguration configuration)
        {
            _appSettings = configuration;
        }

        [HttpPost("deactivateUser", Name = "DeactivateUser")]
        public IActionResult DeactivateUser([FromBody] dynamic user)
        {
            if (user is null || Common.ToInt(user.UserId) <= 0)
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                string result = Common.DeActivateUser(Common.ToInt(user.UserId), false, _appSettings);
                return Ok(result);
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("activateUser", Name = "ActivateUser")]
        public IActionResult ActivateUser([FromBody] dynamic user)
        {
            if (user is null || Common.ToInt(user.UserId) <= 0)
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                string result = Common.DeActivateUser(Common.ToInt(user.UserId), true, _appSettings);
                return Ok(result);
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("approveDriver", Name = "ApproveDriver")]
        public IActionResult ApproveDriver([FromBody] dynamic user)
        {
            if (user is null || Common.ToInt(user.UserId) <= 0)
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                string result = Common.ChangeDriverStatus(Common.ToInt(user.UserId), Status.Approved, "Approved", _appSettings);
                return Ok(result);
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("rejectDriver", Name = "RejectDriver")]
        public IActionResult RejectDriver([FromBody] dynamic user)
        {
            if (user is null || Common.ToInt(user.UserId) <= 0)
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                string result = Common.ChangeDriverStatus(Common.ToInt(user.UserId), Status.Rejected, Common.ToString(user.ApprovalRemarks), _appSettings);
                return Ok(result);
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("getDriverDocuments", Name = "GetDriverDocuments")]
        public IActionResult GetDriverDocuments([FromBody] dynamic user)
        {
            if (user is null || Common.ToInt(user.UserId) <= 0)
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                return Ok(Common.GetDriverDocuments(Common.ToInt(user.UserId), _appSettings));
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("approveDocument", Name = "ApproveDocument")]
        public IActionResult ApproveDocument([FromBody] dynamic user)
        {
            if (user is null || Common.ToInt(user.DriverDocId) <= 0)
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                string result = Common.ChangeDocumentStatus(Common.ToInt(user.DriverDocId), Status.Approved, _appSettings);
                return Ok(result);
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("rejectDocument", Name = "RejectDocument")]
        public IActionResult RejectDocument([FromBody] dynamic user)
        {
            if (user is null || Common.ToInt(user.DriverDocId) <= 0)
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                string result = Common.ChangeDocumentStatus(Common.ToInt(user.DriverDocId), Status.Rejected, _appSettings);
                return Ok(result);
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("approveFeedback", Name = "ApproveFeedback")]
        public IActionResult ApproveFeedback([FromBody] dynamic user)
        {
            if (user is null || Common.ToInt(user.FeedbackId) <= 0)
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                string result = Common.ChangeFeedbackStatus(Common.ToInt(user.FeedbackId), Status.Approved, _appSettings);
                return Ok(result);
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("rejectFeedback", Name = "RejectFeedback")]
        public IActionResult RejectFeedback([FromBody] dynamic user)
        {
            if (user is null || Common.ToInt(user.FeedbackId) <= 0)
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                string result = Common.ChangeFeedbackStatus(Common.ToInt(user.FeedbackId), Status.Rejected, _appSettings);
                return Ok(result);
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpGet("getUser/{id}", Name = "GetUsers")]
        public IActionResult GetUsers(int id)
        {
            try
            {
                dynamic result = null;
                UsersBL objUsersBL = new UsersBL(Common.GetConString(_appSettings));
                objUsersBL.Load(id);
                if (objUsersBL.Data.UserTypeId == (int)UserType.Driver)
                {
                    DriversBL objDriversBL = new DriversBL(Common.GetConString(_appSettings));
                    objDriversBL.Load(id);
                    result.DriverDetails = objDriversBL.Data;
                }
                result.UserDetails = objUsersBL.Data;
                return Ok(result);

            }
            catch(Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }            
        }
    }
}