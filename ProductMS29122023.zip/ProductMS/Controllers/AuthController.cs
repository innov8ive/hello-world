﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using ProductMS.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Authorization;

namespace ProductMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        IConfiguration _appSettings;
        public AuthController(IConfiguration configuration)
        {
            _appSettings = configuration;
        }
        [HttpPost("login")]
        public IActionResult Login([FromBody] Login user)
        {
            if (user is null)
            {
                return BadRequest("Invalid user request!!!");
            }
            var loginUser = Common.IsValidUser(user.UserName, user.Password, user.UserType, _appSettings);
            if (loginUser != null)
            {
                if (loginUser.MobileVerified != "YES")
                {
                    return BadRequest("Mobile not verified.");
                }
                if (loginUser.IsActive != true)
                {
                    return BadRequest("Your account is deactivated, please contact ApnaCab administrator.");
                }
                var permClaims = new List<Claim>();
                permClaims.Add(new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()));
                permClaims.Add(new Claim("UserId", loginUser.UserId.ToString()));
                permClaims.Add(new Claim("Mobile", loginUser.Mobile.ToString()));
                permClaims.Add(new Claim("FirstName", loginUser.FirstName));
                permClaims.Add(new Claim("LastName", loginUser.LastName));
                permClaims.Add(new Claim("UserTypeId", loginUser.UserTypeId.ToString()));

                var secretKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_appSettings["AppSettings:Secret"]));
                var signinCredentials = new SigningCredentials(secretKey, SecurityAlgorithms.HmacSha256);
                var tokeOptions = new JwtSecurityToken(issuer: _appSettings["AppSettings:ValidIssuer"], audience: _appSettings["AppSettings:ValidAudience"], claims: permClaims, expires: DateTime.Now.AddMinutes(60), signingCredentials: signinCredentials);
                var tokenString = new JwtSecurityTokenHandler().WriteToken(tokeOptions);
                return Ok(new JWTTokenResponse
                {
                    Token = tokenString
                });
            }
            else
            {
                return BadRequest("Invalid UserId or password");
            }
        }

        [HttpPost("changePassword", Name = "ChangePassword"), Authorize]
        public IActionResult ChangePassword([FromBody] ChangePassword value)
        {
            if (value is null)
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                string result = Common.ChangePassword(value, _appSettings);
                return Ok(result);
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }

        }

        [HttpPost("forgotPassword", Name = "ForgotPassword")]
        public IActionResult ForgotPassword([FromBody] dynamic value)
        {
            if (value is null || string.IsNullOrEmpty(value.UserName))
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                string result = Common.ForgotPassword(value.UserName, _appSettings);
                return Ok(result);
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }

        }

        [HttpPost("sendOTP", Name = "SendOTP")]
        public IActionResult SendOTP([FromBody] dynamic value)
        {
            if (value is null || string.IsNullOrEmpty(value.Mobile))
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                string result = Common.SendOTP(value.Mobile, _appSettings);
                return Ok(result);
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }

        }

        [HttpPost("verifyOTP", Name = "VerifyOTP")]
        public IActionResult VerifyOTP([FromBody] dynamic value)
        {
            if (value is null || string.IsNullOrEmpty(value.Mobile) || string.IsNullOrEmpty(value.OTP))
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                string result = Common.VerifyOTP(value.Mobile, value.OTP, _appSettings);
                return Ok(result);
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }
    }
}