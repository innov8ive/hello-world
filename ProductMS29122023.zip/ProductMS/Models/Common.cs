﻿using BL;
using Microsoft.Extensions.Configuration;
using OM;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace ProductMS.Models
{
    public enum Status
    {
        Pending = 1,
        Approved = 2,
        Rejected = 3,
        Accepted = 4,
        Cancelled = 5,
        NotAnswered = 6,
        InTransit = 7,
        Completed = 8
    }
    public enum UserType
    {
        Rider = 1,
        Driver = 2,
        Admin = 3
    }

    public class Common
    {
        public static string MD5Encryption(string encryptionText)
        {
            // We have created an instance of the MD5CryptoServiceProvider class.
            MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
            //We converted the data as a parameter to a byte array.
            byte[] array = Encoding.UTF8.GetBytes(encryptionText);
            //We have calculated the hash of the array.
            array = md5.ComputeHash(array);
            //We created a StringBuilder object to store hashed data.
            StringBuilder sb = new StringBuilder();
            //We have converted each byte from string into string type.

            foreach (byte ba in array)
            {
                sb.Append(ba.ToString("x2").ToLower());
            }

            //We returned the hexadecimal string.
            return sb.ToString();
        }

        internal static string GetConString(IConfiguration configuration)
        {
            return configuration["AppSettings:DefaultConnection"];
        }

        public static DataTable GetDBResult(IConfiguration configuration, string query )
        {
            SqlConnection con = new SqlConnection(Common.GetConString(configuration));
            SqlCommand cmd = new SqlCommand(query, con);
            DataTable dt = new DataTable();
            con.Open();
            using (con)
            {
                dt.Load(cmd.ExecuteReader());
            }
            return dt;
        }
        public static DataTable GetDBResultParameterized(IConfiguration configuration, string query, params object[] argument)
        {
            return GetDBResultParameterized(Common.GetConString(configuration), query, argument);
        }
        public static DataTable GetDBResultParameterized(string connectionString, string query, params object[] argument)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand(query, con);

            for (var i = 0; i < argument.Length; i = i + 3)
            {
                cmd.Parameters.Add(Common.ToString(argument[i]), (SqlDbType)argument[i + 1]).Value = argument[i + 2];
            }
            DataTable dt = new DataTable();
            con.Open();
            using (con)
            {
                dt.Load(cmd.ExecuteReader());
            }
            return dt;
        }
        public static int ExecuteNonQuery(string connectionString, string query, params object[] argument)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand(query, con);
            if (argument != null)
                for (var i = 0; i < argument.Length; i = i + 3)
                {
                    cmd.Parameters.Add(Common.ToString(argument[i]), (SqlDbType)argument[i + 1]).Value = argument[i + 2];
                }
            con.Open();
            using (con)
            {
                return cmd.ExecuteNonQuery();
            }
        }
        public static int ExecuteNonQuery(IConfiguration configuration, string query, params object[] argument)
        {
            return ExecuteNonQuery(Common.GetConString(configuration), query, argument);
        }
        public static object GetDBScalar(IConfiguration configuration, string query, params object[] argument)
        {
            SqlConnection con = new SqlConnection(Common.GetConString(configuration));
            SqlCommand cmd = new SqlCommand(query, con);
            if (argument != null)
                for (var i = 0; i < argument.Length; i = i + 3)
                {
                    cmd.Parameters.Add(Common.ToString(argument[i]), (SqlDbType)argument[i + 1]).Value = argument[i + 2];
                }
            con.Open();
            using (con)
            {
                return cmd.ExecuteScalar();
            }
        }
        #region Value Conversions with null value check
        /// <summary>
        /// Convert any value to its boolean equivalent
        /// </summary>
        /// <param name="theValue"></param>
        /// <returns>A boolean value</returns>
        public static bool ToBool(object theValue)
        {
            try
            {
                if (Convert.IsDBNull(theValue)) return false;
                if (theValue is string)
                {
                    switch (theValue.ToString().ToLower())
                    {
                        case "yes":
                        case "on":
                            return true;
                    }
                    if (IsNumeric(theValue))
                        return Convert.ToBoolean((Convert.ToDouble(theValue)));
                }
                return Convert.ToBoolean(theValue);
            }
            catch
            {
                return false;
            }
        }
        public static string ToString(object theValue)
        {
            if (Convert.IsDBNull(theValue))
                return "";
            else
                return Convert.ToString(theValue);
        }
        public static string ConvToDateToString(object theValue, string Format)
        {
            if (Convert.IsDBNull(theValue) || theValue == null)
                return "";
            else
                return Common.ToDate(theValue).ToString(Format);
        }
        public static double ToDouble(object theValue)
        {
            double theResult = 0;
            if (theValue == null || Convert.IsDBNull(theValue) || !double.TryParse(theValue.ToString(), out theResult))
                theResult = 0;
            return theResult;
        }
        public static double? ToDouble(object theValue, double? defaultValue)
        {
            double theResult = 0;
            if (theValue == null || Convert.IsDBNull(theValue) || !double.TryParse(theValue.ToString(), out theResult))
                return defaultValue;
            return theResult;
        }
        public static int ToInt(object theValue)
        {
            int theResult = 0;
            if (theValue == null || Convert.IsDBNull(theValue) || !int.TryParse(theValue.ToString(), out theResult))
                theResult = 0;
            return theResult;
        }
        public static int? ToInt(object theValue, int? defaultValue)
        {
            int theResult = 0;
            if (theValue == null || Convert.IsDBNull(theValue) || !int.TryParse(theValue.ToString(), out theResult))
                return defaultValue;
            return theResult;
        }
        public static float ToFloat(object theValue)
        {
            float theResult = 0;
            if (theValue == null || Convert.IsDBNull(theValue) || !float.TryParse(theValue.ToString(), out theResult))
                theResult = 0;
            return theResult;
        }
        public static float? ToFloat(object theValue, float? defaultValue)
        {
            float theResult = 0;
            if (theValue == null || Convert.IsDBNull(theValue) || !float.TryParse(theValue.ToString(), out theResult))
                return defaultValue;
            return theResult;
        }
        public static decimal ToDecimal(object theValue)
        {
            decimal theResult = 0;
            if (theValue == null || Convert.IsDBNull(theValue) || !decimal.TryParse(theValue.ToString(), out theResult))
                theResult = 0;
            return theResult;
        }
        public static decimal? ToDecimal(object theValue, decimal? defaultValue)
        {
            decimal theResult = 0;
            if (theValue == null || Convert.IsDBNull(theValue) || !decimal.TryParse(theValue.ToString(), out theResult))
                return defaultValue;
            return theResult;
        }
        public static DateTime ToDate(object theValue)
        {
            DateTime theResult;
            if (theValue == null || Convert.IsDBNull(theValue) || !DateTime.TryParse(theValue.ToString(), out theResult))
                theResult = DateTime.UtcNow;
            return theResult;
        }
        public static DateTime? ToDate(object theValue, DateTime? defaultval)
        {
            DateTime theResult;
            if (theValue == null || Convert.IsDBNull(theValue) || !DateTime.TryParse(theValue.ToString(), out theResult))
                return defaultval;
            return theResult;
        }
        public static bool IsNumeric(object theValue)
        {
            try
            {
                double theNum;
                if (Convert.IsDBNull(theValue))
                    return false;
                return double.TryParse(theValue.ToString(), out theNum);
            }
            catch
            {
                return false;
            }
        }
        #endregion

        public static string ChangePassword(ChangePassword objChangePassword, IConfiguration configuration)
        {
            int affectedRows = ExecuteNonQuery(configuration, @"Update Users set Password=@NewPassword where UserID=@UserID and Password=@Password",
                "@UserID", SqlDbType.Int, objChangePassword.UserID,
                "@NewPassword", SqlDbType.VarChar, MD5Encryption(objChangePassword.NewPassword),
                "@Password", SqlDbType.VarChar, MD5Encryption(objChangePassword.OldPassword));

            if (affectedRows > 0)
            {
                return "Changed";
            }
            else
            {
                return "Invalid";
            }
        }

        public static Users IsValidUser(string userName, string password, int userType, IConfiguration configuration)
        {
            SqlConnection con = new SqlConnection(Common.GetConString(configuration));
            SqlCommand cmd = new SqlCommand(@"select * from Users where (EmailID=@UserName OR Mobile=@UserName) and Password=@Password", con);
            cmd.Parameters.Add("@UserName", SqlDbType.VarChar, 250).Value = userName;
            cmd.Parameters.Add("@Password", SqlDbType.VarChar, 250).Value = MD5Encryption(password);
            DataTable dt = new DataTable();
            con.Open();
            using (con)
            {
                dt.Load(cmd.ExecuteReader());
            }

            if (dt.Rows.Count > 0)
            {
                if ((userType == 0 || userType == 2) && Common.ToInt(dt.Rows[0]["UserTypeId"]) == 3)
                {
                    return null;
                }
                UsersBL objUsersBL = new UsersBL(Common.GetConString(configuration));
                objUsersBL.Load(Common.ToInt(dt.Rows[0]["UserId"]));

                return objUsersBL.Data;
            }
            else
            {
                return null;
            }
        }

        public static string ForgotPassword(string userName, IConfiguration configuration)
        {
            int count = Common.ToInt(Common.GetDBScalar(configuration, "Select COUNT(*) from Users where (EmailID=@Username OR Mobile=@Username)",
                "@Username", SqlDbType.VarChar, userName));
            if (count <= 0)
                return "Entered EmailID/Mobile No. is Invalid!";
            string Mobile = Common.ToString(Common.GetDBScalar(configuration, "Select Mobile from Users where (EmailID=@Username OR MobileNo=@Username)",
                "@Username", SqlDbType.VarChar, userName));
            string newPassword = Guid.NewGuid().ToString().Substring(0, 6);
            if (Mobile.Length > 0)
            {
                string sent = Common.SendSMS(configuration, Mobile, string.Format("Your New Password has been Generated! Your new password is {0} -- ApnaCab", newPassword));
                if (sent == "Success")
                {
                    Common.ExecuteNonQuery(configuration, "Update Users set Password = @Password where Mobile=@UserName",
                        "@UserName", SqlDbType.VarChar, userName,
                        "@Password", SqlDbType.VarChar, Common.MD5Encryption(newPassword));
                    return "Success";
                }
                return sent;
            }
            return "The User is not registered!";
        }

        public static string SendOTP(string Mobile, IConfiguration configuration)
        {
            if (!string.IsNullOrEmpty(Mobile))
            {
                Random random = new Random();

                string otp = random.Next(111111, 999999).ToString();
                string sent = Common.SendSMS(configuration, Mobile, string.Format("The OTP for your mobile verification is {0} . -- ApnaCab", otp));
                if (sent == "Success")
                {
                    Common.ExecuteNonQuery(configuration, "Update Users set MobileVerified = @MobileVerified where Mobile=@Mobile",
                        "@Mobile", SqlDbType.VarChar, Mobile,
                        "@MobileVerified", SqlDbType.VarChar, otp);
                    return "Success";
                }
                return sent;
            }
            return "Invalid Mobile!";
        }

        public static string VerifyOTP(string Mobile, string OTP, IConfiguration configuration)
        {
            if (!string.IsNullOrEmpty(Mobile) && !string.IsNullOrEmpty(OTP))
            {
                int affectedRows = ExecuteNonQuery(configuration, @"Update Users set MobileVerified='YES' where Mobile=@Mobile and MobileVerified=@MobileVerified",
                 "@Mobile", SqlDbType.VarChar, Mobile,
                  "@MobileVerified", SqlDbType.VarChar, OTP);

                if (affectedRows > 0)
                {
                    return "Verified";
                }
                else
                {
                    return "Invalid OTP";
                }
            }
            return "Invalid Mobile/OTP!";
        }

        public static string SaveDeviceRegId(int UserId, string DeviceRegId, IConfiguration configuration)
        {
            if (UserId > 0 && !string.IsNullOrEmpty(DeviceRegId))
            {
                int affectedRows = ExecuteNonQuery(configuration, @"Update Users set DeviceRegId=@DeviceRegId where UserId=@UserId",
                 "@DeviceRegId", SqlDbType.VarChar, DeviceRegId,
                  "@UserId", SqlDbType.Int, UserId);

                if (affectedRows > 0)
                {
                    return "Success";
                }
                else
                {
                    return "Invalid UserId";
                }
            }
            return "Invalid UserId!";
        }
        public static bool CheckUserIsAvailable(string mobile, int userId, IConfiguration configuration)
        {
            DataTable dt = Common.GetDBResultParameterized(configuration, @"Select UserID from Users where Mobile = @Mobile and UserID <> @UserID"
                    , "@UserID", SqlDbType.Int, userId
                    , "@Mobile", SqlDbType.VarChar, mobile);
            if (dt.Rows.Count <= 0)
                return true;
            return false;
        }
        public static string UpdateCurrentLocation(int UserId, decimal Lat, decimal Long, IConfiguration configuration)
        {
            if (UserId > 0 && Lat != 0 && Long != 0)
            {
                int affectedRows = ExecuteNonQuery(configuration, @"Update Users set CurrentLat=@CurrentLat,CurrentLong=@CurrentLong where UserId=@UserId",
                 "@CurrentLat", SqlDbType.Decimal, Lat,
                 "@CurrentLong", SqlDbType.Decimal, Long,
                  "@UserId", SqlDbType.Int, UserId);

                if (affectedRows > 0)
                {
                    return "Success";
                }
                else
                {
                    return "Invalid UserId";
                }
            }
            return "Invalid UserId!";
        }
        public static string UpdateMobile(int UserId, string Mobile, IConfiguration configuration)
        {
            if (UserId > 0 && !string.IsNullOrEmpty(Mobile))
            {
                int affectedRows = ExecuteNonQuery(configuration, @"Update Users set Mobile=@Mobile,MobileVerified='NO' where UserId=@UserId",
                 "@Mobile", SqlDbType.VarChar, Mobile,
                 "@UserId", SqlDbType.Int, UserId);

                if (affectedRows > 0)
                {
                    return "Success";
                }
                else
                {
                    return "Invalid UserId";
                }
            }
            return "Invalid UserId/Mobile!";
        }
        public static string DeActivateUser(int UserId, bool IsActive, IConfiguration configuration)
        {
            if (UserId > 0)
            {
                int affectedRows = ExecuteNonQuery(configuration, @"Update Users set IsActive=@IsActive where UserId=@UserId",
                 "@IsActive", SqlDbType.VarChar, IsActive,
                 "@UserId", SqlDbType.Int, UserId);

                if (affectedRows > 0)
                {
                    return "Success";
                }
                else
                {
                    return "Invalid UserId";
                }
            }
            return "Invalid Mobile/OTP!";
        }

        public static string ChangeDriverStatus(int UserId, Status StatusId,string remarks, IConfiguration configuration)
        {
            if (UserId > 0)
            {
                int affectedRows = ExecuteNonQuery(configuration, @"Update Users set StatusId=@StatusId,ApprovalRemarks=@ApprovalRemarks where UserId=@UserId",
                 "@StatusId", SqlDbType.VarChar, (int)StatusId,
                 "@ApprovalRemarks", SqlDbType.NVarChar, remarks,
                 "@UserId", SqlDbType.Int, UserId);

                if (affectedRows > 0)
                {
                    return "Success";
                }
                else
                {
                    return "Invalid UserId";
                }
            }
            return "Invalid UserId";
        }
        public static DataTable GetDriverDocuments(int UserId, IConfiguration configuration)
        {
            return GetDBResultParameterized(configuration, @"select DT.DocTypeId,DT.DocType,DT.IsMandatory,DT.SrNo,DD.DriverDocId,DD.UserId,DD.UploadedOn,DD.StatusId,DD.FileGUID
            FROM DocTypes DT LEFT OUTER JOIN DriverDocs DD ON DT.DocTypeId=DD.DocTypeId and (DD.UserId IS NULL OR DD.UserId=@UserId)",
            "@UserId", SqlDbType.Int, UserId);
        }
        public static DataTable GetNearByDrivers(decimal Lat, decimal Long,  IConfiguration configuration)
        {
            return GetDBResultParameterized(configuration, "exec GetNearByDrivers @Lat, @Long",
            "@Lat", SqlDbType.Decimal, Lat,
            "@Long", SqlDbType.Decimal, Long);
        }
        public static string ChangeDocumentStatus(int DriverDocId, Status StatusId, IConfiguration configuration)
        {
            if (DriverDocId > 0)
            {
                int affectedRows = ExecuteNonQuery(configuration, @"Update DriverDocs set StatusId=@StatusId where DriverDocId=@DriverDocId",
                 "@StatusId", SqlDbType.VarChar, (int)StatusId,
                 "@DriverDocId", SqlDbType.Int, DriverDocId);

                if (affectedRows > 0)
                {
                    return "Success";
                }
                else
                {
                    return "Invalid DriverDocId";
                }
            }
            return "Invalid DriverDocId!";
        }
        public static string ChangeFeedbackStatus(int FeedbackId, Status StatusId, IConfiguration configuration)
        {
            if (FeedbackId > 0)
            {
                int affectedRows = ExecuteNonQuery(configuration, @"Update Feedbacks set StatusId=@StatusId where FeedbackId=@FeedbackId",
                 "@StatusId", SqlDbType.VarChar, (int)StatusId,
                 "@FeedbackId", SqlDbType.Int, FeedbackId);

                if (affectedRows > 0)
                {
                    return "Success";
                }
                else
                {
                    return "Invalid FeedbackId";
                }
            }
            return "Invalid FeedbackId!";
        }
        public static string ChangeRequestStatus(int RideRequestId, Status StatusId, IConfiguration configuration)
        {
            if (RideRequestId > 0)
            {
                int affectedRows = ExecuteNonQuery(configuration, @"Update RideRequests set StatusId=@StatusId where RideRequestId=@RideRequestId",
                 "@StatusId", SqlDbType.VarChar, (int)StatusId,
                 "@RideRequestId", SqlDbType.Int, RideRequestId);

                if (affectedRows > 0)
                {
                    return "Success";
                }
                else
                {
                    return "Invalid RideRequestId";
                }
            }
            return "Invalid RideRequestId!";
        }
        public static string ChangeOnOffDuty(int UserId, bool OnDuty, IConfiguration configuration)
        {
            if (UserId > 0)
            {
                int affectedRows = ExecuteNonQuery(configuration, @"Update Users set OnDuty=@OnDuty where UserId=@UserId",
                 "@OnDuty", SqlDbType.Bit, OnDuty,
                 "@UserId", SqlDbType.Int, UserId);

                if (affectedRows > 0)
                {
                    return "Success";
                }
                else
                {
                    return "Invalid UserId";
                }
            }
            return "Invalid UserId!";
        }
        public static string SendSMS(IConfiguration configuration, string mobile, string messageText)
        {
            bool sendNot = Common.ToBool(configuration["AppSettings:SendNotification"]);
            if (!sendNot)
                return "Success";
            //if (socID <= 0)
            //{
            //    return "Success";
            //}
            //Your user name
            string user = "ConnectV";
            //Your authentication key
            string key = "8fc49a8f56XX";
            //Sender ID,While using route4 sender id should be 6 characters long.
            string senderid = "SOCINN";
            //Your message to send, Add URL encoding here.
            string message = HttpUtility.UrlEncode(messageText);

            //Prepare you post parameters
            StringBuilder sbPostData = new StringBuilder();
            sbPostData.AppendFormat("user={0}", user);
            sbPostData.AppendFormat("&key={0}", key);
            sbPostData.AppendFormat("&mobile={0}", mobile);
            sbPostData.AppendFormat("&message={0}", message);
            sbPostData.AppendFormat("&senderid={0}", senderid);
            sbPostData.AppendFormat("&accusage={0}", "1");

            try
            {
                //Call Send SMS API
                string sendSMSUri = "http://mobicomm.dove-sms.com/mobicomm/submitsms.jsp?";
                //Create HTTPWebrequest
                HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create(sendSMSUri);
                //Prepare and Add URL Encoded data
                UTF8Encoding encoding = new UTF8Encoding();
                byte[] data = encoding.GetBytes(sbPostData.ToString());
                //Specify post method
                httpWReq.Method = "POST";
                httpWReq.ContentType = "application/x-www-form-urlencoded";
                httpWReq.ContentLength = data.Length;
                using (Stream stream = httpWReq.GetRequestStream())
                {
                    stream.Write(data, 0, data.Length);
                }
                //Get the response
                HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
                StreamReader reader = new StreamReader(response.GetResponseStream());
                string responseString = reader.ReadToEnd();

                //Close the response
                reader.Close();
                response.Close();
                return responseString.Contains("success") ? "Success" : responseString;
            }
            catch (SystemException ex)
            {
                return "Failed:" + ex.Message;
            }

        }
    }
}
