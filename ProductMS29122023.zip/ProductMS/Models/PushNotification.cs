﻿using FirebaseAdmin;
using FirebaseAdmin.Messaging;
using Google.Apis.Auth.OAuth2;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace ProductMS.Models
{
    public class PushNotification
    {
        public PushNotification()
        {
            if (FirebaseMessaging.DefaultInstance == null)
            {
                string filePath = Path.Combine(Directory.GetCurrentDirectory(), "serviceAccountKey.json");
                FirebaseApp.Create(new AppOptions()
                {
                    Credential = GoogleCredential.FromFile(filePath),
                });
            }            
        }
        public async Task<BatchResponse> Send(List<string> tokens, Dictionary<string, string> data)
        {
            var message = new MulticastMessage()
            {
                Tokens = tokens,
                Android = new AndroidConfig() { Priority = Priority.High,Data=data },
                //Data = data,
                Notification=new Notification() { Body="test",Title="test"}
            };
            return await FirebaseMessaging.DefaultInstance.SendMulticastAsync(message).ConfigureAwait(false);
        }

    }
}
