﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;

namespace ProductMS.Models
{
    public class AngularGridData
    {
        public string Data { get; set; }
        public object DataJson { get; set; }
        public int TotalRecords { get; set; }
        public int TotalPages { get; set; }
    }
    public class AngularGrid
    {
        public Nullable<int> PageSize { get; set; }
        public Nullable<int> CurrentPage { get; set; }
        public string SearchText { get; set; }
        public string SortBy { get; set; }
        public string SortDir { get; set; }
    }
    public class AngularDropdown
    {
        public string MethodName { get; set; }
        public string query { get; set; }
        public List<Dictionary<string, string>> Data { get; set; }
    }
    public class AngularDropdownData
    {
        public object Key { get; set; }
        public string Value { get; set; }
        public Object Data { get; set; }
        public bool Selected { get; set; }
    }
    public class AngularDataBinder
    {
        private int _PageSize = 10;
        public int PageSize
        {
            get { return _PageSize; }
            set { _PageSize = value; }
        }
        private int _PageIndex = 1;
        public int PageIndex
        {
            get { return _PageIndex; }
            set { _PageIndex = value; }
        }
        public string Query { get; set; }
        public int TotalPages { get; set; }
        public string ValueField { get; set; }
        private Hashtable _Parameters;
        public Hashtable Parameters
        {
            get
            {
                if (_Parameters == null)
                    _Parameters = new Hashtable();
                return _Parameters;
            }
            set { _Parameters = value; }
        }
        private string _OrderBy;
        public string OrderBy
        {
            get
            {
                if (String.IsNullOrEmpty(_OrderBy))
                    return ValueField;
                else
                    return _OrderBy;
            }
            set { _OrderBy = value; }
        }
        private string _OrderDir = "Asc";
        public string OrderDir
        {
            get { return _OrderDir; }
            set { _OrderDir = value; }
        }
        public int TotalRecords { get; set; }
        public AngularDataBinder(AngularGrid objAngularGrid)
        {
            PageIndex = objAngularGrid.CurrentPage == null ? 1 : objAngularGrid.CurrentPage.Value;
            PageSize = objAngularGrid.PageSize == null ? 10 : objAngularGrid.PageSize.Value;
            if (!String.IsNullOrEmpty(objAngularGrid.SortBy))
            {
                OrderBy = objAngularGrid.SortBy;
                OrderDir = objAngularGrid.SortDir;
            }
        }

        public AngularGridData GetData(IConfiguration configuration)
        {
            string pagedQuery = String.Empty;
            DataTable dt = null;
            if (Query != String.Empty)
            {

                //Query = Query.ToLower();
                //string afterFrom = Query.ToLower().Contains(" from ") == true ? Query.Substring(Query.IndexOf(" from ", StringComparison.OrdinalIgnoreCase) + 6) : "";
                //Query = Query.Trim();
                //string beforeFrom = Query.ToLower().Contains("select ") == true ? Query.Substring(6, Query.IndexOf("from ", StringComparison.OrdinalIgnoreCase) - 6) : "";
                //string count = getScalarQueryResult("Select COUNT(" + ValueField + ") from " + afterFrom);
                //TotalRecords = Common.ToInt(count);
                //TotalPages = count != String.Empty ? TotalRecords % PageSize == 0 ? TotalRecords / PageSize : TotalRecords / PageSize + 1 : 0;
                //PageIndex = PageIndex <= 0 ? 1 : PageIndex > TotalPages ? TotalPages : PageIndex;
                //pagedQuery = "select *from(select TOP 100 PERCENT ROW_NUMBER() over(Order By " + OrderBy + " " + OrderDir + ") as RSRNO,"
                //+ beforeFrom + " from " + afterFrom + " ) as T  where T.RSRNO between " + (((PageIndex - 1) * PageSize) + 1)
                //+ " and " + (PageIndex * PageSize);

                string afterFrom = Query.ToLower().Contains(" from ") == true ? Query.Substring(Query.IndexOf(" from ", StringComparison.OrdinalIgnoreCase) + 6) : "";
                string count = getScalarQueryResult(configuration, "Select COUNT(" + ValueField + ") from " + afterFrom);
                TotalRecords = Common.ToInt(count);
                TotalPages = count != String.Empty ? TotalRecords % PageSize == 0 ? TotalRecords / PageSize : TotalRecords / PageSize + 1 : 0;
                StringBuilder query = new StringBuilder();
                string orderBy = OrderBy.Contains(".") ? OrderBy.Substring(OrderBy.IndexOf(".") + 1) : OrderBy;
                query.Append(@"select * from(select TOP 100 PERCENT ROW_NUMBER() over(Order By innerT.").Append(orderBy).Append(" ").Append(OrderDir);
                query.Append(") as RSRNO,innerT.* from(").Append(Query).Append(") as InnerT ) as T  where T.RSRNO between ");
                query.Append((((PageIndex - 1) * PageSize) + 1)).Append(" and ").Append(PageIndex * PageSize);

                dt = getQueryResult(configuration, query.ToString());
                string json = JsonConvert.SerializeObject(dt, Formatting.Indented);
                AngularGridData objAngularData = new AngularGridData();
                objAngularData.TotalRecords = TotalRecords;
                objAngularData.TotalPages = TotalPages;
                objAngularData.Data = json;
                return objAngularData;
            }

            return null;
        }

        public DataTable GetDataTable(IConfiguration configuration)
        {
            string pagedQuery = String.Empty;
            DataTable dt = null;
            if (Query != String.Empty)
            {

                string afterFrom = Query.ToLower().Contains(" from ") == true ? Query.Substring(Query.IndexOf(" from ", StringComparison.OrdinalIgnoreCase) + 6) : "";
                string count = getScalarQueryResult(configuration, "Select COUNT(" + ValueField + ") from " + afterFrom);
                TotalRecords = Common.ToInt(count);
                TotalPages = count != String.Empty ? TotalRecords % PageSize == 0 ? TotalRecords / PageSize : TotalRecords / PageSize + 1 : 0;
                TotalPages = TotalPages == 0 ? 1 : TotalPages;
                StringBuilder query = new StringBuilder();
                string orderBy = OrderBy.Contains(".") ? OrderBy.Substring(OrderBy.IndexOf(".") + 1) : OrderBy;
                query.Append(@"select * from(select TOP 100 PERCENT ROW_NUMBER() over(Order By innerT.").Append(orderBy).Append(" ").Append(OrderDir);
                query.Append(") as RSRNO,innerT.* from(").Append(Query).Append(") as InnerT ) as T  where T.RSRNO between ");
                query.Append((((PageIndex - 1) * PageSize) + 1)).Append(" and ").Append(PageIndex * PageSize);
                
                dt = getQueryResult(configuration, query.ToString());
                return dt;
            }

            return null;
        }
        private string getScalarQueryResult(IConfiguration configuration, string q)
        {
            SqlConnection con = new SqlConnection(Common.GetConString(configuration));
            SqlCommand cmd = new SqlCommand(q, con);

            foreach (object key in Parameters.Keys)
            {
                cmd.Parameters.AddWithValue(key.ToString(), Parameters[key]);
            }
            string s = String.Empty;
            try
            {
                con.Open();
                s = cmd.ExecuteScalar().ToString();
                con.Close();
            }
            finally { con.Dispose(); }
            return s;
        }
        private DataTable getQueryResult(IConfiguration configuration, string q)
        {
            SqlConnection con = new SqlConnection(Common.GetConString(configuration));
            SqlCommand cmd = new SqlCommand(q, con);
            DataTable dt = new DataTable();
            foreach (object key in Parameters.Keys)
            {
                cmd.Parameters.AddWithValue(key.ToString(), Parameters[key]);
            }
            try
            {
                con.Open();
                dt.Load(cmd.ExecuteReader());
                con.Close();
            }
            finally { con.Dispose(); }
            return dt;
        }
    }
}