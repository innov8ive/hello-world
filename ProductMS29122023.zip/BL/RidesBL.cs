using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using OM;
using DL;

namespace BL
{
    [Serializable]
    public class RidesBL
    {

        #region Declaration
        private string connectionString;
        Rides _Rides;
        public Rides Data
        {
            get { return _Rides; }
            set { _Rides = value; }
        }
        public bool IsNew
        {
            get { return (_Rides.RideId <= 0 || _Rides.RideId == null); }
        }
        #endregion

        #region Constructor
        public RidesBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private RidesDL CreateDL()
        {
            return new RidesDL(connectionString);
        }
        public void New()
        {
            _Rides = new Rides();
        }
        public void Load(int RideId)
        {
            var RidesObj = this.CreateDL();
            _Rides = RideId <= 0 ? RidesObj.Load(-1) : RidesObj.Load(RideId);
        }
        public DataTable LoadAllRides()
        {
            var RidesDLObj = CreateDL();
            return RidesDLObj.LoadAllRides();
        }
        public bool Update()
        {
            var RidesDLObj = CreateDL();
            return RidesDLObj.Update(this.Data);
        }
        public bool InsertIntoRideLocations(RideLocations objRideLocations)
        {
            var RidesDLObj = CreateDL();
            return RidesDLObj.InsertIntoRideLocations(objRideLocations);
        }
        public bool Delete(int RideId)
        {
            var RidesDLObj = CreateDL();
            return RidesDLObj.Delete(RideId);
        }
        #endregion
    }
}
