using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using OM;
using DL;

namespace BL
{
    [Serializable]
    public class RideRequestsBL
    {

        #region Declaration
        private string connectionString;
        RideRequests _RideRequests;
        public RideRequests Data
        {
            get { return _RideRequests; }
            set { _RideRequests = value; }
        }
        public bool IsNew
        {
            get { return (_RideRequests.RideRequestId <= 0 || _RideRequests.RideRequestId == null); }
        }
        #endregion

        #region Constructor
        public RideRequestsBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private RideRequestsDL CreateDL()
        {
            return new RideRequestsDL(connectionString);
        }
        public void New()
        {
            _RideRequests = new RideRequests();
        }
        public void Load(int RideRequestId)
        {
            var RideRequestsObj = this.CreateDL();
            _RideRequests = RideRequestId <= 0 ? RideRequestsObj.Load(-1) : RideRequestsObj.Load(RideRequestId);
        }
        public DataTable LoadAllRideRequests()
        {
            var RideRequestsDLObj = CreateDL();
            return RideRequestsDLObj.LoadAllRideRequests();
        }
        public bool Update()
        {
            var RideRequestsDLObj = CreateDL();
            return RideRequestsDLObj.Update(this.Data);
        }
        public bool Delete(int RideRequestId)
        {
            var RideRequestsDLObj = CreateDL();
            return RideRequestsDLObj.Delete(RideRequestId);
        }
        #endregion
    }
}
