using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using OM;
using DL;

namespace BL
{
    [Serializable]
    public class DriverDocsBL
    {

        #region Declaration
        private string connectionString;
        DriverDocs _DriverDocs;
        public DriverDocs Data
        {
            get { return _DriverDocs; }
            set { _DriverDocs = value; }
        }
        public bool IsNew
        {
            get { return (_DriverDocs.DriverDocId <= 0 || _DriverDocs.DriverDocId == null); }
        }
        #endregion

        #region Constructor
        public DriverDocsBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private DriverDocsDL CreateDL()
        {
            return new DriverDocsDL(connectionString);
        }
        public void New()
        {
            _DriverDocs = new DriverDocs();
        }
        public void Load(int DriverDocId)
        {
            var DriverDocsObj = this.CreateDL();
            _DriverDocs = DriverDocId <= 0 ? DriverDocsObj.Load(-1) : DriverDocsObj.Load(DriverDocId);
        }
        public DataTable LoadAllDriverDocs()
        {
            var DriverDocsDLObj = CreateDL();
            return DriverDocsDLObj.LoadAllDriverDocs();
        }
        public bool Update()
        {
            var DriverDocsDLObj = CreateDL();
            return DriverDocsDLObj.Update(this.Data);
        }
        public bool Delete(int DriverDocId)
        {
            var DriverDocsDLObj = CreateDL();
            return DriverDocsDLObj.Delete(DriverDocId);
        }
        #endregion
    }
}
