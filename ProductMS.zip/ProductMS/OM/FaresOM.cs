using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace OM
{

    [Serializable]
    [Table(Name = "dbo.Fares")]
    public class Fares
    {

        private System.Nullable<decimal> _BaseFare;
        private System.Nullable<DateTime> _EffectiveTill;
        private string _FareType;
        private System.Nullable<int> _Id;
        private System.Nullable<decimal> _PerKMFare;
        private System.Nullable<int> _VehicleTypeId;
        private System.Nullable<decimal> _WaitingPerMinuteFare;



        [Column(Storage = "_BaseFare")]
        public System.Nullable<decimal> BaseFare
        {
            get
            {
                return _BaseFare;
            }
            set
            {
                _BaseFare = value;
            }
        }



        [Column(Storage = "_EffectiveTill")]
        public System.Nullable<DateTime> EffectiveTill
        {
            get
            {
                return _EffectiveTill;
            }
            set
            {
                _EffectiveTill = value;
            }
        }



        [Column(Storage = "_FareType")]
        public string FareType
        {
            get
            {
                return _FareType;
            }
            set
            {
                _FareType = value;
            }
        }



        [Column(Storage = "_Id")]
        public System.Nullable<int> Id
        {
            get
            {
                return _Id;
            }
            set
            {
                _Id = value;
            }
        }



        [Column(Storage = "_PerKMFare")]
        public System.Nullable<decimal> PerKMFare
        {
            get
            {
                return _PerKMFare;
            }
            set
            {
                _PerKMFare = value;
            }
        }



        [Column(Storage = "_VehicleTypeId")]
        public System.Nullable<int> VehicleTypeId
        {
            get
            {
                return _VehicleTypeId;
            }
            set
            {
                _VehicleTypeId = value;
            }
        }



        [Column(Storage = "_WaitingPerMinuteFare")]
        public System.Nullable<decimal> WaitingPerMinuteFare
        {
            get
            {
                return _WaitingPerMinuteFare;
            }
            set
            {
                _WaitingPerMinuteFare = value;
            }
        }

    }}
