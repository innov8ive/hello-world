using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace OM
{

    [Serializable]
    [Table(Name = "dbo.Drivers")]
    public class Drivers
    {

        private System.Nullable<int> _CityId;
        private System.Nullable<DateTime> _DLExpiryDate;
        private string _DLNo;
        private System.Nullable<int> _DriverId;
        private string _FullAddress;
        private System.Nullable<int> _UserId;
        private System.Nullable<int> _VehicleTypeId;
        private string _Zipcode;
        private string _CityName;
        private string _VehicleType;
        private string _StatusDetails;
        private decimal? _AccountBalance;
        private bool? _IsOnline;
        private string _YellowCard;

        [Column(Storage = "_YellowCard")]
        public string YellowCard
        {
            get
            {
                return _YellowCard;
            }
            set
            {
                _YellowCard = value;
            }
        }
        [Column(Storage = "_IsOnline")]
        public bool? IsOnline
        {
            get
            {
                return _IsOnline;
            }
            set
            {
                _IsOnline = value;
            }
        }
        [Column(Storage = "_AccountBalance")]
        public decimal? AccountBalance
        {
            get
            {
                return _AccountBalance;
            }
            set
            {
                _AccountBalance = value;
            }
        }
        [Column(Storage = "_StatusDetails")]
        public string StatusDetails
        {
            get
            {
                return _StatusDetails;
            }
            set
            {
                _StatusDetails = value;
            }
        }

        [Column(Storage = "_VehicleType")]
        public string VehicleType
        {
            get
            {
                return _VehicleType;
            }
            set
            {
                _VehicleType = value;
            }
        }

        [Column(Storage = "_CityName")]
        public string CityName
        {
            get
            {
                return _CityName;
            }
            set
            {
                _CityName = value;
            }
        }

        [Column(Storage = "_CityId")]
        public System.Nullable<int> CityId
        {
            get
            {
                return _CityId;
            }
            set
            {
                _CityId = value;
            }
        }



        [Column(Storage = "_DLExpiryDate")]
        public System.Nullable<DateTime> DLExpiryDate
        {
            get
            {
                return _DLExpiryDate;
            }
            set
            {
                _DLExpiryDate = value;
            }
        }



        [Column(Storage = "_DLNo")]
        public string DLNo
        {
            get
            {
                return _DLNo;
            }
            set
            {
                _DLNo = value;
            }
        }



        [Column(Storage = "_DriverId")]
        public System.Nullable<int> DriverId
        {
            get
            {
                return _DriverId;
            }
            set
            {
                _DriverId = value;
            }
        }



        [Column(Storage = "_FullAddress")]
        public string FullAddress
        {
            get
            {
                return _FullAddress;
            }
            set
            {
                _FullAddress = value;
            }
        }



        [Column(Storage = "_UserId")]
        public System.Nullable<int> UserId
        {
            get
            {
                return _UserId;
            }
            set
            {
                _UserId = value;
            }
        }



        [Column(Storage = "_VehicleTypeId")]
        public System.Nullable<int> VehicleTypeId
        {
            get
            {
                return _VehicleTypeId;
            }
            set
            {
                _VehicleTypeId = value;
            }
        }



        [Column(Storage = "_Zipcode")]
        public string Zipcode
        {
            get
            {
                return _Zipcode;
            }
            set
            {
                _Zipcode = value;
            }
        }

        public Users UserDetails { get; set; }

        public List<DriverDoc> DriverDocs { get; set; }

        public List<DriverDocs> DriverImportDocs { get; set; }
    }    public class DriverDoc
    {
        private int? _DocTypeId;
        private int? _SrNo;
        private bool? _IsMandatory;
        private int? _DriverDocId;
        private int? _StatusId;
        private string _DocType;
        private string _FileGUID;
        private string _StatusDetails;
        private string _DocTypeDetails;
        private DateTime? _UploadedOn;

        [Column(Storage = "_DocTypeDetails")]
        public string DocTypeDetails
        {
            get
            {
                return _DocTypeDetails;
            }
            set
            {
                _DocTypeDetails = value;
            }
        }
        [Column(Storage = "_DocTypeId")]
        public int? DocTypeId
        {
            get
            {
                return _DocTypeId;
            }
            set
            {
                _DocTypeId = value;
            }
        }
        [Column(Storage = "_SrNo")]
        public int? SrNo
        {
            get
            {
                return _SrNo;
            }
            set
            {
                _SrNo = value;
            }
        }
        [Column(Storage = "_DriverDocId")]
        public int? DriverDocId
        {
            get
            {
                return _DriverDocId;
            }
            set
            {
                _DriverDocId = value;
            }
        }
        [Column(Storage = "_StatusId")]
        public int? StatusId
        {
            get
            {
                return _StatusId;
            }
            set
            {
                _StatusId = value;
            }
        }
        [Column(Storage = "_IsMandatory")]
        public bool? IsMandatory
        {
            get
            {
                return _IsMandatory;
            }
            set
            {
                _IsMandatory = value;
            }
        }
        [Column(Storage = "_UploadedOn")]
        public DateTime? UploadedOn
        {
            get
            {
                return _UploadedOn;
            }
            set
            {
                _UploadedOn = value;
            }
        }

        [Column(Storage = "_StatusDetails")]
        public string StatusDetails
        {
            get
            {
                return _StatusDetails;
            }
            set
            {
                _StatusDetails = value;
            }
        }
        [Column(Storage = "_FileGUID")]
        public string FileGUID
        {
            get
            {
                return _FileGUID;
            }
            set
            {
                _FileGUID = value;
            }
        }
        [Column(Storage = "_DocType")]
        public string DocType
        {
            get
            {
                return _DocType;
            }
            set
            {
                _DocType = value;
            }
        }
    }}
