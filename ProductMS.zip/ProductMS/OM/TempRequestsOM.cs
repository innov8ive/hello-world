using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace OM
{

    [Serializable]
    [Table(Name = "dbo.TempRequests")]
    public class TempRequests
    {

        private System.Nullable<int> _Id;
        private System.Nullable<bool> _IsAccepted;
        private System.Nullable<bool> _IsExpired;
        private System.Nullable<DateTime> _RequestDate;
        private System.Nullable<int> _UserId;



        [Column(Storage = "_Id")]
        public System.Nullable<int> Id
        {
            get
            {
                return _Id;
            }
            set
            {
                _Id = value;
            }
        }



        [Column(Storage = "_IsAccepted")]
        public System.Nullable<bool> IsAccepted
        {
            get
            {
                return _IsAccepted;
            }
            set
            {
                _IsAccepted = value;
            }
        }



        [Column(Storage = "_IsExpired")]
        public System.Nullable<bool> IsExpired
        {
            get
            {
                return _IsExpired;
            }
            set
            {
                _IsExpired = value;
            }
        }



        [Column(Storage = "_RequestDate")]
        public System.Nullable<DateTime> RequestDate
        {
            get
            {
                return _RequestDate;
            }
            set
            {
                _RequestDate = value;
            }
        }



        [Column(Storage = "_UserId")]
        public System.Nullable<int> UserId
        {
            get
            {
                return _UserId;
            }
            set
            {
                _UserId = value;
            }
        }

    }}
