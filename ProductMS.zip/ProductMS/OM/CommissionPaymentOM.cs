using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace OM
{

    [Serializable]
    [Table(Name = "dbo.CommissionPayment")]
    public class CommissionPayment
    {

        private System.Nullable<decimal> _Amount;
        private System.Nullable<int> _CommissionPaymentId;
        private System.Nullable<DateTime> _PaymentDate;
        private string _PlatformBillID;
        private string _Remarks;
        private System.Nullable<int> _UserId;



        [Column(Storage = "_Amount")]
        public System.Nullable<decimal> Amount
        {
            get
            {
                return _Amount;
            }
            set
            {
                _Amount = value;
            }
        }



        [Column(Storage = "_CommissionPaymentId")]
        public System.Nullable<int> CommissionPaymentId
        {
            get
            {
                return _CommissionPaymentId;
            }
            set
            {
                _CommissionPaymentId = value;
            }
        }



        [Column(Storage = "_PaymentDate")]
        public System.Nullable<DateTime> PaymentDate
        {
            get
            {
                return _PaymentDate;
            }
            set
            {
                _PaymentDate = value;
            }
        }



        [Column(Storage = "_PlatformBillID")]
        public string PlatformBillID
        {
            get
            {
                return _PlatformBillID;
            }
            set
            {
                _PlatformBillID = value;
            }
        }



        [Column(Storage = "_Remarks")]
        public string Remarks
        {
            get
            {
                return _Remarks;
            }
            set
            {
                _Remarks = value;
            }
        }



        [Column(Storage = "_UserId")]
        public System.Nullable<int> UserId
        {
            get
            {
                return _UserId;
            }
            set
            {
                _UserId = value;
            }
        }

    }}
