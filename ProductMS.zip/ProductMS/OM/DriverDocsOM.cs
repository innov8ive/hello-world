using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace OM
{

    [Serializable]
    [Table(Name = "dbo.DriverDocs")]
    public class DriverDocs
    {

        private System.Nullable<int> _DocTypeId;
        private System.Nullable<int> _DriverDocId;
        private string _FileGUID;
        private System.Nullable<int> _StatusId;
        private System.Nullable<DateTime> _UploadedOn;
        private System.Nullable<int> _UserId;



        [Column(Storage = "_DocTypeId")]
        public System.Nullable<int> DocTypeId
        {
            get
            {
                return _DocTypeId;
            }
            set
            {
                _DocTypeId = value;
            }
        }



        [Column(Storage = "_DriverDocId")]
        public System.Nullable<int> DriverDocId
        {
            get
            {
                return _DriverDocId;
            }
            set
            {
                _DriverDocId = value;
            }
        }



        [Column(Storage = "_FileGUID")]
        public string FileGUID
        {
            get
            {
                return _FileGUID;
            }
            set
            {
                _FileGUID = value;
            }
        }



        [Column(Storage = "_StatusId")]
        public System.Nullable<int> StatusId
        {
            get
            {
                return _StatusId;
            }
            set
            {
                _StatusId = value;
            }
        }



        [Column(Storage = "_UploadedOn")]
        public System.Nullable<DateTime> UploadedOn
        {
            get
            {
                return _UploadedOn;
            }
            set
            {
                _UploadedOn = value;
            }
        }



        [Column(Storage = "_UserId")]
        public System.Nullable<int> UserId
        {
            get
            {
                return _UserId;
            }
            set
            {
                _UserId = value;
            }
        }

    }}
