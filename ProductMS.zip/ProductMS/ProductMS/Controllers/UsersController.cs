﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using BL;
using FluentValidation;
using FluentValidation.Results;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using OM;
using ProductMS.Models;

namespace ProductMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        IConfiguration _appSettings;
        private readonly IHubContext<ChatHub> _hubContext;
        public UsersController(IConfiguration configuration, IHubContext<ChatHub> hubContext)
        {
            _appSettings = configuration;
            _hubContext = hubContext;
        }

        [HttpGet("getUserProfile", Name = "GetUserProfile"), Authorize]
        public IActionResult GetUserProfile()
        {
            Drivers result = new Drivers();
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            if (identity != null)
            {
                int userId = Common.ToInt(identity.FindFirst("UserId").Value);
                try
                {
                    DriversBL driversBL = new DriversBL(Common.GetConString(_appSettings));
                    driversBL.Load(userId);
                    result = driversBL.Data;
                    if (result == null)
                    {
                        result = new Drivers();
                    }
                    UsersBL objUsersBL = new UsersBL(Common.GetConString(_appSettings));
                    objUsersBL.Load(userId);
                    result.UserDetails = objUsersBL.Data;
                    return Ok(result);
                }
                catch (Exception Ex)
                {
                    return StatusCode(500, Ex.Message);
                }
            }
            else
            {
                return Unauthorized();
            }
        }

        [HttpPost("register", Name = "Register")]
        public IActionResult Register([FromBody] dynamic value)
        {
            return RegisterUser(value, 1);
        }

        [HttpPost("registerDriver", Name = "RegisterDriver")]
        public IActionResult RegisterDriver([FromBody] dynamic value)
        {
            return RegisterUser(value, 2);
        }

        private IActionResult RegisterUser(dynamic value, int userTypeId)
        {
            JObject objJObject = value.user;
            Users objUsers = objJObject.ToObject<Users>();
            UsersBL objUsersBL = new UsersBL(Common.GetConString(_appSettings));
            objUsersBL.Data = objUsers;
            objUsers.UserTypeId = userTypeId;

            objUsers.RegDate = DateTime.Now;
            objUsers.StatusId = objUsers.UserTypeId == (int)UserType.Rider ? (int)Status.Approved : (int)Status.Pending;
            objUsers.Password = string.IsNullOrEmpty(objUsers.Password) ? null : Common.MD5Encryption(objUsers.Password);
            objUsers.MobileVerified = "YES";
            objUsers.IsActive = true;

            UsersValidator validator = new UsersValidator();
            ValidationResult results = validator.Validate(objUsers);
            if (objUsers.Mobile.Length != 10)
            {
                results.Errors.Add(new ValidationFailure("Mobile", "Mobile No. should be 10 digit only"));
            }

            if (results.IsValid)
            {
                if (Common.ToString(objUsers.Mobile).Length > 0)
                {
                    bool isAvailable = Common.CheckUserIsAvailable(objUsers.Mobile, 0, _appSettings);
                    if (!isAvailable)
                    {
                        ValidationFailure emailError = new ValidationFailure("Mobile", "Mobile is already registered, please choose another Mobile");
                        results.Errors.Add(emailError);
                    }
                }
                objUsersBL.Update();
                if (objUsersBL.Data.UserId > 0 && userTypeId == 2)
                {
                    objJObject = value.driver;
                    Drivers objDrivers = objJObject.ToObject<Drivers>();
                    DriversBL objDriversBL = new DriversBL(Common.GetConString(_appSettings));
                    objDriversBL.Data = objDrivers;
                    objDriversBL.Data.UserId = objUsersBL.Data.UserId;

                    objDriversBL.Update();
                }
                return Ok(objUsersBL.Data);
            }

            return Ok(new Response(string.Join(',', results.Errors.Select(Obj => Obj.ErrorMessage))));
        }

        [HttpPost("getDropdownData", Name = "GetDropdownData")]
        public List<AngularDropdownData> GetDropdownData([FromBody]dynamic value)
        {
            JObject objJObject = value;
            AngularDropdown objAngularDropdown = objJObject.ToObject<AngularDropdown>();
            if (objAngularDropdown == null) return null;
            switch (objAngularDropdown.MethodName)
            {
                case "GetCityList":
                    return Common.GetCityList(_appSettings, objAngularDropdown);
                case "GetLangList":
                    return Common.GetLangList(_appSettings, objAngularDropdown);
                case "GetVehicleTypeList":
                    return Common.GetVehicleTypeList(_appSettings, objAngularDropdown);
            }
            return null;
        }

        [HttpPost("saveDeviceRegId", Name = "SaveDeviceRegId"), Authorize]
        public IActionResult SaveDeviceRegId([FromBody] dynamic value)
        {
            if (value is null || string.IsNullOrEmpty(Common.ToString(value.DeviceRegId)))
            {
                return Ok(new Response("Invalid user request!!!"));
            }
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            if (identity != null)
            {
                int userId = Common.ToInt(identity.FindFirst("UserId").Value);

                try
                {
                    string result = Common.SaveDeviceRegId(userId, Common.ToString(value.DeviceRegId), _appSettings);
                    return Ok(new Response("Success"));
                }
                catch (Exception Ex)
                {
                    return Ok(new Response(Ex.Message));
                }
            }
            else
            {
                return Unauthorized();
            }
        }

        [HttpPost("saveProfile", Name = "SaveProfile"), Authorize]
        public IActionResult SaveProfile([FromBody] dynamic value)
        {
            JObject objJObject = value;
            Users objUsers = objJObject.ToObject<Users>();
            UsersBL objUsersBL = new UsersBL(Common.GetConString(_appSettings));

            objUsersBL.Data.EmailId = objUsers.EmailId;
            objUsersBL.Data.FirstName = objUsers.FirstName;
            objUsersBL.Data.LastName = objUsers.LastName;
            objUsersBL.Data.Lang = objUsers.Lang;

            UsersValidator validator = new UsersValidator();
            ValidationResult results = validator.Validate(objUsers);

            if (results.IsValid)
            {
                objUsersBL.Update();
                return Ok(objUsersBL.Data);
            }

            return StatusCode(500, results.Errors);
        }

        [HttpPost("updateCurrentLocation", Name = "UpdateCurrentLocation"), Authorize]
        public IActionResult UpdateCurrentLocation([FromBody] dynamic value)
        {
            if (value is null || string.IsNullOrEmpty(value.Lat) || string.IsNullOrEmpty(value.Long))
            {
                return BadRequest("Invalid user request!!!");
            }

            var identity = HttpContext.User.Identity as ClaimsIdentity;
            if (identity != null)
            {
                int userId = Common.ToInt(identity.FindFirst("UserId").Value);

                try
                {
                    string result = Common.UpdateCurrentLocation(userId, Common.ToDecimal(value.Lat), Common.ToDecimal(value.Long), _appSettings);
                    return Ok(result);
                }
                catch (Exception Ex)
                {
                    return StatusCode(500, Ex.Message);
                }
            }
            else
            {
                return Unauthorized();
            }
        }

        [HttpPost("updateMobile", Name = "UpdateMobile"), Authorize]
        public IActionResult UpdateMobile([FromBody] dynamic value)
        {
            if (value is null || string.IsNullOrEmpty(value.Mobile))
            {
                return BadRequest("Invalid user request!!!");
            }
            if (Common.ToString(value.Mobile).Length != 10)
            {
                return BadRequest("Mobile No. should be 10 digit only");
            }

            var identity = HttpContext.User.Identity as ClaimsIdentity;
            if (identity != null)
            {
                int userId = Common.ToInt(identity.FindFirst("UserId").Value);

                try
                {
                    bool isAvailable = Common.CheckUserIsAvailable(Common.ToString(value.Mobile), userId, _appSettings);
                    if (!isAvailable)
                    {
                        return BadRequest("Mobile is already registered, please choose another Mobile.");
                    }

                    string result = Common.UpdateMobile(userId, Common.ToString(value.Mobile), _appSettings);
                    return Ok(result);
                }
                catch (Exception Ex)
                {
                    return StatusCode(500, Ex.Message);
                }
            }
            else
            {
                return Unauthorized();
            }
        }

        [HttpPost("estimateDistanceAndFare", Name = "estimateDistanceAndFare"), Authorize]
        public IActionResult EstimateDistanceAndFare([FromBody] dynamic value)
        {
            if (value is null || Common.ToString(value.StartPlaceId).Length == 0 || Common.ToString(value.EndPlaceId).Length == 0)
            {
                return Ok(new Response("Invalid user request!!!"));
            }
            try
            {
                MapHelper mapHelper = new MapHelper(_appSettings["AppSettings:ApiKey"], _appSettings["AppSettings:GMapApiURL"], _appSettings["AppSettings:DefaultConnection"]);
                string source = value.StartPlaceId;
                string destination = value.EndPlaceId;
                var result = mapHelper.EstimateDistanceAndFare(source, destination, Common.ToString(value.FareType), Common.ToInt(value.VehicleTypeId));
                return Ok(result);
            }
            catch (Exception Ex)
            {
                return Ok(new Response(Ex.Message));
            }
        }

        [HttpPost("getNearByDrivers", Name = "GetNearByDrivers"), Authorize]
        public IActionResult GetNearByDrivers([FromBody] dynamic value)
        {
            if (value is null || Common.ToDecimal(value.Lat) == 0 || Common.ToDecimal(value.Long) == 0
                || Common.ToInt(value.VehicleTypeId) == 0)
            {
                return Ok(new Response("Invalid user request!!!"));
            }
            try
            {
                JObject objJObject = value;
                TempRideRequest objRequest = objJObject.ToObject<TempRideRequest>();

                TempRequestsBL tempRequestsBL = new TempRequestsBL(Common.GetConString(_appSettings));
                tempRequestsBL.Data = new OM.TempRequests();
                tempRequestsBL.Data.UserId = objRequest.UserId;
                tempRequestsBL.Update();

                string data = value.ToString();
                DataTable dt = Common.GetNearByDrivers(Common.ToDecimal(value.Lat), Common.ToDecimal(value.Long), Common.ToInt(value.VehicleTypeId), _appSettings);
                foreach (DataRow dr in dt.Rows)
                {
                    Common.SendNotification(Common.ToInt(dr["UserId"]), "msg", data, _appSettings);
                }
                return Ok(dt);
            }
            catch (Exception Ex)
            {
                return Ok(new Response(Ex.Message));
            }
        }

        [HttpPost("sendRideRequest", Name = "SendRideRequest"), Authorize]
        public IActionResult SendRideRequest([FromBody] dynamic value)
        {
            JObject objJObject = value;
            TempRideRequest objRequest = objJObject.ToObject<TempRideRequest>();
            string data = value.ToString();
            _hubContext.Clients.Group("MOCK").SendAsync("ReceiveMessage", data, objRequest.UserId.ToString(), "MOCK");
            return Ok("Success");
        }

        [HttpPost("cancelRequest", Name = "CancelRequest"), Authorize]
        public IActionResult CancelRequest([FromBody] dynamic user)
        {
            RideRequestsBL objRideRequestsBL = new RideRequestsBL(Common.GetConString(_appSettings));
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int userid = Common.ToInt(identity.FindFirst("UserId").Value);
            string userName = Common.ToString(identity.FindFirst("FirstName").Value) + " " + Common.ToString(identity.FindFirst("LastName").Value);
            if (user is null || Common.ToInt(user.RideRequestId) <= 0)
            {
                return Ok(new Response("Invalid user request!!!"));
            }
            try
            {
                objRideRequestsBL.Load(Common.ToInt(user.RideRequestId));
                RideRequests rideRequests = objRideRequestsBL.Data;
                if (rideRequests.RideRequestId > 0 && (rideRequests.ToUserId == userid || rideRequests.FromUserId == userid))
                {
                    string result = Common.ChangeRequestStatus(Common.ToInt(user.RideRequestId), Status.Cancelled, _appSettings);
                    if (result == "Success")
                    {
                        if (userid == rideRequests.ToUserId)
                        {
                            Common.SendNotification(Common.ToInt(objRideRequestsBL.Data.FromUserId), "rrMsg", "Cancelled" + Common.ToInt(objRideRequestsBL.Data.RideRequestId).ToString(), _appSettings);
                        }
                        else if (userid == rideRequests.FromUserId)
                        {
                            Common.SendNotification(Common.ToInt(objRideRequestsBL.Data.ToUserId), "rrMsg", "Cancelled" + Common.ToInt(objRideRequestsBL.Data.RideRequestId).ToString(), _appSettings);
                        }
                    }
                    return Ok(new Response(result));
                }
                else
                {
                    return Ok(new Response("Invalid RideRequestId"));
                }
            }
            catch (Exception Ex)
            {
                return Ok(new Response(Ex.Message));
            }
        }

        [HttpPost("getRideHistory", Name = "GetRideHistory"), Authorize]
        public AngularGridData GetRideHistory([FromBody]dynamic value)
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int userId = Common.ToInt(identity.FindFirst("UserId").Value);
            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = Common.GetRideHistoryQuery();
            if (objAngularGrid.SearchText == "2")
            {
                objAngularDataBinder.Query += " WHERE RR.ToUserId=@UserId";
            }
            else if (objAngularGrid.SearchText == "1")
            {
                objAngularDataBinder.Query += " WHERE RR.FromUserId=@UserId";
            }

            Hashtable ht = new Hashtable();
            ht["@UserId"] = userId;
            objAngularDataBinder.Parameters = ht;
            objAngularDataBinder.ValueField = "RR.RideRequestId";
            return objAngularDataBinder.GetData(_appSettings);
        }

        [HttpGet("getRideDetails/{id}", Name = "GetRideDetails"), Authorize]
        public DataTable GetRideDetails(int id)
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int userId = Common.ToInt(identity.FindFirst("UserId").Value);
            int userTypeId = Common.ToInt(identity.FindFirst("UserTypeId").Value);
            RideRequestsBL objRideRequestsBL = new RideRequestsBL(Common.GetConString(_appSettings));
            objRideRequestsBL.Load(id);
            var rideRequest = objRideRequestsBL.Data;
            if (rideRequest.ToUserId != userId && userTypeId != 3 && rideRequest.FromUserId != userId)
            {
                return null;
            }
            string query = Common.GetRideHistoryQuery();
            query += " WHERE RR.RideRequestId=@Id";
            DataTable dt = Common.GetDBResultParameterized(_appSettings, query, "@Id", SqlDbType.Int, id);
            if (dt.Rows.Count > 0)
            {
                return dt;
            }
            else
            {
                return null;
            }
        }

        [HttpGet("getOpenRideRequest", Name = "GetOpenRideRequest"), Authorize]
        public List<string> GetOpenRideRequest()
        {
            List<string> result = new List<string>();
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int userId = Common.ToInt(identity.FindFirst("UserId").Value);
            int userTypeId = Common.ToInt(identity.FindFirst("UserTypeId").Value);

            string query = "Select RR.RideRequestId from RideRequests RR left join Rides R ON RR.RideRequestId=R.RideRequestId";
            if (userTypeId == (int)UserType.Driver)
            {
                query += " WHERE RR.ToUserId=@Id and (R.StatusId IS NULL OR R.StatusId in (1,2,3,4,6,7,8)) and RR.StatusId<>5";
            }
            else if (userTypeId == (int)UserType.Rider)
            {
                query += " WHERE RR.FromUserId=@Id and (R.StatusId IS NULL OR R.StatusId in (4,7)) and RR.StatusId<>5";
            }
            DataTable dt = Common.GetDBResultParameterized(_appSettings, query, "@Id", SqlDbType.Int, userId);
            if (dt.Rows.Count > 0)
            {
                result.Add(Common.ToString(dt.Rows[0]["RideRequestId"]));
            }
            else
            {
                result.Add("0");
            }
            if (userTypeId == (int)UserType.Driver)
            {
                dt = Common.GetDBResultParameterized(_appSettings, "Select BalanceThresold,dbo.GetDriverBalance(@Id) as DriverBalance,Users.StatusId,FavoriteLocations.Selected from Settings inner join Users ON Users.UserId=@Id left join FavoriteLocations ON FavoriteLocations.UserId=@Id and FavoriteLocations.Selected=1", "@Id", SqlDbType.Int, userId);
                if (dt.Rows.Count > 0)
                {
                    decimal balanceThreshold = Common.ToDecimal(dt.Rows[0]["BalanceThresold"]);
                    decimal balance = Common.ToDecimal(dt.Rows[0]["DriverBalance"]);
                    int status = Common.ToInt(dt.Rows[0]["StatusId"]);
                    bool selected = Common.ToBool(dt.Rows[0]["Selected"]);

                    result.Add(balance <= balanceThreshold ? balance.ToString() : "NO");
                    result.Add(status.ToString());
                    result.Add(selected.ToString());
                }
            }
            return result;
        }

        [HttpPost("saveLocation", Name = "SaveLocation"), Authorize]
        public IActionResult SaveLocation([FromBody]dynamic value)
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int userId = Common.ToInt(identity.FindFirst("UserId").Value);
            int userTypeId = Common.ToInt(identity.FindFirst("UserTypeId").Value);

            if (value is null || Common.ToDecimal(value.Lat) <= 0 || Common.ToDecimal(value.Long) <= 0)
            {
                return Ok(new Response("Invalid user request!!!"));
            }
            int rowsAffected = Common.ExecuteNonQuery(_appSettings, "exec UpdateCurrentLocation @UserId,@Lat,@Long,@LocData,@Accuracy,@CaptureTimeStamp",
                "@Lat", SqlDbType.Decimal, Common.ToDecimal(value.Lat),
                "@Long", SqlDbType.Decimal, Common.ToDecimal(value.Long),
                "@LocData", SqlDbType.VarChar, Common.ToString(value.Data),
                "@Accuracy", SqlDbType.Decimal, Common.ToDecimal(value.Accuracy),
                "@CaptureTimeStamp", SqlDbType.VarChar, Common.ToString(value.CaptureTimeStamp),
                "@UserId", SqlDbType.Int, userId);


            return Ok(new Response(rowsAffected.ToString()));
        }
    }
    public class UsersValidator : AbstractValidator<Users>
    {
        public UsersValidator()
        {
            RuleFor(obj => obj.FirstName).NotEmpty();
            RuleFor(obj => obj.LastName).NotEmpty();
            RuleFor(obj => obj.Mobile).NotEmpty();
            RuleFor(obj => obj.Password).NotEmpty();
            RuleFor(obj => obj.RegDate).NotEmpty();
            RuleFor(obj => obj.StatusId).NotEmpty();
            RuleFor(obj => obj.UserTypeId).NotEmpty();
        }
    }
}