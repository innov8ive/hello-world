using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using OM;
using BL;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Authorization;
using ProductMS.Custom;
using ProductMS.Models;

namespace ProductMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FaresController : ControllerBase
    {
        IConfiguration _appSettings;
        public FaresController(IConfiguration configuration)
        {
            _appSettings = configuration;
        }

        // GET api/Fares
        [HttpPost("FaresList", Name = "GetFareList"), AdminAuthorize]
        public AngularGridData GetFareList([FromBody]dynamic value)
        {
            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = "Select V.VehicleType,F.* from Fares F INNER JOIN VehicleTypes V ON F.VehicleTypeId=V.VehicleTypeId";
            objAngularDataBinder.ValueField = "Id";
            return objAngularDataBinder.GetData(_appSettings);
        }

        // GET api/Fares/Id
        [HttpGet("{id}"), AdminAuthorize]
        public string GetFares(int Id)
        {
            FaresBL objFaresBL = new FaresBL(Common.GetConString(_appSettings));
            objFaresBL.Load(Id);
            return JsonConvert.SerializeObject(objFaresBL.Data);
        }

        // POST api/Fares/
        public string Post([FromBody]dynamic value)
        {
            JObject objJObject = value;
            Fares objFares = objJObject.ToObject<Fares>();
            FaresBL objFaresBL = new FaresBL(Common.GetConString(_appSettings));
            objFaresBL.Data = objFares;

            FaresValidator validator = new FaresValidator();
            ValidationResult results = validator.Validate(objFares);

            if (results.IsValid)
            {
                objFaresBL.Update();
                return JsonConvert.SerializeObject(objFaresBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        // DELETE api/Fares/5
        [HttpDelete("{id}"), AdminAuthorize]
        public bool Delete(int Id)
        {
            FaresBL objFaresBL = new FaresBL(Common.GetConString(_appSettings));
            return objFaresBL.Delete(Id);
        }
    }
    public class FaresValidator : AbstractValidator<Fares>
    {
        public FaresValidator()
        {

            RuleFor(obj => obj.BaseFare).NotEmpty();
            RuleFor(obj => obj.EffectiveTill).NotEmpty();
            RuleFor(obj => obj.FareType).NotEmpty();
            RuleFor(obj => obj.PerKMFare).NotEmpty();
            RuleFor(obj => obj.VehicleTypeId).NotEmpty();
            RuleFor(obj => obj.WaitingPerMinuteFare).NotEmpty();
        }
    }
}

