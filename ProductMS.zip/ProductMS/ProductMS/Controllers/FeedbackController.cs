﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using BL;
using FluentValidation;
using FluentValidation.Results;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using OM;
using ProductMS.Models;

namespace ProductMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FeedbackController : ControllerBase
    {
        IConfiguration _appSettings;
        public FeedbackController(IConfiguration configuration)
        {
            _appSettings = configuration;
        }

        [HttpGet("{id}"), Authorize]
        public IActionResult Get(int id)
        {
            try
            {
                FeedbacksBL objFeedbacksBL = new FeedbacksBL(Common.GetConString(_appSettings));
                objFeedbacksBL.Load(id);
                return Ok(objFeedbacksBL.Data);
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }


        // POST api/FavoriteLocations/
        [HttpPost, Authorize]
        public IActionResult Post([FromBody]dynamic value)
        {
            try
            {
                JObject objJObject = value;
                Feedbacks objFeedbacks = objJObject.ToObject<Feedbacks>();
                FeedbacksBL objFeedbacksBL = new FeedbacksBL(Common.GetConString(_appSettings));
                objFeedbacksBL.Data = objFeedbacks;

                var identity = HttpContext.User.Identity as ClaimsIdentity;
                int UserId = Common.ToInt(identity.FindFirst("UserId").Value);
                int UserTypeId = Common.ToInt(identity.FindFirst("UserTypeId").Value);
                if (objFeedbacksBL.Data.FeedbackId != null && objFeedbacksBL.Data.FeedbackId <= 0)
                {
                    objFeedbacksBL.Data.UserId = UserId;
                }
                if (objFeedbacksBL.Data.UserId != UserId && UserTypeId != (int)UserType.Admin)
                {
                    return BadRequest("Invalid FeedbackId!");
                }

                objFeedbacksBL.Data.UserId = UserId;
                objFeedbacksBL.Data.StatusId = (int)Status.Pending;
                FeedbacksValidator validator = new FeedbacksValidator();
                ValidationResult results = validator.Validate(objFeedbacks);

                if (results.IsValid)
                {
                    objFeedbacksBL.Update();
                    return Ok(objFeedbacksBL.Data);
                }

                return BadRequest(results.Errors);
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        // DELETE api/FavoriteLocations/5
        [Route("{id}")]
        [HttpDelete, Authorize]
        public IActionResult Delete(int id)
        {
            try
            {
                var identity = HttpContext.User.Identity as ClaimsIdentity;
                int UserTypeId = Common.ToInt(identity.FindFirst("UserTypeId").Value);
                FeedbacksBL objFeedbacksBL = new FeedbacksBL(Common.GetConString(_appSettings));
                return Ok(objFeedbacksBL.Delete(id, Common.ToInt(identity.FindFirst("UserId").Value), UserTypeId) ? "Success" : "Failed");
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }           
        }

        [HttpGet("getUserFeedbacks/{id}", Name = "GetUserFeedbacks"), Authorize]
        public IActionResult GetUserFeedbacks(int id)
        {
            try
            {
                var identity = HttpContext.User.Identity as ClaimsIdentity;

                FeedbacksBL feedbacksBL = new FeedbacksBL(Common.GetConString(_appSettings));
                return Ok(feedbacksBL.LoadForUser(id));
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpGet("getDriverFeedbacks/{driverUserId}", Name = "GetDriverFeedbacks"), Authorize]
        public IActionResult GetDriverFeedbacks(int driverUserId)
        {
            try
            {
                var identity = HttpContext.User.Identity as ClaimsIdentity;

                FeedbacksBL feedbacksBL = new FeedbacksBL(Common.GetConString(_appSettings));
                return Ok(feedbacksBL.LoadForDriver(driverUserId));
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }
    }
    public class FeedbacksValidator : AbstractValidator<Feedbacks>
    {
        public FeedbacksValidator()
        {

            RuleFor(obj => obj.DriverUserId).NotEmpty();
            RuleFor(obj => obj.EntryDate).NotEmpty();
            RuleFor(obj => obj.Feedback).NotEmpty();
            RuleFor(obj => obj.Rate).NotEmpty();
            RuleFor(obj => obj.StatusId).NotEmpty();
            RuleFor(obj => obj.UserId).NotEmpty();
        }
    }
}