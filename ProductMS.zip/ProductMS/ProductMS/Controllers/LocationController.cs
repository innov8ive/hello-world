﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using BL;
using FluentValidation;
using FluentValidation.Results;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using OM;
using ProductMS.Models;

namespace ProductMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LocationController : ControllerBase
    {
        IConfiguration _appSettings;
        public LocationController(IConfiguration configuration)
        {
            _appSettings = configuration;
        }

        [HttpGet("{id}"), Authorize]
        public IActionResult Get(int id)
        {
            try
            {
                var identity = HttpContext.User.Identity as ClaimsIdentity;
                int UserId = Common.ToInt(identity.FindFirst("UserId").Value);
                FavoriteLocationsBL objFavoriteLocationsBL = new FavoriteLocationsBL(Common.GetConString(_appSettings));
                objFavoriteLocationsBL.Load(id);
                if (objFavoriteLocationsBL.Data.UserId > 0 && objFavoriteLocationsBL.Data.UserId != UserId)
                {
                    return Ok(new Response("Invalid Request"));
                }
                return Ok(objFavoriteLocationsBL.Data);
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }


        // POST api/FavoriteLocations/
        [HttpPost, Authorize]
        public IActionResult Post([FromBody]dynamic value)
        {
            try
            {
                JObject objJObject = value;
                FavoriteLocations objFavoriteLocations = objJObject.ToObject<FavoriteLocations>();
                FavoriteLocationsBL objFavoriteLocationsBL = new FavoriteLocationsBL(Common.GetConString(_appSettings));
                var identity = HttpContext.User.Identity as ClaimsIdentity;
                int UserId = Common.ToInt(identity.FindFirst("UserId").Value);
                int UserTypeId = Common.ToInt(identity.FindFirst("UserTypeId").Value);
                if (objFavoriteLocations.LocationId != null && objFavoriteLocations.LocationId <= 0)
                {
                    objFavoriteLocations.UserId = UserId;
                }
                if (objFavoriteLocations.UserId != UserId && UserTypeId != (int)UserType.Admin)
                {
                    return BadRequest("Invalid LocationId!");                }


                FavoriteLocationsValidator validator = new FavoriteLocationsValidator();
                ValidationResult results = validator.Validate(objFavoriteLocations);

                if (results.IsValid)
                {
                    objFavoriteLocationsBL.Data = objFavoriteLocations;
                    objFavoriteLocationsBL.Update();
                    return Ok(objFavoriteLocationsBL.Data);
                }

                return Ok(new Response(string.Join(",", results.Errors)));
            }
            catch (Exception Ex)
            {
                return Ok(new Response(Ex.Message));
            }
        }

        // DELETE api/FavoriteLocations/5
        [HttpPost("deleteLocation", Name = "DeleteLocation"), Authorize]
        public IActionResult DeleteLocation([FromBody]dynamic value)
        {
            try
            {
                var identity = HttpContext.User.Identity as ClaimsIdentity;
                int UserId = Common.ToInt(identity.FindFirst("UserId").Value);
                FavoriteLocationsBL objFavoriteLocationsBL = new FavoriteLocationsBL(Common.GetConString(_appSettings));
                objFavoriteLocationsBL.Load(Common.ToInt(value.Id));
                if (objFavoriteLocationsBL.Data.UserId > 0 && objFavoriteLocationsBL.Data.UserId != UserId)
                {
                    return Ok(new Response("Invalid Request"));
                }
                return Ok(new Response(objFavoriteLocationsBL.Delete(Common.ToInt(value.Id), Common.ToInt(identity.FindFirst("UserId").Value)) ? "Success" : "Failed"));
            }
            catch (Exception Ex)
            {
                return Ok(new Response(Ex.Message));
            }
        }

        [HttpGet("getUserLocations/{id}", Name = "GetUserLocations"), Authorize]
        public IActionResult GetUserLocations(int id)
        {
            try
            {
                FavoriteLocationsBL objLocBL = new FavoriteLocationsBL(Common.GetConString(_appSettings));
                return Ok(objLocBL.LoadForUser(id));
            }
            catch (Exception Ex)
            {
                return Ok(new Response(Ex.Message));
            }
        }

        [HttpPost("setUserLocation", Name = "SetUserLocations"), Authorize]
        public IActionResult SetUserLocations([FromBody]dynamic value)
        {
            try
            {
                FavoriteLocationsBL objLocBL = new FavoriteLocationsBL(Common.GetConString(_appSettings));
                return Ok(new Response(objLocBL.SetFavoriteLocations(Common.ToInt(value.UserId), Common.ToInt(value.LocationId), Common.ToBool(value.Selected)) ? "Success" : "Failed"));
            }
            catch (Exception Ex)
            {
                return Ok(new Response(Ex.Message));
            }
        }
    }
    public class FavoriteLocationsValidator : AbstractValidator<FavoriteLocations>
    {
        public FavoriteLocationsValidator()
        {

            RuleFor(obj => obj.GMapName).NotEmpty();
            RuleFor(obj => obj.Lat).NotEmpty();
            RuleFor(obj => obj.LocationName).NotEmpty();
            RuleFor(obj => obj.LocationTypeId).NotEmpty();
            RuleFor(obj => obj.Long).NotEmpty();
        }
    }
}