﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Threading.Tasks;
using BL;
using FluentValidation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using OM;
using ProductMS.Custom;
using ProductMS.Models;

namespace ProductMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController, DriverAuthorize]
    public class DriverController : ControllerBase
    {
        IConfiguration _appSettings;
        private readonly IHubContext<ChatHub> _hubContext;
        public DriverController(IConfiguration configuration, IHubContext<ChatHub> hubContext)
        {
            _appSettings = configuration;
            _hubContext = hubContext;
        }

        [HttpPost("uploadImage", Name = "UploadImage"), DisableRequestSizeLimit]
        public IActionResult UploadImage([FromBody] dynamic user)
        {
            try
            {
                if (user is null || Common.ToString(user.Base64).Length == 0)
                {
                    return Ok(new Response("Invalid user request!!!"));
                }
                var identity = HttpContext.User.Identity as ClaimsIdentity;
                int UserId = Common.ToInt(identity.FindFirst("UserId").Value);


                byte[] bytes = Convert.FromBase64String(Common.ToString(user.Base64));

                var folderName = Path.Combine("Resources", "Images");
                var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), folderName);

                var newFileName = Guid.NewGuid().ToString() + "." + Common.ToString(user.Format);
                var fullPath = Path.Combine(pathToSave, newFileName);
                var dbPath = Path.Combine(folderName, newFileName);


                System.IO.File.WriteAllBytes(fullPath, bytes);

                DriverDocsBL objDriverDocsBL = new DriverDocsBL(Common.GetConString(_appSettings));
                DriverDocs driverDocs = new DriverDocs();
                driverDocs.FileGUID = dbPath;
                driverDocs.UploadedOn = DateTime.Now;
                driverDocs.DocTypeId = Common.ToInt(Common.ToString(user.DocTypeId));
                driverDocs.StatusId = (int)Status.Pending;
                driverDocs.UserId = UserId;
                objDriverDocsBL.Data = driverDocs;
                objDriverDocsBL.Update();

                Common.ChangeDriverStatus(UserId, Status.Pending, "Pending, because new document(s) uploaded.", _appSettings);

                return Ok(new Response("Success"));
            }
            catch (Exception Ex)
            {
                return Ok(new Response(Ex.Message));
            }
        }

        [HttpPost("uploadFile", Name = "UploadFile"), DisableRequestSizeLimit]
        public async Task<IActionResult> UploadFile()
        {
            try
            {
                var formCollection = await Request.ReadFormAsync();
                var file = formCollection.Files.First();
                var folderName = Path.Combine("Resources", "Images");
                var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), folderName);
                if (file.Length > 0)
                {
                    string extension = Path.GetExtension(ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName).ToLower();
                    if (extension != "jpg" && extension != "jpeg" && extension != "png")
                    {
                        return BadRequest();
                    }
                    string fileData = file.Name;
                    if (string.IsNullOrEmpty(fileData))
                    {
                        return BadRequest();
                    }
                    string docType = fileData.Substring(0, fileData.IndexOf("`"));
                    var fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
                    var newFileName = Guid.NewGuid().ToString() + extension;
                    var fullPath = Path.Combine(pathToSave, newFileName);
                    var dbPath = Path.Combine(folderName, newFileName);
                    using (var stream = new FileStream(fullPath, FileMode.Create))
                    {
                        file.CopyTo(stream);
                    }
                    var identity = HttpContext.User.Identity as ClaimsIdentity;
                    int UserId = Common.ToInt(identity.FindFirst("UserId").Value);

                    DriverDocsBL objDriverDocsBL = new DriverDocsBL(Common.GetConString(_appSettings));
                    DriverDocs driverDocs = new DriverDocs();
                    driverDocs.FileGUID = dbPath;
                    driverDocs.UploadedOn = DateTime.Now;
                    driverDocs.DocTypeId = Common.ToInt(docType);
                    driverDocs.StatusId = (int)Status.Pending;
                    driverDocs.UserId = UserId;
                    objDriverDocsBL.Data = driverDocs;
                    objDriverDocsBL.Update();

                    Common.ChangeDriverStatus(UserId, Status.Pending, "Pending, because new document(s) uploaded.", _appSettings);

                    return Ok(new { dbPath });
                }
                else
                {
                    return BadRequest();
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex}");
            }
        }

        [HttpPost("deleteDocument", Name = "DeleteDocument")]
        public IActionResult DeleteDocument([FromBody] dynamic user)
        {
            if (user is null || Common.ToInt(user.DriverDocId) <= 0)
            {
                return Ok(new Response("Invalid user request!!!"));
            }
            try
            {
                DriverDocsBL objDriverDocsBL = new DriverDocsBL(Common.GetConString(_appSettings));
                objDriverDocsBL.Load(Common.ToInt(user.DriverDocId));
                if (objDriverDocsBL.Data != null && !string.IsNullOrEmpty(objDriverDocsBL.Data.FileGUID))
                {
                    try
                    {
                        var pathToDelete = Path.Combine(Directory.GetCurrentDirectory(), objDriverDocsBL.Data.FileGUID);
                        System.IO.File.Delete(pathToDelete);
                    }
                    catch
                    {
                    }
                }
                objDriverDocsBL.Delete(Common.ToInt(user.DriverDocId));
                return Ok(new Response("Success"));
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("getDocuments", Name = "GetDocuments")]
        public IActionResult GetDocuments([FromBody] dynamic user)
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int UserId = Common.ToInt(identity.FindFirst("UserId").Value);
            try
            {
                return Ok(Common.GetDriverDocuments(UserId, _appSettings));
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("setOnDuty", Name = "SetOnDuty")]
        public IActionResult SetOnDuty([FromBody] dynamic user)
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int UserId = Common.ToInt(identity.FindFirst("UserId").Value);
            try
            {
                return Ok(Common.ChangeOnOffDuty(UserId, true, _appSettings));
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("setOffDuty", Name = "SetOffDuty")]
        public IActionResult SetOffDuty([FromBody] dynamic user)
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int UserId = Common.ToInt(identity.FindFirst("UserId").Value);
            try
            {
                return Ok(Common.ChangeOnOffDuty(UserId, false, _appSettings));
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpGet("getDetails", Name = "GetDetails")]
        public IActionResult GetDetails()
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int UserId = Common.ToInt(identity.FindFirst("UserId").Value);
            try
            {
                DriversBL objDriversBL = new DriversBL(Common.GetConString(_appSettings));
                objDriversBL.Load(UserId);
                var result = objDriversBL.Data;
                return Ok(result);
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("updateDetails", Name = "UpdateDetails")]
        public IActionResult UpdateDetails([FromBody] dynamic value)
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int UserId = Common.ToInt(identity.FindFirst("UserId").Value);
            try
            {
                JObject objJObject = value;
                Drivers objDrivers = objJObject.ToObject<Drivers>();
                DriversBL objDriversBL = new DriversBL(Common.GetConString(_appSettings));
                objDriversBL.Data = objDrivers;
                objDriversBL.Data.UserId = UserId;

                DriversValidator validator = new DriversValidator();
                var results = validator.Validate(objDrivers);

                if (results.IsValid)
                {
                    objDriversBL.Update();

                    if (objDrivers.UserDetails != null)
                    {
                        UsersBL objUsersBL = new UsersBL(Common.GetConString(_appSettings));
                        objUsersBL.Data.EmailId = objDrivers.UserDetails.EmailId;
                        objUsersBL.Data.FirstName = objDrivers.UserDetails.FirstName;
                        objUsersBL.Data.LastName = objDrivers.UserDetails.LastName;
                        objUsersBL.Data.Lang = objDrivers.UserDetails.Lang;
                        objUsersBL.Update();
                    }                    

                    Common.ChangeDriverStatus(UserId, Status.Pending, "Pending, because details updated.", _appSettings);
                    return Ok(objDriversBL.Data);
                }

                return BadRequest(results.Errors);
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("startOnHireRide", Name = "StartOnHireRide")]
        public IActionResult StartOnHireRide([FromBody] dynamic value)
        {
            JObject objJObject = value;
            TempRideRequest objRequest = objJObject.ToObject<TempRideRequest>();

            RideRequestsBL objRideRequestsBL = new RideRequestsBL(Common.GetConString(_appSettings));
            RidesBL objRidesBL = new RidesBL(Common.GetConString(_appSettings));
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int userId = Common.ToInt(identity.FindFirst("UserId").Value);
            if (value is null || objRequest == null)
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                Random ran = new Random();
                objRideRequestsBL.Load(0);
                RideRequests rideRequests = objRideRequestsBL.Data;
                rideRequests.DistanceKM = objRequest.Distance;
                rideRequests.EstimatedFare = objRequest.Fare;
                rideRequests.StartLat = objRequest.Lat;
                rideRequests.StartLong = objRequest.Long;
                rideRequests.VehicleTypeId = objRequest.VehicleTypeId;
                rideRequests.EndLat = objRequest.EndLat;
                rideRequests.EndLong = objRequest.EndLong;
                rideRequests.StartLocationText = objRequest.StartName;
                rideRequests.EndLocationText = objRequest.EndName;
                rideRequests.StartPlaceId = objRequest.StartPlaceId;
                rideRequests.EndPlaceId = objRequest.EndPlaceId;
                rideRequests.FromUserId = 0;
                rideRequests.EstimatedMinutes = objRequest.Duration;
                rideRequests.RequestDate = DateTime.Now;
                rideRequests.RideRequestId = 0;
                rideRequests.StatusId = (int)Status.Accepted;
                rideRequests.ToUserId = userId;
                if (objRideRequestsBL.Update())
                {
                    objRidesBL.Load(0);
                    Rides rides = objRidesBL.Data;
                    rides.EstimatedDistanceKM = objRequest.Distance;
                    rides.EstimatedFare = objRequest.Fare;
                    rides.PickTime = DateTime.Now;
                    rides.RideRequestId = objRideRequestsBL.Data.RideRequestId;
                    rides.VehicleTypeId = objRequest.VehicleTypeId;
                    rides.RideId = 0;
                    rides.StatusId = (int)Status.InTransit;
                    rides.StatusUpdatedOn = DateTime.Now;
                    rides.StatusUpdatedById = userId;
                    rides.StatusUpdatedBy = "Driver";
                    objRidesBL.Update();
                    Common.ChangeOnOffDuty(userId, true, _appSettings);
                    return Ok(new Response("Success" + objRideRequestsBL.Data.RideRequestId));
                }
                else
                {
                    return Ok(new Response("Invalid Request."));
                }
            }
            catch (Exception Ex)
            {
                return Ok(new Response(Ex.Message));
            }
        }

        [HttpPost("acceptRequest", Name = "AcceptRequest")]
        public IActionResult AcceptRequest([FromBody] dynamic value)
        {
            JObject objJObject = value;
            TempRideRequest objRequest = objJObject.ToObject<TempRideRequest>();

            RideRequestsBL objRideRequestsBL = new RideRequestsBL(Common.GetConString(_appSettings));

            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int userId = Common.ToInt(identity.FindFirst("UserId").Value);
            if (value is null || objRequest == null)
            {
                return Ok(new Response("Invalid user request!!!"));
            }
            try
            {
                Random ran = new Random();
                objRideRequestsBL.Load(0);
                RideRequests rideRequests = objRideRequestsBL.Data;
                rideRequests.DistanceKM = objRequest.Distance;
                rideRequests.EstimatedFare = objRequest.Fare;
                rideRequests.StartLat = objRequest.Lat;
                rideRequests.StartLong = objRequest.Long;
                rideRequests.EndLat = objRequest.EndLat;
                rideRequests.EndLong = objRequest.EndLong;
                rideRequests.StartLocationText = objRequest.StartName;
                rideRequests.EndLocationText = objRequest.EndName;
                rideRequests.StartPlaceId = objRequest.StartPlaceId;
                rideRequests.EndPlaceId = objRequest.EndPlaceId;
                rideRequests.FromUserId = objRequest.UserId;
                rideRequests.VehicleTypeId = objRequest.VehicleTypeId;
                rideRequests.EstimatedMinutes = objRequest.Duration;
                rideRequests.RequestDate = DateTime.Now;
                rideRequests.RideRequestId = 0;
                rideRequests.StatusId = (int)Status.Accepted;
                rideRequests.ToUserId = userId;
                rideRequests.OTP = ran.Next(111111, 999999);
                DataTable dataTable = Common.GetDBResultParameterized(_appSettings, "select DATEDIFF(S,RequestDate,getdate()) as Sec,IsAccepted from TempRequests where userId=@UserId"
                    , "@UserId", SqlDbType.Int, objRequest.UserId);
                if (dataTable != null && dataTable.Rows.Count > 0)
                {
                    if (Common.ToInt(dataTable.Rows[0]["Sec"]) >= 30)
                    {
                        return Ok(new Response("Expired"));
                    }
                    else if (Common.ToBool(dataTable.Rows[0]["IsAccepted"]) == true)
                    {
                        return Ok(new Response("AcceptedByDriver"));
                    }
                    else
                    {
                        if (objRideRequestsBL.Update())
                        {
                            int rideRequestId = objRideRequestsBL.Data.RideRequestId.Value;
                            Common.SendNotification(objRequest.UserId, "rrMsg", "Accepted" + rideRequestId.ToString(), _appSettings);
                            return Ok(new Response("Success" + objRideRequestsBL.Data.RideRequestId));
                        }
                        else
                        {
                            return Ok(new Response("Invalid Request."));
                        }
                    }
                }
                else
                {
                    return Ok(new Response("Invalid Request."));
                }
            }
            catch (Exception Ex)
            {
                return Ok(new Response(Ex.Message));
            }
        }

        [HttpPost("rejectRequest", Name = "RejectRequest")]
        public IActionResult RejectRequest([FromBody] dynamic value)
        {
            JObject objJObject = value;
            TempRideRequest objRequest = objJObject.ToObject<TempRideRequest>();

            RideRequestsBL objRideRequestsBL = new RideRequestsBL(Common.GetConString(_appSettings));

            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int userId = Common.ToInt(identity.FindFirst("UserId").Value);
            if (value is null || objRequest == null)
            {
                return Ok(new Response("Invalid user request!!!"));
            }
            try
            {
                Common.SendNotification(objRequest.UserId, "rrMsg", "Rejected" + userId.ToString(), _appSettings);
                return Ok(new Response("Success"));
            }
            catch (Exception Ex)
            {
                return Ok(new Response(Ex.Message));
            }
        }

        [HttpPost("startRide", Name = "StartRide")]
        public IActionResult StartRide([FromBody] dynamic value)
        {
            RidesBL objRidesBL = new RidesBL(Common.GetConString(_appSettings));
            RideRequestsBL objRideRequestsBL = new RideRequestsBL(Common.GetConString(_appSettings));
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int userId = Common.ToInt(identity.FindFirst("UserId").Value);
            string userName = Common.ToString(identity.FindFirst("FirstName").Value) + " " + Common.ToString(identity.FindFirst("LastName").Value);
            if (value is null || Common.ToInt(value.RideRequestId) == 0 || Common.ToInt(value.OTP) == 0)
            {
                return Ok(new Response("Invalid user request!!!"));
            }
            try
            {
                objRideRequestsBL.Load(Common.ToInt(value.RideRequestId));
                var rideRequest = objRideRequestsBL.Data;
                if (rideRequest == null || rideRequest.RideRequestId <= 0 || rideRequest.ToUserId != userId)
                {
                    return Ok(new Response("Invalid user request!!!"));
                }
                if (rideRequest.OTP != Common.ToInt(value.OTP))
                {
                    return Ok(new Response("Invalid OTP!!!"));
                }
                objRidesBL.Load(0);
                Rides rides = objRidesBL.Data;
                rides.EstimatedDistanceKM = rideRequest.DistanceKM;
                rides.EstimatedFare = rideRequest.EstimatedFare;
                rides.VehicleTypeId = rideRequest.VehicleTypeId;
                rides.PickTime = DateTime.Now;
                rides.RideRequestId = Common.ToInt(value.RideRequestId);
                rides.RideId = 0;
                rides.StatusId = (int)Status.InTransit;
                rides.StatusUpdatedOn = DateTime.Now;
                rides.StatusUpdatedById = userId;
                rides.StatusUpdatedBy = "Driver";
                objRidesBL.Update();
                Common.ChangeOnOffDuty(userId, true, _appSettings);
                if (objRideRequestsBL.Data.FromUserId > 0)
                {
                    Common.SendNotification(objRideRequestsBL.Data.FromUserId.Value, "rrId", rides.RideRequestId.ToString(), _appSettings);
                }
                return Ok(new Response("Success" + Common.ToInt(rides.RideId)));
            }
            catch (Exception Ex)
            {
                return Ok(new Response(Ex.Message));
            }
        }

        [HttpPost("updateRideLocation", Name = "UpdateRideLocation")]
        public IActionResult UpdateRideLocation([FromBody] dynamic value)
        {
            try
            {
                JObject objJObject = value;
                RideLocations objRideLocations = objJObject.ToObject<RideLocations>();
                RidesBL objRidesBL = new RidesBL(Common.GetConString(_appSettings));
                objRidesBL.InsertIntoRideLocations(objRideLocations);
                return Ok("Success");
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("endRide", Name = "EndRide")]
        public IActionResult EndRide([FromBody] dynamic value)
        {
            RidesBL objRidesBL = new RidesBL(Common.GetConString(_appSettings));
            
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int userId = Common.ToInt(identity.FindFirst("UserId").Value);
            string userName = Common.ToString(identity.FindFirst("FirstName").Value) + " " + Common.ToString(identity.FindFirst("LastName").Value);
            if (value is null || Common.ToInt(value.RideId) == 0 || Common.ToDecimal(value.EndLat) == 0 || Common.ToDecimal(value.EndLong) == 0)
            {
                return Ok(new Response("Invalid user request!!!"));
            }
            try
            {
                objRidesBL.Load(Common.ToInt(value.RideId));
                Rides rides = objRidesBL.Data;
                if (rides.StatusUpdatedById != userId)
                {
                    return Ok(new Response("Invalid user request!!!"));
                }
                
                MapHelper mapHelper = new MapHelper(_appSettings["AppSettings:ApiKey"], _appSettings["AppSettings:GMapApiURL"], _appSettings["AppSettings:DefaultConnection"]);
                string destination = value.EndLat + "," + value.EndLong;
                DistanceMatrix distanceMatrix = mapHelper.CalculateDistanceAndFare2(Common.ToInt(value.RideId), destination);
                if (distanceMatrix == null || distanceMatrix.Fares == null || distanceMatrix.Fares.Count == 0)
                {
                    return Ok(new Response("Error in distance calculation!!!"));
                }
                rides.ActualDistanceKM = distanceMatrix.DistanceMeter / 1000;
                rides.ActualFare = distanceMatrix.Fares[0].EstimatedFare;
                rides.Commission = distanceMatrix.Fares[0].Commission;
                rides.EndTime = DateTime.Now;
                rides.RideMinutes = (rides.EndTime.Value - rides.PickTime.Value).TotalMinutes;
                rides.StatusId = (int)Status.Completed;
                rides.StatusDetails = "Completed";
                rides.StatusUpdatedOn = DateTime.Now;
                rides.StatusUpdatedById = userId;
                rides.StatusUpdatedBy = "Driver";
                rides.EndLat = Common.ToDecimal(value.EndLat);
                rides.EndLong = Common.ToDecimal(value.EndLong);
                rides.EndPlaceId = Common.ToString(value.EndPlaceId);
                rides.EndPlaceText = Common.ToString(value.EndPlaceText);
                objRidesBL.Update();
                RideRequestsBL objRideRequestsBL = new RideRequestsBL(Common.GetConString(_appSettings));
                objRideRequestsBL.Load(rides.RideRequestId.Value);
                Common.ChangeOnOffDuty(userId, false, _appSettings);
                if (objRideRequestsBL.Data.FromUserId > 0)
                {
                    Common.SendNotification(objRideRequestsBL.Data.FromUserId.Value, "rrId", rides.RideRequestId.ToString(), _appSettings);
                }
                return Ok(rides);
            }
            catch (Exception Ex)
            {
                return Ok(new Response(Ex.Message));
            }
        }

        [HttpPost("ridePayment", Name = "RidePayment")]
        public IActionResult RidePayment([FromBody] dynamic value)
        {
            RidesBL objRidesBL = new RidesBL(Common.GetConString(_appSettings));

            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int userId = Common.ToInt(identity.FindFirst("UserId").Value);
            string userName = Common.ToString(identity.FindFirst("FirstName").Value) + " " + Common.ToString(identity.FindFirst("LastName").Value);
            if (value is null || Common.ToInt(value.RideId) == 0 ||
                Common.ToDecimal(value.PaidFare) == 0 || Common.ToString(value.PaidMode).Length == 0
                //|| Common.ToString(value.PlatformBillID).Length == 0
                )
            {
                return Ok(new Response("Invalid user request!!!"));
            }
            try
            {
                objRidesBL.Load(Common.ToInt(value.RideId));
                Rides rides = objRidesBL.Data;
                if (rides.StatusUpdatedById != userId)
                {
                    return Ok(new Response("Invalid user request!!!"));
                }
                rides.PaidFare = Common.ToDecimal(value.PaidFare);
                rides.PaidMode = Common.ToString(value.PaidMode);
                //rides.PlatformBillID = Common.ToString(value.PlatformBillID);
                rides.StatusUpdatedOn = DateTime.Now;
                rides.StatusUpdatedById = userId;
                rides.StatusUpdatedBy = "Driver";
                rides.StatusId = (int)Status.Paid;
                objRidesBL.Update();
                RideRequestsBL objRideRequestsBL = new RideRequestsBL(Common.GetConString(_appSettings));
                objRideRequestsBL.Load(rides.RideRequestId.Value);
                if (objRideRequestsBL.Data.FromUserId > 0)
                {
                    Common.SendNotification(objRideRequestsBL.Data.FromUserId.Value, "rrId", rides.RideRequestId.ToString(), _appSettings);
                }
                return Ok(new Response("Success"));
            }
            catch (Exception Ex)
            {
                return Ok(new Response(Ex.Message));
            }
        }

        [HttpPost("generatePaymentLink", Name = "GeneratePaymentLink")]
        public IActionResult GeneratePaymentLink([FromBody] dynamic value)
        {
            RidesBL objRidesBL = new RidesBL(Common.GetConString(_appSettings));

            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int userId = Common.ToInt(identity.FindFirst("UserId").Value);
            string userName = Common.ToString(identity.FindFirst("FirstName").Value) + " " + Common.ToString(identity.FindFirst("LastName").Value);
            if (value is null || Common.ToInt(value.RideId) == 0 ||
                Common.ToInt(value.ActualFare) == 0 || Common.ToInt(value.RideRequestId) == 0)
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                objRidesBL.Load(Common.ToInt(value.RideId));
                Rides rides = objRidesBL.Data;
                if (rides.StatusUpdatedById != userId)
                {
                    return BadRequest("Invalid user request!!!");
                }

                SetuHelper setuHelper = new SetuHelper(1, Common.GetConString(_appSettings));
                setuHelper.Token = setuHelper.GetExistingToken();
                string link = setuHelper.GenerateDeepLink(Common.ToInt(value.ActualFare), "ApnaCab", "Ride Payment: " + Common.ToInt(value.RideId));
                if (!string.IsNullOrEmpty(link) && link.Contains("`"))
                {
                    rides.PlatformBillID = link.Split('`')[0];
                    objRidesBL.Update();
                    _hubContext.Clients.Group(Common.ToString(value.RideRequestId)).SendAsync("PaymentLinkGenerated", "LinkGenerated", userName);
                    return Ok(new Response(link));
                }
                return BadRequest("Error occurred in generating payment link!!!");
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("generateCommissionPaymentLink", Name = "GenerateCommissionPaymentLink")]
        public IActionResult GenerateCommissionPaymentLink([FromBody] dynamic value)
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int userId = Common.ToInt(identity.FindFirst("UserId").Value);
            if (value is null || Common.ToInt(value.Amount) <= 0)
            {
                return Ok(new Response("Invalid user request!!!"));
            }
            try
            {
                SetuHelper setuHelper = new SetuHelper(1, Common.GetConString(_appSettings));
                setuHelper.Token = setuHelper.GetExistingToken();
                string link = setuHelper.GenerateDeepLink(Common.ToInt(value.Amount), "ApnaCab", "Commission Payment: " + userId.ToString());
                if (!string.IsNullOrEmpty(link) && link.Contains("`"))
                {
                    return Ok(new Response(link));
                }

                return Ok(new Response("Error occurred in generating payment link!!!"));
            }
            catch (Exception Ex)
            {
                return Ok(new Response(Ex.Message));
            }
        }

        [HttpPost("checkCommissionLinkStatus", Name = "CheckCommissionLinkStatus")]
        public IActionResult CheckCommissionLinkStatus([FromBody] dynamic value)
        {
            CommissionPaymentBL objRidesBL = new CommissionPaymentBL(Common.GetConString(_appSettings));

            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int userId = Common.ToInt(identity.FindFirst("UserId").Value);
            if (value is null || Common.ToString(value.PlatformBillID).Length == 0
                || Common.ToDecimal(value.Amount) == 0)
            {
                return Ok(new Response("Invalid user request!!!"));
            }
            try
            {
                objRidesBL.Load(0);
                CommissionPayment rides = objRidesBL.Data;

                SetuHelper setuHelper = new SetuHelper(1, Common.GetConString(_appSettings));
                setuHelper.Token = setuHelper.GetExistingToken();
                string status = setuHelper.CheckLinkStatus(Common.ToString(value.PlatformBillID));
                if (!string.IsNullOrEmpty(status) && (status == "SETTLEMENT_SUCCESSFUL" || status == "PAYMENT_FAILED"))
                {
                    rides.PlatformBillID = Common.ToString(value.PlatformBillID);
                    rides.Amount = Common.ToDecimal(value.Amount);
                    rides.UserId = userId;
                    rides.PaymentDate = DateTime.Now;
                    rides.Remarks = status;
                    objRidesBL.Update();
                    return Ok(new Response(status == "SETTLEMENT_SUCCESSFUL" ? "Success" : "Failed"));
                }
                else
                {
                    return Ok(new Response("In Progress"));
                }
            }
            catch (Exception Ex)
            {
                return Ok(new Response(Ex.Message));
            }
        }

        [HttpPost("checkLinkStatus", Name = "CheckLinkStatus")]
        public IActionResult CheckLinkStatus([FromBody] dynamic value)
        {
            RidesBL objRidesBL = new RidesBL(Common.GetConString(_appSettings));

            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int userId = Common.ToInt(identity.FindFirst("UserId").Value);
            string userName = Common.ToString(identity.FindFirst("FirstName").Value) + " " + Common.ToString(identity.FindFirst("LastName").Value);
            if (value is null || Common.ToInt(value.RideId) == 0 ||
                Common.ToString(value.PlatformBillID).Length == 0 || Common.ToInt(value.RideRequestId) == 0)
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                objRidesBL.Load(Common.ToInt(value.RideId));
                Rides rides = objRidesBL.Data;
                if (rides.StatusUpdatedById != userId)
                {
                    return BadRequest("Invalid user request!!!");
                }

                SetuHelper setuHelper = new SetuHelper(1, Common.GetConString(_appSettings));
                setuHelper.Token = setuHelper.GetExistingToken();
                string status = setuHelper.CheckLinkStatus(Common.ToString(value.PlatformBillID));
                _hubContext.Clients.Group(Common.ToString(value.RideRequestId)).SendAsync("PaymentStatus", status, userName);
                if (!string.IsNullOrEmpty(status) && status == "SETTLEMENT_SUCCESSFUL")
                {
                    return Ok(new Response("Success"));
                }
                else
                {
                    return Ok(new Response("In Progress"));
                }
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("getTxnHistory", Name = "GetTxnHistory")]
        public AngularGridData GetTxnHistory([FromBody]dynamic value)
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int userId = Common.ToInt(identity.FindFirst("UserId").Value);
            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = @"SELECT * FROM GetDriverTransactions(@UserId) ";
            Hashtable ht = new Hashtable();
            ht["@UserId"] = userId;
            objAngularDataBinder.Parameters = ht;
            objAngularDataBinder.ValueField = "TxnDate";
            return objAngularDataBinder.GetData(_appSettings);
        }

        [HttpPost("onlineToggle", Name = "OnlineToggle")]
        public IActionResult OnlineToggle([FromBody] dynamic value)
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int userId = Common.ToInt(identity.FindFirst("UserId").Value);

            try
            {
                string result = Common.OnlineToggleDriver(userId, Common.ToBool(value.IsOnline), _appSettings);
                if (!string.IsNullOrEmpty(result) && result == "Success")
                {
                    return Ok(new Response("Success"));
                }
                else
                {
                    return Ok(new Response(""));
                }
            }
            catch (Exception Ex)
            {
                return Ok(new Response(Ex.Message));
            }
        }

        [HttpGet("getOnlineStatus", Name = "getOnlineStatus")]
        public IActionResult getOnlineStatus()
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int userId = Common.ToInt(identity.FindFirst("UserId").Value);

            try
            {
                var result = Common.GetDBScalar(_appSettings, "Select IsOnline from Drivers where UserId=@UserId",
                    "@UserId", SqlDbType.Int, userId);
                return Ok(new Response(Common.ToBool(result).ToString()));
            }
            catch (Exception Ex)
            {
                return Ok(new Response(Ex.Message));
            }
        }
    }

    public class DriversValidator : AbstractValidator<Drivers>
    {
        public DriversValidator()
        {

            RuleFor(obj => obj.CityId).NotEmpty();
            RuleFor(obj => obj.DLExpiryDate).NotEmpty();
            RuleFor(obj => obj.DLNo).NotEmpty();
            RuleFor(obj => obj.FullAddress).NotEmpty();
            RuleFor(obj => obj.UserId).NotEmpty();
            RuleFor(obj => obj.VehicleTypeId).NotEmpty();
            RuleFor(obj => obj.Zipcode).NotEmpty();
        }
    }
}
