﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using ProductMS.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Authorization;
using ProductMS.Custom;
using BL;
using Newtonsoft.Json.Linq;
using System.Collections;
using OM;
using System.Data;

namespace ProductMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController, AdminAuthorize]
    public class AdminController : ControllerBase
    {
        IConfiguration _appSettings;
        public AdminController(IConfiguration configuration)
        {
            _appSettings = configuration;
        }

        [HttpPost("deactivateUser", Name = "DeactivateUser")]
        public IActionResult DeactivateUser([FromBody] dynamic user)
        {
            if (user is null || Common.ToInt(user.UserId) <= 0)
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                string result = Common.DeActivateUser(Common.ToInt(user.UserId), false, _appSettings);
                return Ok(new Response(result));
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("activateUser", Name = "ActivateUser")]
        public IActionResult ActivateUser([FromBody] dynamic user)
        {
            if (user is null || Common.ToInt(user.UserId) <= 0)
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                string result = Common.DeActivateUser(Common.ToInt(user.UserId), true, _appSettings);
                return Ok(new Response(result));
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("approveDriver", Name = "ApproveDriver")]
        public IActionResult ApproveDriver([FromBody] dynamic user)
        {
            if (user is null || Common.ToInt(user.UserId) <= 0)
            {
                return Ok(new Response("Invalid user request!!!"));
            }
            try
            {
                string result = Common.ChangeDriverStatus(Common.ToInt(user.UserId), Status.Approved, "Approved", _appSettings);
                Common.SendNotification(Common.ToInt(user.UserId), string.Empty, string.Empty, _appSettings, "ApnaCab", "Congulation! Your driver account is Approved.");
                return Ok(new Response(result));
            }
            catch (Exception Ex)
            {
                return Ok(new Response(Ex.Message));
            }
        }

        [HttpPost("rejectDriver", Name = "RejectDriver")]
        public IActionResult RejectDriver([FromBody] dynamic user)
        {
            if (user is null || Common.ToInt(user.UserId) <= 0)
            {
                return Ok(new Response("Invalid user request!!!"));
            }
            try
            {
                string result = Common.ChangeDriverStatus(Common.ToInt(user.UserId), Status.Rejected, Common.ToString(user.ApprovalRemarks), _appSettings);
                Common.SendNotification(Common.ToInt(user.UserId), string.Empty, string.Empty, _appSettings, "ApnaCab", "We are sorry! Your driver account is Rejected. Please check the details.");
                return Ok(new Response(result));
            }
            catch (Exception Ex)
            {
                return Ok(new Response(Ex.Message));
            }
        }

        [HttpPost("getDriverDocuments", Name = "GetDriverDocuments")]
        public IActionResult GetDriverDocuments([FromBody] dynamic user)
        {
            if (user is null || Common.ToInt(user.UserId) <= 0)
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                return Ok(Common.GetDriverDocuments(Common.ToInt(user.UserId), _appSettings));
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("approveDocument", Name = "ApproveDocument")]
        public IActionResult ApproveDocument([FromBody] dynamic user)
        {
            if (user is null || Common.ToInt(user.DriverDocId) <= 0)
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                string result = Common.ChangeDocumentStatus(Common.ToInt(user.DriverDocId), Status.Approved, _appSettings);
                return Ok(new Response(result));
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("rejectDocument", Name = "RejectDocument")]
        public IActionResult RejectDocument([FromBody] dynamic user)
        {
            if (user is null || Common.ToInt(user.DriverDocId) <= 0)
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                string result = Common.ChangeDocumentStatus(Common.ToInt(user.DriverDocId), Status.Rejected, _appSettings);
                return Ok(new Response(result));
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("approveFeedback", Name = "ApproveFeedback")]
        public IActionResult ApproveFeedback([FromBody] dynamic user)
        {
            if (user is null || Common.ToInt(user.FeedbackId) <= 0)
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                string result = Common.ChangeFeedbackStatus(Common.ToInt(user.FeedbackId), Status.Approved, _appSettings);
                return Ok(result);
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("rejectFeedback", Name = "RejectFeedback")]
        public IActionResult RejectFeedback([FromBody] dynamic user)
        {
            if (user is null || Common.ToInt(user.FeedbackId) <= 0)
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                string result = Common.ChangeFeedbackStatus(Common.ToInt(user.FeedbackId), Status.Rejected, _appSettings);
                return Ok(result);
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpGet("getUser/{id}", Name = "GetUsers")]
        public IActionResult GetUsers(int id)
        {
            try
            {
                if (id <= 0)
                {
                    return BadRequest("Invalid user request!!!");
                }
                Drivers result = new Drivers();
                UsersBL objUsersBL = new UsersBL(Common.GetConString(_appSettings));
                objUsersBL.Load(id);
                if (objUsersBL.Data.UserTypeId == (int)UserType.Driver)
                {
                    DriversBL objDriversBL = new DriversBL(Common.GetConString(_appSettings));
                    objDriversBL.Load(id);
                    result = objDriversBL.Data;
                }
                objUsersBL.Data.Password = string.Empty;
                result.UserDetails = objUsersBL.Data;
                return Ok(result);

            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }

        [HttpPost("pendingDriverList", Name = "PendingDriverList")]
        public AngularGridData PendingDriverList([FromBody]dynamic value)
        {
            return SearchUsers(value, @"Select 
U.UserId,U.EmailId,U.Mobile,U.MobileVerified,U.FirstName,U.LastName,U.IsActive,U.RegDate,U.ApprovalRemarks
,S.StatusDetails,C.CityName from Users U 
inner join Status S ON U.StatusId=S.StatusId 
left join Drivers D ON U.UserId=D.DriverId
left join City C ON C.CityID=D.CityID where U.UserTypeId=2 and U.StatusId<>2");
        }

        [HttpPost("driverList", Name = "DriverList")]
        public AngularGridData DriverList([FromBody]dynamic value)
        {
            return SearchUsers(value, @"Select 
U.UserId,U.EmailId,U.Mobile,U.MobileVerified,U.FirstName,U.LastName,U.IsActive,U.RegDate,U.ApprovalRemarks
,S.StatusDetails,C.CityName from Users U 
inner join Status S ON U.StatusId=S.StatusId 
left join Drivers D ON U.UserId=D.DriverId
left join City C ON C.CityID=D.CityID where U.UserTypeId=2");
        }

        [HttpPost("userList", Name = "UserList")]
        public AngularGridData UserList([FromBody]dynamic value)
        {
            return SearchUsers(value, @"Select 
U.UserId, U.EmailId, U.Mobile, U.MobileVerified, U.FirstName, U.LastName, U.IsActive, U.RegDate from Users U  where U.UserTypeId=1");
        }

        private AngularGridData SearchUsers(dynamic value, string baseQuery)
        {
            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = baseQuery;
            if (!string.IsNullOrEmpty(objAngularGrid.SearchText))
            {
                StringBuilder query = new StringBuilder();
                objAngularDataBinder.Query += " and (U.EmailId like '%'+@SearchText+'%' OR U.FirstName like '%'+@SearchText+'%' OR U.LastName like '%'+@SearchText+'%')";

                Hashtable ht = new Hashtable();
                ht["@SearchText"] = objAngularGrid.SearchText;
                objAngularDataBinder.Parameters = ht;
            }
            objAngularDataBinder.ValueField = "U.UserId";
            return objAngularDataBinder.GetData(_appSettings);
        }

        [HttpPost("getDriverRides", Name = "GetDriverRides")]
        public AngularGridData GetDriverRides([FromBody]dynamic value)
        {
            return GetRides(value, (int) UserType.Driver);
        }

        [HttpPost("getUserRides", Name = "GetUserRides")]
        public AngularGridData GetUserRides([FromBody]dynamic value)
        {
            return GetRides(value, (int)UserType.Rider);
        }

        private AngularGridData GetRides(dynamic value, int userTypeId)
        {
            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = Common.GetRideHistoryQuery();
            objAngularDataBinder.Query += " WHERE RR." + (userTypeId == 2 ? "ToUserId" : "FromUserId") + "=@UserId";
            Hashtable ht = new Hashtable();
            ht["@UserId"] = objAngularGrid.SearchText;
            objAngularDataBinder.Parameters = ht;
            objAngularDataBinder.ValueField = "RR.RideRequestId";
            return objAngularDataBinder.GetData(_appSettings);
        }

        [HttpPost("getDriverTxnHistory", Name = "GetDriverTxnHistory")]
        public AngularGridData GetDriverTxnHistory([FromBody]dynamic value)
        {
            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = @"SELECT * FROM GetDriverTransactions(@UserId) ";
            Hashtable ht = new Hashtable();
            ht["@UserId"] = objAngularGrid.SearchText;
            objAngularDataBinder.Parameters = ht;
            objAngularDataBinder.ValueField = "TxnDate";
            return objAngularDataBinder.GetData(_appSettings);
        }
    }
}