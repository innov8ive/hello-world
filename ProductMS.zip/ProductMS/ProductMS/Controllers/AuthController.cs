﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using ProductMS.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Authorization;
using System.Data;
using Newtonsoft.Json.Linq;

namespace ProductMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        IConfiguration _appSettings;
        public AuthController(IConfiguration configuration)
        {
            _appSettings = configuration;
        }
        [HttpPost("cms")]
        public IActionResult cms([FromBody] dynamic user)
        {
            return Ok(new Response(Common.ToString(Common.GetDBScalar(_appSettings, "Select CMSText from CMS where CMSType=@CMSType",
                "@CMSType", SqlDbType.VarChar, Common.ToString(user.CMSType)))));
        }
        [HttpPost("sendNot")]
        public IActionResult sendNot([FromBody] dynamic value)
        {
            JArray objJarray = value.Data;
            PushNotification pushNotification = new PushNotification();
            Dictionary<string, string> data = new Dictionary<string, string>();
            List<Dictionary<string, string>> datas = objJarray.ToObject<List<Dictionary<string, string>>>();
            foreach(var d in datas)
            {
                foreach(var k in d.Keys)
                {
                    data.Add(k, d[k]);
                }               
            }
            data["content_available"] = "true";
            List<string> tokens = new List<string>();
            tokens.Add(Common.ToString(value.DeviceRegId));
            var s = pushNotification.Send(tokens, data, Common.ToString(value.Body),Common.ToString(value.Title)).Result;
            return Ok(new Response("Success"));
        }
        [HttpPost("import")]
        public List<string> import([FromBody] dynamic user)
        {
            JArray objJarray = user.Data;
            List<Models.Import.Root> data = objJarray.ToObject<List<Models.Import.Root>>();
            Models.Import.DataImport dataImport = new Models.Import.DataImport();
            var result = dataImport.ImportData(data, Common.GetConString(_appSettings));
            return result;
        }
        [HttpPost("enc")]
        public string enc([FromBody] dynamic user)
        {
            return StringCipher.Encrypt(Common.ToString(user.Value), Common.ToString(user.Salt));
        }
        [HttpPost("dec")]
        public string dec([FromBody] dynamic user)
        {
            return StringCipher.Decrypt(Common.ToString(user.Value), Common.ToString(user.Salt));
        }
        [HttpGet("getVersion", Name = "GetVersion")]
        public IActionResult GetVersion()
        {
            string version = Common.ToString(Common.GetDBScalar(_appSettings, "Select top 1 CurrentVersion from Settings"));
            return Ok(new Response("version_" + version));
        }
        [HttpPost("login")]
        public IActionResult Login([FromBody] Login user)
        {
            if (user is null)
            {
                return BadRequest("Invalid user request!!!");
            }
            var loginUser = Common.IsValidUser(user.UserName, user.Password, user.UserType, _appSettings);
            if (loginUser != null)
            {
                if (loginUser.MobileVerified != "YES")
                {
                    return Ok(new Response("Mobile not verified."));
                }
                if (loginUser.IsActive != true)
                {
                    return Ok(new Response("Your account is deactivated, please contact ApnaCab administrator."));
                }
                var permClaims = new List<Claim>();
                permClaims.Add(new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()));
                permClaims.Add(new Claim("UserId", loginUser.UserId.ToString()));
                permClaims.Add(new Claim("Mobile", loginUser.Mobile.ToString()));
                permClaims.Add(new Claim("FirstName", loginUser.FirstName));
                permClaims.Add(new Claim("LastName", loginUser.LastName));
                permClaims.Add(new Claim("Lang", loginUser.Lang));
                permClaims.Add(new Claim("UserTypeId", loginUser.UserTypeId.ToString()));
                permClaims.Add(new Claim("VehicleTypeId", loginUser.VehicleTypeId.ToString()));
                permClaims.Add(new Claim("UserGUID", loginUser.UserGUID.ToString()));

               
                var secretKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_appSettings["AppSettings:Secret"]));
                var signinCredentials = new SigningCredentials(secretKey, SecurityAlgorithms.HmacSha256);
                var tokeOptions = new JwtSecurityToken(issuer: _appSettings["AppSettings:ValidIssuer"], audience: _appSettings["AppSettings:ValidAudience"], claims: permClaims, expires: DateTime.Now.AddMinutes(600), signingCredentials: signinCredentials);
                var tokenString = new JwtSecurityTokenHandler().WriteToken(tokeOptions);
                return Ok(new JWTTokenResponse
                {
                    Token = tokenString
                });
            }
            else
            {
                return Ok(new Response("Invalid UserId or password"));
            }
        }

        [HttpPost("changePassword", Name = "ChangePassword"), Authorize]
        public IActionResult ChangePassword([FromBody] ChangePassword value)
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            int userId = Common.ToInt(identity.FindFirst("UserId").Value);
            if (value is null || userId <= 0)
            {
                return Ok(new Response("Invalid user request!!!"));
            }
            try
            {
                value.UserID = userId;
                string result = Common.ChangePassword(value, _appSettings);
                return Ok(new Response(result));
            }
            catch (Exception Ex)
            {
                return Ok(new Response(Ex.Message));
            }

        }

        [HttpPost("changePasswordOTP", Name = "ChangePasswordOTP")]
        public IActionResult ChangePasswordOTP([FromBody] ChangePassword value)
        {
            if (value is null || value.OTP == "YES" || string.IsNullOrEmpty(value.Mobile) || string.IsNullOrEmpty(value.OTP))
            {
                return Ok(new Response("Invalid user request!!!"));
            }
            try
            {
                string result = Common.ChangePasswordOTP(value, _appSettings);
                return Ok(new Response(result));
            }
            catch (Exception Ex)
            {
                return Ok(new Response(Ex.Message));
            }

        }

        [HttpPost("forgotPassword", Name = "ForgotPassword")]
        public IActionResult ForgotPassword([FromBody] dynamic value)
        {
            if (value is null || string.IsNullOrEmpty(value.UserName))
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                string result = Common.ForgotPassword(value.UserName, _appSettings);
                return Ok(result);
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }

        }

        [HttpPost("sendOTP", Name = "SendOTP")]
        public IActionResult SendOTP([FromBody] dynamic value)
        {
            if (value is null || string.IsNullOrEmpty(Common.ToString(value.Mobile)))
            {
                return Ok(new Response("Invalid user request!!!"));
            }
            try
            {
                string result = Common.SendOTP(Common.ToString(value.Mobile), _appSettings);
                return Ok(new Response(result));
            }
            catch (Exception Ex)
            {
                return Ok(new Response(Ex.Message));
            }

        }

        [HttpPost("verifyOTP", Name = "VerifyOTP")]
        public IActionResult VerifyOTP([FromBody] dynamic value)
        {
            if (value is null || string.IsNullOrEmpty(value.Mobile) || string.IsNullOrEmpty(value.OTP))
            {
                return BadRequest("Invalid user request!!!");
            }
            try
            {
                string result = Common.VerifyOTP(value.Mobile, value.OTP, _appSettings);
                return Ok(result);
            }
            catch (Exception Ex)
            {
                return StatusCode(500, Ex.Message);
            }
        }
    }
}