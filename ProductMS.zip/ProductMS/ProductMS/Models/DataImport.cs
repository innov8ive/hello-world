﻿using BL;
using OM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductMS.Models.Import
{
    public class DataImport
    {
        public List<string> ImportData(List<Root> datas, string connectionString)
        {
            List<string> failed = new List<string>();
            DriversBL driversBL = new DriversBL(connectionString);
            foreach (var data in datas)
            {
                try
                {
                    driversBL.Load(0);
                    Drivers drivers = driversBL.Data;
                    Users users = new Users();
                    users.EmailId = data.email;
                    users.Mobile = data.phoneNo;
                    users.FirstName = data.name;
                    users.IsActive = true;
                    users.MobileVerified = "YES";
                    users.Password = Common.MD5Encryption("123456");
                    users.RegDate = DateTime.Now;
                    users.StatusId = (int)Status.Approved;
                    users.UserTypeId = (int)UserType.Driver;
                    drivers.UserDetails = users;
                    drivers.FullAddress = data.address;
                    if (data.vehicle != null)
                    {
                        drivers.VehicleTypeId = GetVehicleTypeId(data.vehicle.vehicleType);
                    }
                    if (data.documents != null)
                    {
                        drivers.DriverImportDocs = new List<DriverDocs>();
                        AddDocument(data.documents, drivers.DriverImportDocs);
                    }
                    driversBL.ImportUpdate();
                }
                catch
                {
                    failed.Add(data.name);
                }               
            }
            return failed;
        }
        private void AddDocument(Documents documents, List<DriverDocs> list)
        {
            list.Add(new DriverDocs()
            {
                DocTypeId = GetDocTypeId("aadhaarBack"),
                FileGUID = documents.aadhaarBack,
                StatusId = (int)Status.Approved,
                UploadedOn = DateTime.Now,
                DriverDocId = 0
            });
            list.Add(new DriverDocs()
            {
                DocTypeId = GetDocTypeId("aadhaarFront"),
                FileGUID = documents.aadhaarFront,
                StatusId = (int)Status.Approved,
                UploadedOn = DateTime.Now,
                DriverDocId = 0
            });
            list.Add(new DriverDocs()
            {
                DocTypeId = GetDocTypeId("drvingLicenseFront"),
                FileGUID = documents.drvingLicenseFront,
                StatusId = (int)Status.Approved,
                UploadedOn = DateTime.Now,
                DriverDocId = 0
            });
            list.Add(new DriverDocs()
            {
                DocTypeId = GetDocTypeId("drvingLicenseBack"),
                FileGUID = documents.drvingLicenseBack,
                StatusId = (int)Status.Approved,
                UploadedOn = DateTime.Now,
                DriverDocId = 0
            });
            list.Add(new DriverDocs()
            {
                DocTypeId = GetDocTypeId("fitness"),
                FileGUID = documents.fitness,
                StatusId = (int)Status.Approved,
                UploadedOn = DateTime.Now,
                DriverDocId = 0
            });
            list.Add(new DriverDocs()
            {
                DocTypeId = GetDocTypeId("insurance"),
                FileGUID = documents.insurance,
                StatusId = (int)Status.Approved,
                UploadedOn = DateTime.Now,
                DriverDocId = 0
            });
            list.Add(new DriverDocs()
            {
                DocTypeId = GetDocTypeId("panCard"),
                FileGUID = documents.panCard,
                StatusId = (int)Status.Approved,
                UploadedOn = DateTime.Now,
                DriverDocId = 0
            });
            list.Add(new DriverDocs()
            {
                DocTypeId = GetDocTypeId("profilePic"),
                FileGUID = documents.profilePic,
                StatusId = (int)Status.Approved,
                UploadedOn = DateTime.Now,
                DriverDocId = 0
            });
            list.Add(new DriverDocs()
            {
                DocTypeId = GetDocTypeId("puc"),
                FileGUID = documents.puc,
                StatusId = (int)Status.Approved,
                UploadedOn = DateTime.Now,
                DriverDocId = 0
            });
            list.Add(new DriverDocs()
            {
                DocTypeId = GetDocTypeId("pvCertificate"),
                FileGUID = documents.pvCertificate,
                StatusId = (int)Status.Approved,
                UploadedOn = DateTime.Now,
                DriverDocId = 0
            });
            list.Add(new DriverDocs()
            {
                DocTypeId = GetDocTypeId("rcFirst"),
                FileGUID = documents.rcFirst,
                StatusId = (int)Status.Approved,
                UploadedOn = DateTime.Now,
                DriverDocId = 0
            });
            list.Add(new DriverDocs()
            {
                DocTypeId = GetDocTypeId("rcSecond"),
                FileGUID = documents.rcSecond,
                StatusId = (int)Status.Approved,
                UploadedOn = DateTime.Now,
                DriverDocId = 0
            });
            list.Add(new DriverDocs()
            {
                DocTypeId = GetDocTypeId("rcThird"),
                FileGUID = documents.rcThird,
                StatusId = (int)Status.Approved,
                UploadedOn = DateTime.Now,
                DriverDocId = 0
            });
            list.Add(new DriverDocs()
            {
                DocTypeId = GetDocTypeId("rcFourth"),
                FileGUID = documents.rcFourth,
                StatusId = (int)Status.Approved,
                UploadedOn = DateTime.Now,
                DriverDocId = 0
            });
            list.Add(new DriverDocs()
            {
                DocTypeId = GetDocTypeId("roadTax"),
                FileGUID = documents.roadTax,
                StatusId = (int)Status.Approved,
                UploadedOn = DateTime.Now,
                DriverDocId = 0
            });
            list.Add(new DriverDocs()
            {
                DocTypeId = GetDocTypeId("vehicleBack"),
                FileGUID = documents.vehicleBack,
                StatusId = (int)Status.Approved,
                UploadedOn = DateTime.Now,
                DriverDocId = 0
            });
            list.Add(new DriverDocs()
            {
                DocTypeId = GetDocTypeId("vehicleFront"),
                FileGUID = documents.vehicleFront,
                StatusId = (int)Status.Approved,
                UploadedOn = DateTime.Now,
                DriverDocId = 0
            });
            list.Add(new DriverDocs()
            {
                DocTypeId = GetDocTypeId("permit"),
                FileGUID = documents.permit,
                StatusId = (int)Status.Approved,
                UploadedOn = DateTime.Now,
                DriverDocId = 0
            });
        }
        private int GetVehicleTypeId(string vehicleType)
        {
            switch (vehicleType.ToLower())
            {
                case "auto":
                    return 1;
                case "taxi":
                    return 2;
                case "hatchback":
                    return 6;
                case "sedan":
                    return 9;
                case "suv":
                    return 11;
            }
            return 2;
        }
        private int GetDocTypeId(string docType)
        {
            switch (docType.ToLower())
            {
                case "profilepic":
                    return 1;
                case "drvinglicensefront":
                    return 2;
                case "drvinglicenseback":
                    return 3;
                case "pvcertificate":
                    return 4;
                case "aadhaarfront":
                    return 5;
                case "aadhaarback":
                    return 6;
                case "pancard":
                    return 7;
                case "vehiclefront":
                    return 8;
                case "vehicleback":
                    return 9;
                case "rcfirst":
                    return 10;
                case "rcsecond":
                    return 11;
                case "rcthird":
                    return 12;
                case "rcfourth":
                    return 13;
                case "insurance":
                    return 14;
                case "roadtax":
                    return 15;
                case "fitness":
                    return 16;
                case "permit":
                    return 17;
                case "puc":
                    return 18;
            }
            return 2;
        }
    }
    
    public class Banking
    {
        public string bankName { get; set; }
        public string accountHolderName { get; set; }
        public string bankAccountNo { get; set; }
    }

    public class Documents
    {
        public string aadhaarFront { get; set; }
        public string drvingLicenseFront { get; set; }
        public string drvingLicenseBack { get; set; }
        public string vehicleLeft { get; set; }
        public string profilePic { get; set; }
        public string rcThird { get; set; }
        public string rcFourth { get; set; }
        public string aadhaarBack { get; set; }
        public string panCard { get; set; }
        public string rcSecond { get; set; }
        public string puc { get; set; }
        public string rcFirst { get; set; }
        public string vehicleBack { get; set; }
        public string vehicleFront { get; set; }
        public string fitness { get; set; }
        public string pvCertificate { get; set; }
        public string insurance { get; set; }
        public string roadTax { get; set; }
        public string permit { get; set; }
    }

    public class Root
    {
        public Vehicle vehicle { get; set; }
        public double homeLongitude { get; set; }
        public bool approved { get; set; }
        public string homeGeohash { get; set; }
        public int status { get; set; }
        public Banking banking { get; set; }
        public Documents documents { get; set; }
        public string name { get; set; }
        public double homeLatitude { get; set; }
        public string driverId { get; set; }
        public string currentRideId { get; set; }
        public string address { get; set; }
        public string email { get; set; }
        public int wallet { get; set; }
        public string phoneNo { get; set; }
        public string id { get; set; }
    }

    public class Vehicle
    {
        public string vehicleNo { get; set; }
        public string vehicleModel { get; set; }
        public string vehicleType { get; set; }
    }


}
