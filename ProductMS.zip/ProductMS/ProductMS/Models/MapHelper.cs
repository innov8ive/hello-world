﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace ProductMS.Models
{
    public class MapHelper
    {
        private string _apiKey;
        private string _apiUrl;
        private string _connectionString;
        private const decimal DEFAULTKM = 1.5M;
        private const decimal COMMISSION = 10;
        public MapHelper(string apiKey, string apiUrl, string connectionString)
        {
            _apiKey = apiKey;
            _apiUrl = apiUrl;
            _connectionString = connectionString;
        }
        public DistanceMatrix EstimateDistanceAndFare(string source, string destination, string fareType, int vehicleTypeId)
        {
            DistanceMatrix result = new DistanceMatrix();
            string api = string.Format("directions/json?origin=place_id:{0}&destination=place_id:{1}&mode=driving&departure_time=now&key={2}", source, destination, _apiKey);
            string resultString = HttpCall(api, "GET", string.Empty);
            DistanceResponse distanceResponse = Newtonsoft.Json.JsonConvert.DeserializeObject<DistanceResponse>(resultString);
            if (distanceResponse != null && distanceResponse.routes != null && distanceResponse.routes.Count > 0)
            {
                result.StartAddress = distanceResponse.routes[0].legs[0].start_address;
                result.EndAddress = distanceResponse.routes[0].legs[0].end_address;
                result.DistanceMeter = distanceResponse.routes[0].legs[0].distance.value;
                result.DurationSeconds = distanceResponse.routes[0].legs[0].duration.value;
                result.DurationInTrafficSeconds = distanceResponse.routes[0].legs[0].duration_in_traffic.value;
                result.RideTerms = Common.ToString(Common.GetDBScalar(_connectionString, "Select CMSText from CMS where CMSType=@CMSType",
                "@CMSType", SqlDbType.VarChar, "RideTerms"));
                result.Fares = new List<FareMatrix>();

                DataTable dtFare = Common.GetDBResultParameterized(_connectionString, @"select V.Details, V.VehicleType,F.* from Fares F inner join VehicleTypes V 
                ON F.VehicleTypeId=V.VehicleTypeId 
                WHERE EffectiveTill is NULL OR EffectiveTill > getdate() AND FareType=@FareType
                and (@VehicleTypeId =0 OR F.VehicleTypeId=@VehicleTypeId)",
                "@FareType", SqlDbType.VarChar, fareType,
                "@VehicleTypeId", SqlDbType.VarChar, vehicleTypeId);
                foreach (DataRow dr in dtFare.Rows)
                {
                    FareMatrix fareMatrix = new FareMatrix();
                    fareMatrix.VehicleType = Common.ToString(dr["VehicleType"]);
                    fareMatrix.VehicleTypeId = Common.ToInt(dr["VehicleTypeId"]);
                    fareMatrix.Details = Common.ToString(dr["Details"]);
                    fareMatrix.RatePerKM = Common.ToDecimal(dr["PerKMFare"]);
                    fareMatrix.WaitingPerMinute = Common.ToDecimal(dr["WaitingPerMinuteFare"]);
                    fareMatrix.BaseFare = Common.ToDecimal(dr["BaseFare"]);

                    decimal BaseFare = fareMatrix.BaseFare;
                    decimal PerKMFare = fareMatrix.RatePerKM;
                    decimal WaitingPerMinuteFare = fareMatrix.WaitingPerMinute;

                    decimal estimatedDistance = result.DistanceMeter / 1000;
                    estimatedDistance = estimatedDistance <= DEFAULTKM ? 0 : (estimatedDistance - DEFAULTKM);
                    decimal estimatedWaiting = (result.DurationInTrafficSeconds - result.DurationSeconds) / 60;
                    decimal estimatedTotalFare = BaseFare + (estimatedDistance - DEFAULTKM) * PerKMFare + (estimatedWaiting * WaitingPerMinuteFare);

                    //Commission
                    estimatedTotalFare = estimatedTotalFare + (estimatedTotalFare * COMMISSION) / 100;

                    fareMatrix.EstimatedFare = Math.Ceiling(estimatedTotalFare);
                    result.Fares.Add(fareMatrix);
                }
            }
            return result;
        }
        public DistanceMatrix CalculateDistanceAndFare(int rideId, string destination)
        {
            DistanceMatrix result = new DistanceMatrix();
            DataTable dtRide = Common.GetDBResultParameterized(_connectionString, @"select StartLat,StartLong,R.PickTime,R.VehicleTypeId from RideRequests RR INNER JOIN Rides R ON RR.RideRequestId=R.RideRequestId where R.RideId=@RideId",
                "@RideId", SqlDbType.Int, rideId);
            if (dtRide != null && dtRide.Rows.Count > 0)
            {
                string source = Common.ToString(dtRide.Rows[0]["StartLat"]) + "," + Common.ToString(dtRide.Rows[0]["StartLong"]);
                DateTime pickupTime = Common.ToDate(dtRide.Rows[0]["PickTime"]);
                int vehicleTypeId = Common.ToInt(dtRide.Rows[0]["VehicleTypeId"]);

                StringBuilder waypointsStringBuilder = new StringBuilder();
                waypointsStringBuilder.Append("&waypoints=via:" + SnapToRoad(rideId, destination));

                //DataTable dtWaypoints = Common.GetDBResultParameterized(_connectionString, "select * from RideLocations where RideId=@RideId",
                //"@RideId", SqlDbType.Int, rideId);
                //if (dtWaypoints != null && dtWaypoints.Rows.Count > 0)
                //{
                //    waypointsStringBuilder.Append("&waypoints=via:");
                //    foreach (DataRow drWayPoint in dtWaypoints.Rows)
                //    {
                //        waypointsStringBuilder.Append(Common.ToString(drWayPoint["Lat"])).Append(",").Append(Common.ToString(drWayPoint["Long"])).Append("|");
                //    }
                //    waypointsStringBuilder.Remove(waypointsStringBuilder.Length-1, 1);
                //}

                string api = string.Format("distancematrix/json?origins={0}&destinations={1}{2}&mode=driving&departure_time=now&key={3}", source, destination, waypointsStringBuilder.ToString(), _apiKey);
                string resultString = HttpCall(api, "GET", string.Empty);
                DistanceMatrixResponse distanceResponse = Newtonsoft.Json.JsonConvert.DeserializeObject<DistanceMatrixResponse>(resultString);
                if (distanceResponse != null && distanceResponse.rows != null && distanceResponse.rows.Count > 0
                    && distanceResponse.rows[0].elements != null && distanceResponse.rows[0].elements.Count > 0)
                {

                    result.DistanceMeter = distanceResponse.rows[0].elements[0].distance.value;
                    result.DurationSeconds = distanceResponse.rows[0].elements[0].duration.value;

                    result.Fares = new List<FareMatrix>();

                    DataTable dtFare = Common.GetDBResultParameterized(_connectionString, @"select V.VehicleType,F.* from Fares F inner join VehicleTypes V ON F.VehicleTypeId=V.VehicleTypeId WHERE EffectiveTill is NULL OR EffectiveTill > getdate() AND FareType='Local'
and F.VehicleTypeId=@VehicleTypeId", "@VehicleTypeId", SqlDbType.Int, vehicleTypeId);
                    foreach (DataRow dr in dtFare.Rows)
                    {
                        FareMatrix fareMatrix = new FareMatrix();
                        fareMatrix.VehicleType = Common.ToString(dr["VehicleType"]);
                        fareMatrix.VehicleTypeId = Common.ToInt(dr["VehicleTypeId"]);

                        decimal BaseFare = Common.ToDecimal(dr["BaseFare"]);
                        decimal PerKMFare = Common.ToDecimal(dr["PerKMFare"]);
                        decimal WaitingPerMinuteFare = Common.ToDecimal(dr["WaitingPerMinuteFare"]);
                        decimal actualPickupDuration = Common.ToDecimal((DateTime.Now - pickupTime).TotalSeconds);

                        decimal estimatedDistance = result.DistanceMeter / 1000;
                        estimatedDistance = estimatedDistance <= DEFAULTKM ? 0 : (estimatedDistance - DEFAULTKM);
                        decimal estimatedWaiting = (actualPickupDuration - result.DurationSeconds) / 60;
                        decimal estimatedTotalFare = BaseFare + (estimatedDistance) * PerKMFare + (estimatedWaiting * WaitingPerMinuteFare);

                        //Commission
                        decimal Commission = (estimatedTotalFare * COMMISSION) / 100;
                        estimatedTotalFare = estimatedTotalFare + Commission;

                        fareMatrix.EstimatedFare = Math.Ceiling(estimatedTotalFare);
                        fareMatrix.Commission = Commission;
                        result.Fares.Add(fareMatrix);
                    }
                }
            }
            return result;
        }
        public DistanceMatrix CalculateDistanceAndFare2(int rideId, string destination)
        {
            DistanceMatrix result = new DistanceMatrix();
            DataTable dtRide = Common.GetDBResultParameterized(_connectionString, @"select StartLat,StartLong,R.PickTime,R.VehicleTypeId from RideRequests RR INNER JOIN Rides R ON RR.RideRequestId=R.RideRequestId where R.RideId=@RideId",
                "@RideId", SqlDbType.Int, rideId);
            if (dtRide != null && dtRide.Rows.Count > 0)
            {
                string source = Common.ToString(dtRide.Rows[0]["StartLat"]) + "," + Common.ToString(dtRide.Rows[0]["StartLong"]);
                DateTime pickupTime = Common.ToDate(dtRide.Rows[0]["PickTime"]);
                int vehicleTypeId = Common.ToInt(dtRide.Rows[0]["VehicleTypeId"]);

                StringBuilder waypointsStringBuilder = new StringBuilder();
                waypointsStringBuilder.Append("&waypoints=via:" + SnapToRoad2(rideId, destination));

                string api = string.Format("directions/json?origin={0}&destination={1}{2}&mode=driving&departure_time=now&key={3}", source, destination, waypointsStringBuilder.ToString(), _apiKey);
                string resultString = HttpCall(api, "GET", string.Empty);
                DistanceResponse distanceResponse = Newtonsoft.Json.JsonConvert.DeserializeObject<DistanceResponse>(resultString);
                if (distanceResponse != null && distanceResponse.routes != null && distanceResponse.routes.Count > 0
                    && distanceResponse.routes[0].legs != null && distanceResponse.routes[0].legs.Count > 0)
                {
                    foreach(var l in distanceResponse.routes[0].legs)
                    {
                        result.DistanceMeter += l.distance.value;
                        result.DurationSeconds += l.duration.value;
                    }

                    result.Fares = new List<FareMatrix>();

                    DataTable dtFare = Common.GetDBResultParameterized(_connectionString, @"select V.VehicleType,F.* from Fares F inner join VehicleTypes V ON F.VehicleTypeId=V.VehicleTypeId WHERE EffectiveTill is NULL OR EffectiveTill > getdate() AND FareType='Local'
and F.VehicleTypeId=@VehicleTypeId", "@VehicleTypeId", SqlDbType.Int, vehicleTypeId);
                    foreach (DataRow dr in dtFare.Rows)
                    {
                        FareMatrix fareMatrix = new FareMatrix();
                        fareMatrix.VehicleType = Common.ToString(dr["VehicleType"]);
                        fareMatrix.VehicleTypeId = Common.ToInt(dr["VehicleTypeId"]);

                        decimal BaseFare = Common.ToDecimal(dr["BaseFare"]);
                        decimal PerKMFare = Common.ToDecimal(dr["PerKMFare"]);
                        decimal WaitingPerMinuteFare = Common.ToDecimal(dr["WaitingPerMinuteFare"]);
                        decimal actualPickupDuration = Common.ToDecimal((DateTime.Now - pickupTime).TotalSeconds);

                        decimal estimatedDistance = result.DistanceMeter / 1000;
                        estimatedDistance = estimatedDistance <= DEFAULTKM ? 0 : (estimatedDistance - DEFAULTKM);
                        decimal estimatedWaiting = (actualPickupDuration - result.DurationSeconds) / 60;
                        decimal estimatedTotalFare = BaseFare + (estimatedDistance) * PerKMFare + (estimatedWaiting * WaitingPerMinuteFare);

                        //Commission
                        decimal Commission = (estimatedTotalFare * COMMISSION) / 100;
                        estimatedTotalFare = estimatedTotalFare + Commission;

                        fareMatrix.EstimatedFare = Math.Ceiling(estimatedTotalFare);
                        fareMatrix.Commission = Commission;
                        result.Fares.Add(fareMatrix);
                    }
                }
            }
            return result;
        }
        public string SnapToRoad(int rideId, string destination)
        {
            StringBuilder encodedPoints = new StringBuilder();

            StringBuilder waypointsStringBuilder = new StringBuilder();
            DistanceMatrix result = new DistanceMatrix();
            DataTable dtRide = Common.GetDBResultParameterized(_connectionString, @"select StartLat,StartLong,R.PickTime,D.VehicleTypeId from RideRequests RR INNER JOIN Rides R ON RR.RideRequestId=R.RideRequestId 
inner join Drivers D ON RR.ToUserId = D.UserId where R.RideId=@RideId",
                "@RideId", SqlDbType.Int, rideId);
            if (dtRide != null && dtRide.Rows.Count > 0)
            {
                waypointsStringBuilder.Append(Common.ToString(dtRide.Rows[0]["StartLat"])).Append(",").Append(Common.ToString(dtRide.Rows[0]["StartLong"])).Append("|");

                DataTable dtWaypoints = Common.GetDBResultParameterized(_connectionString, "select * from RideLocations where RideId=@RideId",
                "@RideId", SqlDbType.Int, rideId);
                if (dtWaypoints != null && dtWaypoints.Rows.Count > 0)
                {
                    List<GeoLocation> orginalLocations = new List<GeoLocation>();
                    foreach (DataRow drWayPoint in dtWaypoints.Rows)
                    {
                        orginalLocations.Add(new GeoLocation() { Latitude = Common.ToDouble(drWayPoint["Lat"]), Longitude = Common.ToDouble(drWayPoint["Long"]) });
                    }
                    if (orginalLocations.Count > 100)
                    {
                        orginalLocations = CompactList(orginalLocations);
                    }
                    foreach(var location in orginalLocations)
                    {
                        waypointsStringBuilder.Append(Common.ToString(location.Latitude)).Append(",").Append(Common.ToString(location.Longitude)).Append("|");
                    }
                }
                waypointsStringBuilder.Append(destination).Append("|");
                waypointsStringBuilder.Remove(waypointsStringBuilder.Length - 1, 1);

                string api = string.Format("https://roads.googleapis.com/v1/snapToRoads?path={0}&interpolate=false&key={1}", waypointsStringBuilder.ToString(), _apiKey);
                string resultString = HttpCall(api, "GET", string.Empty);
                RoadAPIResult roadAPI = Newtonsoft.Json.JsonConvert.DeserializeObject<RoadAPIResult>(resultString);
                if (roadAPI != null && roadAPI.snappedPoints != null && roadAPI.snappedPoints.Count > 0)
                {
                    StringBuilder sss = new StringBuilder();
                    int counter = 1;
                    foreach(var a in roadAPI.snappedPoints)
                    {
                        sss.Append("addMarker(" + a.location.latitude.ToString() + "," + a.location.longitude.ToString() + "," + counter.ToString() + ");").AppendLine();
                        counter++;
                    }
                    string s = sss.ToString();

                    encodedPoints.Append(Encode(roadAPI.snappedPoints));
                }
            }
            return encodedPoints.ToString();
        }
        public string SnapToRoad2(int rideId, string destination)
        {
            StringBuilder waypointsStringBuilder = new StringBuilder();
            DistanceMatrix result = new DistanceMatrix();
            DataTable dtRide = Common.GetDBResultParameterized(_connectionString, @"select StartLat,StartLong,R.PickTime,D.VehicleTypeId from RideRequests RR INNER JOIN Rides R ON RR.RideRequestId=R.RideRequestId 
inner join Drivers D ON RR.ToUserId = D.UserId where R.RideId=@RideId",
                "@RideId", SqlDbType.Int, rideId);
            if (dtRide != null && dtRide.Rows.Count > 0)
            {
                //waypointsStringBuilder.Append(Common.ToString(dtRide.Rows[0]["StartLat"])).Append(",").Append(Common.ToString(dtRide.Rows[0]["StartLong"])).Append("|");

                DataTable dtWaypoints = Common.GetDBResultParameterized(_connectionString, "select * from RideLocations where RideId=@RideId",
                "@RideId", SqlDbType.Int, rideId);
                if (dtWaypoints != null && dtWaypoints.Rows.Count > 0)
                {
                    List<GeoLocation> orginalLocations = new List<GeoLocation>();
                    foreach (DataRow drWayPoint in dtWaypoints.Rows)
                    {
                        orginalLocations.Add(new GeoLocation() { Latitude = Common.ToDouble(drWayPoint["Lat"]), Longitude = Common.ToDouble(drWayPoint["Long"]) });
                    }
                    if (orginalLocations.Count > 25)
                    {
                        orginalLocations = CompactList(orginalLocations, 25);
                    }
                    foreach (var location in orginalLocations)
                    {
                        waypointsStringBuilder.Append("enc:").Append(Encode(location)).Append(":|");
                    }
                }
                //waypointsStringBuilder.Append(destination).Append("|");
                waypointsStringBuilder.Remove(waypointsStringBuilder.Length - 1, 1);
            }
            return waypointsStringBuilder.ToString();
        }
        public static string Encode(IEnumerable<SnapPoint> points)
        {
            var str = new StringBuilder();

            var encodeDiff = (Action<int>)(diff =>
            {
                int shifted = diff << 1;
                if (diff < 0)
                    shifted = ~shifted;
                int rem = shifted;
                while (rem >= 0x20)
                {
                    str.Append((char)((0x20 | (rem & 0x1f)) + 63));
                    rem >>= 5;
                }
                str.Append((char)(rem + 63));
            });

            int lastLat = 0;
            int lastLng = 0;
            foreach (var point in points)
            {
                int lat = (int)Math.Round(point.location.latitude * 1E5);
                int lng = (int)Math.Round(point.location.longitude * 1E5);
                encodeDiff(lat - lastLat);
                encodeDiff(lng - lastLng);
                lastLat = lat;
                lastLng = lng;
            }
            return str.ToString();
        }
        public static string Encode(GeoLocation point)
        {
            var str = new StringBuilder();

            var encodeDiff = (Action<int>)(diff =>
            {
                int shifted = diff << 1;
                if (diff < 0)
                    shifted = ~shifted;
                int rem = shifted;
                while (rem >= 0x20)
                {
                    str.Append((char)((0x20 | (rem & 0x1f)) + 63));
                    rem >>= 5;
                }
                str.Append((char)(rem + 63));
            });

            int lastLat = 0;
            int lastLng = 0;

            int lat = (int)Math.Round(point.Latitude * 1E5);
            int lng = (int)Math.Round(point.Longitude * 1E5);
            encodeDiff(lat - lastLat);
            encodeDiff(lng - lastLng);
            lastLat = lat;
            lastLng = lng;

            return str.ToString();
        }

        private string HttpCall(string api, string method, string request)
        {
            System.Net.ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            HttpClient httpClient = new HttpClient();
            HttpResponseMessage response;

            var fullUrl = api.Contains("http") ? api : _apiUrl + api;
            var content = new StringContent(request, Encoding.UTF8, "application/json");
            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            switch (method)
            {
                case "GET":
                    {
                        response = httpClient.GetAsync(fullUrl).Result;
                        break;
                    }

                case "PUT":
                    {
                        response = httpClient.PutAsync(fullUrl, content).Result;
                        break;
                    }

                case "POST":
                    {
                        response = httpClient.PostAsync(fullUrl, content).Result;
                        break;
                    }

                case "Delete":
                    {
                        response = httpClient.DeleteAsync(fullUrl).Result;
                        break;
                    }

                default:
                    {
                        throw new Exception("Unsupported HTTP Request Method: " + method);
                    }
            }

            if (!response.IsSuccessStatusCode)
            {
                var responseContentString = response.Content.ReadAsStringAsync().Result;
                return response.Content.ReadAsStringAsync().Result;
            }
            else
                return response.Content.ReadAsStringAsync().Result;
        }

        private List<T> CompactList<T>(List<T> originalList, int maxSize = 100)
        {
            List<T> resultList = new List<T>();
            int divider = originalList.Count / maxSize + (originalList.Count % maxSize > 0 ? 1 : 0);
            int remainingSpace = maxSize - (originalList.Count / divider);
            List<List<T>> tempResult = SplitList(originalList, divider);
            remainingSpace = tempResult.Count - remainingSpace;
            for (int counter = 0; counter < tempResult.Count; counter++)
            {
                if (counter <= remainingSpace)
                {
                    resultList.Add(tempResult[counter][0]);
                }
                else
                {
                    resultList.Add(tempResult[counter][0]);
                    if (tempResult[counter].Count > 1)
                        resultList.Add(tempResult[counter][1]);
                }
            }

            return resultList;
        }

        private List<List<T>> SplitList<T>(IList<T> source, int divider)
        {
            return source
                .Select((x, i) => new { Index = i, Value = x })
                .GroupBy(x => x.Index / divider)
                .Select(x => x.Select(v => v.Value).ToList())
                .ToList();
        }
    }

    public class DistanceMatrix
    {
        public string StartAddress { get; set; }
        public string EndAddress { get; set; }
        public decimal DistanceMeter { get; set; }
        public decimal DurationSeconds { get; set; }
        public decimal DurationInTrafficSeconds { get; set; }
        public string RideTerms { get; set; }
        public List<FareMatrix> Fares { get; set; }
    }
    public class FareMatrix
    {
        public int VehicleTypeId { get; set; }
        public string Details { get; set; }
        public decimal BaseFare { get; set; }
        public decimal RatePerKM { get; set; }
        public decimal WaitingPerMinute { get; set; }
        public string VehicleType { get; set; }
        public decimal EstimatedFare { get; set; }
        public decimal Commission { get; set; }
    }

    public class TextValue
    {
        public string text { get; set; }
        public int value { get; set; }
    }

    public class Leg
    {
        public TextValue distance { get; set; }
        public TextValue duration { get; set; }
        public TextValue duration_in_traffic { get; set; }
        public string end_address { get; set; }
        public string start_address { get; set; }
    }

    public class DistanceResponse
    {
        public List<Route> routes { get; set; }
        public string status { get; set; }
    }

    public class Route
    {
        public List<Leg> legs { get; set; }
    }
    public class GeoLocation
    {
        public double Latitude { get; set; }
        public double Longitude { get; set; }
    }

    public class RoadLocation
    {
        public double latitude { get; set; }
        public double longitude { get; set; }
    }
    public class SnapPoint
    {
        public RoadLocation location { get; set; }
        public string placeId { get; set; }
    }
    public class RoadAPIResult
    {
        public List<SnapPoint> snappedPoints { get; set; }
    }

    public class Element
    {
        public TextValue distance { get; set; }
        public TextValue duration { get; set; }
        public TextValue duration_in_traffic { get; set; }
        public string status { get; set; }
    }

    public class DistanceMatrixResponse
    {
        public List<string> destination_addresses { get; set; }
        public List<string> origin_addresses { get; set; }
        public List<Row> rows { get; set; }
        public string status { get; set; }
    }

    public class Row
    {
        public List<Element> elements { get; set; }
    }
}
