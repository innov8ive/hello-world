using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using OM;

namespace DL
{
    public class CommissionPaymentDL
    {

        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public CommissionPaymentDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public CommissionPayment Load(int CommissionPaymentId)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            CommissionPayment objCommissionPayment = new CommissionPayment();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get CommissionPayment
                var resultCommissionPayment = dc.ExecuteQuery<CommissionPayment>("exec Get_CommissionPayment {0}", CommissionPaymentId).ToList();
                if (resultCommissionPayment.Count > 0)
                {
                    objCommissionPayment = resultCommissionPayment[0];
                }
                dc.Dispose();
                return objCommissionPayment;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllCommissionPayment()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_CommissionPayment", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(CommissionPayment objCommissionPayment)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update CommissionPayment
                UpdateCommissionPayment(objCommissionPayment, trn);
                if (objCommissionPayment.CommissionPaymentId > 0)
                {

                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int CommissionPaymentId)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete CommissionPayment
                DeleteCommissionPayment(CommissionPaymentId, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateCommissionPayment(CommissionPayment objCommissionPayment, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_CommissionPayment", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@Amount", SqlDbType.Decimal).Value = objCommissionPayment.Amount;
                cmd.Parameters.Add("@CommissionPaymentId", SqlDbType.Int).Value = objCommissionPayment.CommissionPaymentId;
                cmd.Parameters["@CommissionPaymentId"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@PaymentDate", SqlDbType.DateTime).Value = objCommissionPayment.PaymentDate;
                cmd.Parameters.Add("@PlatformBillID", SqlDbType.VarChar, 50).Value = objCommissionPayment.PlatformBillID;
                cmd.Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = objCommissionPayment.Remarks;
                cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = objCommissionPayment.UserId;

                cmd.ExecuteNonQuery();

                //after updating the CommissionPayment, update CommissionPaymentId
                objCommissionPayment.CommissionPaymentId = Convert.ToInt32(cmd.Parameters["@CommissionPaymentId"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteCommissionPayment(int CommissionPaymentId, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from CommissionPayment where CommissionPaymentId=@CommissionPaymentId", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@CommissionPaymentId", SqlDbType.Int).Value = CommissionPaymentId;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        #endregion
    }
}
