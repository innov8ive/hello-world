using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using OM;

namespace DL
{
    public class RidesDL
    {

        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public RidesDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public Rides Load(int RideId)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            Rides objRides = new Rides();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get Rides
                var resultRides = dc.ExecuteQuery<Rides>("exec Get_Rides {0}", RideId).ToList();
                if (resultRides.Count > 0)
                {
                    objRides = resultRides[0];
                }
                //Get RideLocations
                var resultRideLocations = dc.ExecuteQuery<RideLocations>("exec Get_RideLocations {0}", RideId).ToList();
                objRides.RideLocationsList = resultRideLocations;
                objRides.Types = new System.Collections.Hashtable();
                objRides.Types["RideLocationsList"] = new RideLocations();
                dc.Dispose();
                return objRides;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllRides()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_Rides", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(Rides objRides)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update Rides
                UpdateRides(objRides, trn);
                if (objRides.RideId > 0)
                {
                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int RideId)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete RideLocations
                DeleteRideLocations(RideId, trn);
                //Delete Rides
                DeleteRides(RideId, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool InsertIntoRideLocations(RideLocations objRideLocations)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete RideLocations
                InsertIntoRideLocations(objRideLocations, trn);
                
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateRides(Rides objRides, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_Rides", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@ActualFare", SqlDbType.Decimal).Value = objRides.ActualFare;
                cmd.Parameters.Add("@EstimatedFare", SqlDbType.Decimal).Value = objRides.EstimatedFare;
                cmd.Parameters.Add("@EstimatedDistanceKM", SqlDbType.Decimal).Value = objRides.EstimatedDistanceKM;
                cmd.Parameters.Add("@ActualDistanceKM", SqlDbType.Decimal).Value = objRides.ActualDistanceKM;                
                cmd.Parameters.Add("@EndTime", SqlDbType.DateTime).Value = objRides.EndTime;
                cmd.Parameters.Add("@PaidFare", SqlDbType.Decimal).Value = objRides.PaidFare;
                cmd.Parameters.Add("@Commission", SqlDbType.Decimal).Value = objRides.Commission;
                cmd.Parameters.Add("@PaidMode", SqlDbType.VarChar, 50).Value = objRides.PaidMode;
                cmd.Parameters.Add("@PickTime", SqlDbType.DateTime).Value = objRides.PickTime;
                cmd.Parameters.Add("@RideId", SqlDbType.Int).Value = objRides.RideId;
                cmd.Parameters["@RideId"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@RideRequestId", SqlDbType.Int).Value = objRides.RideRequestId;
                cmd.Parameters.Add("@StatusId", SqlDbType.Int).Value = objRides.StatusId;
                cmd.Parameters.Add("@StatusUpdatedBy", SqlDbType.VarChar, 20).Value = objRides.StatusUpdatedBy;
                cmd.Parameters.Add("@StatusUpdatedById", SqlDbType.Int).Value = objRides.StatusUpdatedById;
                cmd.Parameters.Add("@StatusUpdatedOn", SqlDbType.DateTime).Value = objRides.StatusUpdatedOn;
                cmd.Parameters.Add("@EndLat", SqlDbType.Decimal).Value = objRides.EndLat;
                cmd.Parameters.Add("@EndLong", SqlDbType.Decimal).Value = objRides.EndLong;
                cmd.Parameters.Add("@EndPlaceId", SqlDbType.NVarChar, 250).Value = objRides.EndPlaceId;
                cmd.Parameters.Add("@EndPlaceText", SqlDbType.NVarChar, 2500).Value = objRides.EndPlaceText;
                cmd.Parameters.Add("@VehicleTypeId", SqlDbType.Int).Value = objRides.VehicleTypeId;

                cmd.ExecuteNonQuery();

                //after updating the Rides, update RideId
                objRides.RideId = Convert.ToInt32(cmd.Parameters["@RideId"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteRides(int RideId, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from Rides where RideId=@RideId", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@RideId", SqlDbType.Int).Value = RideId;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        public bool DeleteRideLocations(int RideId, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from RideLocations where RideId=@RideId", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@RideId", SqlDbType.Int).Value = RideId;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        private bool InsertIntoRideLocations(RideLocations objRideLocations, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Into_RideLocations", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Transaction = trn;


                cmd.Parameters.Add("@CaptureDate", SqlDbType.DateTime).Value = objRideLocations.CaptureDate;
                cmd.Parameters.Add("@Lat", SqlDbType.Decimal).Value = objRideLocations.Lat;
                cmd.Parameters.Add("@Long", SqlDbType.Decimal).Value = objRideLocations.Long;
                cmd.Parameters.Add("@RideId", SqlDbType.Int).Value = objRideLocations.RideId;
                cmd.Parameters.Add("@RideLocationId", SqlDbType.Int).Value = objRideLocations.RideLocationId;

                cmd.ExecuteNonQuery();

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        #endregion
    }
}
