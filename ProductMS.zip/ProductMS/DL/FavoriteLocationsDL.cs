using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using OM;

namespace DL
{
    public class FavoriteLocationsDL
    {

        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public FavoriteLocationsDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public FavoriteLocations Load(int LocationId)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            FavoriteLocations objFavoriteLocations = new FavoriteLocations();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get FavoriteLocations
                var resultFavoriteLocations = dc.ExecuteQuery<FavoriteLocations>("exec Get_FavoriteLocations {0}", LocationId).ToList();
                if (resultFavoriteLocations.Count > 0)
                {
                    objFavoriteLocations = resultFavoriteLocations[0];
                }
                dc.Dispose();
                return objFavoriteLocations;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }

        public List<FavoriteLocations> LoadForUser(int UserId)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            List<FavoriteLocations> objFavoriteLocations = new List<FavoriteLocations>();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get FavoriteLocations
                var resultFavoriteLocations = dc.ExecuteQuery<FavoriteLocations>("Select * from FavoriteLocations where UserId = {0}", UserId).ToList();
                if (resultFavoriteLocations.Count > 0)
                {
                    objFavoriteLocations = resultFavoriteLocations;
                }
                dc.Dispose();
                return objFavoriteLocations;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }

        public DataTable LoadAllFavoriteLocations()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_FavoriteLocations", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool SetFavoriteLocations(int userId, int locationID, bool selected)
        {
            try
            {
                SqlConnection con = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand("SetFavoriteLocations", con);
                cmd.CommandType = CommandType.StoredProcedure;


                cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = userId;
                cmd.Parameters.Add("@LocationId", SqlDbType.Int).Value = locationID;
                cmd.Parameters.Add("@Selected", SqlDbType.Int).Value = selected;

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                return true;
            }
            catch
            {
                return false;
            }           
        }
        public bool Update(FavoriteLocations objFavoriteLocations)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update FavoriteLocations
                UpdateFavoriteLocations(objFavoriteLocations, trn);
                if (objFavoriteLocations.LocationId > 0)
                {

                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int LocationId, int UserId)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete FavoriteLocations
                DeleteFavoriteLocations(LocationId, UserId, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateFavoriteLocations(FavoriteLocations objFavoriteLocations, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_FavoriteLocations", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@GMapName", SqlDbType.VarChar, 5000).Value = objFavoriteLocations.GMapName;
                cmd.Parameters.Add("@Lat", SqlDbType.VarChar, 250).Value = objFavoriteLocations.Lat;
                cmd.Parameters.Add("@LocationId", SqlDbType.Int).Value = objFavoriteLocations.LocationId;
                cmd.Parameters["@LocationId"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@LocationName", SqlDbType.VarChar, 5000).Value = objFavoriteLocations.LocationName;
                cmd.Parameters.Add("@LocationTypeId", SqlDbType.Int).Value = objFavoriteLocations.LocationTypeId;
                cmd.Parameters.Add("@Long", SqlDbType.VarChar, 250).Value = objFavoriteLocations.Long;
                cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = objFavoriteLocations.UserId;

                cmd.ExecuteNonQuery();

                //after updating the FavoriteLocations, update LocationId
                objFavoriteLocations.LocationId = Convert.ToInt32(cmd.Parameters["@LocationId"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteFavoriteLocations(int LocationId, int UserId, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from FavoriteLocations where LocationId=@LocationId and UserId=@UserId", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@LocationId", SqlDbType.Int).Value = LocationId;
                cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = UserId;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        #endregion
    }
}
