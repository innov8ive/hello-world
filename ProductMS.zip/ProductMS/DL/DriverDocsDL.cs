using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using OM;

namespace DL
{
    public class DriverDocsDL
    {

        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public DriverDocsDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public DriverDocs Load(int DriverDocId)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            DriverDocs objDriverDocs = new DriverDocs();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get DriverDocs
                var resultDriverDocs = dc.ExecuteQuery<DriverDocs>("exec Get_DriverDocs {0}", DriverDocId).ToList();
                if (resultDriverDocs.Count > 0)
                {
                    objDriverDocs = resultDriverDocs[0];
                }
                dc.Dispose();
                return objDriverDocs;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllDriverDocs()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_DriverDocs", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(DriverDocs objDriverDocs)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update DriverDocs
                UpdateDriverDocs(objDriverDocs, trn);
                if (objDriverDocs.DriverDocId > 0)
                {

                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int DriverDocId)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete DriverDocs
                DeleteDriverDocs(DriverDocId, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateDriverDocs(DriverDocs objDriverDocs, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_DriverDocs", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@DocTypeId", SqlDbType.Int).Value = objDriverDocs.DocTypeId;
                cmd.Parameters.Add("@DriverDocId", SqlDbType.Int).Value = objDriverDocs.DriverDocId;
                cmd.Parameters["@DriverDocId"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@FileGUID", SqlDbType.VarChar, 250).Value = objDriverDocs.FileGUID;
                cmd.Parameters.Add("@StatusId", SqlDbType.Int).Value = objDriverDocs.StatusId;
                cmd.Parameters.Add("@UploadedOn", SqlDbType.DateTime).Value = objDriverDocs.UploadedOn;
                cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = objDriverDocs.UserId;

                cmd.ExecuteNonQuery();

                //after updating the DriverDocs, update DriverDocId
                objDriverDocs.DriverDocId = Convert.ToInt32(cmd.Parameters["@DriverDocId"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteDriverDocs(int DriverDocId, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from DriverDocs where DriverDocId=@DriverDocId", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@DriverDocId", SqlDbType.Int).Value = DriverDocId;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        #endregion
    }
}
