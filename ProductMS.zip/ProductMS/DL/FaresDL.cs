using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using OM;

namespace DL
{
    public class FaresDL
    {

        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public FaresDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public Fares Load(int Id)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            Fares objFares = new Fares();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get Fares
                var resultFares = dc.ExecuteQuery<Fares>("exec Get_Fares {0}", Id).ToList();
                if (resultFares.Count > 0)
                {
                    objFares = resultFares[0];
                }
                dc.Dispose();
                return objFares;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllFares()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_Fares", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(Fares objFares)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update Fares
                UpdateFares(objFares, trn);
                if (objFares.Id > 0)
                {

                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int Id)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete Fares
                DeleteFares(Id, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateFares(Fares objFares, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_Fares", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@BaseFare", SqlDbType.Decimal).Value = objFares.BaseFare;
                cmd.Parameters.Add("@EffectiveTill", SqlDbType.DateTime).Value = objFares.EffectiveTill;
                cmd.Parameters.Add("@FareType", SqlDbType.VarChar, 50).Value = objFares.FareType;
                cmd.Parameters.Add("@Id", SqlDbType.Int).Value = objFares.Id;
                cmd.Parameters["@Id"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@PerKMFare", SqlDbType.Decimal).Value = objFares.PerKMFare;
                cmd.Parameters.Add("@VehicleTypeId", SqlDbType.Int).Value = objFares.VehicleTypeId;
                cmd.Parameters.Add("@WaitingPerMinuteFare", SqlDbType.Decimal).Value = objFares.WaitingPerMinuteFare;

                cmd.ExecuteNonQuery();

                //after updating the Fares, update Id
                objFares.Id = Convert.ToInt32(cmd.Parameters["@Id"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteFares(int Id, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from Fares where Id=@Id", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@Id", SqlDbType.Int).Value = Id;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        #endregion
    }
}
