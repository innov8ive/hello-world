using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using OM;

namespace DL
{
    public class TempRequestsDL
    {

        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public TempRequestsDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public TempRequests Load(int Id)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            TempRequests objTempRequests = new TempRequests();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get TempRequests
                var resultTempRequests = dc.ExecuteQuery<TempRequests>("exec Get_TempRequests {0}", Id).ToList();
                if (resultTempRequests.Count > 0)
                {
                    objTempRequests = resultTempRequests[0];
                }
                dc.Dispose();
                return objTempRequests;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllTempRequests()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_TempRequests", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(TempRequests objTempRequests)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update TempRequests
                UpdateTempRequests(objTempRequests, trn);
                if (objTempRequests.Id > 0)
                {

                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int Id)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete TempRequests
                DeleteTempRequests(Id, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateTempRequests(TempRequests objTempRequests, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_TempRequests", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@Id", SqlDbType.Int).Value = objTempRequests.Id;
                cmd.Parameters["@Id"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@IsAccepted", SqlDbType.Bit).Value = objTempRequests.IsAccepted;
                cmd.Parameters.Add("@IsExpired", SqlDbType.Bit).Value = objTempRequests.IsExpired;
                cmd.Parameters.Add("@RequestDate", SqlDbType.DateTime).Value = objTempRequests.RequestDate;
                cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = objTempRequests.UserId;

                cmd.ExecuteNonQuery();

                //after updating the TempRequests, update Id
                objTempRequests.Id = Convert.ToInt32(cmd.Parameters["@Id"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteTempRequests(int Id, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from TempRequests where Id=@Id", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@Id", SqlDbType.Int).Value = Id;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        #endregion
    }
}
