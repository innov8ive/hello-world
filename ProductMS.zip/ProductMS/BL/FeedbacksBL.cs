using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using OM;
using DL;

namespace BL
{
    [Serializable]
    public class FeedbacksBL
    {

        #region Declaration
        private string connectionString;
        Feedbacks _Feedbacks;
        public Feedbacks Data
        {
            get { return _Feedbacks; }
            set { _Feedbacks = value; }
        }
        public bool IsNew
        {
            get { return (_Feedbacks.FeedbackId <= 0 || _Feedbacks.FeedbackId == null); }
        }
        #endregion

        #region Constructor
        public FeedbacksBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private FeedbacksDL CreateDL()
        {
            return new FeedbacksDL(connectionString);
        }
        public void New()
        {
            _Feedbacks = new Feedbacks();
        }
        public void Load(int FeedbackId)
        {
            var FeedbacksObj = this.CreateDL();
            _Feedbacks = FeedbackId <= 0 ? FeedbacksObj.Load(-1) : FeedbacksObj.Load(FeedbackId);
        }
        public List<Feedbacks> LoadForUser(int UserId)
        {
            var FeedbacksDLObj = CreateDL();
            return FeedbacksDLObj.LoadForUser(UserId);
        }
        public List<Feedbacks> LoadForDriver(int DriverUserId)
        {
            var FeedbacksDLObj = CreateDL();
            return FeedbacksDLObj.LoadForDriver(DriverUserId);
        }
        public DataTable LoadAllFeedbacks()
        {
            var FeedbacksDLObj = CreateDL();
            return FeedbacksDLObj.LoadAllFeedbacks();
        }
        public bool Update()
        {
            var FeedbacksDLObj = CreateDL();
            return FeedbacksDLObj.Update(this.Data);
        }
        public bool Delete(int FeedbackId,int UserId, int UserTypeId)
        {
            var FeedbacksDLObj = CreateDL();
            return FeedbacksDLObj.Delete(FeedbackId, UserId, UserTypeId);
        }
        #endregion
    }
}
