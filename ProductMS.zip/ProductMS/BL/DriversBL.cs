using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using OM;
using DL;

namespace BL
{
    [Serializable]
    public class DriversBL
    {

        #region Declaration
        private string connectionString;
        Drivers _Drivers;
        public Drivers Data
        {
            get { return _Drivers; }
            set { _Drivers = value; }
        }
        public bool IsNew
        {
            get { return (_Drivers.DriverId <= 0 || _Drivers.DriverId == null); }
        }
        #endregion

        #region Constructor
        public DriversBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private DriversDL CreateDL()
        {
            return new DriversDL(connectionString);
        }
        public void New()
        {
            _Drivers = new Drivers();
        }
        public void Load(int UserId)
        {
            var DriversObj = this.CreateDL();
            _Drivers = UserId <= 0 ? DriversObj.Load(-1) : DriversObj.Load(UserId);
        }
        public DataTable LoadAllDrivers()
        {
            var DriversDLObj = CreateDL();
            return DriversDLObj.LoadAllDrivers();
        }
        public bool Update()
        {
            var DriversDLObj = CreateDL();
            return DriversDLObj.Update(this.Data);
        }
        public bool ImportUpdate()
        {
            var DriversDLObj = CreateDL();
            return DriversDLObj.ImportUpdate(this.Data);
        }
        public bool Delete(int DriverId)
        {
            var DriversDLObj = CreateDL();
            return DriversDLObj.Delete(DriverId);
        }
        #endregion
    }
}
