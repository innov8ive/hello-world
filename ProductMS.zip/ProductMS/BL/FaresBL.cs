using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using OM;
using DL;

namespace BL
{
    [Serializable]
    public class FaresBL
    {

        #region Declaration
        private string connectionString;
        Fares _Fares;
        public Fares Data
        {
            get { return _Fares; }
            set { _Fares = value; }
        }
        public bool IsNew
        {
            get { return (_Fares.Id <= 0 || _Fares.Id == null); }
        }
        #endregion

        #region Constructor
        public FaresBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private FaresDL CreateDL()
        {
            return new FaresDL(connectionString);
        }
        public void New()
        {
            _Fares = new Fares();
        }
        public void Load(int Id)
        {
            var FaresObj = this.CreateDL();
            _Fares = Id <= 0 ? FaresObj.Load(-1) : FaresObj.Load(Id);
        }
        public DataTable LoadAllFares()
        {
            var FaresDLObj = CreateDL();
            return FaresDLObj.LoadAllFares();
        }
        public bool Update()
        {
            var FaresDLObj = CreateDL();
            return FaresDLObj.Update(this.Data);
        }
        public bool Delete(int Id)
        {
            var FaresDLObj = CreateDL();
            return FaresDLObj.Delete(Id);
        }
        #endregion
    }
}
