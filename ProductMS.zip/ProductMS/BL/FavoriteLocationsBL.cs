using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using OM;
using DL;

namespace BL
{
    [Serializable]
    public class FavoriteLocationsBL
    {

        #region Declaration
        private string connectionString;
        FavoriteLocations _FavoriteLocations;
        public FavoriteLocations Data
        {
            get { return _FavoriteLocations; }
            set { _FavoriteLocations = value; }
        }
        public bool IsNew
        {
            get { return (_FavoriteLocations.LocationId <= 0 || _FavoriteLocations.LocationId == null); }
        }
        #endregion

        #region Constructor
        public FavoriteLocationsBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private FavoriteLocationsDL CreateDL()
        {
            return new FavoriteLocationsDL(connectionString);
        }
        public void New()
        {
            _FavoriteLocations = new FavoriteLocations();
        }
        public void Load(int LocationId)
        {
            var FavoriteLocationsObj = this.CreateDL();
            _FavoriteLocations = LocationId <= 0 ? FavoriteLocationsObj.Load(-1) : FavoriteLocationsObj.Load(LocationId);
        }
        public DataTable LoadAllFavoriteLocations()
        {
            var FavoriteLocationsDLObj = CreateDL();
            return FavoriteLocationsDLObj.LoadAllFavoriteLocations();
        }
        public List<FavoriteLocations> LoadForUser(int UserId)
        {
            var FavoriteLocationsDLObj = CreateDL();
            return FavoriteLocationsDLObj.LoadForUser(UserId);
        }
        public bool SetFavoriteLocations(int userId, int locationID, bool selected)
        {
            var FavoriteLocationsDLObj = CreateDL();
            return FavoriteLocationsDLObj.SetFavoriteLocations(userId, locationID, selected);
        }
        public bool Update()
        {
            var FavoriteLocationsDLObj = CreateDL();
            return FavoriteLocationsDLObj.Update(this.Data);
        }
        public bool Delete(int LocationId, int UserId)
        {
            var FavoriteLocationsDLObj = CreateDL();
            return FavoriteLocationsDLObj.Delete(LocationId, UserId);
        }
        #endregion
    }
}
