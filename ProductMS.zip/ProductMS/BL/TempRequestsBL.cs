using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using OM;
using DL;

namespace BL
{
    [Serializable]
    public class TempRequestsBL
    {

        #region Declaration
        private string connectionString;
        TempRequests _TempRequests;
        public TempRequests Data
        {
            get { return _TempRequests; }
            set { _TempRequests = value; }
        }
        public bool IsNew
        {
            get { return (_TempRequests.Id <= 0 || _TempRequests.Id == null); }
        }
        #endregion

        #region Constructor
        public TempRequestsBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private TempRequestsDL CreateDL()
        {
            return new TempRequestsDL(connectionString);
        }
        public void New()
        {
            _TempRequests = new TempRequests();
        }
        public void Load(int Id)
        {
            var TempRequestsObj = this.CreateDL();
            _TempRequests = Id <= 0 ? TempRequestsObj.Load(-1) : TempRequestsObj.Load(Id);
        }
        public DataTable LoadAllTempRequests()
        {
            var TempRequestsDLObj = CreateDL();
            return TempRequestsDLObj.LoadAllTempRequests();
        }
        public bool Update()
        {
            var TempRequestsDLObj = CreateDL();
            return TempRequestsDLObj.Update(this.Data);
        }
        public bool Delete(int Id)
        {
            var TempRequestsDLObj = CreateDL();
            return TempRequestsDLObj.Delete(Id);
        }
        #endregion
    }
}
