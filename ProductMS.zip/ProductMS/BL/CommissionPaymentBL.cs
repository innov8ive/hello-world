using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using OM;
using DL;

namespace BL
{
    [Serializable]
    public class CommissionPaymentBL
    {

        #region Declaration
        private string connectionString;
        CommissionPayment _CommissionPayment;
        public CommissionPayment Data
        {
            get { return _CommissionPayment; }
            set { _CommissionPayment = value; }
        }
        public bool IsNew
        {
            get { return (_CommissionPayment.CommissionPaymentId <= 0 || _CommissionPayment.CommissionPaymentId == null); }
        }
        #endregion

        #region Constructor
        public CommissionPaymentBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private CommissionPaymentDL CreateDL()
        {
            return new CommissionPaymentDL(connectionString);
        }
        public void New()
        {
            _CommissionPayment = new CommissionPayment();
        }
        public void Load(int CommissionPaymentId)
        {
            var CommissionPaymentObj = this.CreateDL();
            _CommissionPayment = CommissionPaymentId <= 0 ? CommissionPaymentObj.Load(-1) : CommissionPaymentObj.Load(CommissionPaymentId);
        }
        public DataTable LoadAllCommissionPayment()
        {
            var CommissionPaymentDLObj = CreateDL();
            return CommissionPaymentDLObj.LoadAllCommissionPayment();
        }
        public bool Update()
        {
            var CommissionPaymentDLObj = CreateDL();
            return CommissionPaymentDLObj.Update(this.Data);
        }
        public bool Delete(int CommissionPaymentId)
        {
            var CommissionPaymentDLObj = CreateDL();
            return CommissionPaymentDLObj.Delete(CommissionPaymentId);
        }
        #endregion
    }
}
