﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using OM;
using DL;

namespace BL
{
    [Serializable]
    public class UsersBL
    {

        #region Declaration
        private string connectionString;
        Users _Users;
        public Users Data
        {
            get { return _Users; }
            set { _Users = value; }
        }
        public bool IsNew
        {
            get { return (_Users.UserId <= 0 || _Users.UserId == null); }
        }
        #endregion

        #region Constructor
        public UsersBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private UsersDL CreateDL()
        {
            return new UsersDL(connectionString);
        }
        public void New()
        {
            _Users = new Users();
        }
        public void Load(int UserId)
        {
            var UsersObj = this.CreateDL();
            _Users = UserId <= 0 ? UsersObj.Load(-1) : UsersObj.Load(UserId);
        }
        public List<string> GetUserDeviceIds(string UserIds)
        {
            var UsersDLObj = CreateDL();
            return UsersDLObj.GetUserDeviceIds(UserIds);
        }
        public DataTable LoadAllUsers()
        {
            var UsersDLObj = CreateDL();
            return UsersDLObj.LoadAllUsers();
        }
        public bool Update()
        {
            var UsersDLObj = CreateDL();
            return UsersDLObj.Update(this.Data);
        }
        public bool Delete(int UserId)
        {
            var UsersDLObj = CreateDL();
            return UsersDLObj.Delete(UserId);
        }
        #endregion
    }
}
