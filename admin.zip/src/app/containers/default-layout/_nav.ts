import { INavData } from '@coreui/angular';

export const navItems: INavData[] = [
  {
    name: 'Approvals',
    url: '/dashboard',
    iconComponent: { name: 'cil-speedometer' }    
  },
  {
    title: true,
    name: 'Manage'
  },
  {
    name: 'Drivers',
    url: '/dashboard/drivers',
    iconComponent: { name: 'cil-user' }
  },
  {
    name: 'Riders',
    url: '/dashboard/users',
    linkProps: { fragment: 'someAnchor' },
    iconComponent: { name: 'cil-user' }
  },
  {
    name: 'Fare Settings',
    url: '/dashboard/FaresList',
    linkProps: { fragment: 'someAnchor' },
    iconComponent: { name: 'cil-settings' }
  }  
];
