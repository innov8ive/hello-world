import { Component, Input, ChangeDetectorRef, AfterViewChecked } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Component({
    selector: 'my-table',
    templateUrl: 'table.component.html'
})
export class TableComponent implements AfterViewChecked {
    @Input() apiUrl: string;
    @Input() sortField: string;
    @Input() sortDir: string;
    @Input() cols: any[];
    @Input() dataKey: string;
    @Input() gridTitle: string;

    selectedRow: any = {};
    differ: any;

    data: any[] = [];
    pageSize: number = 20;
    loading: boolean;

    PageNo: number = 1;
    totalRecords: number = 0;
    allowPaging: boolean = true;
    searchedText: string = '';
    constructor(private http: HttpClient, private changeDetectorRef: ChangeDetectorRef) {
    }

    bindGrid(event: any) {
        this.sortField = event.sortField;
        this.sortDir = event.sortOrder == 1 ? 'Asc' : 'Desc';
        this.pageSize = event.rows;
        this.PageNo = (event.first / event.rows) + 1;
        this.loadData(this.searchedText);
    }

    loadData(searchText: string) {
        this.searchedText = searchText;
        this.loading = true;
        this.http.post(this.apiUrl, {
            PageSize: this.pageSize, CurrentPage: this.PageNo, SortBy: this.sortField,
            SortDir: this.sortDir, SearchText: searchText
        }).subscribe(pagedData => {
            let result: any = pagedData;
            this.data = JSON.parse(result.data);
            this.loading = false;
            this.totalRecords = result.totalRecords;
        });
    }
    ngAfterViewChecked() {
        this.changeDetectorRef.detectChanges();
    }
}