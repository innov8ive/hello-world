import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { TableModule as TableModule2 } from 'primeng/table';

import {
  AccordionModule,
  AvatarModule,
  BadgeModule,
  ButtonGroupModule,
  ButtonModule,
  CardModule,
  FormModule,
  GridModule,
  NavModule,
  ProgressModule,
  SharedModule,
  TableModule,
  TabsModule
} from '@coreui/angular';
import { IconModule } from '@coreui/icons-angular';
import { ChartjsModule } from '@coreui/angular-chartjs';


import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './dashboard.component';

import { WidgetsModule } from '../widgets/widgets.module';
import { TableComponent } from '../gridbase/table.component';
import { FormsModule } from '@angular/forms'
import { DriversComponent } from './drivers/drivers.component';
import { DriversProfileComponent } from './drivers-profile/drivers-profile.component';
import { UsersProfileComponent } from './users-profile/users-profile.component';
import { UsersComponent } from './users/users.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { FaresComponent } from './fares/FaresComponent';
import { FaresListComponent } from './fares/FaresListComponent';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgSelectModule } from '@ng-select/ng-select';
import { ToastModule } from 'primeng/toast';

@NgModule({
  exports: [TableComponent],
  imports: [
    DashboardRoutingModule,
    CardModule,
    NavModule,
    IconModule,
    TabsModule,
    CommonModule,
    GridModule,
    ProgressModule,
    ReactiveFormsModule,
    ButtonModule,
    FormModule,
    ButtonModule,
    ButtonGroupModule,
    ChartjsModule,
    AvatarModule,
    TableModule,
    WidgetsModule,
    TableModule2,
    FormsModule,
    BadgeModule,
    AccordionModule,
    SharedModule,
    NgbModule,
    NgSelectModule,
    ToastModule 
  ],
  declarations: [DashboardComponent, TableComponent, DriversComponent, 
    UsersComponent, DriversProfileComponent, UsersProfileComponent, ChangePasswordComponent,
    FaresComponent,
    FaresListComponent]
})
export class DashboardModule {
}
