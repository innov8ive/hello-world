import { Component, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TableComponent } from '../../gridbase/table.component';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Message, MessageService } from 'primeng/api';
import { NgForm } from '@angular/forms';


@Component({
  templateUrl: 'change-password.component.html',
  styleUrl: 'change-password.component.scss',
  providers: [MessageService]
})
export class ChangePasswordComponent {
  constructor(private _router: Router, private http: HttpClient, private messageService: MessageService) {
  }
  formCPSubmitted: boolean = false;
  CP: any = {
    OldPassword: '',
    NewPassword: '',
    ConfirmPassword: ''
  };
  msgs: Message[] = [];
  ngOnInit(): void {
  }

  changePassword(formCP: NgForm) {

    this.formCPSubmitted = true;
    if (formCP.invalid == true) return;
    if(this.CP.NewPassword!=this.CP.ConfirmPassword){
      this.messageService.add({
        severity: 'error',
        summary: 'Failure Message!',
        detail: 'New Password and Confirm Password does not match.',
      });
      return;
    }
    this.http.post('api/Auth/changePassword', this.CP).subscribe(
      data => {

        let result = data as any;
        if (result.text == 'Invalid') {
          this.messageService.add({
            severity: 'error',
            summary: 'Failure Message!',
            detail: 'Incorrect Current Password.',
          });
        } else {
          this.messageService.add({
            severity: 'success',
            summary: 'Success Message',
            detail: 'Password Changed Successfully!',
          });

          window.setTimeout(()=>{
            this._router.navigate(['/dashboard']);
          },2000);          
        }
      },
      error => {

      }
    );
  }
  goBack() {
    this._router.navigate(['/dashboard']);
  }
}
