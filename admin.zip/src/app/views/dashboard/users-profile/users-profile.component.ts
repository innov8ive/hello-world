import { Component, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TableComponent } from '../../gridbase/table.component';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Message } from 'primeng/api';


@Component({
  templateUrl: 'users-profile.component.html',
  styleUrl: 'users-profile.component.scss'
})
export class UsersProfileComponent {
  loading = false;
  driverData: any;
  driverRides: any;
  userId: number;
  baseUrl = 'https://localhost:44339/';
  remarkEditing = false;
  constructor(private _router: Router, private route: ActivatedRoute, private http: HttpClient) {
    this.userId = route.snapshot.params['UserId'];
  }
  @ViewChild('rideTable') myTable: TableComponent;
  cols = [
    { field: 'Driver', header: 'Driver' },
    { field: 'StatusDetails', header: 'Status' },
    { field: 'Distance', header: 'Distance (KM)' },
    { field: 'Fare', header: 'Fare (₹)' },
    { field: 'PaidMode', header: 'Payment Mode' },
    { field: 'StartLocationText', header: 'Start Location' },
    { field: 'EndLocationText', header: 'End Location' },
    { field: 'PickTime', header: 'Pickup Time', format: 'dd-MMM-yyyy hh:MM a' },
    { field: 'EndTime', header: 'Drop Time', format: 'hh:MM a' }
  ];
  dataKey: string = 'RideRequestId';
  searchText: string = '';
  ngOnInit(): void {
    this.loadData(this.userId);
  }
  loadData(userId: number) {
    this.loading = true;
    this.http.get('api/Admin/getUser/' + userId).subscribe(data => {
      this.driverData = data
      this.loading = false;
      this.loadUsersRides()
    });
  }
  loadUsersRides() {
    window.setTimeout(() => {
      this.myTable.loadData(this.userId.toString());
    }, 100);
  }
  getColor(status: string) {
    if (status == 'Approved') {
      return 'success';
    } else if (status == 'Pending') {
      return 'warning';
    } else if (status == 'Rejected') {
      return 'danger';
    } else {
      return 'secondary';
    }
  }

  getImgPath(fileGUID: string) {
    return this.baseUrl + fileGUID;
  }

  setActiveInActive(isActive: boolean) {
    let apiName = isActive == false ? 'api/Admin/activateUser' : 'api/Admin/deactivateUser';
    this.loading = true;
    this.http.post(apiName, { UserId: this.userId }).subscribe(data => {
      this.loading = false;
      let result = data as any;
      if (result.text == 'Success') {
        this.driverData.userDetails.isActive = !this.driverData.userDetails.isActive;
      }
    });
  }
}
