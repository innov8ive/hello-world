import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { DashboardComponent } from './dashboard.component';
import { DriversComponent } from './drivers/drivers.component';
import { UsersComponent } from './users/users.component';
import { DriversProfileComponent } from './drivers-profile/drivers-profile.component';
import { UsersProfileComponent } from './users-profile/users-profile.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { FaresComponent } from './fares/FaresComponent';
import { FaresListComponent } from './fares/FaresListComponent';

const routes: Routes = [
  {
    path: '',
    component: DashboardComponent,
    data: {
      title: $localize`Pending Drivers for Approval`
    }
  },
  {
    path: 'drivers',
    component: DriversComponent,
    data: {
      title: $localize`Drivers`
    }
  },
  {
    path: 'users',
    component: UsersComponent,
    data: {
      title: $localize`Riders`
    }
  },
  {
    path: 'drivers-profile/:UserId',
    component: DriversProfileComponent,
    data: {
      title: $localize`Driver Profile`
    }
  },
  {
    path: 'users-profile/:UserId',
    component: UsersProfileComponent,
    data: {
      title: $localize`Rider Profile`
    }
  },
  {
    path: 'change-password',
    component: ChangePasswordComponent,
    data: {
      title: $localize`Change Password`
    }
  },
  {
    path: 'FaresList',
    component: FaresListComponent,
    data: {
    title: 'Fares List'
    }
    },
    {
    path: 'Fares/:Id',
    component: FaresComponent,
    data: {
    title: 'Fares'
    }
    }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule {
}
