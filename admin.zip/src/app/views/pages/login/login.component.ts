import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {

  constructor(private http: HttpClient, private router: Router) { }
  username = '';
  password = '';
  error = '';
  onLogin() {
    this.http.post('api/Auth/login', {
      username: this.username,
      password: this.password,
      userType: 3
    }).subscribe((data: any) => {
      if (data && data.token) {
        sessionStorage.setItem('token', data.token);
        this.router.navigate(['/dashboard']);
      } else {

      }
    });
  }
}
