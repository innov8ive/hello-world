using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
    public class NBDL
    {

        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public NBDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public NB Load(int NBID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            NB objNB = new NB();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get NB
                var resultNB = dc.ExecuteQuery<NB>("exec Get_NB {0}", NBID).ToList();
                if (resultNB.Count > 0)
                {
                    objNB = resultNB[0];
                }
                dc.Dispose();
                return objNB;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public List<NB> LoadForListing(int SocID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            var dc = new DataContext(SqlCon);
            try
            {
                //Get NB
                var resultNB = dc.ExecuteQuery<NB>("Select * from NB where IsActive=1 and ShowTillDate>=GetDate() and SocID={0}", SocID).ToList();
                
                dc.Dispose();
                return resultNB;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllNB()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_NB", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(NB objNB)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update NB
                UpdateNB(objNB, trn);
                if (objNB.NBID > 0)
                {

                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int NBID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete NB
                DeleteNB(NBID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateNB(NB objNB, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_NB", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@Details", SqlDbType.NText).Value = objNB.Details;
                cmd.Parameters.Add("@IsActive", SqlDbType.Bit).Value = objNB.IsActive;
                cmd.Parameters.Add("@NBID", SqlDbType.Int).Value = objNB.NBID;
                cmd.Parameters["@NBID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@ShowTillDate", SqlDbType.DateTime).Value = objNB.ShowTillDate;
                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = objNB.SocID;
                cmd.Parameters.Add("@Title", SqlDbType.NVarChar, 250).Value = objNB.Title;

                cmd.ExecuteNonQuery();

                //after updating the NB, update NBID
                objNB.NBID = Convert.ToInt32(cmd.Parameters["@NBID"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteNB(int NBID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from NB where NBID=@NBID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@NBID", SqlDbType.Int).Value = NBID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        #endregion
    }
}
