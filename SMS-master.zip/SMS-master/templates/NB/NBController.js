var app = angular.module('myApp');

app.controller('NBListCtrl', function ($scope, $http, $location, GridData) {

    $scope = readyAngularGrid($scope, $http, 'api/NBList', 'NBID', GridData, 'NB');
    $scope.gridOptions.columnDefs = [
    { displayName: 'Title', field: 'Title' },    
    { displayName: 'Show Till Date', field: 'ShowTillDate', cellFilter: 'date:\'dd-MMM-yyyy\'' }];
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchNB = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };
    $scope.newNB = function () {
        saveGridData($scope, GridData, 'NB');
        $location.path('/NB/0');
    };
    $scope.editNB = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            saveGridData($scope, GridData, 'NB');
            $location.path('/NB/' + selected[0].NBID);
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.deleteNB = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'DELETE',
                url: 'api/NB/' + selected[0].NBID
            }).success(function (result) {
                if (result == true)
                    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
            });
        }
        else {
            alert('Please select a record to edit.');
        }
    };
})
app.controller('NBListingCtrl', function ($scope, $http, $location) {

    $scope.NBs = [];
    setTimeout(function () {
        $http({
            method: 'POST',
            url: 'api/NB/GetAllNBs'
        }).success(function (NBs) {
            $scope.NBs = NBs;
        });
    }, 100);

    $scope.toMarkup = function (text) {
        return toMarkup(text);
    };
})
.controller('NBCtrl', function ($scope, $http, $location, $routeParams) {
    var NBID = $routeParams.NBID;
    $scope.NB = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.NBSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.NBSubmitted = true;
        if ($scope.formNB.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/NB', $scope.NB, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.NB = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/NBList');
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/NB/' + NBID
        }).success(function (NB) {
            $scope.NB = JSON.parse(NB);
        });
    }, 100);

    $scope.toMarkup = function (text) {
        return toMarkup(text);
    };
});
