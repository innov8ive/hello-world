using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;
using System.Web.Http.Cors;

namespace SampleAngular.Api
{
    public class NBController : ApiController
    {
        // GET api/NB
        [Route("api/NBList/")]
        [HttpPost]
        public AngularGridData GetNB([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.NoticeBoard, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = "Select * from NB where SocID=@SocID";
            objAngularDataBinder.ValueField = "NBID";
            Hashtable ht = new Hashtable();
            ht["@SocID"] = objLoggedUser.SocID;
            objAngularDataBinder.Parameters = ht;
            return objAngularDataBinder.GetData();
        }

        // GET api/NB/Id
        [Route("api/NB/{Id}")]
        public string GetNB(int Id)
        {
            //Common.IsValidForm(Constants.Forms.NB, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            NBBL objNBBL = new NBBL(Common.GetConString());
            objNBBL.Load(Id);
            NB objNB = objNBBL.Data;
            if (Common.ToInt(objNB.SocID) > 0 && objNB.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            return JsonConvert.SerializeObject(objNBBL.Data);
        }

        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/NB/GetAllNBs/")]
        [HttpPost]
        public DataTable GetAllNBs()
        {
            Common.IsValidForm(Constants.Forms.NormalUser, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            NBBL objNBBL = new NBBL(Common.GetConString());
            DataTable dt = Common.GetDBResult("Select * from NB where IsActive=1 and ShowTillDate>=GetDate() and SocID=" + objLoggedUser.SocID);
            return dt;
        }
        // POST api/NB/
        public string Post([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.NoticeBoard, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            JObject objJObject = value;
            NB objNB = objJObject.ToObject<NB>();
            NBBL objNBBL = new NBBL(Common.GetConString());
            objNBBL.Data = objNB;

            NBValidator validator = new NBValidator();
            ValidationResult results = validator.Validate(objNB);

            if (Common.ToInt(objNB.SocID) > 0 && objNB.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            if (objLoggedUser.UserType != 2)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
           
            if (results.IsValid)
            {
                objNB.SocID = objLoggedUser.SocID;
                objNBBL.Update();
                return JsonConvert.SerializeObject(objNBBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        // DELETE api/NB/5
        [Route("api/NB/{Id}")]
        [HttpDelete]
        public bool Delete(int Id)
        {
            Common.IsValidForm(Constants.Forms.NoticeBoard, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            NBBL objNBBL = new NBBL(Common.GetConString());
            objNBBL.Load(Id);
            NB objNB = objNBBL.Data;
            if (Common.ToInt(objNB.SocID) > 0 && objNB.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            if (objLoggedUser.UserType != 2)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            return objNBBL.Delete(Id);
        }
    }
    public class NBValidator : AbstractValidator<NB>
    {
        public NBValidator()
        {
            RuleFor(obj => obj.Details).NotEmpty();
            RuleFor(obj => obj.ShowTillDate).NotEmpty();
            RuleFor(obj => obj.Title).NotEmpty();
        }
    }
}

