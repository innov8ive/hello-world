using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
    [Serializable]
    public class NBBL
    {

        #region Declaration
        private string connectionString;
        NB _NB;
        public NB Data
        {
            get { return _NB; }
            set { _NB = value; }
        }
        public bool IsNew
        {
            get { return (_NB.NBID <= 0 || _NB.NBID == null); }
        }
        #endregion

        #region Constructor
        public NBBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private NBDL CreateDL()
        {
            return new NBDL(connectionString);
        }
        public void New()
        {
            _NB = new NB();
        }
        public void Load(int NBID)
        {
            var NBObj = this.CreateDL();
            _NB = NBID <= 0 ? NBObj.Load(-1) : NBObj.Load(NBID);
        }
        public List<NB> LoadForListing(int SocID)
        {
            var NBDLObj = CreateDL();
            return NBDLObj.LoadForListing(SocID);
        }
        public DataTable LoadAllNB()
        {
            var NBDLObj = CreateDL();
            return NBDLObj.LoadAllNB();
        }
        public bool Update()
        {
            var NBDLObj = CreateDL();
            return NBDLObj.Update(this.Data);
        }
        public bool Delete(int NBID)
        {
            var NBDLObj = CreateDL();
            return NBDLObj.Delete(NBID);
        }
        #endregion
    }
}
