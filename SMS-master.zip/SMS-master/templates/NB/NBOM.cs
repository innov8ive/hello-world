using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

    [Serializable]
    [Table(Name = "dbo.NB")]
    public class NB
    {

        private string _Details;
        private System.Nullable<bool> _IsActive;
        private System.Nullable<int> _NBID;
        private System.Nullable<DateTime> _ShowTillDate;
        private System.Nullable<int> _SocID;
        private string _Title;



        [Column(Storage = "_Details")]
        public string Details
        {
            get
            {
                return _Details;
            }
            set
            {
                _Details = value;
            }
        }



        [Column(Storage = "_IsActive")]
        public System.Nullable<bool> IsActive
        {
            get
            {
                return _IsActive;
            }
            set
            {
                _IsActive = value;
            }
        }



        [Column(Storage = "_NBID")]
        public System.Nullable<int> NBID
        {
            get
            {
                return _NBID;
            }
            set
            {
                _NBID = value;
            }
        }



        [Column(Storage = "_ShowTillDate")]
        public System.Nullable<DateTime> ShowTillDate
        {
            get
            {
                return _ShowTillDate;
            }
            set
            {
                _ShowTillDate = value;
            }
        }



        [Column(Storage = "_SocID")]
        public System.Nullable<int> SocID
        {
            get
            {
                return _SocID;
            }
            set
            {
                _SocID = value;
            }
        }



        [Column(Storage = "_Title")]
        public string Title
        {
            get
            {
                return _Title;
            }
            set
            {
                _Title = value;
            }
        }

    }


}
