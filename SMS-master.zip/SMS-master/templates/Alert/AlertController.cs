using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;
using System.IO;
using System.Web.Http.Cors;

namespace SampleAngular.Api
{
    public class AlertController : ApiController
    {
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/Alert/MarkRead/")]
        [HttpPost]
        public string MarkRead([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser != null)
            {
                if (objLoggedUser.UserType == 2)
                {
                    Common.ExecuteNonQuery(@"Update Alerts set IsRead=1 where SocID=@SocID and UserID=0",
        "@SocID", SqlDbType.Int, objLoggedUser.SocID);
                }
                else
                {
                    Common.ExecuteNonQuery(@"Update Alerts set IsRead=1 where SocID=@SocID and UserID=@UserID",
       "@SocID", SqlDbType.Int, objLoggedUser.SocID,
       "@UserID", SqlDbType.Int, objLoggedUser.UserID);
                }
            }
            return "Success";
        }

        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/Alert/GetList/")]
        [HttpPost]
        public DataTable GetAlertList([FromBody]dynamic value)
        {
            //Common.IsValidForm(Constants.Forms.Service, Request);
            LoggedUser objLoggedUser = HttpContext.Current.Session["LoggedUser"] as LoggedUser;
            DataTable dt = new DataTable();
            if (objLoggedUser != null)
            {
                if (objLoggedUser.UserType == 2)
                {
                    dt = Common.GetDBResultParameterized(@"Select * from Alerts where SocID=@SocID and UserID=0 and IsRead=0",
        "@SocID", SqlDbType.Int, objLoggedUser.SocID);
                }
                else
                {
                    dt = Common.GetDBResultParameterized(@"Select * from Alerts where SocID=@SocID and UserID=@UserID and IsRead=0",
        "@SocID", SqlDbType.Int, objLoggedUser.SocID,
        "@UserID", SqlDbType.Int, objLoggedUser.UserID);
                }
            }
            return dt;
        }
    }
}

