using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

    [Serializable]
    [Table(Name = "dbo.MT")]
    public class MT
    {
        private string _Agenda;
        private string _AT;
        private System.Nullable<DateTime> _MDate;
        private string _MOM;
        private System.Nullable<int> _MTID;
        private string _MTime;
        private string _Sub;
        private System.Nullable<int> _SocID;
        private System.Nullable<int> _MOMFileID;
        private string _FileGUID;
        private string _FileName;
        private string _MOMFileUrl;

        [Column(Storage = "_MOMFileUrl")]
        public string MOMFileUrl
        {
            get { return _MOMFileUrl; }
            set { _MOMFileUrl = value; }
        }

        [Column(Storage = "_FileName")]
        public string FileName
        {
            get { return _FileName; }
            set { _FileName = value; }
        }

        [Column(Storage = "_FileGUID")]
        public string FileGUID
        {
            get { return _FileGUID; }
            set { _FileGUID = value; }
        }

        [Column(Storage = "_MOMFileID")]
        public System.Nullable<int> MOMFileID
        {
            get { return _MOMFileID; }
            set { _MOMFileID = value; }
        }

        [Column(Storage = "_SocID")]
        public System.Nullable<int> SocID
        {
            get { return _SocID; }
            set { _SocID = value; }
        }

        [Column(Storage = "_Agenda")]
        public string Agenda
        {
            get
            {
                return _Agenda;
            }
            set
            {
                _Agenda = value;
            }
        }

        [Column(Storage = "_AT")]
        public string AT
        {
            get
            {
                return _AT;
            }
            set
            {
                _AT = value;
            }
        }

        [Column(Storage = "_MDate")]
        public System.Nullable<DateTime> MDate
        {
            get
            {
                return _MDate;
            }
            set
            {
                _MDate = value;
            }
        }

        [Column(Storage = "_MOM")]
        public string MOM
        {
            get
            {
                return _MOM;
            }
            set
            {
                _MOM = value;
            }
        }

        [Column(Storage = "_MTID")]
        public System.Nullable<int> MTID
        {
            get
            {
                return _MTID;
            }
            set
            {
                _MTID = value;
            }
        }

        [Column(Storage = "_MTime")]
        public string MTime
        {
            get
            {
                return _MTime;
            }
            set
            {
                _MTime = value;
            }
        }

        [Column(Storage = "_Sub")]
        public string Sub
        {
            get
            {
                return _Sub;
            }
            set
            {
                _Sub = value;
            }
        }


        public System.Collections.Generic.List<string> MTUsers { get; set; }
        public Hashtable Types { get; set; }
    }


    [Serializable]
    [Table(Name = "dbo.MTUsers")]
    public class MTUsers
    {

        private System.Nullable<int> _MTID;
        private System.Nullable<int> _UserID;



        [Column(Storage = "_MTID")]
        public System.Nullable<int> MTID
        {
            get
            {
                return _MTID;
            }
            set
            {
                _MTID = value;
            }
        }



        [Column(Storage = "_UserID")]
        public System.Nullable<int> UserID
        {
            get
            {
                return _UserID;
            }
            set
            {
                _UserID = value;
            }
        }

    }


}
