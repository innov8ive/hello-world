using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
    [Serializable]
    public class MTBL
    {

        #region Declaration
        private string connectionString;
        MT _MT;
        public MT Data
        {
            get { return _MT; }
            set { _MT = value; }
        }
        public bool IsNew
        {
            get { return (_MT.MTID <= 0 || _MT.MTID == null); }
        }
        #endregion

        #region Constructor
        public MTBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private MTDL CreateDL()
        {
            return new MTDL(connectionString);
        }
        public void New()
        {
            _MT = new MT();
        }
        public void Load(int MTID)
        {
            var MTObj = this.CreateDL();
            _MT = MTID <= 0 ? MTObj.Load(-1) : MTObj.Load(MTID);
        }
        public DataTable LoadAllMT()
        {
            var MTDLObj = CreateDL();
            return MTDLObj.LoadAllMT();
        }
        public bool Update()
        {
            var MTDLObj = CreateDL();
            return MTDLObj.Update(this.Data);
        }
        public bool Delete(int MTID)
        {
            var MTDLObj = CreateDL();
            return MTDLObj.Delete(MTID);
        }
        #endregion
    }
}
