using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;
using System.Text;
using System.IO;

namespace SampleAngular.Api
{
    public class MTController : ApiController
    {
        [Route("api/MT/SendMOMSMS")]
        [HttpPost]
        public string SendMOMSMS([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            Common.IsValidForm(Constants.Forms.MeetingManager, Request);

            JObject objJObject = value;
            MT objMT = objJObject.ToObject<MT>();
            MTBL objMTBL = new MTBL(Common.GetConString());
            objMTBL.Data = objMT;
            List<string> mobList = new List<string>();
            StringBuilder mobileNo = new StringBuilder();
            StringBuilder message = new StringBuilder("Dear Society Members, MOM of ");
            message.Append(Common.ToDate(objMT.MDate).ToString("dd-MMM-yyyy hh:mm"));
            message.Append("\n").Append(objMT.MOMFileUrl);

            DataTable dt = Common.GetDBResultParameterized(@"Select MobileNo from Users where CreatedBy=@CreatedBy and 
MobileNo<>'' and MobileNo IS NOT NULL and IsActive=1 and " + Common.GetMemberTypeCondition(objMT.AT),
                                                              "@CreatedBy", SqlDbType.Int, objLoggedUser.UserID);

            foreach (DataRow dr in dt.Rows)
            {
                string mob = Common.ToString(dr["MobileNo"]);
                if (mobList.Contains(mob) == false)
                {
                    mobList.Add(mob);
                }
            }
            StringBuilder mobile = new StringBuilder();
            foreach (string e in mobList)
            {
                mobile.Append(",").Append(e);
            }
            string mobiles = String.Empty;
            if (mobile.Length > 0)
            {
                mobiles = mobile.ToString().Substring(1);
            }
            return Common.SendSMS(mobiles, message.ToString(), objLoggedUser.SocID);
        }

        [Route("api/MT/SendMOM")]
        [HttpPost]
        public string SendMOM([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            Common.IsValidForm(Constants.Forms.MeetingManager, Request);

            JObject objJObject = value;
            MT objMT = objJObject.ToObject<MT>();
            MTBL objMTBL = new MTBL(Common.GetConString());
            objMTBL.Data = objMT;
            List<string> emailList = new List<string>();
            StringBuilder mobileNo = new StringBuilder();
            string subject = "Minutes of Meeting of " + Common.ToDate(objMT.MDate).ToString("dd-MMM-yyyy hh:mm");
            StringBuilder message = new StringBuilder("Dear Society Members, the meeting held on ");
            message.Append(Common.ToDate(objMT.MDate).ToString("dd-MMM-yyyy hh:mm"));
            message.Append(", on Subject '").Append(objMT.Sub).Append("', has following Minutes Of Meeting");
            message.Append("<br/>").Append(objMT.MOM).Append("<br/><a target='_blank' href='").Append(objMT.MOMFileUrl).Append("'>")
                .Append(objMT.FileName).Append("</a>");

            DataTable dt = Common.GetDBResultParameterized(@"Select EmailID from Users where CreatedBy=@CreatedBy and 
EmailID<>'' and EmailID IS NOT NULL and IsActive=1 and " + Common.GetMemberTypeCondition(objMT.AT),
                                                              "@CreatedBy", SqlDbType.Int, objLoggedUser.UserID);
         
            foreach (DataRow dr in dt.Rows)
            {
                string mob = Common.ToString(dr["EmailID"]);
                if (emailList.Contains(mob) == false)
                {
                    emailList.Add(mob);
                }
            }

            StringBuilder email = new StringBuilder();
            foreach (string e in emailList)
            {
                email.Append(",").Append(e);
            }
            string emails = String.Empty;
            if (email.Length > 0)
            {
                emails = email.ToString().Substring(1);
            }
            Common.SendEmailSendGrid(emails, message.ToString(), subject);
            return String.Empty;
        }

        [Route("api/MT/SendNotification")]
        [HttpPost]
        public string SendNotification([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            Common.IsValidForm(Constants.Forms.MeetingManager, Request);

            JObject objJObject = value;
            MT objMT = objJObject.ToObject<MT>();
            MTBL objMTBL = new MTBL(Common.GetConString());
            objMTBL.Data = objMT;
            List<string> mobileNoList = new List<string>();
            StringBuilder mobileNo = new StringBuilder();
            StringBuilder message = new StringBuilder("Dear Society Members, the meeting would be held on ");
            message.Append(Common.ToDate(objMT.MDate).ToString("dd-MMM-yyyy hh:mm"));
            message.Append(". Sub: ").Append(objMT.Sub.Length > 70 ? objMT.Sub.Substring(0, 70) : objMT.Sub);

            DataTable dt = Common.GetDBResultParameterized(@"Select MobileNo from Users where CreatedBy=@CreatedBy and 
MobileNo<>'' and MobileNo IS NOT NULL and IsActive=1 and " + Common.GetMemberTypeCondition(objMT.AT),
                                                         "@CreatedBy", SqlDbType.Int, objLoggedUser.UserID);
            foreach (DataRow dr in dt.Rows)
            {
                string mob = Common.ToString(dr["MobileNo"]);
                if (mobileNoList.Contains(mob) == false)
                {
                    mobileNoList.Add(mob);
                }
            }

            foreach (string m in mobileNoList)
            {
                mobileNo.Append(",").Append("+91").Append(m);
            }
            string mobileNos = String.Empty;
            if (mobileNo.Length > 0)
            {
                mobileNos = mobileNo.ToString().Substring(1);
            }
            return Common.SendSMS(mobileNos, message.ToString(), objLoggedUser.SocID);
        }

        [Route("api/MT/SendNotificationEmail")]
        [HttpPost]
        public string SendNotificationEmail([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            Common.IsValidForm(Constants.Forms.MeetingManager, Request);

            JObject objJObject = value;
            MT objMT = objJObject.ToObject<MT>();
            MTBL objMTBL = new MTBL(Common.GetConString());
            objMTBL.Data = objMT;
            List<string> mobileNoList = new List<string>();
            StringBuilder mobileNo = new StringBuilder();
            StringBuilder message = new StringBuilder("Dear Society Members, the meeting would be held on ");
            string subject = "SocietyInn: Meeting Notification";
            message.Append(Common.ToDate(objMT.MDate).ToString("dd-MMM-yyyy hh:mm"));
            message.Append(". Sub: ").Append(objMT.Sub.Length > 70 ? objMT.Sub.Substring(0, 70) : objMT.Sub);

            DataTable dt = Common.GetDBResultParameterized(@"Select EmailID from Users where CreatedBy=@CreatedBy and 
EmailID<>'' and EmailID IS NOT NULL and IsActive=1 and " + Common.GetMemberTypeCondition(objMT.AT),
                                                         "@CreatedBy", SqlDbType.Int, objLoggedUser.UserID);
            foreach (DataRow dr in dt.Rows)
            {
                string mob = Common.ToString(dr["EmailID"]);
                if (mobileNoList.Contains(mob) == false)
                {
                    mobileNoList.Add(mob);
                }
            }

            foreach (string m in mobileNoList)
            {
                mobileNo.Append(",").Append(m);
            }
            string mobileNos = String.Empty;
            if (mobileNo.Length > 0)
            {
                mobileNos = mobileNo.ToString().Substring(1);
            }
            Common.SendEmailSendGrid(mobileNos, message.ToString(), subject);
            return String.Empty;
        }

        [Route("api/MT/UpdateMOM")]
        [HttpPost]
        public string UpdateMOM([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            Common.IsValidForm(Constants.Forms.MeetingManager, Request);

            JObject objJObject = value;
            MT objMT = objJObject.ToObject<MT>();
            MTBL objMTBL = new MTBL(Common.GetConString());
            objMTBL.Data = objMT;

            if (Common.ToInt(objMT.SocID) > 0 && objMT.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            if (objMT.MTime != null)
            {
                objMT.MDate = objMT.MDate.Value.Date.AddMinutes(Common.ToInt(objMT.MTime));
            }
            MTValidator validator = new MTValidator();
            ValidationResult results = validator.Validate(objMT);

            if (results.IsValid)
            {
                objMTBL.Update();
                return JsonConvert.SerializeObject(objMTBL.Data);
            }

            return String.Empty;
        }
        [Route("api/MT/DeleteMOM")]
        [HttpPost]
        public string DeleteMOM([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            Common.IsValidForm(Constants.Forms.MeetingManager, Request);

            JObject objJObject = value;
            MT objMT = objJObject.ToObject<MT>();
            MTBL objMTBL = new MTBL(Common.GetConString());
            objMTBL.Data = objMT;

            FilesBL objFileBL = new FilesBL(Common.GetConString());
            objFileBL.Delete(Common.ToInt(objMT.MOMFileID));

            if (Common.ToInt(objMT.SocID) > 0 && objMT.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            Common.ExecuteNonQuery("Update MT set MOMFileID=NULL,MOMFileUrl=NULL where MTID=@MTID",
                "@MTID", SqlDbType.Int, Common.ToInt(objMT.MTID));
            try
            {
                string filePath = HttpContext.Current.Server.MapPath("~/AttachedFiles") + "/" + objMT.FileGUID;
                File.Delete(filePath);
            }
            catch { }

            return String.Empty;
        }
      
        [Route("api/MTList/")]
        [HttpPost]
        public AngularGridData GetMT([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            Common.IsValidForm(Constants.Forms.MeetingManager, Request);

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = @"Select * from MT where SocID=@SocID
and (Sub like '%'+@Name+'%' OR Agenda like '%'+@Name+'%')";
            objAngularDataBinder.ValueField = "MTID";
            objAngularDataBinder.OrderBy = "MDate";
            objAngularDataBinder.OrderDir = "Desc";
            Hashtable ht = new Hashtable();
            ht["@SocID"] = objLoggedUser.SocID;
            ht["@Name"] = Common.ToString(value.SearchText);
            objAngularDataBinder.Parameters = ht;
            return objAngularDataBinder.GetData();
        }

        // GET api/MT/Id
        [Route("api/MT/{Id}")]
        public string GetMT(int Id)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            Common.IsValidForm(Constants.Forms.MeetingManager, Request);

            MTBL objMTBL = new MTBL(Common.GetConString());
            objMTBL.Load(Id);

            MT objMT = objMTBL.Data;
            if (Common.ToInt(objMT.SocID) > 0 && objMT.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            if (objMT.MDate != null)
            {
                objMT.MTime = Common.ToString(objMT.MDate.Value.Hour * 60 + objMT.MDate.Value.Minute);
                //objMT.MDate = objMT.MDate.Value.Date;
            }
            return JsonConvert.SerializeObject(objMTBL.Data);
        }

        // POST api/MT/
        public string Post([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            Common.IsValidForm(Constants.Forms.MeetingManager, Request);

            JObject objJObject = value;
            MT objMT = objJObject.ToObject<MT>();
            MTBL objMTBL = new MTBL(Common.GetConString());
            objMTBL.Data = objMT;
            if (objMTBL.IsNew)
            {
                objMT.SocID = objLoggedUser.SocID;
            }
            if (Common.ToInt(objMT.SocID) > 0 && objMT.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            if (objMT.MTime != null)
            {
                objMT.MDate = objMT.MDate.Value.Date.AddMinutes(Common.ToInt(objMT.MTime));
            }
            MTValidator validator = new MTValidator();
            ValidationResult results = validator.Validate(objMT);

            if (results.IsValid)
            {
                objMTBL.Update();
                return JsonConvert.SerializeObject(objMTBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        // DELETE api/MT/5
        [Route("api/MT/{Id}")]
        [HttpDelete]
        public bool Delete(int Id)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            Common.IsValidForm(Constants.Forms.MeetingManager, Request);

            MTBL objMTBL = new MTBL(Common.GetConString());
            objMTBL.Load(Id);

            MT objMT = objMTBL.Data;
            if (Common.ToInt(objMT.SocID) > 0 && objMT.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            if (!String.IsNullOrEmpty(objMT.MOM) || objMT.MTUsers.Count > 0)
            {
                return false;
            }

            return objMTBL.Delete(Id);
        }
    }
    public class MTValidator : AbstractValidator<MT>
    {
        public MTValidator()
        {
            RuleFor(obj => obj.Agenda).NotEmpty();
            RuleFor(obj => obj.AT).NotEmpty();
            RuleFor(obj => obj.MDate).NotEmpty();
            RuleFor(obj => obj.MTime).NotEmpty();
            RuleFor(obj => obj.Sub).NotEmpty();
        }
    }
}

