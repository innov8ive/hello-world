var app = angular.module('myApp');

app.controller('MTListCtrl', function ($scope, $http, $location, GridData) {

    $scope = readyAngularGrid($scope, $http, 'api/MTList', 'MTID', GridData, 'MT');
    $scope.gridOptions.columnDefs = [

    { displayName: 'Meeting Subject', field: 'Sub' },
    { displayName: 'Agenda', field: 'Agenda' },
    { displayName: 'Meeting Date and Time', field: 'MDate', cellFilter: 'date:\'dd-MMM-yyyy hh:mm a\'' }, ];
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchMT = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };
    $scope.newMT = function () {
        saveGridData($scope, GridData, 'MT');
        $location.path('/MT/0');
    };
    $scope.editMT = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            saveGridData($scope, GridData, 'MT');
            $location.path('/MT/' + selected[0].MTID);
        }
        else {
            alert('Please select a record to edit.');
        }
    };
    $scope.viewMOM = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            saveGridData($scope, GridData, 'MT');
            $location.path('/MOM/' + selected[0].MTID);
        }
        else {
            alert('Please select a record to view.');
        }
    };
    $scope.deleteMT = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'DELETE',
                url: 'api/MT/' + selected[0].MTID
            }).success(function (result) {
                if (result == true)
                    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
                else
                    alert('You cannot delete this Meeting, because the Meeting is already held');
            });
        }
        else {
            alert('Please select a record to edit.');
        }
    };
})
.controller('MTCtrl', function ($scope, $http, $location, $routeParams) {
    var MTID = $routeParams.MTID;
    $scope.MT = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.MTSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.MTSubmitted = true;
        if ($scope.formMT.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/MT', $scope.MT, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.MT = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/MTList');
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/MT/' + MTID
        }).success(function (MT) {
            $scope.MT = JSON.parse(MT);
        });
    }, 100);
    $scope.MTUsers = {};
    $scope.MTUsersSubmitted = false;
    var MTUsers = [];
    $scope.editMTUsers = function (indx) {
        $scope.EditMode = true;
        $scope.MTUsers = $scope.MT.MTUsersList[indx];
        MTUsers = angular.copy($scope.MT.MTUsersList);
    };
    $scope.deleteMTUsers = function (indx) {
        if (confirm('Are you sure want to delete?') == true) {
            $scope.MT.MTUsersList.splice(indx, 1);
        }
    };
    $scope.newMTUsers = function () {
        $scope.EditMode = true;
        $scope.MTUsersSubmitted = false;
        MTUsers = angular.copy($scope.MT.MTUsersList);
        $scope.MTUsers = {};
        $scope.MT.MTUsersList.push($scope.MTUsers);
    };
    $scope.cancelMTUsers = function () {
        $scope.EditMode = false;
        $scope.MTUsers = {};
        angular.copy(MTUsers, $scope.MT.MTUsersList);
    };
    $scope.updateMTUsers = function (indx) {
        $scope.MTUsersSubmitted = true;
        if ($scope.formMTUsers.$invalid == true) return;
        $scope.EditMode = false;
        $scope.MTUsers = {};
    };

    $scope.sendNotification = function () {
        $http({
            method: 'POST',
            url: 'api/MT/SendNotification',
            data: JSON.stringify($scope.MT)
        }).success(function (data) {
            swal({ title: "Invitation Sent Successfully!", type: "success", timer: 1000, showConfirmButton: false });
        });
    };
    $scope.sendNotificationEmail = function () {
        $http({
            method: 'POST',
            url: 'api/MT/SendNotificationEmail',
            data: JSON.stringify($scope.MT)
        }).success(function (data) {
            swal({ title: "Invitation Sent Successfully!", type: "success", timer: 1000, showConfirmButton: false });
        });
    };
    $scope.timelist = [];
    $scope.bindTime = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetTimeList', Data: null })
        }).success(function (data) {
            $scope.timelist = data;
        });
    }
    $scope.bindTime();
})
.controller('MOMCtrl', function ($scope, $http, $location, $routeParams) {
    var MTID = $routeParams.MTID;
    $scope.MT = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.MTSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.MTSubmitted = true;
        if ($scope.formMT.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }

        $http({
            method: 'POST',
            url: 'api/MT/UpdateMOM',
            data: JSON.stringify($scope.MT)
        }).success(function (MT) {
            swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
        });
    };

    $scope.cancel = function () {
        $location.path('/MTList');
    }

    $scope.userlist = [];
    $scope.bindUser = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetUserListByType', Data: null, query: $scope.MT.AT })
        }).success(function (data) {
            $scope.userlist = data;
        });
    };

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/MT/' + MTID
        }).success(function (MT) {
            $scope.MT = JSON.parse(MT);
            $scope.bindUser();
        });
    }, 100);
    $scope.MTUsers = {};
    $scope.MTUsersSubmitted = false;
    var MTUsers = [];
    $scope.editMTUsers = function (indx) {
        $scope.EditMode = true;
        $scope.MTUsers = $scope.MT.MTUsersList[indx];
        MTUsers = angular.copy($scope.MT.MTUsersList);
    };
    $scope.deleteMTUsers = function (indx) {
        if (confirm('Are you sure want to delete?') == true) {
            $scope.MT.MTUsersList.splice(indx, 1);
        }
    };
    $scope.newMTUsers = function () {
        $scope.EditMode = true;
        $scope.MTUsersSubmitted = false;
        MTUsers = angular.copy($scope.MT.MTUsersList);
        $scope.MTUsers = {};
        $scope.MT.MTUsersList.push($scope.MTUsers);
    };
    $scope.cancelMTUsers = function () {
        $scope.EditMode = false;
        $scope.MTUsers = {};
        angular.copy(MTUsers, $scope.MT.MTUsersList);
    };
    $scope.updateMTUsers = function (indx) {
        $scope.MTUsersSubmitted = true;
        if ($scope.formMTUsers.$invalid == true) return;
        $scope.EditMode = false;
        $scope.MTUsers = {};
    };
    $scope.sendNotification = function () {
        $http({
            method: 'POST',
            url: 'api/MT/SendMOM',
            data: JSON.stringify($scope.MT)
        }).success(function (data) {
            swal({ title: "Minutes of Meeting Sent Successfully!", type: "success", timer: 1000, showConfirmButton: false });
        });
    };
    $scope.sendNotificationSMS = function () {
        $http({
            method: 'POST',
            url: 'api/MT/SendMOMSMS',
            data: JSON.stringify($scope.MT)
        }).success(function (data) {
            if (data == "Success") {
                swal({ title: "Minutes of Meeting SMS Sent Successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
            else {
                swal({ title: "Minutes of Meeting SMS not Sent Successfully!", type: "error", timer: 1000, showConfirmButton: false });
            }
        });
    };

    $scope.showFileUploader = function () {
        openFileUploader($scope.fileUploaded, 'FileUploadHandler.ashx?MTID=' + $scope.MT.MTID, false);
    };
    
    $scope.fileUploaded = function (result) {
        var resultArr = result.split('|');
        if (resultArr.length > 1) {
            $scope.MT.FileGUID = resultArr[0];
            $scope.MT.FileName = resultArr[1];
            $scope.MT.MOMFileID = resultArr[2];
        }
    };
    $scope.removeFile = function () {
        $http({
            method: 'POST',
            url: 'api/MT/DeleteMOM',
            data: JSON.stringify($scope.MT)
        }).success(function (data) {
            if (data == "") {
                $scope.MT.FileGUID = null;
                $scope.MT.FileName = null;
                $scope.MT.MOMFileID = null;
                swal({ title: "File Deleted Successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
            else {
                swal({ title: "File not Deleted Successfully!", type: "error", timer: 1000, showConfirmButton: false });
            }
        });
    };
});

