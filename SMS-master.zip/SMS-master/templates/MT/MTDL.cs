using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;
using System.Text;

namespace SampleAngularDL
{
    public class MTDL
    {
        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public MTDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public MT Load(int MTID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            MT objMT = new MT();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get MT
                var resultMT = dc.ExecuteQuery<MT>("exec Get_MT {0}", MTID).ToList();
                if (resultMT.Count > 0)
                {
                    objMT = resultMT[0];
                }
                //Get MTUsers
                var resultMTUsers = dc.ExecuteQuery<string>("Select Convert(varchar,UserID) as UserID from MTUsers where MTID = {0}", MTID).ToList();
                objMT.MTUsers = resultMTUsers;
                objMT.Types = new System.Collections.Hashtable();
                objMT.Types["MTUsersList"] = new MTUsers();
                dc.Dispose();
                return objMT;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllMT()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_MT", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(MT objMT)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update MT
                UpdateMT(objMT, trn);
                if (objMT.MTID > 0)
                {

                    //Update MTUsers
                    DeleteMTUsers(Convert.ToInt32(objMT.MTID), trn);
                    foreach (string UserID in objMT.MTUsers)
                    {
                        InsertIntoMTUsers(UserID, Convert.ToInt32(objMT.MTID), trn);
                    }
                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int MTID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete MTUsers
                DeleteMTUsers(MTID, trn);
                //Delete MT
                DeleteMT(MTID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateMT(MT objMT, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_MT", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;

                cmd.Parameters.Add("@Agenda", SqlDbType.VarChar, 1000).Value = objMT.Agenda;
                cmd.Parameters.Add("@AT", SqlDbType.VarChar, 10).Value = objMT.AT;
                cmd.Parameters.Add("@MDate", SqlDbType.DateTime).Value = objMT.MDate;
                cmd.Parameters.Add("@MOM", SqlDbType.NVarChar, 4000).Value = objMT.MOM;
                cmd.Parameters.Add("@MTID", SqlDbType.Int).Value = objMT.MTID;
                cmd.Parameters["@MTID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@MTime", SqlDbType.VarChar,10).Value = objMT.MTime;
                cmd.Parameters.Add("@Sub", SqlDbType.VarChar, 250).Value = objMT.Sub;
                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = objMT.SocID;

                cmd.ExecuteNonQuery();

                //after updating the MT, update MTID
                objMT.MTID = Convert.ToInt32(cmd.Parameters["@MTID"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteMT(int MTID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from MT where MTID=@MTID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@MTID", SqlDbType.Int).Value = MTID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        public bool DeleteMTUsers(int MTID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from MTUsers where MTID=@MTID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@MTID", SqlDbType.Int).Value = MTID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        public bool InsertIntoMTUsers(string UserID,int MTID, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Into_MTUsers", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Transaction = trn;


                cmd.Parameters.Add("@MTID", SqlDbType.Int).Value = MTID;
                cmd.Parameters.Add("@UserID", SqlDbType.Int).Value = Convert.ToInt32(UserID);

                cmd.ExecuteNonQuery();

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        #endregion
    }
}
