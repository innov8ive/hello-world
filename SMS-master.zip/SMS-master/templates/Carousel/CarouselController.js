var app = angular.module('myApp');

app.controller('CarouselListCtrl', function ($scope, $http, $location, GridData) {

    $scope = readyAngularGrid($scope, $http, 'api/CarouselList', 'ID', GridData, 'Carousel');
    $scope.gridOptions.columnDefs = [

    { displayName: 'Title', field: 'Title' },
    { displayName: 'Details', field: 'Details' },
    ];
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchCarousel = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };
    $scope.newCarousel = function () {
        saveGridData($scope, GridData, 'Carousel');
        $location.path('/Carousel/0');
    };
    $scope.editCarousel = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            saveGridData($scope, GridData, 'Carousel');
            $location.path('/Carousel/' + selected[0].ID);
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.deleteCarousel = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'DELETE',
                url: 'api/Carousel/' + selected[0].ID
            }).success(function (result) {
                if (result == true)
                    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
            });
        }
        else {
            alert('Please select a record to edit.');
        }
    };
})

.controller('CarouselCtrl', function ($scope, $http, $location, $routeParams) {
    var ID = $routeParams.ID;
    $scope.Carousel = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.CarouselSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.CarouselSubmitted = true;
        if ($scope.formCarousel.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/Carousel', $scope.Carousel, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.Carousel = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/CarouselList');
    }


    $scope.removePhoto = function () {
        if (confirm('Are you sure, want to remove photo?')) {
            $http({
                method: 'POST',
                url: 'api/Carousel/RemovePhoto/',
                data: JSON.stringify($scope.Carousel.ID + '.' + $scope.Carousel.ImageUrl)
            }).success(function (result) {
                if (result == 'true')
                    $scope.Carousel.ImageUrl = '';
            });
        }
    };
    $scope.uploadPhoto = function () {
        AttachImage($scope.photoUploaded);
    };
    $scope.photoUploaded = function (fileGUIDName, fileName, fileID) {
        $scope.Carousel.ImageUrl = fileGUIDName;
        $http({
            method: 'POST',
            url: 'api/Carousel/AttachPhoto/',
            data: JSON.stringify($scope.Carousel.ID + '.' + $scope.Carousel.ImageUrl)
        }).success(function (result) {

        });
    };

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/Carousel/' + ID
        }).success(function (Carousel) {
            $scope.Carousel = JSON.parse(Carousel);
        });
    }, 100);
});
app.controller('SiteHomeController', function ($scope, $http, $location, User) {
    $scope.CarouselList = [];
    $scope.getCarousel = function () {
        $http({
            method: 'POST',
            url: 'api/Carousel/GetCarousel/'
        }).success(function (result) {
            $scope.CarouselList = result;
            if ($scope.CarouselList != null && $scope.CarouselList.length > 0) {
                window.setTimeout(function () {
                    $('#myCarousel').carousel({
                        interval: 3000,
                        cycle: true
                    });
                }, 500);
                $scope.showAd = User.ShowAd;
                User.ShowAd = false;
            }
        });
    }
    $scope.getCarousel();


});