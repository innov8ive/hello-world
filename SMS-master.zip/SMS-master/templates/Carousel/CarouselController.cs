using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;
using System.IO;
using System.Web.Http.Cors;

namespace SampleAngular.Api
{
    public class CarouselController : ApiController
    {
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/Carousel/GetCarousel/")]
        [HttpPost]
        public DataTable GetCarousels([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            DataTable dt = Common.GetDBResult("Select * from Carousel where CategoryID=" + objLoggedUser.SocID);

            return dt;
        }

        // GET api/Carousel
        [Route("api/CarouselList/")]
        [HttpPost]
        public AngularGridData GetCarousel([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.Advertisement, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = "Select * from Carousel where CategoryID=" + objLoggedUser.SocID;
            objAngularDataBinder.ValueField = "ID";
            return objAngularDataBinder.GetData();
        }

        // GET api/Carousel/Id
        [Route("api/Carousel/{Id}")]
        public string GetCarousel(int Id)
        {
            Common.IsValidForm(Constants.Forms.Advertisement, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            CarouselBL objCarouselBL = new CarouselBL(Common.GetConString());
            objCarouselBL.Load(Id);
            Carousel objCarousel = objCarouselBL.Data;

            if (Common.ToInt(objCarousel.CategoryID) > 0 && objCarousel.CategoryID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            return JsonConvert.SerializeObject(objCarouselBL.Data);
        }

        // POST api/Carousel/
        public string Post([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.Advertisement, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            Carousel objCarousel = objJObject.ToObject<Carousel>();
            CarouselBL objCarouselBL = new CarouselBL(Common.GetConString());
            objCarouselBL.Data = objCarousel;
            if(objCarouselBL.IsNew)
            {
                objCarousel.CategoryID = objLoggedUser.SocID;
            }
            CarouselValidator validator = new CarouselValidator();
            ValidationResult results = validator.Validate(objCarousel);

            if (results.IsValid)
            {
                objCarouselBL.Update();
                return JsonConvert.SerializeObject(objCarouselBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        // DELETE api/Carousel/5
        [Route("api/Carousel/{Id}")]
        [HttpDelete]
        public bool Delete(int Id)
        {
            Common.IsValidForm(Constants.Forms.Advertisement, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);


            CarouselBL objCarouselBL = new CarouselBL(Common.GetConString());
            objCarouselBL.Load(Id);
            Carousel objCarousel = objCarouselBL.Data;

            if (Common.ToInt(objCarousel.CategoryID) > 0 && objCarousel.CategoryID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            try
            {
                string filePath = HttpContext.Current.Server.MapPath("~/images/profile") + "/" + objCarousel.ImageUrl;
                File.Delete(filePath);
            }
            catch { }
            return objCarouselBL.Delete(Id);
        }

        [Route("api/Carousel/RemovePhoto/")]
        [HttpPost]
        public string CarouselRemovePhoto([FromBody]dynamic param)
        {
            int ID = 0;
            string imageUrl;
            string data = param;
            if (data.Contains("."))
            {
                ID = Common.ToInt(data.Substring(0, data.IndexOf(".")));
                imageUrl = data.Substring(data.IndexOf(".") + 1);
                int count = Common.ExecuteNonQuery("Update Carousel Set ImageUrl='' where ID=@ID", "@ID", SqlDbType.Int, Common.ToInt(ID));
                if (count > 0)
                {
                    try
                    {
                        string filePath = HttpContext.Current.Server.MapPath("~/images/profile") + "/" + imageUrl;
                        File.Delete(filePath);
                    }
                    catch { }
                    return "true";
                }
                else
                {
                    return "false";
                }
            }
            return "false";
        }
        [Route("api/Carousel/AttachPhoto/")]
        [HttpPost]
        public string CarouselAttachPhoto([FromBody]dynamic param)
        {
            int ID = 0;
            string imageUrl;
            string data = param;
            if (data.Contains("."))
            {
                ID = Common.ToInt(data.Substring(0, data.IndexOf(".")));
                imageUrl = data.Substring(data.IndexOf(".") + 1);

                int count = Common.ExecuteNonQuery("Update Carousel Set ImageUrl=@ImageUrl where ID=@ID"
                    , "@ID", SqlDbType.Int, ID
                    , "@ImageUrl", SqlDbType.VarChar, imageUrl);
                if (count > 0)
                {
                    return imageUrl;
                }
                else
                {
                    return String.Empty;
                }
            }
            return String.Empty;
        }
    }
    public class CarouselValidator : AbstractValidator<Carousel>
    {
        public CarouselValidator()
        {
            RuleFor(obj => obj.Details).NotEmpty();
            RuleFor(obj => obj.ImageUrl).NotEmpty();
            RuleFor(obj => obj.Title).NotEmpty();
        }
    }
}

