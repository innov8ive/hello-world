using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
[Serializable]
public class CarouselBL
{

#region Declaration
private string connectionString;
Carousel _Carousel;
public Carousel Data
{
get { return _Carousel; }
set { _Carousel = value; }
}
public bool IsNew
{
get { return (_Carousel.ID <= 0 || _Carousel.ID ==null); }
}
#endregion

#region Constructor
public CarouselBL(string conString)
{
connectionString = conString;
}
#endregion

#region Main Methods
private CarouselDL CreateDL()
{
return new CarouselDL(connectionString);
}
public void New()
{
_Carousel = new Carousel();
}
public void Load(int ID)
{
var CarouselObj = this.CreateDL();
_Carousel = ID <= 0 ? CarouselObj.Load(-1) : CarouselObj.Load(ID);
}
public DataTable LoadAllCarousel()
{
var CarouselDLObj = CreateDL();
return CarouselDLObj.LoadAllCarousel();
}
public bool Update()
{
var CarouselDLObj = CreateDL();
return CarouselDLObj.Update(this.Data);
}
public bool Delete(int ID)
{
var CarouselDLObj = CreateDL();
return CarouselDLObj.Delete(ID);
}
#endregion
}
}
