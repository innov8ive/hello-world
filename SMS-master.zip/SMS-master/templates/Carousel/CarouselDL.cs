using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
    public class CarouselDL
    {

        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public CarouselDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public Carousel Load(int ID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            Carousel objCarousel = new Carousel();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get Carousel
                var resultCarousel = dc.ExecuteQuery<Carousel>("exec Get_Carousel {0}", ID).ToList();
                if (resultCarousel.Count > 0)
                {
                    objCarousel = resultCarousel[0];
                }
                dc.Dispose();
                return objCarousel;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllCarousel()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_Carousel", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(Carousel objCarousel)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update Carousel
                UpdateCarousel(objCarousel, trn);
                if (objCarousel.ID > 0)
                {

                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int ID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete Carousel
                DeleteCarousel(ID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateCarousel(Carousel objCarousel, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_Carousel", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@CategoryID", SqlDbType.Int).Value = objCarousel.CategoryID;
                cmd.Parameters.Add("@Details", SqlDbType.VarChar, 250).Value = objCarousel.Details;
                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = objCarousel.ID;
                cmd.Parameters["@ID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@ImageUrl", SqlDbType.VarChar, 50).Value = objCarousel.ImageUrl;
                cmd.Parameters.Add("@Title", SqlDbType.VarChar, 100).Value = objCarousel.Title;
                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = objCarousel.SocID;

                cmd.ExecuteNonQuery();

                //after updating the Carousel, update ID
                objCarousel.ID = Convert.ToInt32(cmd.Parameters["@ID"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteCarousel(int ID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from Carousel where ID=@ID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = ID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        #endregion
    }
}
