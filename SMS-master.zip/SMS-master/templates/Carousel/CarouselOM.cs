using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

    [Serializable]
    [Table(Name = "dbo.Carousel")]
    public class Carousel
    {

        private System.Nullable<int> _CategoryID;
        private string _Details;
        private System.Nullable<int> _ID;
        private string _ImageUrl;
        private string _Title;
        private System.Nullable<int> _SocID;

        [Column(Storage = "_SocID")]
        public System.Nullable<int> SocID
        {
            get { return _SocID; }
            set { _SocID = value; }
        }


        [Column(Storage = "_CategoryID")]
        public System.Nullable<int> CategoryID
        {
            get
            {
                return _CategoryID;
            }
            set
            {
                _CategoryID = value;
            }
        }



        [Column(Storage = "_Details")]
        public string Details
        {
            get
            {
                return _Details;
            }
            set
            {
                _Details = value;
            }
        }



        [Column(Storage = "_ID")]
        public System.Nullable<int> ID
        {
            get
            {
                return _ID;
            }
            set
            {
                _ID = value;
            }
        }



        [Column(Storage = "_ImageUrl")]
        public string ImageUrl
        {
            get
            {
                return _ImageUrl;
            }
            set
            {
                _ImageUrl = value;
            }
        }



        [Column(Storage = "_Title")]
        public string Title
        {
            get
            {
                return _Title;
            }
            set
            {
                _Title = value;
            }
        }

    }


}
