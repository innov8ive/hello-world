using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

    [Serializable]
    [Table(Name = "dbo.CP")]
    public class CP
    {
        private string _BN;
        private System.Nullable<int> _CPID;
        private string _MD;
        private System.Nullable<int> _RMID;
        private string _SLName;
        private System.Nullable<int> _SocID;
        private string _VN;
        private string _ParkingType;
        private System.Nullable<decimal> _Charges;

        [Column(Storage = "_Charges")]
        public System.Nullable<decimal> Charges
        {
            get { return _Charges; }
            set { _Charges = value; }
        }

        [Column(Storage = "_ParkingType")]
        public string ParkingType
        {
            get { return _ParkingType; }
            set { _ParkingType = value; }
        }

        [Column(Storage = "_BN")]
        public string BN
        {
            get
            {
                return _BN;
            }
            set
            {
                _BN = value;
            }
        }

        [Column(Storage = "_CPID")]
        public System.Nullable<int> CPID
        {
            get
            {
                return _CPID;
            }
            set
            {
                _CPID = value;
            }
        }

        [Column(Storage = "_MD")]
        public string MD
        {
            get
            {
                return _MD;
            }
            set
            {
                _MD = value;
            }
        }
        
        [Column(Storage = "_RMID")]
        public System.Nullable<int> RMID
        {
            get
            {
                return _RMID;
            }
            set
            {
                _RMID = value;
            }
        }

        [Column(Storage = "_SLName")]
        public string SLName
        {
            get
            {
                return _SLName;
            }
            set
            {
                _SLName = value;
            }
        }

        [Column(Storage = "_SocID")]
        public System.Nullable<int> SocID
        {
            get
            {
                return _SocID;
            }
            set
            {
                _SocID = value;
            }
        }

        [Column(Storage = "_VN")]
        public string VN
        {
            get
            {
                return _VN;
            }
            set
            {
                _VN = value;
            }
        }
    }
}
