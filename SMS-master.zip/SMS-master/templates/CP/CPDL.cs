using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
    public class CPDL
    {
        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public CPDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public CP Load(int CPID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            CP objCP = new CP();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get CP
                var resultCP = dc.ExecuteQuery<CP>("exec Get_CP {0}", CPID).ToList();
                if (resultCP.Count > 0)
                {
                    objCP = resultCP[0];
                }
                dc.Dispose();
                return objCP;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllCP()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_CP", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(CP objCP)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update CP
                UpdateCP(objCP, trn);
                if (objCP.CPID > 0)
                {

                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int CPID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete CP
                DeleteCP(CPID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateCP(CP objCP, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_CP", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@BN", SqlDbType.VarChar, 50).Value = objCP.BN;
                cmd.Parameters.Add("@CPID", SqlDbType.Int).Value = objCP.CPID;
                cmd.Parameters["@CPID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@MD", SqlDbType.VarChar, 50).Value = objCP.MD;
                cmd.Parameters.Add("@RMID", SqlDbType.Int).Value = objCP.RMID;
                cmd.Parameters.Add("@SLName", SqlDbType.VarChar, 50).Value = objCP.SLName;
                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = objCP.SocID;
                cmd.Parameters.Add("@VN", SqlDbType.VarChar, 20).Value = objCP.VN;
                cmd.Parameters.Add("@ParkingType", SqlDbType.VarChar, 20).Value = objCP.ParkingType;
                cmd.Parameters.Add("@Charges", SqlDbType.Decimal).Value = objCP.Charges;

                cmd.ExecuteNonQuery();

                //after updating the CP, update CPID
                objCP.CPID = Convert.ToInt32(cmd.Parameters["@CPID"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteCP(int CPID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from CP where CPID=@CPID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@CPID", SqlDbType.Int).Value = CPID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        #endregion
    }
}
