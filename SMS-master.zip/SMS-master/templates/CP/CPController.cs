using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;
using System.Web.Http.Cors;
using System.Text;

namespace SampleAngular.Api
{
    public class CPController : ApiController
    {
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/UpdateCPListing/")]
        [HttpPost]
        public List<CP> UpdateCPListing([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.NormalUser, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JArray objJObject = value;
            List<CP> objCPList = objJObject.ToObject<List<CP>>();

            foreach (CP objCP in objCPList)
            {
                Common.ExecuteNonQuery("Update CP set BN=@BN,MD=@MD,VN=@VN where CPID=@CPID and RMID=@RMID",
                    "@BN", SqlDbType.VarChar, objCP.BN,
                    "@MD", SqlDbType.VarChar, objCP.MD,
                    "@VN", SqlDbType.VarChar, objCP.VN,
                    "@CPID", SqlDbType.Int, objCP.CPID,
                    "@RMID", SqlDbType.VarChar, objCP.RMID);
            }

            return objCPList;
        }

        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/CPListing/")]
        [HttpPost]
        public DataTable CPListing([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.NormalUser, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            DataTable dt = Common.GetDBResultParameterized(@"Select * from CP
where exists (select 1 from UserRooms U where U.RoomID=CP.RMID and U.SocID=CP.SocID and U.UserID=@UserID)"
                , "@UserID", SqlDbType.Int, objLoggedUser.UserID);

            return dt;
        }

        // GET api/CP
        [Route("api/CPList/")]
        [HttpPost]
        public AngularGridData GetCP([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.ParkingManager, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            StringBuilder query = new StringBuilder(@"Select CP.*,W.WingName+' '+R.RoomNo as RMNo from CP 
left join Rooms R ON CP.RMID=R.RoomID 
left join Wings W ON R.WingID=W.WingID where CP.SocID=" + objLoggedUser.SocID);
            Hashtable ht = new Hashtable();
            if (!String.IsNullOrEmpty(objAngularGrid.SearchText))
            {
                query.Append(" and (W.WingName like '%'+@Text+'%' OR R.RoomNo like '%'+@Text+'%' OR SLName like '%'+@Text+'%' OR MD like '%'+@Text+'%' OR VN like '%'+@Text+'%'  OR BN like '%'+@Text+'%')");
       
                ht["@Text"] = objAngularGrid.SearchText;
                objAngularDataBinder.Parameters = ht;
            }

            objAngularDataBinder.Query = query.ToString();
            objAngularDataBinder.ValueField = "CPID";
            return objAngularDataBinder.GetData();
        }
        [Route("api/CPDetails/")]
        [HttpPost]
        public DataTable CPDetails([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.ParkingManager, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            DataTable dt = Common.GetDBResult(@"Select CP.*,W.WingName+' '+R.RoomNo as RMNo from CP 
left join Rooms R ON CP.RMID=R.RoomID 
left join Wings W ON R.WingID=W.WingID where CP.CPID=" + Common.ToInt(value.CPID));

            return dt;
        }

        // GET api/CP/Id
        [Route("api/CP/{Id}")]
        public string GetCP(int Id)
        {
            Common.IsValidForm(Constants.Forms.ParkingManager, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            CPBL objCPBL = new CPBL(Common.GetConString());
            objCPBL.Load(Id);

            CP objCP = objCPBL.Data;
            if (Common.ToInt(objCP.SocID) > 0 && objCP.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            return JsonConvert.SerializeObject(objCPBL.Data);
        }

        // POST api/CP/
        public string Post([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.ParkingManager, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            CP objCP = objJObject.ToObject<CP>();
            CPBL objCPBL = new CPBL(Common.GetConString());
            objCPBL.Data = objCP;

            CPValidator validator = new CPValidator();
            ValidationResult results = validator.Validate(objCP);
            if (objCPBL.IsNew)
            {
                objCP.SocID = objLoggedUser.SocID;
            }

            if (!Common.IsUniqueInTable("CP", "SLName",
               Common.ToString(objCP.SLName),
               "CPID", Common.ToInt(objCP.CPID).ToString(), "SocID=" + Common.ToInt(objCP.SocID).ToString()))
            {
                results.Errors.Add(new ValidationFailure("SLName", "This Slot Name is already exists"));
            }

            if (objCP.RMID > 0)
            {
                if (String.IsNullOrEmpty(objCP.MD))
                    results.Errors.Add(new ValidationFailure("MD", "Please enter Vehicle Model"));
                if (String.IsNullOrEmpty(objCP.VN))
                    results.Errors.Add(new ValidationFailure("VN", "Please enter Vehicle No."));
                if (String.IsNullOrEmpty(objCP.BN))
                    results.Errors.Add(new ValidationFailure("BN", "Please enter Vehicle Brand"));
            }

            if (results.IsValid)
            {
                objCPBL.Update();
                return JsonConvert.SerializeObject(objCPBL.Data);
            }
            return JsonConvert.SerializeObject(results.Errors);
        }

        // DELETE api/CP/5
        [Route("api/CP/{Id}")]
        [HttpDelete]
        public bool Delete(int Id)
        {
            Common.IsValidForm(Constants.Forms.ParkingManager, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            CPBL objCPBL = new CPBL(Common.GetConString());
            objCPBL.Load(Id);

            CP objCP = objCPBL.Data;
            if (Common.ToInt(objCP.SocID) > 0 && objCP.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            return objCPBL.Delete(Id);
        }
    }
    public class CPValidator : AbstractValidator<CP>
    {
        public CPValidator()
        {
            RuleFor(obj => obj.SLName).NotEmpty();
        }
    }
}

