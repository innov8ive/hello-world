using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
    [Serializable]
    public class CPBL
    {

        #region Declaration
        private string connectionString;
        CP _CP;
        public CP Data
        {
            get { return _CP; }
            set { _CP = value; }
        }
        public bool IsNew
        {
            get { return (_CP.CPID <= 0 || _CP.CPID == null); }
        }
        #endregion

        #region Constructor
        public CPBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private CPDL CreateDL()
        {
            return new CPDL(connectionString);
        }
        public void New()
        {
            _CP = new CP();
        }
        public void Load(int CPID)
        {
            var CPObj = this.CreateDL();
            _CP = CPID <= 0 ? CPObj.Load(-1) : CPObj.Load(CPID);
        }
        public DataTable LoadAllCP()
        {
            var CPDLObj = CreateDL();
            return CPDLObj.LoadAllCP();
        }
        public bool Update()
        {
            var CPDLObj = CreateDL();
            return CPDLObj.Update(this.Data);
        }
        public bool Delete(int CPID)
        {
            var CPDLObj = CreateDL();
            return CPDLObj.Delete(CPID);
        }
        #endregion
    }
}
