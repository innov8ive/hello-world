var app = angular.module('myApp');
app.controller('CPListingCtrl', function ($scope, $http, $location) {
    $scope.CPList = [];

    $scope.searchCP = function () {
        $http({
            method: 'POST',
            url: 'api/CPListing/',
            data: JSON.stringify($scope.filter)
        }).success(function (result) {
            $scope.CPList = result;
        });
    };

    $scope.update = function () {
        $http({
            method: 'POST',
            url: 'api/UpdateCPListing/',
            data: JSON.stringify($scope.CPList)
        }).success(function (result) {
            //$scope.CPList = result;
            swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
        });
    };
    window.setTimeout(function () { $scope.searchCP(); }, 200);
});
app.controller('CPListCtrl', function ($scope, $http, $location, GridData) {

    $scope = readyAngularGrid($scope, $http, 'api/CPList', 'CPID', GridData, 'CP');
    $scope.gridOptions.columnDefs = [

    { displayName: 'Slot Name', field: 'SLName' },
    { displayName: 'Parking Type', field: 'ParkingType' },
    { displayName: 'Assigned To', field: 'RMNo' },
    { displayName: 'Vehicle No.', field: 'VN' },
    { displayName: 'Vehicle Brand', field: 'BN' },
    { displayName: 'Vehicle Model', field: 'MD' }, 
    { displayName: 'Parking Charges', field: 'Charges' }, ];
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchCP = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };
    $scope.newCP = function () {
        saveGridData($scope, GridData, 'CP');
        $location.path('/CP/0');
    };
    $scope.editCP = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            saveGridData($scope, GridData, 'CP');
            $location.path('/CP/' + selected[0].CPID);
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.deleteCP = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'DELETE',
                url: 'api/CP/' + selected[0].CPID
            }).success(function (result) {
                if (result == true)
                    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
            });
        }
        else {
            alert('Please select a record to edit.');
        }
    };
})

.controller('CPCtrl', function ($scope, $http, $location, $routeParams,User) {
    var CPID = $routeParams.CPID;
    $scope.CP = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.CPSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.CPSubmitted = true;
        if ($scope.formCP.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/CP', $scope.CP, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.CP = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/CPList');
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/CP/' + CPID
        }).success(function (CP) {
            $scope.CP = JSON.parse(CP);
        });
    }, 100);

    $scope.rmlist = [];
    $scope.bindRM = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetRoomList', Data: null, query: User.SocID })
        }).success(function (data) {
            $scope.rmlist = data;
        });
    }
    $scope.bindRM();
});
