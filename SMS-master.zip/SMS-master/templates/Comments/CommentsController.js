var app = angular.module('myApp');

app.controller('CommentsListCtrl', function ($scope, $http, $location, GridData) {

    $scope = readyAngularGrid($scope, $http, 'api/CommentsList', 'CommentID', GridData, 'Comments');
    $scope.gridOptions.columnDefs = [

    { displayName: 'CommentDate', field: 'CommentDate', cellFilter: 'date:\'dd-MMM-yyyy\'' },
    { displayName: 'CommentedBy', field: 'CommentedBy' },
    { displayName: 'ForumID', field: 'ForumID' },
    { displayName: 'Remarks', field: 'Remarks' }, ];
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchComments = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };
    $scope.newComments = function () {
        saveGridData($scope, GridData, 'Comments');
        $location.path('/Comments/0');
    };
    $scope.editComments = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            saveGridData($scope, GridData, 'Comments');
            $location.path('/Comments/' + selected[0].CommentID);
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.deleteComments = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'DELETE',
                url: 'api/Comments/' + selected[0].CommentID
            }).success(function (result) {
                if (result == true)
                    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
            });
        }
        else {
            alert('Please select a record to edit.');
        }
    };
})

.controller('CommentsCtrl', function ($scope, $http, $location, $routeParams) {
    var CommentID = $routeParams.CommentID;
    $scope.Comments = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.CommentsSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.CommentsSubmitted = true;
        if ($scope.formComments.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/Comments', $scope.Comments, config)
        .success(function (data, status, headers, config) {

            $scope.loading = false;
            var result = data;
            if (result.ErrorCode == 1)
                $scope.ErrorMessages = result.data;
            else {
                $scope.ErrorMessages = [];
                $scope.Comments = result.data;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/CommentsList');
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/Comments/' + CommentID
        }).success(function (Comments) {
            $scope.Comments = JSON.parse(Comments);
        });
    }, 100);
});
