using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
    public class CommentsDL
    {

        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public CommentsDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public Comments Load(int CommentID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            Comments objComments = new Comments();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get Comments
                var resultComments = dc.ExecuteQuery<Comments>("exec Get_Comments {0}", CommentID).ToList();
                if (resultComments.Count > 0)
                {
                    objComments = resultComments[0];
                }
                dc.Dispose();
                return objComments;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }

        public List<CommentDetails> LoadAllComments(string ForumID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            var dc = new DataContext(SqlCon);
            try
            {
                //Get Comments
                var resultComments = dc.ExecuteQuery<CommentDetails>("Select C.CommentID,C.Remarks,C.CommentDate,U.FirstName+ISNULL(' '+U.LastName,'') as CommentedByName,U.ImageUrl as CommentedByImageUrl from Comments C inner join Users U ON C.CommentedBy=U.UserID where ForumID={0} order by C.CommentDate", ForumID).ToList();
                dc.Dispose();
                return resultComments;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public List<int> LoadAllLikes(string ForumID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            var dc = new DataContext(SqlCon);
            try
            {
                //Get Comments
                var resultComments = dc.ExecuteQuery<int>("Select UserID from Likes where ForumID={0}", ForumID).ToList();
                dc.Dispose();
                return resultComments;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public bool Update(Comments objComments)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update Comments
                UpdateComments(objComments, trn);
                if (objComments.CommentID > 0)
                {

                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int CommentID, string forumID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete Comments
                DeleteComments(CommentID, forumID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateComments(Comments objComments, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_Comments", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@CommentDate", SqlDbType.DateTime).Value = objComments.CommentDate;
                cmd.Parameters.Add("@CommentedBy", SqlDbType.Int).Value = objComments.CommentedBy;
                cmd.Parameters.Add("@CommentID", SqlDbType.Int).Value = objComments.CommentID;
                cmd.Parameters["@CommentID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@ForumID", SqlDbType.VarChar, 36).Value = objComments.ForumID;
                cmd.Parameters.Add("@Remarks", SqlDbType.VarChar, 500).Value = objComments.Remarks;

                cmd.ExecuteNonQuery();

                //after updating the Comments, update CommentID
                objComments.CommentID = Convert.ToInt32(cmd.Parameters["@CommentID"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool Like(int UserID, string ForumID)
        {
            bool liked = false;
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("LikeForum", con);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@UserID", SqlDbType.Int).Value = UserID;
                cmd.Parameters.Add("@ForumID", SqlDbType.VarChar, 36).Value = ForumID;
                cmd.Parameters.Add("@Liked", SqlDbType.Bit).Value = liked;
                cmd.Parameters["@Liked"].Direction = ParameterDirection.InputOutput;

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                liked = Convert.ToBoolean(cmd.Parameters["@Liked"].Value);

                return liked;
            }
            catch
            {
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool DeleteComments(int CommentID,string forumID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from Comments where CommentID=@CommentID and ForumID=@ForumID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@CommentID", SqlDbType.Int).Value = CommentID;
                cmd.Parameters.Add("@ForumID", SqlDbType.VarChar, 36).Value = forumID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        #endregion
    }
}
