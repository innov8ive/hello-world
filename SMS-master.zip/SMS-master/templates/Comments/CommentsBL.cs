using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
    [Serializable]
    public class CommentsBL
    {

        #region Declaration
        private string connectionString;
        Comments _Comments;
        public Comments Data
        {
            get { return _Comments; }
            set { _Comments = value; }
        }
        public bool IsNew
        {
            get { return (_Comments.CommentID <= 0 || _Comments.CommentID == null); }
        }
        #endregion

        #region Constructor
        public CommentsBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private CommentsDL CreateDL()
        {
            return new CommentsDL(connectionString);
        }
        public void New()
        {
            _Comments = new Comments();
        }
        public void Load(int CommentID)
        {
            var CommentsObj = this.CreateDL();
            _Comments = CommentID <= 0 ? CommentsObj.Load(-1) : CommentsObj.Load(CommentID);
        }
        public List<CommentDetails> LoadAllComments(string ForumID)
        {
            var CommentsDLObj = CreateDL();
            return CommentsDLObj.LoadAllComments(ForumID);
        }
        public List<int> LoadAllLikes(string ForumID)
        {
            var CommentsDLObj = CreateDL();
            return CommentsDLObj.LoadAllLikes(ForumID);
        }
        public bool Update()
        {
            var CommentsDLObj = CreateDL();
            return CommentsDLObj.Update(this.Data);
        }
        public bool Delete(int CommentID, string forumID)
        {
            var CommentsDLObj = CreateDL();
            return CommentsDLObj.Delete(CommentID, forumID);
        }
        public bool Like(int UserID, string ForumID)
        {
            var CommentsDLObj = CreateDL();
            return CommentsDLObj.Like(UserID, ForumID);
        }
        #endregion
    }
}
