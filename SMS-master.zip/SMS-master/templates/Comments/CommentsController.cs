using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;

namespace SampleAngular.Api
{
    public class CommentsController : ApiController
    {
        // GET api/Comments
        [Route("api/CommentsList/")]
        [HttpPost]
        public string GetComments([FromBody]dynamic forumID)
        {
            DataTable dt = Common.GetDBResultParameterized("Select * from Comments where ForumID=@ForumID",
                "@ForumID", SqlDbType.VarChar, forumID.forumID.ToString());
            return JsonConvert.SerializeObject(dt, Formatting.Indented);
        }

        // GET api/Comments/Id
        [Route("api/Comments/{Id}")]
        public string GetComments(int Id)
        {
            CommentsBL objCommentsBL = new CommentsBL(Common.GetConString());
            objCommentsBL.Load(Id);
            return JsonConvert.SerializeObject(objCommentsBL.Data);
        }

        // POST api/Comments/
        public object Post([FromBody]dynamic value)
        {
            PostResponse objPostResponse = new PostResponse();
            //Common.IsValidForm(Constants.Forms.Forum, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser == null) throw new HttpResponseException(HttpStatusCode.Unauthorized);

            JObject objJObject = value;
            Comments objComments = objJObject.ToObject<Comments>();
            CommentsBL objCommentsBL = new CommentsBL(Common.GetConString());

            CommentsValidator validator = new CommentsValidator();
            ValidationResult results = validator.Validate(objComments);

            if (results.IsValid)
            {
                objComments.CommentedBy = objLoggedUser.UserID;
                objComments.CommentDate = DateTime.Now;
                objCommentsBL.Data = objComments;
                objCommentsBL.Update();
                objPostResponse.ErrorCode = 0;
                objPostResponse.data = JsonConvert.DeserializeObject(JsonConvert.SerializeObject(objCommentsBL.Data));
                return objPostResponse;
            }
            objPostResponse.ErrorCode = 1;
            objPostResponse.data = JsonConvert.DeserializeObject(JsonConvert.SerializeObject(results.Errors));
            objPostResponse.ErrorMessage = Common.ErrorToString(results);
            return objPostResponse;
        }

        [Route("api/Comments/Like/")]
        [HttpPost]
        public bool Like([FromBody]dynamic forumID)
        {
            //Common.IsValidForm(Constants.Forms.Forum, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser == null) throw new HttpResponseException(HttpStatusCode.Unauthorized);
            //Common.IsValidForm(Constants.Forms.Forum, Request);

            CommentsBL objCommentsBL = new CommentsBL(Common.GetConString());
            bool liked =  objCommentsBL.Like(objLoggedUser.UserID, forumID.ToString());
            return liked;
        }

        // DELETE api/Comments/5
        [Route("api/Comments/{Id}/{ForumID}")]
        [HttpDelete]
        public bool Delete(int Id,string forumID)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            Common.IsValidForm(Constants.Forms.Forum, Request);
            if (objLoggedUser == null) throw new HttpResponseException(HttpStatusCode.Unauthorized);

            CommentsBL objCommentsBL = new CommentsBL(Common.GetConString());
            return objCommentsBL.Delete(Id, forumID);
        }
    }
    public class CommentsValidator : AbstractValidator<Comments>
    {
        public CommentsValidator()
        {
            RuleFor(obj => obj.ForumID).NotEmpty();
            RuleFor(obj => obj.Remarks).NotEmpty();
        }
    }
}

