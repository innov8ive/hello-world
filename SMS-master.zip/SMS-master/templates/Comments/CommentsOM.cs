using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

[Serializable][Table(Name = "dbo.Comments")]public class Comments{
private System.Nullable<DateTime> _CommentDate;
private System.Nullable<int> _CommentedBy;
private System.Nullable<int> _CommentID;
private string _ForumID;
private string _Remarks;
 
[Column(Storage = "_CommentDate")]
public System.Nullable<DateTime> CommentDate{get {return _CommentDate;}set { _CommentDate=value;}}
[Column(Storage = "_CommentedBy")]
public System.Nullable<int> CommentedBy{get {return _CommentedBy;}set { _CommentedBy=value;}}
[Column(Storage = "_CommentID")]
public System.Nullable<int> CommentID{get {return _CommentID;}set { _CommentID=value;}}
[Column(Storage = "_ForumID")]
public string ForumID{get {return _ForumID;}set { _ForumID=value;}}
[Column(Storage = "_Remarks")]
public string Remarks{get {return _Remarks;}set { _Remarks=value;}}
}}
