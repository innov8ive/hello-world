using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

    [Serializable]
    [Table(Name = "dbo.RMBSU")]
    public class RMBSU
    {

        private System.Nullable<DateTime> _BDate;
        private System.Nullable<int> _BSID;
        private System.Nullable<decimal> _LF;
        private string _Name;
        private System.Nullable<int> _RefBSID;
        private System.Nullable<int> _RMID;
        private System.Nullable<int> _SocID;
        private System.Nullable<int> _Term;
        private System.Nullable<int> _PNID;

        [Column(Storage = "_PNID")]
        public System.Nullable<int> PNID
        {
            get { return _PNID; }
            set { _PNID = value; }
        }

        [Column(Storage = "_BDate")]
        public System.Nullable<DateTime> BDate
        {
            get
            {
                return _BDate;
            }
            set
            {
                _BDate = value;
            }
        }

        [Column(Storage = "_BSID")]
        public System.Nullable<int> BSID
        {
            get
            {
                return _BSID;
            }
            set
            {
                _BSID = value;
            }
        }

        [Column(Storage = "_LF")]
        public System.Nullable<decimal> LF
        {
            get
            {
                return _LF;
            }
            set
            {
                _LF = value;
            }
        }

        [Column(Storage = "_Name")]
        public string Name
        {
            get
            {
                return _Name;
            }
            set
            {
                _Name = value;
            }
        }

        [Column(Storage = "_RefBSID")]
        public System.Nullable<int> RefBSID
        {
            get
            {
                return _RefBSID;
            }
            set
            {
                _RefBSID = value;
            }
        }

        [Column(Storage = "_RMID")]
        public System.Nullable<int> RMID
        {
            get
            {
                return _RMID;
            }
            set
            {
                _RMID = value;
            }
        }

        [Column(Storage = "_SocID")]
        public System.Nullable<int> SocID
        {
            get
            {
                return _SocID;
            }
            set
            {
                _SocID = value;
            }
        }

        [Column(Storage = "_Term")]
        public System.Nullable<int> Term
        {
            get
            {
                return _Term;
            }
            set
            {
                _Term = value;
            }
        }


        public System.Collections.Generic.List<RMChg> RMChgList { get; set; }
        public Hashtable Types { get; set; }
    }


    [Serializable]
    [Table(Name = "dbo.RMChg")]
    public class RMChg
    {

        private System.Nullable<decimal> _Amt;
        private System.Nullable<int> _BSID;
        private System.Nullable<int> _ChgID;
        private System.Nullable<bool> _IsFixed;
        private System.Nullable<int> _RMID;
        private System.Nullable<decimal> _RPS;
        private Nullable<int> _CRGEID;

        [Column(Storage = "_CRGEID")]
        public Nullable<int> CRGEID
        {
            get { return _CRGEID; }
            set { _CRGEID = value; }
        }


        [Column(Storage = "_Amt")]
        public System.Nullable<decimal> Amt
        {
            get
            {
                return _Amt;
            }
            set
            {
                _Amt = value;
            }
        }



        [Column(Storage = "_BSID")]
        public System.Nullable<int> BSID
        {
            get
            {
                return _BSID;
            }
            set
            {
                _BSID = value;
            }
        }



        [Column(Storage = "_ChgID")]
        public System.Nullable<int> ChgID
        {
            get
            {
                return _ChgID;
            }
            set
            {
                _ChgID = value;
            }
        }



        [Column(Storage = "_IsFixed")]
        public System.Nullable<bool> IsFixed
        {
            get
            {
                return _IsFixed;
            }
            set
            {
                _IsFixed = value;
            }
        }



        [Column(Storage = "_RMID")]
        public System.Nullable<int> RMID
        {
            get
            {
                return _RMID;
            }
            set
            {
                _RMID = value;
            }
        }



        [Column(Storage = "_RPS")]
        public System.Nullable<decimal> RPS
        {
            get
            {
                return _RPS;
            }
            set
            {
                _RPS = value;
            }
        }

    }


}
