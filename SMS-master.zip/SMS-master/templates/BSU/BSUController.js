var app = angular.module('myApp');

app.controller('BSUListCtrl', function ($scope, $http, $location, GridData) {

    $scope = readyAngularGrid($scope, $http, 'api/BSUList', 'BSID', GridData, 'BSU');
    $scope.gridOptions.columnDefs = [

    { displayName: 'Name', field: 'Name' },
    { displayName: 'Bill Date', field: 'BDate', cellFilter: 'date:\'dd-MMM\'' },
    { displayName: 'Payment Term', field: 'Term' },
    { displayName: 'Penalty Method', field: 'PNName' }, ];
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchBSU = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
       
    };
    $scope.newBSU = function () {
        saveGridData($scope, GridData, 'BSU');
        $location.path('/BSU/0');
    };
    $scope.editBillTerms = function () {
        $location.path('/BillTerms');
    };
    $scope.editBSU = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            saveGridData($scope, GridData, 'BSU');
            $location.path('/BSU/' + selected[0].BSID);
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.deleteBSU = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'DELETE',
                url: 'api/BSU/' + selected[0].BSID
            }).success(function (result) {
                if (result == true)
                    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
            });
        }
        else {
            alert('Please select a record to edit.');
        }
    };
})

.controller('BSUCtrl', function ($scope, $http, $location, $routeParams) {
    var BSID = $routeParams.BSID;
    $scope.BSU = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.BSUSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.BSUSubmitted = true;
        if ($scope.formBSU.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        if ($scope.BSU.BSUChgList == null || $scope.BSU.BSUChgList.length <= 0) {
            swal({ title: "Please add at least one Charge!", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        $http.post('api/BSU', $scope.BSU, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.BSU = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/BSUList');
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/BSU/' + BSID
        }).success(function (BSU) {
            $scope.BSU = JSON.parse(BSU);
        });
    }, 100);

    $scope.copyToAllRM = function () {
        $http({
            method: 'POST',
            url: 'api/BSU/CopyBSUToAll/',
            data: JSON.stringify($scope.BSU)
        }).success(function (BSU) {
            swal({ title: "Data Copied successfully!", type: "success", timer: 1000, showConfirmButton: false });
        });
    };

    $scope.BSUChg = {};
    $scope.UnitTypeChgList = [];
    $scope.RoomList = [];
    $scope.WingChgList = [];
    $scope.FloorChgList = [];
    $scope.BSUChgSubmitted = false;
    var BSUChg = [];
    $scope.editBSUChg = function (indx) {
        $scope.EditMode = true;
        $scope.BSUChg = $scope.BSU.BSUChgList[indx];
        BSUChg = angular.copy($scope.BSU.BSUChgList);
        var chgID = $scope.BSUChg.ChgID;
        $scope.GetUnitTypeChg(chgID);
        $scope.GetRoomChg(chgID);
        $scope.GetWingChg(chgID);
        $scope.GetFloorChg(chgID);
    };
    $scope.deleteBSUChg = function (indx) {
        if (confirm('Are you sure want to delete?') == true) {
            var chgID = $scope.BSU.BSUChgList[indx].ChgID;
            $scope.deleteWingChg(chgID);
            $scope.deleteFloorChg(chgID);
            $scope.deleteUnitTypeChg(chgID);
            $scope.deleteRoomChg(chgID);
            $scope.BSU.BSUChgList.splice(indx, 1);
        }
    };
    $scope.newBSUChg = function () {
        $scope.EditMode = true;
        $scope.BSUChgSubmitted = false;
        BSUChg = angular.copy($scope.BSU.BSUChgList);
        $scope.BSUChg = { Basis: 'Fixed' };
        $scope.BSU.BSUChgList.push($scope.BSUChg);

        $scope.GetUnitTypeChg(0);
        $scope.GetRoomChg(0);
        $scope.GetWingChg(0);
        $scope.GetFloorChg(0);
    };
    $scope.cancelBSUChg = function () {
        $scope.EditMode = false;
        $scope.BSUChg = {};
        angular.copy(BSUChg, $scope.BSU.BSUChgList);
    };
    $scope.updateBSUChg = function (indx) {
        $scope.BSUChgSubmitted = true;
        if ($scope.BSUChg.ChgID == null || $scope.BSUChg.ChgID <= 0) {
            swal({ title: "Please Select Charge", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        if (($scope.BSUChg.Amt == null || $scope.BSUChg.Amt <= 0) && ($scope.BSUChg.Basis == 'Fixed' || $scope.BSUChg.Basis == 'Per SQFT')) {
            swal({ title: "Please enter Amount", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        var x = findByValue($scope.BSU.BSUChgList, 'ChgID', $scope.BSUChg.ChgID);
        if (x.length > 1) {
            swal({ title: "This Charge is already added, please select another Charge.", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }

        if ($scope.BSUChg.Basis == 'Per Unit Type') {
            for (var j = 0; j < $scope.UnitTypeChgList.length; j++) {
                if ($scope.UnitTypeChgList[j].Amount == null || $scope.UnitTypeChgList[j].Amount <= 0) {
                    swal({ title: "Please enter Amount for Unit Type:" + $scope.UnitTypeChgList[j].UnitType, type: "error", timer: 1000, showConfirmButton: false });
                    return;
                }
            }
        }
        if ($scope.BSUChg.Basis == 'Per Unit') {
            for (var j = 0; j < $scope.RoomList.length; j++) {
                if ($scope.RoomList[j].Amount == null || $scope.RoomList[j].Amount <= 0) {
                    swal({ title: "Please enter Amount for Unit:" + $scope.RoomList[j].RoomNo, type: "error", timer: 1000, showConfirmButton: false });
                    return;
                }
            }
        }
        if ($scope.BSUChg.Basis == 'Per Block/Wing') {
            for (var j = 0; j < $scope.WingChgList.length; j++) {
                if ($scope.WingChgList[j].Amount == null || $scope.WingChgList[j].Amount <= 0) {
                    swal({ title: "Please enter Amount for Block/Wing:" + $scope.WingChgList[j].WingName, type: "error", timer: 1000, showConfirmButton: false });
                    return;
                }
            }
        }


        var chgID = $scope.BSUChg.ChgID;
        $scope.deleteWingChg(chgID);
        $scope.deleteFloorChg(chgID);
        $scope.deleteUnitTypeChg(chgID);
        $scope.deleteRoomChg(chgID);
        if ($scope.BSUChg.Basis == 'Per Unit Type')
            $scope.saveUnitTypeChg(chgID);
        if ($scope.BSUChg.Basis == 'Per Unit')
            $scope.saveRoomChg(chgID);
        if ($scope.BSUChg.Basis == 'Per Block/Wing')
            $scope.saveWingChg(chgID);
        if ($scope.BSUChg.Basis == 'Per Floor Type')
            $scope.saveFloorChg(chgID);
        $scope.EditMode = false;
        $scope.BSUChg = {};
    };
    $scope.chglist = [];
    $scope.bindChg = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetChgList', Data: null })
        }).success(function (data) {
            $scope.chglist = data;
        });
    }
    $scope.bindChg();

    $scope.pnlist = [];
    $scope.bindPNList = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetPNList', Data: null })
        }).success(function (data) {
            $scope.pnlist = data;
        });
    }
    $scope.bindPNList();

    $scope.getText = function (model, array) {
        for (var j = 0; j < array.length; j++) {
            if (model == array[j].Key) {
                return array[j].Value;
            }
        }
        return '';
    };

    $scope.GetUnitTypeChg = function (chgID) {
        var result = [];
        if ($scope.BSU.BSUChgUnitTypeList != null)
            result = findByValue($scope.BSU.BSUChgUnitTypeList, 'ChgID', chgID, 0);
        if (result.length == 0)
            result = angular.copy($scope.BSU.BSUChgUnitTypeTempList);
        $scope.UnitTypeChgList = result;
    };
    $scope.GetRoomChg = function (chgID) {
        var result = [];
        if ($scope.BSU.BSUChgRoomList != null)
            result = findByValue($scope.BSU.BSUChgRoomList, 'ChgID', chgID, 0);
        if (result.length == 0)
            result = angular.copy($scope.BSU.BSUChgRoomTempList);
        $scope.RoomList = result;
    };
    $scope.GetWingChg = function (chgID) {
        var result = [];
        if ($scope.BSU.BSUChgWingList != null)
         result = findByValue($scope.BSU.BSUChgWingList, 'ChgID', chgID, 0);
        if (result.length == 0)
            result = angular.copy($scope.BSU.BSUChgWingTempList);
        $scope.WingChgList = result;
    };
    $scope.GetFloorChg = function (chgID) {
        var result = [];
        if ($scope.BSU.BSUChgWingList != null)
            result = findByValue($scope.BSU.BSUChgFloorList, 'ChgID', chgID, 0);
        if (result.length == 0)
            result = angular.copy($scope.BSU.BSUChgFloorTempList);
        $scope.FloorChgList = result;
    };
    $scope.deleteUnitTypeChg = function (ChgID) {
        var result = [];
        for (var j = 0; j < $scope.BSU.BSUChgUnitTypeList.length; j++) {
            if ($scope.BSU.BSUChgUnitTypeList[j].ChgID != ChgID) {
                result.push($scope.BSU.BSUChgUnitTypeList[j]);
            }
        }
        $scope.BSU.BSUChgUnitTypeList = result;
    };
    $scope.deleteRoomChg = function (ChgID) {
        var result = [];
        for (var j = 0; j < $scope.BSU.BSUChgRoomList.length; j++) {
            if ($scope.BSU.BSUChgRoomList[j].ChgID != ChgID) {
                result.push($scope.BSU.BSUChgRoomList[j]);
            }
        }
        $scope.BSU.BSUChgRoomList = result;
    };
    $scope.deleteWingChg = function (ChgID) {
        var result = [];
        for (var j = 0; j < $scope.BSU.BSUChgWingList.length; j++) {
            if ($scope.BSU.BSUChgWingList[j].ChgID != ChgID) {
                result.push($scope.BSU.BSUChgWingList[j]);
            }
        }
        $scope.BSU.BSUChgWingList = result;
    };
    $scope.deleteFloorChg = function (ChgID) {
        var result = [];
        for (var j = 0; j < $scope.BSU.BSUChgFloorList.length; j++) {
            if ($scope.BSU.BSUChgFloorList[j].ChgID != ChgID) {
                result.push($scope.BSU.BSUChgFloorList[j]);
            }
        }
        $scope.BSU.BSUChgFloorList = result;
    };

    $scope.saveUnitTypeChg = function (ChgID) {

        for (var j = 0; j < $scope.UnitTypeChgList.length; j++) {
            $scope.UnitTypeChgList[j].ChgID = ChgID;
            $scope.BSU.BSUChgUnitTypeList.push($scope.UnitTypeChgList[j]);
        }
    };
    $scope.saveRoomChg = function (ChgID) {

        for (var j = 0; j < $scope.RoomList.length; j++) {
            $scope.RoomList[j].ChgID = ChgID;
            $scope.BSU.BSUChgRoomList.push($scope.RoomList[j]);
        }
    };
    $scope.saveWingChg = function (ChgID) {

        for (var j = 0; j < $scope.WingChgList.length; j++) {
            $scope.WingChgList[j].ChgID = ChgID;
            $scope.BSU.BSUChgWingList.push($scope.WingChgList[j]);
        }
    };
    $scope.saveFloorChg = function (ChgID) {

        for (var j = 0; j < $scope.FloorChgList.length; j++) {
            $scope.FloorChgList[j].ChgID = ChgID;
            $scope.BSU.BSUChgFloorList.push($scope.FloorChgList[j]);
        }
    };
});
app.directive('bsuchg', function () {
    return {
        restrict: 'E',
        replace: true,
        templateUrl: 'templates/BSU/BSUChg.html'
    }
});
