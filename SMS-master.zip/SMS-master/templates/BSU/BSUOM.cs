using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

    [Serializable]
    [Table(Name = "dbo.BSU")]
    public class BSU
    {
        private System.Nullable<DateTime> _BDate;
        private System.Nullable<int> _BSID;
        private System.Nullable<decimal> _LF;
        private string _Name;
        private System.Nullable<int> _SocID;
        private System.Nullable<int> _Term;
        private System.Nullable<int> _PNID;
        private System.Nullable<int> _CreateEveryAfterMonth;
        private string _CreateEveryAfterMonthString;
        private System.Nullable<int> _GraceDays;

        [Column(Storage = "_GraceDays")]
        public System.Nullable<int> GraceDays
        {
            get { return _GraceDays; }
            set { _GraceDays = value; }
        }

        public string CreateEveryAfterMonthString
        {
            get { return _CreateEveryAfterMonthString; }
            set { _CreateEveryAfterMonthString = value; }
        }

        [Column(Storage = "_CreateEveryAfterMonth")]
        public System.Nullable<int> CreateEveryAfterMonth
        {
            get { return _CreateEveryAfterMonth; }
            set { _CreateEveryAfterMonth = value; }
        }

        [Column(Storage = "_PNID")]
        public System.Nullable<int> PNID
        {
            get { return _PNID; }
            set { _PNID = value; }
        }

        [Column(Storage = "_BDate")]
        public System.Nullable<DateTime> BDate
        {
            get
            {
                return _BDate;
            }
            set
            {
                _BDate = value;
            }
        }

        [Column(Storage = "_BSID")]
        public System.Nullable<int> BSID
        {
            get
            {
                return _BSID;
            }
            set
            {
                _BSID = value;
            }
        }

        [Column(Storage = "_LF")]
        public System.Nullable<decimal> LF
        {
            get
            {
                return _LF;
            }
            set
            {
                _LF = value;
            }
        }

        [Column(Storage = "_Name")]
        public string Name
        {
            get
            {
                return _Name;
            }
            set
            {
                _Name = value;
            }
        }

        [Column(Storage = "_SocID")]
        public System.Nullable<int> SocID
        {
            get
            {
                return _SocID;
            }
            set
            {
                _SocID = value;
            }
        }

        [Column(Storage = "_Term")]
        public System.Nullable<int> Term
        {
            get
            {
                return _Term;
            }
            set
            {
                _Term = value;
            }
        }
        public System.Collections.Generic.List<BSUChg> BSUChgList { get; set; }
        public List<BSUChgUnitType> BSUChgUnitTypeList { get; set; }
        public List<BSUChgRoom> BSUChgRoomList { get; set; }
        public List<BSUChgWing> BSUChgWingList { get; set; }
        public List<BSUChgFloor> BSUChgFloorList { get; set; }
        public List<BSUChgUnitType> BSUChgUnitTypeTempList { get; set; }
        public List<BSUChgRoom> BSUChgRoomTempList { get; set; }
        public List<BSUChgWing> BSUChgWingTempList { get; set; }
        public List<BSUChgFloor> BSUChgFloorTempList { get; set; }
        public List<string> BillTo { get; set; }
        public Hashtable Types { get; set; }
    }

    [Serializable]
    [Table(Name = "dbo.BSUChg")]
    public class BSUChg
    {
        private System.Nullable<decimal> _Amt;
        private System.Nullable<int> _BSID;
        private System.Nullable<int> _ChgID;
        private System.Nullable<bool> _IsFixed;
        private System.Nullable<decimal> _RPS;
        private string _ChgName;
        private string _Basis;
        private string _AccountType;

        [Column(Storage = "_AccountType")]
        public string AccountType
        {
            get { return _AccountType; }
            set { _AccountType = value; }
        }

        [Column(Storage = "_Basis")]
        public string Basis
        {
            get { return _Basis; }
            set { _Basis = value; }
        }

        [Column(Storage = "_ChgName")]
        public string ChgName
        {
            get { return _ChgName; }
            set { _ChgName = value; }
        }

        [Column(Storage = "_Amt")]
        public System.Nullable<decimal> Amt
        {
            get
            {
                return _Amt;
            }
            set
            {
                _Amt = value;
            }
        }

        [Column(Storage = "_BSID")]
        public System.Nullable<int> BSID
        {
            get
            {
                return _BSID;
            }
            set
            {
                _BSID = value;
            }
        }

        [Column(Storage = "_ChgID")]
        public System.Nullable<int> ChgID
        {
            get
            {
                return _ChgID;
            }
            set
            {
                _ChgID = value;
            }
        }

        [Column(Storage = "_IsFixed")]
        public System.Nullable<bool> IsFixed
        {
            get
            {
                return _IsFixed;
            }
            set
            {
                _IsFixed = value;
            }
        }

        [Column(Storage = "_RPS")]
        public System.Nullable<decimal> RPS
        {
            get
            {
                return _RPS;
            }
            set
            {
                _RPS = value;
            }
        }
    }


    [Serializable]
    [Table(Name = "dbo.BSUChgWing")]
    public class BSUChgWing
    {
        private System.Nullable<decimal> _Amount;
        private System.Nullable<int> _BSUID;
        private System.Nullable<int> _ChgID;
        private System.Nullable<int> _WingID;
        private string _WingName;

        [Column(Storage = "_WingName")]
        public string WingName
        {
            get { return _WingName; }
            set { _WingName = value; }
        }

        [Column(Storage = "_Amount")]
        public System.Nullable<decimal> Amount
        {
            get
            {
                return _Amount;
            }
            set
            {
                _Amount = value;
            }
        }

        [Column(Storage = "_BSUID")]
        public System.Nullable<int> BSUID
        {
            get
            {
                return _BSUID;
            }
            set
            {
                _BSUID = value;
            }
        }

        [Column(Storage = "_ChgID")]
        public System.Nullable<int> ChgID
        {
            get
            {
                return _ChgID;
            }
            set
            {
                _ChgID = value;
            }
        }

        [Column(Storage = "_WingID")]
        public System.Nullable<int> WingID
        {
            get
            {
                return _WingID;
            }
            set
            {
                _WingID = value;
            }
        }
    }

    [Serializable]
    [Table(Name = "dbo.BSUChgUnitType")]
    public class BSUChgUnitType
    {
        private System.Nullable<decimal> _Amount;
        private System.Nullable<int> _BSUID;
        private System.Nullable<int> _ChgID;
        private string _UnitType;

        [Column(Storage = "_Amount")]
        public System.Nullable<decimal> Amount
        {
            get
            {
                return _Amount;
            }
            set
            {
                _Amount = value;
            }
        }

        [Column(Storage = "_BSUID")]
        public System.Nullable<int> BSUID
        {
            get
            {
                return _BSUID;
            }
            set
            {
                _BSUID = value;
            }
        }

        [Column(Storage = "_ChgID")]
        public System.Nullable<int> ChgID
        {
            get
            {
                return _ChgID;
            }
            set
            {
                _ChgID = value;
            }
        }

        [Column(Storage = "_UnitType")]
        public string UnitType
        {
            get
            {
                return _UnitType;
            }
            set
            {
                _UnitType = value;
            }
        }
    }

    [Serializable]
    [Table(Name = "dbo.BSUChgRoom")]
    public class BSUChgRoom
    {
        private System.Nullable<decimal> _Amount;
        private System.Nullable<int> _BSUID;
        private System.Nullable<int> _ChgID;
        private Nullable<int> _RoomID;
        private string _RoomNo;

        [Column(Storage = "_RoomNo")]
        public string RoomNo
        {
            get { return _RoomNo; }
            set { _RoomNo = value; }
        }

        [Column(Storage = "_Amount")]
        public System.Nullable<decimal> Amount
        {
            get
            {
                return _Amount;
            }
            set
            {
                _Amount = value;
            }
        }

        [Column(Storage = "_BSUID")]
        public System.Nullable<int> BSUID
        {
            get
            {
                return _BSUID;
            }
            set
            {
                _BSUID = value;
            }
        }

        [Column(Storage = "_ChgID")]
        public System.Nullable<int> ChgID
        {
            get
            {
                return _ChgID;
            }
            set
            {
                _ChgID = value;
            }
        }

        [Column(Storage = "_RoomID")]
        public Nullable<int> RoomID
        {
            get
            {
                return _RoomID;
            }
            set
            {
                _RoomID = value;
            }
        }
    }

    [Serializable]
    [Table(Name = "dbo.BSUChgFloor")]
    public class BSUChgFloor
    {
        private System.Nullable<decimal> _Amount;
        private System.Nullable<int> _BSUID;
        private System.Nullable<int> _ChgID;
        private System.Nullable<int> _FloorNo;



        [Column(Storage = "_Amount")]
        public System.Nullable<decimal> Amount
        {
            get
            {
                return _Amount;
            }
            set
            {
                _Amount = value;
            }
        }

        [Column(Storage = "_BSUID")]
        public System.Nullable<int> BSUID
        {
            get
            {
                return _BSUID;
            }
            set
            {
                _BSUID = value;
            }
        }

        [Column(Storage = "_ChgID")]
        public System.Nullable<int> ChgID
        {
            get
            {
                return _ChgID;
            }
            set
            {
                _ChgID = value;
            }
        }

        [Column(Storage = "_FloorNo")]
        public System.Nullable<int> FloorNo
        {
            get
            {
                return _FloorNo;
            }
            set
            {
                _FloorNo = value;
            }
        }
    }
}