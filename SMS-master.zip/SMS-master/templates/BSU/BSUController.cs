using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;

namespace SampleAngular.Api
{
    public class BSUController : ApiController
    {
        [Route("api/BSU/CopyBSUToAll")]
        [HttpPost]
        public string CopyBSUToAll([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.BillSetUp, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            BSU objBSU = objJObject.ToObject<BSU>();
            RMBSUBL objRMBSUBL = new RMBSUBL(Common.GetConString());
            DataTable dtRooms = Common.GetDBResultParameterized("Select RoomID,100 as Area from Rooms where SocID=@SocID",
                   "@SocID", SqlDbType.Int, objLoggedUser.SocID);
            foreach (DataRow drRoom in dtRooms.Rows)
            {
                int RMID = Common.ToInt(drRoom["RoomID"]);
                int BSID = Common.ToInt(Common.GetDBScalar("Select BSID from RMBSU where RMID=" + RMID + " and RefBSID=" + Common.ToInt(objBSU.BSID)));
                
                objRMBSUBL.Load(BSID);
                RMBSU objRMBSU = objRMBSUBL.Data;
                objRMBSU.BDate = objBSU.BDate;
                objRMBSU.LF = objBSU.LF;
                objRMBSU.Name = objBSU.Name;
                objRMBSU.RefBSID = objBSU.BSID;
                objRMBSU.RMID =RMID;
                objRMBSU.SocID = objBSU.SocID;
                objRMBSU.PNID = objBSU.PNID;
                objRMBSU.Term = objBSU.Term;
                objRMBSU.RMChgList = new List<RMChg>();

                foreach (BSUChg objBSUChg in objBSU.BSUChgList)
                {
                    RMChg objRMChg = new RMChg();
                    objRMChg.Amt = objBSUChg.Amt;
                    objRMChg.BSID = objBSUChg.BSID;
                    objRMChg.ChgID = objBSUChg.ChgID;
                    objRMChg.IsFixed = objBSUChg.IsFixed;
                    objRMChg.RMID = RMID;
                    objRMChg.RPS = objBSUChg.RPS;

                    objRMBSU.RMChgList.Add(objRMChg);
                }
                objRMBSUBL.Update();
            }
            return String.Empty;
        }

        // GET api/BSU
        [Route("api/BSUList/")]
        [HttpPost]
        public AngularGridData GetBSU([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.BillSetUp, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = "Select BSU.*,P.PNName from BSU left join Penalty P ON P.PNID=BSU.PNID where BSU.SocID=" + objLoggedUser.SocID;
            objAngularDataBinder.ValueField = "BSID";
            return objAngularDataBinder.GetData();
        }

        [Route("api/GetBSUBlank/")]
        [HttpPost]
        public string GetBSUBlank([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.BillSetUp, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            BSUBL objBSUBL = new BSUBL(Common.GetConString());
            objBSUBL.Load(0, 0);
            BSU objBSU = objBSUBL.Data;
            objBSU.CreateEveryAfterMonth = objBSU.CreateEveryAfterMonth == null ? 1 : objBSU.CreateEveryAfterMonth;
            objBSU.CreateEveryAfterMonthString = Common.ToString(objBSU.CreateEveryAfterMonth);

            if (Common.ToInt(objBSU.SocID) > 0 && objBSU.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            return JsonConvert.SerializeObject(objBSUBL.Data);
        }
        // GET api/BSU/Id
        [Route("api/BSU/{Id}")]
        public string GetBSU(int Id)
        {
            Common.IsValidForm(Constants.Forms.BillSetUp, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            BSUBL objBSUBL = new BSUBL(Common.GetConString());
            objBSUBL.Load(Id, objLoggedUser.SocID);
            BSU objBSU = objBSUBL.Data;
            objBSU.CreateEveryAfterMonth = objBSU.CreateEveryAfterMonth == null ? 1 : objBSU.CreateEveryAfterMonth;
            objBSU.CreateEveryAfterMonthString = Common.ToString(objBSU.CreateEveryAfterMonth);
           
            if (Common.ToInt(objBSU.SocID) > 0 && objBSU.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            return JsonConvert.SerializeObject(objBSUBL.Data);
        }

        // POST api/BSU/
        public string Post([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.BillSetUp, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            BSU objBSU = objJObject.ToObject<BSU>();
            BSUBL objBSUBL = new BSUBL(Common.GetConString());
            objBSUBL.Data = objBSU;
            if (objBSUBL.IsNew)
            {
                objBSU.SocID = objLoggedUser.SocID;
            }
            objBSU.CreateEveryAfterMonth = Common.ToInt(objBSU.CreateEveryAfterMonthString);
            BSUValidator validator = new BSUValidator();
            ValidationResult results = validator.Validate(objBSU);

            if (results.IsValid)
            {
                objBSUBL.Update();
                return JsonConvert.SerializeObject(objBSUBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        // DELETE api/BSU/5
        [Route("api/BSU/{Id}")]
        [HttpDelete]
        public bool Delete(int Id)
        {
            Common.IsValidForm(Constants.Forms.BillSetUp, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            BSUBL objBSUBL = new BSUBL(Common.GetConString());
            objBSUBL.Load(Id, objLoggedUser.SocID);

            BSU objBSU = objBSUBL.Data;
            if (Common.ToInt(objBSU.SocID) > 0 && objBSU.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            return objBSUBL.Delete(Id);
        }
    }
    public class BSUValidator : AbstractValidator<BSU>
    {
        public BSUValidator()
        {
            RuleFor(obj => obj.BDate).NotEmpty();
            RuleFor(obj => obj.Name).NotEmpty();
            RuleFor(obj => obj.Term).NotEmpty();
        }
    }
}

