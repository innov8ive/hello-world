using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
    public class BSUDL
    {

        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public BSUDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public BSU Load(int BSID, int SocID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            BSU objBSU = new BSU();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get BSU
                var resultBSU = dc.ExecuteQuery<BSU>("exec Get_BSU {0},{1}", BSID, SocID).ToList();
                if (resultBSU.Count > 0)
                {
                    objBSU = resultBSU[0];
                    BSID = Convert.ToInt32(objBSU.BSID);
                }
                //Get BSUChg
                var resultBSUChg = dc.ExecuteQuery<BSUChg>("exec Get_BSUChg {0}", BSID).ToList();
                objBSU.BSUChgList = resultBSUChg;

                objBSU.BSUChgUnitTypeList = dc.ExecuteQuery<BSUChgUnitType>("Select * from BSUChgUnitType where BSUID= {0}", BSID).ToList();
                objBSU.BSUChgRoomList = dc.ExecuteQuery<BSUChgRoom>(@"Select UT.*,W.WingName+ ' '+R.RoomNo as RoomNo from BSUChgRoom UT 
left join Rooms R ON UT.RoomID=R.RoomID
left join Wings W ON R.WingID = W.WingID where BSUID= {0}", BSID).ToList();
                objBSU.BSUChgWingList = dc.ExecuteQuery<BSUChgWing>("Select B.*,W.WIngName from BSUChgWing B inner join Wings W ON B.WIngID=W.WingID where BSUID= {0}", BSID).ToList();
                objBSU.BSUChgFloorList = dc.ExecuteQuery<BSUChgFloor>("Select B.* from BSUChgFloor B where B.BSUID= {0}", BSID).ToList();

                objBSU.BSUChgUnitTypeTempList = dc.ExecuteQuery<BSUChgUnitType>(@"Select UT.UnitType,B.Amount,B.ChgID,B.BSUID from
UnitTypes UT left join 
 BSUChgUnitType B ON UT.UnitTypeID=B.UnitType and B.BSUID=-999
 where exists(select 1 from Rooms R where R.UnitType=UT.UnitType and R.SocID={0})
 Order By UT.SrNo", SocID).ToList();
                objBSU.BSUChgRoomTempList = dc.ExecuteQuery<BSUChgRoom>(@"Select W.WingName+ ' '+UT.RoomNo as RoomNo,UT.RoomID,B.Amount,B.ChgID,B.BSUID from
Rooms UT left join 
Wings W ON UT.WingID = W.WingID left join 
 BSUChgRoom B ON UT.RoomID=B.RoomID and B.BSUID=-999
 where UT.SocID={0}
 Order By UT.RoomID", SocID).ToList();
                objBSU.BSUChgWingTempList = dc.ExecuteQuery<BSUChgWing>(@"Select W.WingID,W.WingName,B.Amount,B.ChgID,B.BSUID from
Wings W left join 
 BSUChgWing B ON W.WingID=B.WingID and B.BSUID=-999
 where W.SocID={0}
 Order By W.WingName", SocID).ToList();
                objBSU.BSUChgFloorTempList = new List<BSUChgFloor>();
                for (int i = 0; i <= 15; i++)
                {
                    objBSU.BSUChgFloorTempList.Add(new BSUChgFloor()
                    {
                        Amount = 0,
                        BSUID = BSID,
                        ChgID = 0,
                        FloorNo = i
                    });
                }
                dc.Dispose();
                return objBSU;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllBSU()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_BSU", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(BSU objBSU)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update BSU
                UpdateBSU(objBSU, trn);
                if (objBSU.BSID > 0)
                {

                    //Update BSUChg
                    DeleteBSUChg(Convert.ToInt32(objBSU.BSID), trn);
                    foreach (BSUChg objBSUChg in objBSU.BSUChgList)
                    {
                        objBSUChg.BSID = objBSU.BSID;
                        InsertIntoBSUChg(objBSUChg, trn);
                    }

                    //Update BSUChgUnitType
                    DeleteBSUChgUnitType(Convert.ToInt32(objBSU.BSID), trn);
                    foreach (BSUChgUnitType objBSUChgUnitType in objBSU.BSUChgUnitTypeList)
                    {
                        objBSUChgUnitType.BSUID = objBSU.BSID;
                        InsertIntoBSUChgUnitType(objBSUChgUnitType, trn);
                    }
                  
                    //Update BSUChgRoom
                    DeleteBSUChgRoom(Convert.ToInt32(objBSU.BSID), trn);
                    foreach (BSUChgRoom objBSUChgRoom in objBSU.BSUChgRoomList)
                    {
                        objBSUChgRoom.BSUID = objBSU.BSID;
                        InsertIntoBSUChgRoom(objBSUChgRoom, trn);
                    }

                    //Update BSUChgWing
                    DeleteBSUChgWing(Convert.ToInt32(objBSU.BSID), trn);
                    foreach (BSUChgWing objBSUChgWing in objBSU.BSUChgWingList)
                    {
                        objBSUChgWing.BSUID = objBSU.BSID;
                        InsertIntoBSUChgWing(objBSUChgWing, trn);
                    }

                    //Update BSUChgFloor
                    DeleteBSUChgFloor(Convert.ToInt32(objBSU.BSID), trn);
                    foreach (BSUChgFloor objBSUChgFloor in objBSU.BSUChgFloorList)
                    {
                        objBSUChgFloor.BSUID = objBSU.BSID;
                        InsertIntoBSUChgFloor(objBSUChgFloor, trn);
                    }
                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int BSID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete BSUChg
                DeleteBSUChg(BSID, trn);
                DeleteBSUChgRoom(BSID, trn);
                DeleteBSUChgUnitType(BSID, trn);
                DeleteBSUChgFloor(BSID, trn);
                //Delete BSU
                DeleteBSU(BSID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateBSU(BSU objBSU, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_BSU", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@BDate", SqlDbType.DateTime).Value = objBSU.BDate;
                cmd.Parameters.Add("@BSID", SqlDbType.Int).Value = objBSU.BSID;
                cmd.Parameters["@BSID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@LF", SqlDbType.Decimal).Value = objBSU.LF;
                cmd.Parameters.Add("@Name", SqlDbType.VarChar, 100).Value = objBSU.Name;
                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = objBSU.SocID;
                cmd.Parameters.Add("@Term", SqlDbType.Int).Value = objBSU.Term;
                cmd.Parameters.Add("@PNID", SqlDbType.Int).Value = objBSU.PNID;
                cmd.Parameters.Add("@CreateEveryAfterMonth", SqlDbType.Int).Value = objBSU.CreateEveryAfterMonth;
                cmd.Parameters.Add("@GraceDays", SqlDbType.Int).Value = objBSU.GraceDays;

                cmd.ExecuteNonQuery();

                //after updating the BSU, update BSID
                objBSU.BSID = Convert.ToInt32(cmd.Parameters["@BSID"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteBSU(int BSID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from BSU where BSID=@BSID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@BSID", SqlDbType.Int).Value = BSID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        public bool DeleteBSUChg(int BSID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from BSUChg where BSID=@BSID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@BSID", SqlDbType.Int).Value = BSID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        public bool InsertIntoBSUChg(BSUChg objBSUChg, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Into_BSUChg", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Transaction = trn;


                cmd.Parameters.Add("@Amt", SqlDbType.Decimal).Value = objBSUChg.Amt;
                cmd.Parameters.Add("@BSID", SqlDbType.Int).Value = objBSUChg.BSID;
                cmd.Parameters.Add("@ChgID", SqlDbType.Int).Value = objBSUChg.ChgID;
                cmd.Parameters.Add("@IsFixed", SqlDbType.Bit).Value = objBSUChg.IsFixed;
                cmd.Parameters.Add("@RPS", SqlDbType.Decimal).Value = objBSUChg.RPS;
                cmd.Parameters.Add("@Basis", SqlDbType.VarChar, 50).Value = objBSUChg.Basis;

                cmd.ExecuteNonQuery();

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool InsertIntoBSUChgUnitType(BSUChgUnitType objBSUChgUnitType, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Into_BSUChgUnitType", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Transaction = trn;
                cmd.Parameters.Add("@Amount", SqlDbType.Decimal).Value = objBSUChgUnitType.Amount;
                cmd.Parameters.Add("@BSUID", SqlDbType.Int).Value = objBSUChgUnitType.BSUID;
                cmd.Parameters.Add("@ChgID", SqlDbType.Int).Value = objBSUChgUnitType.ChgID;
                cmd.Parameters.Add("@UnitType", SqlDbType.VarChar, 50).Value = objBSUChgUnitType.UnitType;

                cmd.ExecuteNonQuery();

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool InsertIntoBSUChgRoom(BSUChgRoom objBSUChgRoom, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Into_BSUChgRoom", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Transaction = trn;
                cmd.Parameters.Add("@Amount", SqlDbType.Decimal).Value = objBSUChgRoom.Amount;
                cmd.Parameters.Add("@BSUID", SqlDbType.Int).Value = objBSUChgRoom.BSUID;
                cmd.Parameters.Add("@ChgID", SqlDbType.Int).Value = objBSUChgRoom.ChgID;
                cmd.Parameters.Add("@RoomID", SqlDbType.Int).Value = objBSUChgRoom.RoomID;

                cmd.ExecuteNonQuery();

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteBSUChgUnitType(int BSUID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from BSUChgUnitType where BSUID=@BSUID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@BSUID", SqlDbType.Int).Value = BSUID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        public bool DeleteBSUChgRoom(int BSUID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from BSUChgRoom where BSUID=@BSUID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@BSUID", SqlDbType.Int).Value = BSUID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        public bool DeleteBSUChgWing(int BSUID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from BSUChgWing where BSUID=@BSUID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@BSUID", SqlDbType.Int).Value = BSUID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        public bool InsertIntoBSUChgWing(BSUChgWing objBSUChgWing, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Into_BSUChgWing", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Transaction = trn;
                cmd.Parameters.Add("@Amount", SqlDbType.Decimal).Value = objBSUChgWing.Amount;
                cmd.Parameters.Add("@BSUID", SqlDbType.Int).Value = objBSUChgWing.BSUID;
                cmd.Parameters.Add("@ChgID", SqlDbType.Int).Value = objBSUChgWing.ChgID;
                cmd.Parameters.Add("@WingID", SqlDbType.Int).Value = objBSUChgWing.WingID;

                cmd.ExecuteNonQuery();

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteBSUChgFloor(int BSUID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from BSUChgFloor where BSUID=@BSUID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@BSUID", SqlDbType.Int).Value = BSUID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        public bool InsertIntoBSUChgFloor(BSUChgFloor objBSUChgFloor, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Into_BSUChgFloor", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Transaction = trn;
                cmd.Parameters.Add("@Amount", SqlDbType.Decimal).Value = objBSUChgFloor.Amount;
                cmd.Parameters.Add("@BSUID", SqlDbType.Int).Value = objBSUChgFloor.BSUID;
                cmd.Parameters.Add("@ChgID", SqlDbType.Int).Value = objBSUChgFloor.ChgID;
                cmd.Parameters.Add("@FloorNo", SqlDbType.Int).Value = objBSUChgFloor.FloorNo;

                cmd.ExecuteNonQuery();

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        #endregion
    }
}
