using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;

namespace SampleAngular.Api
{
    public class RMBSUController : ApiController
    {
        // GET api/BSU/Id
        [Route("api/RMBSU/{Id}")]
        public string GetBSU(int Id)
        {
            Common.IsValidForm(Constants.Forms.BillSetUp, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            RMBSUBL objBSUBL = new RMBSUBL(Common.GetConString());
            objBSUBL.Load(Id);

            RMBSU objBSU = objBSUBL.Data;
            if (Common.ToInt(objBSU.SocID) > 0 && objBSU.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            return JsonConvert.SerializeObject(objBSUBL.Data);
        }

        // POST api/BSU/
        public string Post([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.BillSetUp, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            RMBSU objBSU = objJObject.ToObject<RMBSU>();
            RMBSUBL objBSUBL = new RMBSUBL(Common.GetConString());
            objBSUBL.Data = objBSU;
            if (objBSUBL.IsNew)
            {
                objBSU.SocID = objLoggedUser.SocID;
            }
            RMBSUValidator validator = new RMBSUValidator();
            ValidationResult results = validator.Validate(objBSU);

            if (results.IsValid)
            {
                objBSUBL.Update();
                return JsonConvert.SerializeObject(objBSUBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        // DELETE api/BSU/5
        [Route("api/RMBSU/{Id}")]
        [HttpDelete]
        public bool Delete(int Id)
        {
            Common.IsValidForm(Constants.Forms.BillSetUp, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            RMBSUBL objBSUBL = new RMBSUBL(Common.GetConString());
            objBSUBL.Load(Id);

            RMBSU objBSU = objBSUBL.Data;
            if (Common.ToInt(objBSU.SocID) > 0 && objBSU.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            return objBSUBL.Delete(Id);
        }
    }
    public class RMBSUValidator : AbstractValidator<RMBSU>
    {
        public RMBSUValidator()
        {
            RuleFor(obj => obj.BDate).NotEmpty();
            RuleFor(obj => obj.LF).NotEmpty();
            RuleFor(obj => obj.Name).NotEmpty();
            RuleFor(obj => obj.Term).NotEmpty();
        }
    }
}

