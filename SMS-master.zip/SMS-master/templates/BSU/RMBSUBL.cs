using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
[Serializable]
public class RMBSUBL
{

#region Declaration
private string connectionString;
RMBSU _RMBSU;
public RMBSU Data
{
get { return _RMBSU; }
set { _RMBSU = value; }
}
public bool IsNew
{
get { return (_RMBSU.BSID <= 0 || _RMBSU.BSID ==null); }
}
#endregion

#region Constructor
public RMBSUBL(string conString)
{
connectionString = conString;
}
#endregion

#region Main Methods
private RMBSUDL CreateDL()
{
return new RMBSUDL(connectionString);
}
public void New()
{
_RMBSU = new RMBSU();
}
public void Load(int BSID)
{
var RMBSUObj = this.CreateDL();
_RMBSU = BSID <= 0 ? RMBSUObj.Load(-1) : RMBSUObj.Load(BSID);
}
public DataTable LoadAllRMBSU()
{
var RMBSUDLObj = CreateDL();
return RMBSUDLObj.LoadAllRMBSU();
}
public bool Update()
{
var RMBSUDLObj = CreateDL();
return RMBSUDLObj.Update(this.Data);
}
public bool Delete(int BSID)
{
var RMBSUDLObj = CreateDL();
return RMBSUDLObj.Delete(BSID);
}
#endregion
}
}
