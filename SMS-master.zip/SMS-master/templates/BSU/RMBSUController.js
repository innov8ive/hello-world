var app = angular.module('myApp');

app.controller('RMBSUCtrl', function ($scope, $http, $location, $routeParams, $window) {
    var BSID = $routeParams.BSID;
    var RMID = $routeParams.RMID;
    $scope.BSU = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.BSUSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.BSUSubmitted = true;
        if ($scope.formBSU.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        if ($scope.BSU.RMChgList == null || $scope.BSU.RMChgList.length <= 0) {
            swal({ title: "Please add at least one Charge!", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        $scope.BSU.RMID = RMID;
        $http.post('api/RMBSU', $scope.BSU, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.BSU = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        //$location.path('/BSUList');
        $window.history.back();
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/RMBSU/' + BSID
        }).success(function (BSU) {
            $scope.BSU = JSON.parse(BSU);
        });
    }, 100);


    $scope.BSUChg = {};
    $scope.BSUChgSubmitted = false;
    var BSUChg = [];
    $scope.editBSUChg = function (indx) {
        $scope.EditMode = true;
        $scope.BSUChg = $scope.BSU.RMChgList[indx];
        BSUChg = angular.copy($scope.BSU.RMChgList);
    };
    $scope.deleteBSUChg = function (indx) {
        if (confirm('Are you sure want to delete?') == true) {
            $scope.BSU.RMChgList.splice(indx, 1);
        }
    };
    $scope.newBSUChg = function () {
        $scope.EditMode = true;
        $scope.BSUChgSubmitted = false;
        BSUChg = angular.copy($scope.BSU.RMChgList);
        $scope.BSUChg = { IsFixed: true, RMID: RMID };
        $scope.BSU.RMChgList.push($scope.BSUChg);
    };
    $scope.cancelBSUChg = function () {
        $scope.EditMode = false;
        $scope.BSUChg = {};
        angular.copy(BSUChg, $scope.BSU.RMChgList);
    };
    $scope.updateBSUChg = function (indx) {
        $scope.BSUChgSubmitted = true;
        if ($scope.BSUChg.ChgID == null || $scope.BSUChg.ChgID <=0) {
            swal({ title: "Please enter Charge", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        if (($scope.BSUChg.Amt == null || $scope.BSUChg.Amt <= 0) && $scope.BSUChg.IsFixed == true) {
            swal({ title: "Please enter Amount", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        if (($scope.BSUChg.RPS == null || $scope.BSUChg.RPS <= 0) && $scope.BSUChg.IsFixed == false) {
            swal({ title: "Please enter Rate Per Sqft", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        var x = findByValue($scope.BSU.RMChgList, 'ChgID', $scope.BSUChg.ChgID);
        if (x.length > 1) {
            swal({ title: "This Charge is already added, please select another Charge.", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        $scope.EditMode = false;
        $scope.BSUChg = {};
    };
    $scope.chglist = [];
    $scope.bindChg = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetChgList', Data: null })
        }).success(function (data) {
            $scope.chglist = data;
        });
    }
    $scope.bindChg();

    $scope.pnlist = [];
    $scope.bindPNList = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetPNList', Data: null })
        }).success(function (data) {
            $scope.pnlist = data;
        });
    }
    $scope.bindPNList();

    $scope.getText = function (model, array) {
        for (var j = 0; j < array.length; j++) {
            if (model == array[j].Key) {
                return array[j].Value;
            }
        }
        return '';
    };
});
app.directive('rmbsuchg', function () {
    return {
        restrict: 'E',
        replace: true,
        templateUrl: 'templates/BSU/RMBSUChg.html'
    }
});
