using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
    [Serializable]
    public class BSUBL
    {

        #region Declaration
        private string connectionString;
        BSU _BSU;
        public BSU Data
        {
            get { return _BSU; }
            set { _BSU = value; }
        }
        public bool IsNew
        {
            get { return (_BSU.BSID <= 0 || _BSU.BSID == null); }
        }
        #endregion

        #region Constructor
        public BSUBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private BSUDL CreateDL()
        {
            return new BSUDL(connectionString);
        }
        public void New()
        {
            _BSU = new BSU();
        }
        public void Load(int BSID,int SocID)
        {
            var BSUObj = this.CreateDL();
            _BSU = BSID <= 0 ? BSUObj.Load(-1, SocID) : BSUObj.Load(BSID, SocID);
        }
        public DataTable LoadAllBSU()
        {
            var BSUDLObj = CreateDL();
            return BSUDLObj.LoadAllBSU();
        }
        public bool Update()
        {
            var BSUDLObj = CreateDL();
            return BSUDLObj.Update(this.Data);
        }
        public bool Delete(int BSID)
        {
            var BSUDLObj = CreateDL();
            return BSUDLObj.Delete(BSID);
        }
        #endregion
    }
}
