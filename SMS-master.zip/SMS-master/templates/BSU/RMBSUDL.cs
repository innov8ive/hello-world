using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
    public class RMBSUDL
    {

        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public RMBSUDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public RMBSU Load(int BSID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            RMBSU objRMBSU = new RMBSU();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get RMBSU
                var resultRMBSU = dc.ExecuteQuery<RMBSU>("exec Get_RMBSU {0}", BSID).ToList();
                if (resultRMBSU.Count > 0)
                {
                    objRMBSU = resultRMBSU[0];
                }
                //Get RMChg
                var resultRMChg = dc.ExecuteQuery<RMChg>("exec Get_RMChg {0}", BSID).ToList();
                objRMBSU.RMChgList = resultRMChg;
                objRMBSU.Types = new System.Collections.Hashtable();
                objRMBSU.Types["RMChgList"] = new RMChg();
                dc.Dispose();
                return objRMBSU;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllRMBSU()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_RMBSU", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(RMBSU objRMBSU)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update RMBSU
                UpdateRMBSU(objRMBSU, trn);
                if (objRMBSU.BSID > 0)
                {

                    //Update RMChg
                    DeleteRMChg(Convert.ToInt32(objRMBSU.BSID), trn);
                    foreach (RMChg objRMChg in objRMBSU.RMChgList)
                    {
                        objRMChg.BSID = objRMBSU.BSID;
                        InsertIntoRMChg(objRMChg, trn);
                    }
                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int BSID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete RMChg
                DeleteRMChg(BSID, trn);
                //Delete RMBSU
                DeleteRMBSU(BSID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateRMBSU(RMBSU objRMBSU, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_RMBSU", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@BDate", SqlDbType.DateTime).Value = objRMBSU.BDate;
                cmd.Parameters.Add("@BSID", SqlDbType.Int).Value = objRMBSU.BSID;
                cmd.Parameters["@BSID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@LF", SqlDbType.Decimal).Value = objRMBSU.LF;
                cmd.Parameters.Add("@Name", SqlDbType.VarChar, 100).Value = objRMBSU.Name;
                cmd.Parameters.Add("@RefBSID", SqlDbType.Int).Value = objRMBSU.RefBSID;
                cmd.Parameters.Add("@RMID", SqlDbType.Int).Value = objRMBSU.RMID;
                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = objRMBSU.SocID;
                cmd.Parameters.Add("@Term", SqlDbType.Int).Value = objRMBSU.Term;
                cmd.Parameters.Add("@PNID", SqlDbType.Int).Value = objRMBSU.PNID;

                cmd.ExecuteNonQuery();

                //after updating the RMBSU, update BSID
                objRMBSU.BSID = Convert.ToInt32(cmd.Parameters["@BSID"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteRMBSU(int BSID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from RMBSU where BSID=@BSID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@BSID", SqlDbType.Int).Value = BSID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        public bool DeleteRMChg(int BSID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from RMChg where BSID=@BSID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@BSID", SqlDbType.Int).Value = BSID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        public bool InsertIntoRMChg(RMChg objRMChg, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Into_RMChg", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Transaction = trn;


                cmd.Parameters.Add("@Amt", SqlDbType.Decimal).Value = objRMChg.Amt;
                cmd.Parameters.Add("@BSID", SqlDbType.Int).Value = objRMChg.BSID;
                cmd.Parameters.Add("@ChgID", SqlDbType.Int).Value = objRMChg.ChgID;
                cmd.Parameters.Add("@IsFixed", SqlDbType.Bit).Value = objRMChg.IsFixed;
                cmd.Parameters.Add("@RMID", SqlDbType.Int).Value = objRMChg.RMID;
                cmd.Parameters.Add("@RPS", SqlDbType.Decimal).Value = objRMChg.RPS;

                cmd.ExecuteNonQuery();

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        #endregion
    }
}
