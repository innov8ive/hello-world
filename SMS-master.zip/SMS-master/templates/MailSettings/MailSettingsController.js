var app = angular.module('myApp');

app.controller('MailSettingsCtrl', function ($scope, $http, $location, $routeParams) {
    $scope.loading = false;
    var MailID = $routeParams.MailID;
    $scope.MailSettings = {};
    $scope.ErrorMessages = [];
    $scope.MS = { Password: '',Email:'' };
    $scope.dateOptions = {changeYear: true,changeMonth: true,dateFormat: 'dd-MM-yy'};
    $scope.EditMode = false;
    $scope.MailSettingsSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.MailSettingsSubmitted = true;
        if ($scope.formMailSettings.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $scope.loading = true;
        $http.post('api/SaveMailSettings/', $scope.MailSettings, config)
        .success(function (data, status, headers, config) {
            $scope.loading = false;
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.MailSettings = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

   
    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/MailSettings/'
        }).success(function (MailSettings) {
            $scope.MailSettings = JSON.parse(MailSettings);
        });
    }, 100);

    $scope.changePassword = function () {
        if ($scope.MS.Password == '') {
            alert('Please enter Password');
            return;
        }
        $scope.loading = true;
        $http({
            method: 'POST',
            url: 'api/MailSettings/ChangePassword',
            data: JSON.stringify($scope.MS.Password)
        }).success(function (MailSettings) {
            $scope.loading = false;
            $scope.MS.Password = '';
            alert('Password Changed!');
        });
    };

    $scope.sendTestMail = function () {
        if ($scope.MS.Email == '') {
            alert('Please enter Email');
            return;
        }
        $scope.loading = true;
        $http({
            method: 'POST',
            url: 'api/MailSettings/SendTestEmail',
            data: JSON.stringify($scope.MS.Password)
        }).success(function (MailSettings) {
            $scope.loading = false;
            alert('Mail Sent!');
        });
    }
});
