using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

    [Serializable]
    [Table(Name = "dbo.MailSettings")]
    public class MailSettings
    {

        private System.Nullable<bool> _EnableSSL;
        private string _FromName;
        private string _Host;
        private System.Nullable<int> _MailID;
        private string _Password;
        private System.Nullable<int> _Port;
        private System.Nullable<int> _ReaderPort;
        private System.Nullable<bool> _UseDefaultCredentials;
        private string _UserName;

        [Column(Storage = "_EnableSSL")]
        public System.Nullable<bool> EnableSSL
        {
            get
            {
                return _EnableSSL;
            }
            set
            {
                _EnableSSL = value;
            }
        }

        [Column(Storage = "_FromName")]
        public string FromName
        {
            get
            {
                return _FromName;
            }
            set
            {
                _FromName = value;
            }
        }

        [Column(Storage = "_Host")]
        public string Host
        {
            get
            {
                return _Host;
            }
            set
            {
                _Host = value;
            }
        }

        [Column(Storage = "_MailID")]
        public System.Nullable<int> MailID
        {
            get
            {
                return _MailID;
            }
            set
            {
                _MailID = value;
            }
        }

        [Column(Storage = "_Password")]
        public string Password
        {
            get
            {
                return _Password;
            }
            set
            {
                _Password = value;
            }
        }

        [Column(Storage = "_Port")]
        public System.Nullable<int> Port
        {
            get
            {
                return _Port;
            }
            set
            {
                _Port = value;
            }
        }

        [Column(Storage = "_UseDefaultCredentials")]
        public System.Nullable<bool> UseDefaultCredentials
        {
            get
            {
                return _UseDefaultCredentials;
            }
            set
            {
                _UseDefaultCredentials = value;
            }
        }

        [Column(Storage = "_UserName")]
        public string UserName
        {
            get
            {
                return _UserName;
            }
            set
            {
                _UserName = value;
            }
        }
    }


}
