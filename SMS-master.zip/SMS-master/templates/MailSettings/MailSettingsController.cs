using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;

namespace SampleAngular.Api
{
    public class MailSettingsController : ApiController
    {

        // GET api/MailSettings/Id
        [Route("api/MailSettings/")]
        public string GetMailSettings()
        {
            Common.IsValidForm(Constants.Forms.MailSettings, Request);
            return JsonConvert.SerializeObject(Common.LoadEmailSettings());
        }

        [Route("api/SaveMailSettings")]
        [HttpPost]
        public string SaveMailSettings([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.MailSettings, Request);

            JObject objJObject = value;
            MailSettings objMailSettings = objJObject.ToObject<MailSettings>();
            MailSettingsValidator validator = new MailSettingsValidator();
            ValidationResult results = validator.Validate(objMailSettings);

            if (results.IsValid)
            {
                Common.UpdateEmailSettings(objMailSettings);
                return JsonConvert.SerializeObject(objMailSettings);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        [Route("api/MailSettings/ChangePassword")]
        [HttpPost]
        public string ChangePassword([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.MailSettings, Request);
            Common.UpdateEmailSettingPassword(Common.ToString(value));
            return "true";
        }

        [Route("api/MailSettings/SendTestEmail")]
        [HttpPost]
        public string SendTestEmail([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.MailSettings, Request);
            Common.SendEmail(Common.ToString(value),"This is test mail","This is test email");
            return "true";
        }
    }
    public class MailSettingsValidator : AbstractValidator<MailSettings>
    {
        public MailSettingsValidator()
        {

            RuleFor(obj => obj.EnableSSL).NotEmpty();
            RuleFor(obj => obj.FromName).NotEmpty();
            RuleFor(obj => obj.Host).NotEmpty();
            RuleFor(obj => obj.Port).NotEmpty();
            RuleFor(obj => obj.UseDefaultCredentials).NotEmpty();
            RuleFor(obj => obj.UserName).NotEmpty();
        }
    }
}
