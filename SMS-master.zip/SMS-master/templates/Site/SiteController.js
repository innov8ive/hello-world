var app = angular.module('myApp');

app.controller('MenuCtrl', function ($scope, $http, $location, User) {
    $scope.categoryList = [];
    $scope.User = User;
    $scope.getCategories = function () {
        $http({
            method: 'POST',
            url: 'api/Site/GetCategories/'
        }).success(function (result) {
            $scope.categoryList = JSON.parse(result);
        });
    }
    $scope.getCategories();
});
app.controller('SiteHomeController', function ($scope, $http, $location) {
    $scope.CarouselList = [];
    $scope.getCarousel = function () {
        $http({
            method: 'POST',
            url: 'api/Site/GetCarousel/'
        }).success(function (result) {
            $scope.CarouselList = JSON.parse(result);
            window.setTimeout(function () {
                $('#myCarousel').carousel({
                    interval: 3000,
                    cycle: true
                });
            }, 500);

        });
    }
    $scope.getCarousel();

    $scope.newArrivalsCategories = [];
    $scope.trendingCategories = [];
    $scope.featuredCategories = [];
    $scope.getCategories = function () {
        $http({
            method: 'POST',
            url: 'api/Site/GetCategories/'
        }).success(function (result) {
            var categoryList = JSON.parse(result);
            $scope.newArrivalsCategories = findByValue(categoryList, 'Type', 'New Arrivals', 4);
            $scope.trendingCategories = findByValue(categoryList, 'Type', 'Trending', 4);
            $scope.featuredCategories = findByValue(categoryList, 'Type', 'Featured', 4);
        });
    }
    $scope.getCategories();

    $scope.filter = { filterText: '' };
    $scope.searchSP = function () {
        if ($scope.filter.filterText != '')
            $location.path('/search/0/0/' + $scope.filter.filterText);
    };

    $scope.catlist = [];
    $scope.bindCategory = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetCategorySubCategoryList', Data: null, query: '' })
        }).success(function (data) {
            $scope.catlist = data;
        });
    };
    $scope.bindCategory();

    $scope.subCategorySelected = function ($item, $select) {
        $location.path('/search/0/' + $item.Key + '/');
    };
});

app.controller('CategoryController', function ($scope, $http, $location, $routeParams) {
    var CategoryID = $routeParams.CategoryID;
    $scope.Category = {};
    $scope.getCategory = function () {
        $http({
            method: 'POST',
            url: 'api/Site/GetCategory/',
            data: CategoryID
        }).success(function (result) {
            $scope.Category = JSON.parse(result);
        });
    };

    setTimeout(function () { $scope.getCategory(); }, 100);
});

app.controller('UserProfileCtrl', function ($scope, $http, $location, $routeParams) {
    var UserID = $routeParams.UserID;
    $scope.Users = {};
    $scope.getUser = function () {
        $http({
            method: 'POST',
            url: 'api/Site/GetUserProfile/',
            data: UserID
        }).success(function (result) {
            result = JSON.parse(result);
            if (result.length > 0)
                $scope.Users = result[0];
        });
    };

    setTimeout(function () { $scope.getUser(); }, 100);
});


app.controller('SiteSPCtrl', function ($scope, $http, $location) {
    $scope.CP = { ConfirmPassword: '' };
    $scope.SP = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.SPSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {

        $scope.SPSubmitted = true;
        if ($scope.formSP.$invalid == true) return;
        if ($scope.SP.Password != $scope.CP.ConfirmPassword) {
            swal({ title: "Password and Confirmn Password must be same!", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        $http.post('api/SP/Register/', $scope.SP, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.SP = result;
                swal({ title: "Profile created sucessfully! An email link has sent to your emailid for varification. Please verify!", type: "success", showConfirmButton: true });
                $location.path('/login');
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.citylist = [];
    $scope.bindCity = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetAllCityList', Data: null })
        }).success(function (data) {
            $scope.citylist = data;
        });
    };
    $scope.bindCity();
});

app.controller('SiteUserCtrl', function ($scope, $http, $location) {
    $scope.CP = { ConfirmPassword: '' };
    $scope.User = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.UserSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {

        $scope.UserSubmitted = true;
        if ($scope.formUser.$invalid == true) return;
        if ($scope.User.Password != $scope.CP.ConfirmPassword) {
            swal({ title: "Password and Confirmn Password must be same!", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        $http.post('api/User/Register/', $scope.User, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.User = result;
                swal({ title: "Profile created sucessfully! An email link has sent to your emailid for varification. Please verify!", type: "success", showConfirmButton: true });
                $location.path('/login');
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.citylist = [];
    $scope.bindCity = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetAllCityList', Data: null })
        }).success(function (data) {
            $scope.citylist = data;
        });
    };
    $scope.bindCity();
});

app.controller('SearchResultController', function ($scope, $http, $location, $routeParams, User) {
    $scope.PageSize = 1;
    $scope.CurrentPage = 1;
    $scope.TotalPages = 0;

    var CategoryID = $routeParams.CategoryID;
    var SubID = $routeParams.SubID;
    var SearchText = $routeParams.SearchText;
    $scope.SB = { SubID: SubID };
    
    $scope.getSP = function () {
        $http({
            method: 'POST',
            url: 'api/Site/GetSPList/',
            data: JSON.stringify({ PageSize: $scope.PageSize, CurrentPage: $scope.CurrentPage, CategoryID: CategoryID, SubID: SubID, SearchText: SearchText, CityID: User.CityID })
        }).success(function (largeLoad) {
            $scope.TotalPages = largeLoad.TotalPages;
            $scope.SPList = JSON.parse(largeLoad.Data);
        });
    };
    $scope.prevPage = function () {
        $scope.CurrentPage--;
        $scope.getSP();
    }
    $scope.nextPage = function () {
        $scope.CurrentPage++;
        $scope.getSP();
    }
    setTimeout(function () { $scope.getSP(); }, 100);

    $scope.filter = { filterText: SearchText };
    $scope.searchSP = function () {
        if ($scope.filter.filterText != '')
            $location.path('/search/' + CategoryID + '/' + SubID + '/' + $scope.filter.filterText);
    };
    $scope.catlist = [];
    $scope.bindCategory = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetCategorySubCategoryList', Data: null, query: '' })
        }).success(function (data) {
            $scope.catlist = data;
        });
    };
    $scope.bindCategory();

    $scope.subCategorySelected = function ($item, $select) {
        $location.path('/search/0/' + $item.Key + '/');
    };
});

app.controller('SPProfileController', function ($scope, $http, $location, $routeParams, User) {
    var SPID = $routeParams.SPID;
    $scope.User = User;
    $scope.SP = {};

    $scope.Rate = { OverallRating: 1, Rating: 1, Review: '' };
    var calculateRating = function () {
        $scope.Rate.OverallRating = 0;
        var sumRating = 0;
        for (var j = 0; j < $scope.SP.SPRevList.length; j++) {
            sumRating += $scope.SP.SPRevList[j].Rating;
        }
        if (sumRating > 0)
            $scope.Rate.OverallRating = sumRating / $scope.SP.SPRevList.length;

        var yourRating = findByValue($scope.SP.SPRevList, 'UserID', User.UserID);
        if (yourRating.length >= 1)
            $scope.Rate.Rating = yourRating[0].Rating;
    };
    $scope.getSPProfile = function () {
        $http({
            method: 'POST',
            url: 'api/Site/GetSPProfile/',
            data: JSON.stringify(SPID)
        }).success(function (Data) {
            $scope.SP = JSON.parse(Data);
            $scope.SP.images = [];
            var baseImageUrl = 'Download.aspx?filepath=images/profile/'
            for (var j = 0; j < $scope.SP.SPImgList.length; j++) {
                var objImg = $scope.SP.SPImgList[j];
                $scope.SP.images.push({ thumb: baseImageUrl + objImg.ImageUrl, img: baseImageUrl + objImg.ImageUrl, description: objImg.Title });
            }

            calculateRating();
        });
    };



    setTimeout(function () { $scope.getSPProfile(); $scope.Rate.Rating = 0; }, 100);

    $scope.filter = { filterText: '' };
    $scope.searchSP = function () {
        if ($scope.filter.filterText != '')
            $location.path('/search/0/0/' + $scope.filter.filterText);
    };


    $scope.showModal = false;
    $scope.rate = function (rating) {
        $scope.showModal = true;
    };
    $scope.addReview = function () {
        if ($scope.Rate.Review == '' && $scope.Rate.Rating <= 5) {
            alert('Please add review when rating 5 or less than 5');
            return;
        }
        $http({
            method: 'POST',
            url: 'api/Site/AddReview/',
            data: JSON.stringify({ SPID: $scope.SP.SPID, Review: $scope.Rate.Review, Rating: $scope.Rate.Rating })
        }).success(function (Data) {
            var curDate = (new Date()).toJSON();
            $scope.SP.SPRevList = deleteByValue($scope.SP.SPRevList, 'UserID', User.UserID);
            $scope.SP.SPRevList.splice(0, 0, { ReviewDate: curDate, Review: $scope.Rate.Review, ImageUrl: User.ImageUrl, Rating: $scope.Rate.Rating, UserID: User.UserID });
            calculateRating();
            $scope.showModal = false;
        });
    };
});
app.controller('PagesController', function ($scope, $http, $location, $routeParams, User) {
    var PageID = $routeParams.PageID;
    $scope.Pages = {};
    $scope.toMarkup = function (text) {
        if (text == null) return '';
        text = text.replace(/\*\*\*(.*?)\*\*\*/g, "<h1>$1</h1>");
        text = text.replace(/\*\*(.*?)\*\*/g, "<h3>$1</h3>");
        text = text.replace(/\*(.*?)\*/g, "<b>$1</b>");
        text = text.replace(/_(.*?)_/g, "<u>$1</u>");
        text = text.replace(/~(.*?)~/g, "<i>$1</i>");
        text = text.replace(/--(.*?)--/g, "<del>$1</del>");
        text = text.replace(/<<(.*?)\|(.*?)>>/g, "<a href='$1'>$2</a>");
        text = text.replace(/\n(.*?)/g, "<br/>$1");
        return text;
    };
    var loadPage = function () {
        $http({
            method: 'GET',
            url: 'api/Pages/' + PageID
        }).success(function (Pages) {
            $scope.Pages = JSON.parse(Pages);
        });
    };
    setTimeout(function () {
        loadPage();
    }, 100);
});