using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
[Serializable]
public class LanguageBL
{

#region Declaration
private string connectionString;
Language _Language;
public Language Data
{
get { return _Language; }
set { _Language = value; }
}
public bool IsNew
{
get { return (_Language.ID <= 0 || _Language.ID ==null); }
}
#endregion

#region Constructor
public LanguageBL(string conString)
{
connectionString = conString;
}
#endregion

#region Main Methods
private LanguageDL CreateDL()
{
return new LanguageDL(connectionString);
}
public void New()
{
_Language = new Language();
}
public void Load(int ID)
{
var LanguageObj = this.CreateDL();
_Language = ID <= 0 ? LanguageObj.Load(-1) : LanguageObj.Load(ID);
}
public DataTable LoadAllLanguage()
{
var LanguageDLObj = CreateDL();
return LanguageDLObj.LoadAllLanguage();
}
public bool Update()
{
var LanguageDLObj = CreateDL();
return LanguageDLObj.Update(this.Data);
}
public bool Delete(int ID)
{
var LanguageDLObj = CreateDL();
return LanguageDLObj.Delete(ID);
}
#endregion
}
}
