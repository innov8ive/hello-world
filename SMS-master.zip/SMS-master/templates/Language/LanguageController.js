var app = angular.module('myApp');

app.controller('LanguageListCtrl', function ($scope, $http, $location, GridData) {

    $scope = readyAngularGrid($scope, $http, 'api/LanguageList', 'ID', GridData, 'Language');
    $scope.gridOptions.columnDefs = [

    { displayName: 'Language Key', field: 'LangKey' },
    { displayName: 'English', field: 'EN' },
    { displayName: 'Portuguese', field: 'PT' }, ];
    //$scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchLanguage = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.pagingOptions.currentPage = 1;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };
    $scope.newLanguage = function () {
        saveGridData($scope, GridData, 'Language');
        $location.path('/Language/0');
    };
    $scope.editLanguage = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            saveGridData($scope, GridData, 'Language');
            $location.path('/Language/' + selected[0].ID);
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.deleteLanguage = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'DELETE',
                url: 'api/Language/' + selected[0].ID
            }).success(function (result) {
                if (result == true)
                    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
            });
        }
        else {
            alert('Please select a record to edit.');
        }
    };
})

.controller('LanguageCtrl', function ($scope, $http, $location, $routeParams) {
    var ID = $routeParams.ID;
    $scope.Language = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.LanguageSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.LanguageSubmitted = true;
        if ($scope.formLanguage.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/Language', $scope.Language, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.Language = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/LanguageList');
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/Language/' + ID
        }).success(function (Language) {
            $scope.Language = JSON.parse(Language);
        });
    }, 100);
});
