using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;

namespace SampleAngular.Api
{
    public class LanguageController : ApiController
    {
        [Route("api/FetchLanguage")]
        [HttpGet]
        public Hashtable Language(string lang)
        {
            Hashtable ht = new Hashtable();
            DataTable dt = new DataTable();
            if (lang == "EN")
                dt = Common.GetDBResult("Select distinct LangKey,EN as LangValue from Language");
            else
                dt = Common.GetDBResult("Select distinct LangKey,PT as LangValue from Language");

            foreach (DataRow dr in dt.Rows)
            {
                ht[Common.ToString(dr["LangKey"])] = Common.ToString(dr["LangValue"]);
            }

            return ht;
        }

        // GET api/Language
        [Route("api/LanguageList/")]
        [HttpPost]
        public AngularGridData GetLanguage([FromBody]dynamic value)
        {
            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);

            if (!String.IsNullOrEmpty(objAngularGrid.SearchText))
            {
                objAngularDataBinder.Query = "Select * from Language where (LangKey like '%'+@Text+'%' OR EN like '%'+@Text+'%' OR PT like '%'+@Text+'%')";
                Hashtable ht = new Hashtable();
                ht["@Text"] = Common.ToString(objAngularGrid.SearchText);
                objAngularDataBinder.Parameters = ht;
            }
            else
            {
                objAngularDataBinder.Query = "Select * from Language";
            }
            objAngularDataBinder.ValueField = "ID";
            return objAngularDataBinder.GetData();
        }

        // GET api/Language/Id
        [Route("api/Language/{Id}")]
        public string GetLanguage(int Id)
        {
            LanguageBL objLanguageBL = new LanguageBL(Common.GetConString());
            objLanguageBL.Load(Id);
            return JsonConvert.SerializeObject(objLanguageBL.Data);
        }

        // POST api/Language/
        public string Post([FromBody]dynamic value)
        {
            JObject objJObject = value;
            Language objLanguage = objJObject.ToObject<Language>();
            LanguageBL objLanguageBL = new LanguageBL(Common.GetConString());
            objLanguageBL.Data = objLanguage;

            LanguageValidator validator = new LanguageValidator();
            ValidationResult results = validator.Validate(objLanguage);

            if (results.IsValid)
            {
                objLanguageBL.Update();
                return JsonConvert.SerializeObject(objLanguageBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        // DELETE api/Language/5
        [Route("api/Language/{Id}")]
        [HttpDelete]
        public bool Delete(int Id)
        {
            LanguageBL objLanguageBL = new LanguageBL(Common.GetConString());
            return objLanguageBL.Delete(Id);
        }
    }
    public class LanguageValidator : AbstractValidator<Language>
    {
        public LanguageValidator()
        {

            RuleFor(obj => obj.EN).NotEmpty();
            RuleFor(obj => obj.LangKey).NotEmpty();
            RuleFor(obj => obj.PT).NotEmpty();
        }
    }
}

