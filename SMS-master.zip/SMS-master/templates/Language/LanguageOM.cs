using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

[Serializable][Table(Name = "dbo.Language")]public class Language{
private string _EN;
private System.Nullable<int> _ID;
private string _LangKey;
private string _PT;
 
[Column(Storage = "_EN")]
public string EN{get {return _EN;}set { _EN=value;}}
[Column(Storage = "_ID")]
public System.Nullable<int> ID{get {return _ID;}set { _ID=value;}}
[Column(Storage = "_LangKey")]
public string LangKey{get {return _LangKey;}set { _LangKey=value;}}
[Column(Storage = "_PT")]
public string PT{get {return _PT;}set { _PT=value;}}
}}
