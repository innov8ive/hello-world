using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
    public class LanguageDL
    {
        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public LanguageDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public Language Load(int ID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            Language objLanguage = new Language();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get Language
                var resultLanguage = dc.ExecuteQuery<Language>("exec Get_Language {0}", ID).ToList();
                if (resultLanguage.Count > 0)
                {
                    objLanguage = resultLanguage[0];
                }
                dc.Dispose();
                return objLanguage;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllLanguage()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_Language", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(Language objLanguage)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update Language
                UpdateLanguage(objLanguage, trn);
                if (objLanguage.ID > 0)
                {

                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int ID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete Language
                DeleteLanguage(ID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateLanguage(Language objLanguage, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_Language", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@EN", SqlDbType.VarChar, 500).Value = objLanguage.EN;
                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = objLanguage.ID;
                cmd.Parameters["@ID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@LangKey", SqlDbType.VarChar, 250).Value = objLanguage.LangKey;
                cmd.Parameters.Add("@PT", SqlDbType.VarChar, 1000).Value = objLanguage.PT;

                cmd.ExecuteNonQuery();

                //after updating the Language, update ID
                objLanguage.ID = Convert.ToInt32(cmd.Parameters["@ID"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteLanguage(int ID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from Language where ID=@ID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = ID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        #endregion
    }
}
