using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;
using System.Text;
using System.IO;

namespace SampleAngular.Api
{
    public class MsgController : ApiController
    {
        [Route("api/Msg/SendEmailReminder")]
        [HttpPost]
        public string SendEmailReminder([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            JArray objJObject = value.val;
            DataTable dtDefaulter = objJObject.ToObject<DataTable>();
            string _subject = "SocietyInn: {0} Reminder for Payment";
            string _text = @"Dear <b>{0}</b>,<br/>
Your Total Due on Date <b>{1}</b> is <b>{2}</b>. Please Pay on or before Due Date to avoid interest.<br/>
<i>Note: It is reminder email. Please ignore this email if already paid.</i><br/>
Regards,<br/>
<b>{0}</b><br/>
Via SocietyInn";
            foreach (DataRow dr in dtDefaulter.Rows)
            {
                if (Common.ToBool(dr["Selected"]) == true)
                {
                    string emailID = Common.ToString(dr["EmailID"]);
                    if (emailID.Length > 0)
                    {
                        string subject = String.Format(_subject, objLoggedUser.SocName);
                        string text = String.Format(_text, Common.ToString(dr["PersonName"]), DateTime.Now.ToString("dd-MMM-yyyy"),
                            Common.ToDecimal(dr["Outstanding"]).ToString("0.00"), objLoggedUser.SocName);
                        Common.SendEmailSendGrid(emailID, text, subject);
                    }
                }
            }
            return String.Empty;
        }

        [Route("api/Msg/SendSMSReminder")]
        [HttpPost]
        public string SendSMSReminder([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            JArray objJObject = value.val;
            DataTable dtDefaulter = objJObject.ToObject<DataTable>();
            string _text = @"Alert: Your Total Due on Date {1} is {2}. Please ignore if already paid. {0} Via SocietyInn";
            foreach (DataRow dr in dtDefaulter.Rows)
            {
                if (Common.ToBool(dr["Selected"]) == true)
                {
                    string mobileNo = Common.ToString(dr["MobileNo"]);
                    if (mobileNo.Length > 0)
                    {
                        string text = String.Format(_text, objLoggedUser.SocName, DateTime.Now.ToString("dd-MMM-yyyy"),
                            Common.ToDecimal(dr["Outstanding"]).ToString("0.00"));
                        Common.SendSMS(mobileNo, text, objLoggedUser.SocID);
                    }
                }
            }
            return String.Empty;
        }

        [Route("api/Msg/SendSMS")]
        [HttpPost]
        public string SendSMS([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            JArray objJObject = value.val;
            List<string> mobileNoList = new List<string>();
            if (objJObject != null)
                mobileNoList = objJObject.ToObject<List<string>>();

            objJObject = value.Group;
            List<string> smsGroupList = new List<string>();
            if (objJObject != null)
                smsGroupList = objJObject.ToObject<List<string>>();

            string message = Common.ToString(value.Msg);
            StringBuilder mobileNo = new StringBuilder();

            if (mobileNoList.Contains("0"))
            {
                //Send to all members
                DataTable dtAll = Common.GetDBResultParameterized(@"select MobileNo 
from VW_Users U where MobileNo<>'' and MobileNo IS NOT NULL and CreatedBy=@CreatedBy Order By MobileNo",
                "@CreatedBy", SqlDbType.Int, objLoggedUser.UserID);
                mobileNoList = new List<string>();
                foreach (DataRow dr in dtAll.Rows)
                {
                    mobileNoList.Add(Common.ToString(dr["MobileNo"]));
                }
            }

            //add group sms
            foreach (string group in smsGroupList)
            {
                DataTable dt = Common.GetDBResultParameterized(@"Select MobileNo from Users where CreatedBy=@CreatedBy and 
MobileNo<>'' and MobileNo IS NOT NULL and IsActive=1 and " + Common.GetMemberTypeCondition(group),
                                                         "@CreatedBy", SqlDbType.Int, objLoggedUser.UserID);
                foreach (DataRow dr in dt.Rows)
                {
                    string mob = Common.ToString(dr["MobileNo"]);
                    if (mobileNoList.Contains(mob) == false)
                    {
                        mobileNoList.Add(mob);
                    }
                }
            }

            foreach (string m in mobileNoList)
            {
                mobileNo.Append(",").Append("+91").Append(m);
            }
            string mobileNos = String.Empty;
            if (mobileNo.Length > 0)
            {
                mobileNos = mobileNo.ToString().Substring(1);
            }
            if (Common.GetSMSCredit(objLoggedUser.SocID) < mobileNos.Split(',').Length)
            {
                return "Failed: You don't have enough SMS Credit to send SMS";
            }
            return Common.SendSMS(mobileNos, message, objLoggedUser.SocID);
        }

        [Route("api/Msg/SendEmail")]
        [HttpPost]
        public string SendEmail([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            JArray objJObject = value.val;
            List<string> emailList = new List<string>();
            if (objJObject != null)
                emailList = objJObject.ToObject<List<string>>();

            objJObject = value.Group;
            List<string> emailGroupList = new List<string>();
            if (objJObject != null)
                emailGroupList = objJObject.ToObject<List<string>>();
            string message = Common.ToString(value.Msg);
            string subject = Common.ToString(value.Sub);
            string fileGUID = Common.ToString(value.FileGUID);
            string fileName = Common.ToString(value.FileName);

            //add group sms
            foreach (string group in emailGroupList)
            {
                DataTable dt = Common.GetDBResultParameterized(@"Select EmailID from Users where CreatedBy=@CreatedBy and 
EmailID<>'' and EmailID IS NOT NULL and IsActive=1 and " + Common.GetMemberTypeCondition(group),
                                                         "@CreatedBy", SqlDbType.Int, objLoggedUser.UserID);
                foreach (DataRow dr in dt.Rows)
                {
                    string mob = Common.ToString(dr["EmailID"]);
                    if (emailList.Contains(mob) == false)
                    {
                        emailList.Add(mob);
                    }
                }
            }

            StringBuilder email = new StringBuilder();
            foreach (string e in emailList)
            {
                email.Append(",").Append(e);
            }
            string emails = String.Empty;
            if (email.Length > 0)
            {
                emails = email.ToString().Substring(1);
            }
            Dictionary<string, string> attachments = new Dictionary<string, string>();
            if (fileGUID.Length > 0)
            {
                string filePath = HttpContext.Current.Server.MapPath("~/AttachedFiles") + "/" + fileGUID;
                attachments.Add(fileName, filePath);
            }
            Common.SendEmailSendGrid(emails, message, subject, attachments);
            return String.Empty;
        }


        [Route("api/Msg/DeleteMsgFile")]
        [HttpPost]
        public string DeleteMsgFile([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            Common.IsValidForm(Constants.Forms.Message, Request);

            string FileGUID = Common.ToString(value.FileGUID);

            try
            {
                string filePath = HttpContext.Current.Server.MapPath("~/AttachedFiles") + "/" + FileGUID;
                File.Delete(filePath);
            }
            catch { }

            return String.Empty;
        }
    }
}

