﻿var app = angular.module('myApp');

app.controller('EmailMsgCtrl', function ($scope, $http, $location) {
    $scope.Msg = { Email: [] };
    var emaillist = [];
    $scope.bindEmailList = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetEmailList' })
        }).success(function (data) {
            $scope.emaillist = data;
        });
    };
    $scope.bindEmailList();

    var emailbulklist = [];
    $scope.bindEmailListBulk = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetEmailListBulk' })
        }).success(function (data) {
            $scope.emailbulklist = data;
        });
    };
    $scope.bindEmailListBulk();

    $scope.send = function () {

        if ($scope.Msg.Email.length == 0 && ($scope.Msg.EmailGroup == null || $scope.Msg.EmailGroup.length == 0)) {
            alert('Please enter email!');
            return;
        }
        if ($scope.Msg.Subject == null || $scope.Msg.Subject == '') {
            alert('Please enter Subject!');
            return;
        }
        if ($scope.Msg.Message == null || $scope.Msg.Message == '') {
            alert('Please enter Message!');
            return;
        }

        $http({
            method: 'POST',
            url: 'api/Msg/SendEmail',
            data: JSON.stringify({
                val: $scope.Msg.Email, Msg: $scope.Msg.Message,
                Sub: $scope.Msg.Subject, Group: $scope.Msg.EmailGroup,
                FileGUID: $scope.Msg.FileGUID, FileName: $scope.Msg.FileName
            })
        }).success(function (data) {
            if (data == "") {
                alert('Message Sent!');
                $scope.Msg.Email = [];
                $scope.Msg.EmailGroup = [];
                $scope.Msg.Message = '';
                $scope.Msg.Subject = '';
            }
            else {
                alert(data);
            }
        });
    };
    $scope.showFileUploader = function () {
        openFileUploader($scope.fileUploaded, 'FileUploadHandler.ashx', false);
    };
    $scope.fileUploaded = function (result) {
        var resultArr = result.split('|');
        if (resultArr.length > 1) {
            $scope.Msg.FileGUID = resultArr[0];
            $scope.Msg.FileName = resultArr[1];
        }
    };
    $scope.removeFile = function () {
        $http({
            method: 'POST',
            url: 'api/Msg/DeleteMsgFile',
            data: JSON.stringify($scope.Msg)
        }).success(function (data) {
            if (data == "") {
                $scope.Msg.FileGUID = null;
                $scope.Msg.FileName = null;
                swal({ title: "File Deleted Successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
            else {
                swal({ title: "File not Deleted Successfully!", type: "error", timer: 1000, showConfirmButton: false });
            }
        });
    };
});
app.controller('SMSCtrl', function ($scope, $http, $location) {
    $scope.Msg = { SMS: [] };
    var mobilelist = [];
    $scope.bindMobileList = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetMobileList' })
        }).success(function (data) {
            $scope.mobilelist = data;
        });
    };
    $scope.bindMobileList();

    var mobilebulklist = [];
    $scope.bindMobileListBulk = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetMobileListBulk' })
        }).success(function (data) {
            $scope.mobilebulklist = data;
        });
    };
    $scope.bindMobileListBulk();

    $scope.send = function () {
        var sms = [];
        for (var j = 0; j < $scope.Msg.SMS.length; j++) {
            sms.push($scope.Msg.SMS[j]);
        }

        if (sms.length == 0 && ($scope.Msg.SMSGroup == null || $scope.Msg.SMSGroup.length == 0)) {
            alert('Please enter Mobile Number or Group!');
            return;
        }

        if ($scope.Msg.Message == null || $scope.Msg.Message == '') {
            alert('Please enter Message!');
            return;
        }


        $http({
            method: 'POST',
            url: 'api/Msg/SendSMS',
            data: JSON.stringify({ val: sms, Msg: $scope.Msg.Message, Group: $scope.Msg.SMSGroup })
        }).success(function (data) {
            if (data == "Success") {
                alert('Message Sent!');
                $scope.Msg.SMS = [];
                $scope.Msg.SMSGroup = [];
                $scope.Msg.Message = '';
            }
            else {
                alert(data);
            }
        });
    };
});
