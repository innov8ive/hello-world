using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

    [Serializable]
    [Table(Name = "dbo.FM")]
    public class FM
    {
        private System.Nullable<int> _AddedBy;
        private System.Nullable<int> _FMID;
        private string _FMName;
        private string _Rel;
        private System.Nullable<int> _SocID;
        private string _EmailID;
        private string _MobileNo;
        private string _Gender;
        private Nullable<DateTime> _DOB;
        private string _IDCardType;
        private string _IDCardNo;
        private string _FMType;
        private Nullable<DateTime> _FromDate;
        private Nullable<DateTime> _ToDate;
        private string _ImageUrl;

         [Column(Storage = "_ImageUrl")]
        public string ImageUrl
        {
            get { return _ImageUrl; }
            set { _ImageUrl = value; }
        }

        [Column(Storage = "_ToDate")]
        public Nullable<DateTime> ToDate
        {
            get { return _ToDate; }
            set { _ToDate = value; }
        }

        [Column(Storage = "_FromDate")]
        public Nullable<DateTime> FromDate
        {
            get { return _FromDate; }
            set { _FromDate = value; }
        }

        [Column(Storage = "_FMType")]
        public string FMType
        {
            get { return _FMType; }
            set { _FMType = value; }
        }

        [Column(Storage = "_IDCardNo")]
        public string IDCardNo
        {
            get { return _IDCardNo; }
            set { _IDCardNo = value; }
        }

        [Column(Storage = "_IDCardType")]
        public string IDCardType
        {
            get { return _IDCardType; }
            set { _IDCardType = value; }
        }

        [Column(Storage = "_DOB")]
        public Nullable<DateTime> DOB
        {
            get { return _DOB; }
            set { _DOB = value; }
        }

        [Column(Storage = "_Gender")]
        public string Gender
        {
            get { return _Gender; }
            set { _Gender = value; }
        }

        [Column(Storage = "_MobileNo")]
        public string MobileNo
        {
            get { return _MobileNo; }
            set { _MobileNo = value; }
        }

        [Column(Storage = "_EmailID")]
        public string EmailID
        {
            get { return _EmailID; }
            set { _EmailID = value; }
        }

        [Column(Storage = "_AddedBy")]
        public System.Nullable<int> AddedBy
        {
            get
            {
                return _AddedBy;
            }
            set
            {
                _AddedBy = value;
            }
        }

        [Column(Storage = "_FMID")]
        public System.Nullable<int> FMID
        {
            get
            {
                return _FMID;
            }
            set
            {
                _FMID = value;
            }
        }

        [Column(Storage = "_FMName")]
        public string FMName
        {
            get
            {
                return _FMName;
            }
            set
            {
                _FMName = value;
            }
        }

        [Column(Storage = "_Rel")]
        public string Rel
        {
            get
            {
                return _Rel;
            }
            set
            {
                _Rel = value;
            }
        }

        [Column(Storage = "_SocID")]
        public System.Nullable<int> SocID
        {
            get
            {
                return _SocID;
            }
            set
            {
                _SocID = value;
            }
        }
    }
}
