using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
[Serializable]
public class FMBL
{

#region Declaration
private string connectionString;
FM _FM;
public FM Data
{
get { return _FM; }
set { _FM = value; }
}
public bool IsNew
{
get { return (_FM.FMID <= 0 || _FM.FMID ==null); }
}
#endregion

#region Constructor
public FMBL(string conString)
{
connectionString = conString;
}
#endregion

#region Main Methods
private FMDL CreateDL()
{
return new FMDL(connectionString);
}
public void New()
{
_FM = new FM();
}
public void Load(int FMID)
{
var FMObj = this.CreateDL();
_FM = FMID <= 0 ? FMObj.Load(-1) : FMObj.Load(FMID);
}
public DataTable LoadAllFM()
{
var FMDLObj = CreateDL();
return FMDLObj.LoadAllFM();
}
public bool Update()
{
var FMDLObj = CreateDL();
return FMDLObj.Update(this.Data);
}
public bool Delete(int FMID)
{
var FMDLObj = CreateDL();
return FMDLObj.Delete(FMID);
}
#endregion
}
}
