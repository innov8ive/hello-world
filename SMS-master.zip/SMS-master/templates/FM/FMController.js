var app = angular.module('myApp');

app.controller('FMListCtrl', function ($scope, $http, $location, GridData, $routeParams) {
    $scope.FMType = $routeParams.FMType;
    $scope.filter = { filterText: '', FMType: '' };
    $scope.FMList = [];

    $scope.searchFM = function () {
        $scope.filter.FMType = $scope.FMType;
        $http({
            method: 'POST',
            url: 'api/FMList/',
            data: JSON.stringify($scope.filter)
        }).success(function (result) {
            $scope.FMList = result;
           
        });
    };
    $scope.newFM = function () {
        $location.path('/FM/0/' + $scope.FMType);
    };
    $scope.editFM = function (FMID) {
        $location.path('/FM/' + FMID + '/' + $scope.FMType);
    };

    $scope.deleteFM = function (FMID) {
        if (confirm('Are you sure want to delete?') == false) return;
        $http({
            method: 'DELETE',
            url: 'api/FM/' + FMID
        }).success(function (result) {
            if (result == true)
                $scope.searchFM();
        });
    };

    window.setTimeout(function () { $scope.searchFM(); }, 200);
})

.controller('FMCtrl', function ($scope, $http, $location, $routeParams) {
    var FMID = $routeParams.FMID;
    $scope.FMType = $routeParams.FMType;
    $scope.FM = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.FMSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.FMSubmitted = true;
        if ($scope.formFM.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $scope.FM.FMType = $scope.FMType;
        $http.post('api/FM', $scope.FM, config)
        .success(function (data, status, headers, config) {
            var result = data;
            if (result.ErrorCode == 1)
                $scope.ErrorMessages = result.data;
            else {
                $scope.ErrorMessages = [];
                $scope.FM = result.data;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/FMList/' + $scope.FMType);
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/FM/' + FMID
        }).success(function (FM) {
            $scope.FM = FM;
        });
    }, 100);

    $scope.removePhoto = function () {
        if (confirm('Are you sure, want to remove photo?')) {
            $http({
                method: 'POST',
                url: 'api/FM/RemovePhoto/',
                data: JSON.stringify($scope.FM.FMID + '.' + $scope.FM.ImageUrl)
            }).success(function (result) {
                if (result == 'true')
                    $scope.FM.ImageUrl = '';
            });
        }
    };
    $scope.uploadPhoto = function () {
        AttachImage($scope.photoUploaded);
    };
    $scope.photoUploaded = function (fileGUIDName, fileName, fileID) {
        $scope.FM.ImageUrl = fileGUIDName;
        $http({
            method: 'POST',
            url: 'api/FM/AttachPhoto/',
            data: JSON.stringify($scope.FM.FMID + '.' + $scope.FM.ImageUrl)
        }).success(function (result) {

        });
    };
});
