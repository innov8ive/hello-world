using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;
using System.IO;
using System.Web.Http.Cors;

namespace SampleAngular.Api
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class FMController : ApiController
    {
        // GET api/FM
        [Route("api/FMList/")]
        [HttpPost]
        public DataTable FMList([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.NormalUser, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            string filterText = Common.ToString(value.filterText);
            string FMType = Common.ToString(value.FMType);

            DataTable dt = Common.GetDBResultParameterized(@"Select * from FM where AddedBy=@AddedBy 
and (FMName like '%'+@Name+'%' OR Rel like '%'+@Name+'%') and FMType=@FMType", "@AddedBy", SqlDbType.Int, objLoggedUser.UserID,
                                                          "@Name", SqlDbType.VarChar, filterText,
                                                          "@FMType", SqlDbType.VarChar, FMType);

            return dt;
        }

        // GET api/FM/Id
        [Route("api/FM/{Id}")]
        public object GetFM(int Id)
        {
            Common.IsValidForm(Constants.Forms.NormalUser, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            FMBL objFMBL = new FMBL(Common.GetConString());
            objFMBL.Load(Id);
            FM objFM = objFMBL.Data;
            if (Common.ToInt(objFM.AddedBy) > 0 && objFM.AddedBy != objLoggedUser.UserID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            return JsonConvert.DeserializeObject(JsonConvert.SerializeObject(objFMBL.Data));
        }

        // POST api/FM/
        public object Post([FromBody]dynamic value)
        {
            PostResponse objPostResponse = new PostResponse();
            Common.IsValidForm(Constants.Forms.NormalUser, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            FM objFM = objJObject.ToObject<FM>();
            FMBL objFMBL = new FMBL(Common.GetConString());
            objFMBL.Data = objFM;
            if (objFMBL.IsNew)
            {
                objFM.AddedBy = objLoggedUser.UserID;
                objFM.SocID = objLoggedUser.SocID;
            }
            FMValidator validator = new FMValidator();
            ValidationResult results = validator.Validate(objFM);
            if (objFM.MobileNo != null)
            {
                if (objFM.MobileNo.Length != 10)
                {
                    results.Errors.Add(new ValidationFailure("MobileNo", "Mobile No. should be 10 digit only"));
                }
                if (objFM.MobileNo.Length > 0 && Common.ToDouble(objFM.MobileNo) < 0)
                {
                    results.Errors.Add(new ValidationFailure("MobileNo", "Mobile No. should be 10 digit only"));
                }
                if (!String.IsNullOrEmpty(objFM.MobileNo) && objFM.MobileNo.Length > 0 && Common.ToInt(objFM.MobileNo.Substring(0, 1)) < 6)
                {
                    results.Errors.Add(new ValidationFailure("MobileNo", "Invalid Mobile No."));
                }
            }
            if (objFM.FMType == "Tenants" && objFM.FromDate == null)
            {
                results.Errors.Add(new ValidationFailure("FromDate", "Please enter From Date"));
            }
            if (objFM.FMType == "Tenants" && objFM.ToDate == null)
            {
                results.Errors.Add(new ValidationFailure("ToDate", "Please enter To Date"));
            }
            if (objFM.FMType == "Tenants" && objFM.ToDate != null && objFM.FromDate != null
                && objFM.ToDate.Value < objFM.FromDate.Value)
            {
                results.Errors.Add(new ValidationFailure("ToDate", "To Date should be greater than From Date"));
            }

            if (results.IsValid)
            {
                objFMBL.Update();
                objPostResponse.ErrorCode = 0;
                objPostResponse.data = JsonConvert.DeserializeObject(JsonConvert.SerializeObject(objFMBL.Data));
                return objPostResponse;
            }
            objPostResponse.ErrorCode = 1;
            objPostResponse.data = JsonConvert.DeserializeObject(JsonConvert.SerializeObject(results.Errors));
            objPostResponse.ErrorMessage = Common.ErrorToString(results);
            return objPostResponse;
        }

        // DELETE api/FM/5
        [Route("api/FM/{Id}")]
        [HttpDelete]
        public bool Delete(int Id)
        {
            Common.IsValidForm(Constants.Forms.NormalUser, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            FMBL objFMBL = new FMBL(Common.GetConString());
            objFMBL.Load(Id);
            FM objFM = objFMBL.Data;
            if (Common.ToInt(objFM.AddedBy) > 0 && objFM.AddedBy != objLoggedUser.UserID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            try
            {
                string filePath = HttpContext.Current.Server.MapPath("~/images/profile") + "/" + Common.ToString(objFM.ImageUrl);
                File.Delete(filePath);
            }
            catch { }
            return objFMBL.Delete(Id);
        }

        [Route("api/FMDelete/{Id}")]
        [HttpPost]
        public bool FMDelete(int Id)
        {
            return Delete(Id);
        }

        [Route("api/FM/RemovePhoto/")]
        [HttpPost]
        public string FMRemovePhoto([FromBody]dynamic param)
        {
            int userID = 0;
            string imageUrl;
            string data = param;
            if (data.Contains("."))
            {
                userID = Common.ToInt(data.Substring(0, data.IndexOf(".")));
                imageUrl = data.Substring(data.IndexOf(".") + 1);
                int count = Common.ExecuteNonQuery("Update FM Set ImageUrl='' where FMID=@FMID", "@FMID", SqlDbType.Int, Common.ToInt(userID));
                if (count > 0)
                {
                    try
                    {
                        string filePath = HttpContext.Current.Server.MapPath("~/images/profile") + "/" + imageUrl;
                        File.Delete(filePath);
                    }
                    catch { }
                    return "true";
                }
                else
                {
                    return "false";
                }
            }
            return "false";
        }
        [Route("api/FM/AttachPhoto/")]
        [HttpPost]
        public string FMAttachPhoto([FromBody]dynamic param)
        {
            int userID = 0;
            string imageUrl;
            string data = param;
            if (data.Contains("."))
            {
                userID = Common.ToInt(data.Substring(0, data.IndexOf(".")));
                imageUrl = data.Substring(data.IndexOf(".") + 1);

                int count = Common.ExecuteNonQuery("Update FM Set ImageUrl=@ImageUrl where FMID=@FMID"
                    , "@FMID", SqlDbType.Int, userID
                    , "@ImageUrl", SqlDbType.VarChar, imageUrl);
                if (count > 0)
                {
                    return imageUrl;
                }
                else
                {
                    return String.Empty;
                }
            }
            return String.Empty;
        }
    }
    public class FMValidator : AbstractValidator<FM>
    {
        public FMValidator()
        {
            RuleFor(obj => obj.FMName).NotEmpty();
        }
    }
}

