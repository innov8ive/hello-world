using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
    public class FMDL
    {

        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public FMDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public FM Load(int FMID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            FM objFM = new FM();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get FM
                var resultFM = dc.ExecuteQuery<FM>("exec Get_FM {0}", FMID).ToList();
                if (resultFM.Count > 0)
                {
                    objFM = resultFM[0];
                }
                dc.Dispose();
                return objFM;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllFM()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_FM", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(FM objFM)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update FM
                UpdateFM(objFM, trn);
                if (objFM.FMID > 0)
                {

                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int FMID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete FM
                DeleteFM(FMID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateFM(FM objFM, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_FM", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@AddedBy", SqlDbType.Int).Value = objFM.AddedBy;
                cmd.Parameters.Add("@FMID", SqlDbType.Int).Value = objFM.FMID;
                cmd.Parameters["@FMID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@FMName", SqlDbType.VarChar, 100).Value = objFM.FMName;
                cmd.Parameters.Add("@Rel", SqlDbType.VarChar, 50).Value = objFM.Rel;
                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = objFM.SocID;
                cmd.Parameters.Add("@EmailID", SqlDbType.VarChar, 100).Value = objFM.EmailID;
                cmd.Parameters.Add("@MobileNo", SqlDbType.VarChar, 20).Value = objFM.MobileNo;
                cmd.Parameters.Add("@Gender", SqlDbType.VarChar, 10).Value = objFM.Gender;
                cmd.Parameters.Add("@DOB", SqlDbType.DateTime).Value = objFM.DOB;
                cmd.Parameters.Add("@IDCardType", SqlDbType.VarChar, 10).Value = objFM.IDCardType;
                cmd.Parameters.Add("@IDCardNo", SqlDbType.VarChar, 20).Value = objFM.IDCardNo;
                cmd.Parameters.Add("@FMType", SqlDbType.VarChar, 10).Value = objFM.FMType;
                cmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = objFM.FromDate;
                cmd.Parameters.Add("@ToDate", SqlDbType.DateTime).Value = objFM.ToDate;

                cmd.ExecuteNonQuery();

                //after updating the FM, update FMID
                objFM.FMID = Convert.ToInt32(cmd.Parameters["@FMID"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteFM(int FMID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from FM where FMID=@FMID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@FMID", SqlDbType.Int).Value = FMID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        #endregion
    }
}
