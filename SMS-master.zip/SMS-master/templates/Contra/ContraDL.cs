using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
    public class ContraDL
    {
        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public ContraDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public Contra Load(int ContraID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            Contra objContra = new Contra();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get Contra
                var resultContra = dc.ExecuteQuery<Contra>("exec Get_Contra {0}", ContraID).ToList();
                if (resultContra.Count > 0)
                {
                    objContra = resultContra[0];
                }
                dc.Dispose();
                return objContra;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllContra()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_Contra", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(Contra objContra)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update Contra
                UpdateContra(objContra, trn);
                if (objContra.ContraID > 0)
                {

                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int ContraID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete Contra
                DeleteContra(ContraID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateContra(Contra objContra, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_Contra", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;
                cmd.Parameters.Add("@Amount", SqlDbType.Decimal).Value = objContra.Amount;
                cmd.Parameters.Add("@CompanyID", SqlDbType.Int).Value = objContra.CompanyID;
                cmd.Parameters.Add("@CrGEID", SqlDbType.Int).Value = objContra.CrGEID;
                cmd.Parameters.Add("@DrGEID", SqlDbType.Int).Value = objContra.DrGEID;
                cmd.Parameters.Add("@ContraID", SqlDbType.Int).Value = objContra.ContraID;
                cmd.Parameters["@ContraID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@FromGLID", SqlDbType.Int).Value = objContra.FromGLID;
                cmd.Parameters.Add("@LocationID", SqlDbType.Int).Value = objContra.LocationID;
                cmd.Parameters.Add("@RefDate", SqlDbType.DateTime).Value = objContra.RefDate;
                cmd.Parameters.Add("@RefNo", SqlDbType.VarChar, 100).Value = objContra.RefNo;
                cmd.Parameters["@RefNo"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@Remark", SqlDbType.VarChar, 500).Value = objContra.Remark;
                cmd.Parameters.Add("@ToGLID", SqlDbType.Int).Value = objContra.ToGLID;
                cmd.Parameters.Add("@WPID", SqlDbType.Int).Value = objContra.WPID;

                cmd.ExecuteNonQuery();

                //after updating the Contra, update ContraID
                objContra.ContraID = Convert.ToInt32(cmd.Parameters["@ContraID"].Value);
                objContra.RefNo = cmd.Parameters["@RefNo"].Value.ToString();

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteContra(int ContraID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from Contra where ContraID=@ContraID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@ContraID", SqlDbType.Int).Value = ContraID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        #endregion
    }
}
