var app = angular.module('myApp');

app.controller('ContraListCtrl', function ($scope, $http, $location, GridData) {
    $scope.Filter = { ContraType: null };
    $scope = readyAngularGrid($scope, $http, 'api/ContraList', 'ContraID', GridData, 'Contra');
    $scope.gridOptions.columnDefs = [

    { displayName: 'Ref No.', field: 'RefNo' },
    { displayName: 'Ref Date', field: 'RefDate', cellFilter: 'date:\'dd-MMM-yyyy\'' },
    { displayName: 'Amount', field: 'Amount' },
    { displayName: 'Debited from A/C', field: 'FGL' },
    { displayName: 'Credited to A/C', field: 'TGL' },
    { displayName: 'Remark', field: 'Remark' },
    ];
    
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchContra = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };
    $scope.newContra = function () {
        saveGridData($scope, GridData, 'Contra');
        $location.path('/Contra/0');
    };
    $scope.editContra = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            saveGridData($scope, GridData, 'Contra');
            $location.path('/Contra/' + selected[0].ContraID);
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.deleteContra = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'DELETE',
                url: 'api/Contra/' + selected[0].ContraID
            }).success(function (result) {
                if (result == true)
                    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
            });
        }
        else {
            alert('Please select a record to edit.');
        }
    };


    $scope.Contratypelist = [];
    $scope.bindContraType = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetOverheadGLList', Data: null, query: '18' })//In-Direct Contraense
        }).success(function (data) {
            $scope.Contratypelist = data;
        });
    }
    $scope.bindContraType();
})

.controller('ContraCtrl', function ($scope, $http, $location, $routeParams) {
    var ID = $routeParams.ContraID;
    $scope.Contra = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.ContraSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.ContraSubmitted = true;
        if ($scope.formContra.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        if ($scope.Contra.FromGLID == $scope.Contra.ToGLID) { alert('"From" and "To" Contra A/C should be different.'); return; }
        $http.post('api/Contra', $scope.Contra, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.Contra = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/ContraList');
    }

    $scope.debitfromlist = [];
    $scope.credittolist = [];
    $scope.bindDebitFrom = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetContraGLList', Data: null })
        }).success(function (data) {
            $scope.debitfromlist = data;
            $scope.credittolist = data;
        });
    }
    $scope.bindDebitFrom();

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/Contra/' + ID
        }).success(function (Contra) {
            $scope.Contra = JSON.parse(Contra);
            $scope.bindYear();
        });
    }, 100);

    $scope.yearlist = [];
    $scope.bindYear = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetYearList', Data: null })
        }).success(function (data) {
            $scope.yearlist = data;
        });
    };
});
