using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularDL;
using SampleAngularOM;

namespace SampleAngularBL
{
    [Serializable]
    public class ContraBL
    {
        #region Declaration
        private string connectionString;
        Contra _Contra;
        public Contra Data
        {
            get { return _Contra; }
            set { _Contra = value; }
        }
        public bool IsNew
        {
            get { return (_Contra.ContraID <= 0 || _Contra.ContraID == null); }
        }
        #endregion

        #region Constructor
        public ContraBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private ContraDL CreateDL()
        {
            return new ContraDL(connectionString);
        }
        public void New()
        {
            _Contra = new Contra();
        }
        public void Load(int ContraID)
        {
            var ContraObj = this.CreateDL();
            _Contra = ContraID <= 0 ? ContraObj.Load(-1) : ContraObj.Load(ContraID);
        }
        public DataTable LoadAllContra()
        {
            var ContraDLObj = CreateDL();
            return ContraDLObj.LoadAllContra();
        }
        public bool Update()
        {
            var ContraDLObj = CreateDL();
            return ContraDLObj.Update(this.Data);
        }
        public bool Delete(int ContraID)
        {
            var ContraDLObj = CreateDL();
            return ContraDLObj.Delete(ContraID);
        }
        #endregion
    }
}
