using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;
using System.IO;

namespace SampleAngular.Api
{
    public class ContraController : ApiController
    {
        // GET api/Contra
        [Route("api/ContraList/")]
        [HttpPost]
        public AngularGridData GetContra([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.FundTransfer, Request);
            LoggedUser objLoggedUser = HttpContext.Current.Session["LoggedUser"] as LoggedUser;

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = @"SELECT E.Amount,E.ContraID,E.RefDate,
E.RefNo,E.Remark,F.AccountName as FGL,T.AccountName as TGL FROM Contra E 
left outer join Accounts F ON E.FromGLID = F.AccountID and E.CompanyID=F.SocID
left outer join Accounts T ON E.ToGLID=T.AccountID and E.CompanyID=T.SocID where
(@FGL=0 OR E.FromGLID=@FGL) and E.CompanyID=@SocID";
            Hashtable ht = new Hashtable();
            ht["@FGL"] = Common.ToInt(0);
            ht["@SocID"] = objLoggedUser.SocID;
            objAngularDataBinder.Parameters = ht;
            objAngularDataBinder.ValueField = "ContraID";
            return objAngularDataBinder.GetData();
        }

        // GET api/Contra/Id
        [Route("api/Contra/{Id}")]
        public string GetContra(int Id)
        {
            Common.IsValidForm(Constants.Forms.FundTransfer, Request);
            LoggedUser objLoggedUser = HttpContext.Current.Session["LoggedUser"] as LoggedUser;

            ContraBL objContraBL = new ContraBL(Common.GetConString());
            objContraBL.Load(Id);
            if (objContraBL.IsNew)
            {
                objContraBL.Data.WPID = objLoggedUser.WPID;
            }
            if (objContraBL.IsNew == false && objContraBL.Data.CompanyID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            return JsonConvert.SerializeObject(objContraBL.Data);
        }

        // POST api/Contra/
        public string Post([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.FundTransfer, Request);
            LoggedUser objLoggedUser = HttpContext.Current.Session["LoggedUser"] as LoggedUser;

            JObject objJObject = value;
            Contra objContra = objJObject.ToObject<Contra>();
            ContraBL objContraBL = new ContraBL(Common.GetConString());
            objContraBL.Data = objContra;
            bool isNew = objContraBL.IsNew;

            ContraValidator validator = new ContraValidator();
            ValidationResult results = validator.Validate(objContra);
            if (objLoggedUser.WPID <= 0 || objContra.WPID <= 0)
            {
                results.Errors.Add(new ValidationFailure("WPID", "Working Period Not Selected"));
            }
            if (objContra.RefDate > objLoggedUser.EndDate || objContra.RefDate < objLoggedUser.StartDate)
            {
                results.Errors.Add(new ValidationFailure("RefDate", "Transfer Date is not in Working Period Range"));
            }
            if (results.IsValid)
            {
                if (isNew)
                {
                    objContra.WPID = objLoggedUser.WPID;
                    objContra.CompanyID = objLoggedUser.SocID;
                }
                else
                {
                    if (objContraBL.Data.CompanyID != objLoggedUser.SocID)
                        throw new HttpResponseException(HttpStatusCode.Unauthorized);
                }
                if (objContraBL.Update())
                {
                    int GEGroupID = Common.ToInt(objContra.ContraGEGroupID);
                    Common.ExecuteNonQuery("delete from GE where CompanyID=" + objContra.CompanyID + " and GEGroupID=" + GEGroupID);

                    GE objGE = GECommon.GEntry(GEGroupID, Common.ToInt(objContra.ToGLID), Common.ToDecimal(objContra.Amount), 0,
                        Common.ToInt(objContra.ContraID), objContra.RefNo, objContra.Remark,
                         Common.ToDate(objContra.RefDate),
                        objLoggedUser.SocID, 0, "Contra");

                    GEGroupID = Common.ToInt(objGE.GEGroupID);
                    GECommon.GEntry(GEGroupID, Common.ToInt(objContra.FromGLID), 0, Common.ToDecimal(objContra.Amount),
                        Common.ToInt(objContra.ContraID), objContra.RefNo, objContra.Remark,
                       Common.ToDate(objContra.RefDate),
                        objLoggedUser.SocID, 0, "Contra");

                    Common.ExecuteNonQuery("Update Contra set ContraGEGroupID=@ContraGEGroupID where ContraID=@ContraID",
                        "@ContraGEGroupID", SqlDbType.Int, GEGroupID,
                        "@ContraID", SqlDbType.Int, Common.ToInt(objContra.ContraID));
                    objContra.ContraGEGroupID = GEGroupID;
                }
               
                return JsonConvert.SerializeObject(objContraBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        // DELETE api/Contra/5
        [Route("api/Contraense/{Id}")]
        [HttpDelete]
        public bool Delete(int Id)
        {
            Common.IsValidForm(Constants.Forms.FundTransfer, Request);
            LoggedUser objLoggedUser = HttpContext.Current.Session["LoggedUser"] as LoggedUser;


            ContraBL objContraBL = new ContraBL(Common.GetConString());
            objContraBL.Load(Id);
            Contra objContra = objContraBL.Data;
            if (objContra.CompanyID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            GECommon.DeleteGEEntry(Common.ToInt(objContra.DrGEID));
            GECommon.DeleteGEEntry(Common.ToInt(objContra.CrGEID));
            return objContraBL.Delete(Id);
        }
    }
    public class ContraValidator : AbstractValidator<Contra>
    {
        public ContraValidator()
        {
            RuleFor(obj => obj.Remark).NotEmpty();
        }
    }
}

