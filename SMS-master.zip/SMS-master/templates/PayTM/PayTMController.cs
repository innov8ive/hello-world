using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;
using System.Threading;
using SampleAngular.PayTM;
using System.Text;
using System.Web.Http.Cors;

namespace SampleAngular.Api
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class PayTMController : ApiController
    {
        [Route("api/PayTM/GetToken/")]
        [HttpPost]
        public string GetToken([FromBody]dynamic value)
        {
            try
            {
                string authKey = Common.ToString(Common.GetDBScalar("Select AuthKey from Users where UserName='paytm'"));
                if (authKey != Common.ToString(value.AuthKey))
                {
                    return "Failure: Invalid Auth Key!";
                }
                else
                {
                    int userID = Common.ToInt(Common.GetDBScalar("Select UserID from Users where AuthKey=@AuthKey",
                           "@AuthKey", SqlDbType.VarChar, authKey));
                    LoginUser IsvalidUser = Common.LoadUser(userID);
                    if (IsvalidUser != null)
                        return IsvalidUser.Token;
                    else
                        return "Failure: UnKnown Error!";
                }
            }
            catch (Exception Ex)
            {
                return "Failure:" + Ex.Message;
            }
        }
        [Route("api/PayTM/GetAuthKey/")]
        [HttpGet]
        public string GetAuthKey([FromBody]dynamic value)
        {
            try
            {
                Common.IsValidForm(Constants.Forms.PayTMUser, Request);
                LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
                if (objLoggedUser == null) throw new HttpResponseException(HttpStatusCode.Unauthorized);

                string authKey = Common.ToString(Common.GetDBScalar("Select AuthKey from Users where UserName='paytm'"));

                return authKey;
            }
            catch (Exception Ex)
            {
                return "Failure:" + Ex.Message;
            }
        }

        [Route("api/PayTM/GenerateAuthKey/")]
        [HttpGet]
        public string GenerateAuthKey([FromBody]dynamic value)
        {
            try
            {
                Common.IsValidForm(Constants.Forms.PayTMUser, Request);
                LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
                if (objLoggedUser == null) throw new HttpResponseException(HttpStatusCode.Unauthorized);

                string authKey = Guid.NewGuid().ToString();
                Common.ExecuteNonQuery("Update Users set AuthKey=@AuthKey WHERE UserName='paytm'",
                    "@AuthKey", SqlDbType.VarChar, authKey);

                return authKey;
            }
            catch (Exception Ex)
            {
                return "Failure:" + Ex.Message;
            }
        }

        [Route("api/PayTM/SocietyList/")]
        [HttpPost]
        public object SocietyList([FromBody]dynamic value)
        {
            try
            {
                string authKey = Common.ToString(Common.GetDBScalar("Select AuthKey from Users where UserName='paytm'"));
                string authKeyFromHeader = GetAuthKeyFromHeader();
                if (authKey != authKeyFromHeader)
                    throw new HttpResponseException(HttpStatusCode.Unauthorized);

                string stateName = String.Empty;
                string city = String.Empty;

                if (value.StateName != null)
                    stateName = Common.ToString(value.StateName);

                if (value.City != null)
                    city = Common.ToString(value.City);

                PayTMBL objPayTMBL = new PayTMBL(Common.GetConString());
                List<SocietyDetails> objSocList = objPayTMBL.GetSocietyList(stateName, city);
                return JsonConvert.DeserializeObject(JsonConvert.SerializeObject(objSocList));
            }
            catch (Exception Ex)
            {
                return JsonConvert.DeserializeObject(JsonConvert.SerializeObject(new UnitDetails() { Response = "Failure:" + Ex.Message }));
            }
        }

        [Route("api/PayTM/GetUnitBills/{UnitNo}")]
        [HttpGet]
        public object GetUnitBills(int UnitNo)
        {
            try
            {
                string authKey = Common.ToString(Common.GetDBScalar("Select AuthKey from Users where UserName='paytm'"));
                string authKeyFromHeader = GetAuthKeyFromHeader();
                if (authKey != authKeyFromHeader)
                    throw new HttpResponseException(HttpStatusCode.Unauthorized);

                PayTMBL objPayTMBL = new PayTMBL(Common.GetConString());
                UnitDetails objUnitDetails = objPayTMBL.GetUnitDetails(UnitNo);
                objUnitDetails.Response = "Success";
                return JsonConvert.DeserializeObject(JsonConvert.SerializeObject(objUnitDetails));
            }
            catch (Exception Ex)
            {
                return JsonConvert.DeserializeObject(JsonConvert.SerializeObject(new UnitDetails() { Response = "Failure:" + Ex.Message }));
            }
        }

        [Route("api/PayTM/PostPayment/")]
        [HttpPost]
        public object PostPayment([FromBody]dynamic value)
        {
            try
            {
                string authKey = Common.ToString(Common.GetDBScalar("Select AuthKey from Users where UserName='paytm'"));
                string authKeyFromHeader = GetAuthKeyFromHeader();
                if (authKey != authKeyFromHeader)
                   throw new HttpResponseException(HttpStatusCode.Unauthorized);

                JObject objJObject = value;
                PaymentDetails objPaymentDetails = objJObject.ToObject<PaymentDetails>();

                StringBuilder error = new StringBuilder();
                int SocID = 0;
                string SocName = String.Empty;
                int PayTMGLID = 0;
                if (objPaymentDetails != null)
                {
                    DateTime? paidDate = Common.ToDate(objPaymentDetails.PaymentDate + " " + objPaymentDetails.PaymentTime, null);
                    if (paidDate == null)
                    {
                        error.AppendLine("Invalid Payment Date/Time");
                    }
                    if (objPaymentDetails.UnitNo <= 0)
                    {
                        error.AppendLine("Invalid Payment UnitNo");
                    }
                    if (String.IsNullOrEmpty(objPaymentDetails.PayTMTxnID))
                    {
                        error.AppendLine("PayTMTxnID should not be blank");
                    }
                    //Get SocID of UnitNo
                    SocName = Common.ToString(Common.GetDBScalar("Select S.SocName from Rooms R inner join Soc S ON R.SocID=S.SocID where R.RoomID=" + objPaymentDetails.UnitNo));
                    SocID = Common.ToInt(Common.GetDBScalar("Select SocID from Rooms where RoomID=" + objPaymentDetails.UnitNo));
                    //Get AccountID of PayTM ChgID
                    PayTMGLID = Common.ToInt(Common.GetDBScalar("Select AccountID from Accounts where AccountType='PayTM' and SocID=" + SocID));
                    if (SocID <= 0)
                    {
                        error.AppendLine("Invalid Unit No.");
                    }
                    if (PayTMGLID <= 0)
                    {
                        error.AppendLine("The Society is not allowed to get Payment through PayTM.");
                    }

                    //Code to verify Paytm Transaction
                    //error.AppendLine("Paytm Transaction TransactionID verification coding is pending.");

                    BillsBL objBillsBL = new BillsBL(Common.GetConString());
                    if (objPaymentDetails.PaymentBillDetails != null)
                    {
                        for (int counter = 0; counter < objPaymentDetails.PaymentBillDetails.Count; counter++)
                        {
                            PaymentBillDetails objPaymentBillDetails = objPaymentDetails.PaymentBillDetails[counter];
                            if (objPaymentBillDetails.BillID <= 0)
                            {
                                error.AppendLine("Invalid BillID of row " + (counter + 1));
                            }
                            else if (objPaymentBillDetails.PaidAmount <= 0)
                            {
                                error.AppendLine("Invalid PaidAmount of row " + (counter + 1));
                            }
                            else
                            {
                                //Check whether the Bill is 
                                //1. already paid
                                //2. amount mismatch (for misc bill)
                                objBillsBL.Load(objPaymentBillDetails.BillID);
                                Bills objBills = objBillsBL.Data;

                                if (objBills != null)
                                {
                                    if (objBills.RoomID != objPaymentDetails.UnitNo)
                                    {
                                        error.AppendLine("Invalid BillID or UnitNo of row " + (counter + 1));
                                    }
                                    if (objBills.BSID == 0 && objBills.TotalBillAmount != objPaymentBillDetails.PaidAmount)
                                    {
                                        error.AppendLine("PaidAmount mismatch of row " + (counter + 1));
                                    }
                                    if (objBills.PaidDate != null)
                                    {
                                        DataTable dtPayment = Common.GetDBResultParameterized(@"select BillID,PaymentID from dbo.BillPayments where PaymentID in 
(Select PaymentID from dbo.Payments where PaidRefNo=@PaidRefNo)", "@PaidRefNo", SqlDbType.VarChar, objPaymentDetails.PayTMTxnID);
                                        if (dtPayment.Rows.Count > 0)
                                        {
                                            //Send same response
                                            objPaymentDetails.PaymentID = Common.ToInt(dtPayment.Rows[0]["PaymentID"]);
                                            foreach (var objPBDetails in objPaymentDetails.PaymentBillDetails)
                                            {
                                                if (dtPayment.Select("BillID=" + objPBDetails.BillID).Count() > 0)
                                                {
                                                    objPBDetails.PaymentStatus = "Success";
                                                }
                                            }
                                            objPaymentDetails.Response = "Success";
                                            return JsonConvert.DeserializeObject(JsonConvert.SerializeObject(objPaymentDetails));
                                        }
                                        else
                                        {
                                            error.AppendLine("Bill is already paid of row " + (counter + 1));
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (error.Length > 0)
                    {
                        return JsonConvert.DeserializeObject(JsonConvert.SerializeObject(new PaymentDetails() { Response = "Failure:" + error.ToString() }));
                    }
                    else
                    {
                        PaymentsBL objPaymentsBL = new PaymentsBL(Common.GetConString());
                        Payments objPayment = new Payments();
                        objPayment.Amount = objPaymentDetails.TotalPaid;
                        objPayment.Approved = true;
                        objPayment.PaymentDate = paidDate;
                        objPayment.PaymentID = 0;
                        objPayment.PaymentMode = "PayTM";
                        objPayment.Remarks = "Paid via PayTM";
                        objPayment.RoomID = objPaymentDetails.UnitNo;
                        objPayment.SocID = SocID;

                        objPayment.PaidRefDate = paidDate;
                        objPayment.PaidRefNo = objPaymentDetails.PayTMTxnID;
                        objPayment.PaidToGLID = PayTMGLID;

                        objPayment.BillPaymentsList = new List<BillPayments>();
                        foreach (var objPaymentBillDetails in objPaymentDetails.PaymentBillDetails)
                        {
                            objPayment.BillPaymentsList.Add(new BillPayments()
                            {
                                BillID = objPaymentBillDetails.BillID,
                                PaidAmount = objPaymentBillDetails.PaidAmount,
                            });
                        }
                        objPaymentsBL.Data = objPayment;
                        if (objPaymentsBL.Update())
                        {
                            Common.UpdatePostPayment(SocID, SocName, objPayment);
                            objPaymentDetails.PaymentID = Common.ToInt(objPayment.PaymentID);
                            foreach (var objPaymentBillDetails in objPaymentDetails.PaymentBillDetails)
                            {
                                objPaymentBillDetails.PaymentStatus = "Success";
                            }
                            objPaymentDetails.Response = "Success";

                        }
                        else
                        {
                            return JsonConvert.DeserializeObject(JsonConvert.SerializeObject(new PaymentDetails() { Response = "Failure: Unknown Error occurred!" }));
                        }
                    }
                }
                else
                {
                    return JsonConvert.DeserializeObject(JsonConvert.SerializeObject(new PaymentDetails() { Response = "Failure: Invalid Request!" }));
                }
                return JsonConvert.DeserializeObject(JsonConvert.SerializeObject(objPaymentDetails));
            }
            catch (Exception Ex)
            {
                return JsonConvert.DeserializeObject(JsonConvert.SerializeObject(new PaymentDetails() { Response = "Failure:" + Ex.Message }));
            }
        }

        private string GetAuthKeyFromHeader()
        {
            IEnumerable<string> headerValues = null;
            var nameFilter = string.Empty;
            if (Request.Headers.TryGetValues("AuthKey", out headerValues))
            {
                return Common.ToString(headerValues.FirstOrDefault());
            }
            return String.Empty;
        }
    }
}

