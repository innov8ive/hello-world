﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Web;

namespace SampleAngular.PayTM
{
    [Serializable]
    public class UnitDetails
    {
        private string _SocName;
        private string _SocAddress1;
        private string _SocAddress2;
        private string _City;
        private string _ZipCode;
        private string _StateName;
        private string _BankAccountNo;
        private string _BankBranch;
        private string _BankIFSC;
        private string _BankName;
        private string _UnitNo;
        private string _Response;

        [Column(Storage = "_Response")]
        public string Response
        {
            get { return _Response; }
            set { _Response = value; }
        }

        [Column(Storage = "_UnitNo")]
        public string UnitNo
        {
            get { return _UnitNo; }
            set { _UnitNo = value; }
        }
        [Column(Storage = "_BankIFSC")]
        public string BankIFSC
        {
            get { return _BankIFSC; }
            set { _BankIFSC = value; }
        }
        [Column(Storage = "_BankName")]
        public string BankName
        {
            get { return _BankName; }
            set { _BankName = value; }
        }
        [Column(Storage = "_BankBranch")]
        public string BankBranch
        {
            get { return _BankBranch; }
            set { _BankBranch = value; }
        }
        [Column(Storage = "_BankAccountNo")]
        public string BankAccountNo
        {
            get { return _BankAccountNo; }
            set { _BankAccountNo = value; }
        }
        [Column(Storage = "_StateName")]
        public string StateName
        {
            get { return _StateName; }
            set { _StateName = value; }
        }
        [Column(Storage = "_ZipCode")]
        public string ZipCode
        {
            get { return _ZipCode; }
            set { _ZipCode = value; }
        }
        [Column(Storage = "_City")]
        public string City
        {
            get { return _City; }
            set { _City = value; }
        }
        [Column(Storage = "_SocAddress2")]
        public string SocAddress2
        {
            get { return _SocAddress2; }
            set { _SocAddress2 = value; }
        }
        [Column(Storage = "_SocAddress1")]
        public string SocAddress1
        {
            get { return _SocAddress1; }
            set { _SocAddress1 = value; }
        }
        [Column(Storage = "_SocName")]
        public string SocName
        {
            get { return _SocName; }
            set { _SocName = value; }
        }

        public List<BillDetails> Bills { get; set; }
    }

    [Serializable]
    public class BillDetails
    {
        private decimal? _TotalBillAmount;
        private int _BillID;
        private bool? _PartialPaymentAccept;
        private bool? _AdvancedPaymentAccept;
        private string _BillTitle;
        private DateTime? _BillDate;
        private DateTime? _DueDate;

        [Column(Storage = "_DueDate")]
        public DateTime? DueDate
        {
            get { return _DueDate; }
            set { _DueDate = value; }
        }

        [Column(Storage = "_TotalBillAmount")]
        public decimal? TotalBillAmount
        {
            get { return _TotalBillAmount; }
            set { _TotalBillAmount = value; }
        }

        [Column(Storage = "_BillID")]
        public int BillID
        {
            get { return _BillID; }
            set { _BillID = value; }
        }

        [Column(Storage = "_PartialPaymentAccept")]
        public bool? PartialPaymentAccept
        {
            get { return _PartialPaymentAccept; }
            set { _PartialPaymentAccept = value; }
        }

        [Column(Storage = "_AdvancedPaymentAccept")]
        public bool? AdvancedPaymentAccept
        {
            get { return _AdvancedPaymentAccept; }
            set { _AdvancedPaymentAccept = value; }
        }

        [Column(Storage = "_BillTitle")]
        public string BillTitle
        {
            get { return _BillTitle; }
            set { _BillTitle = value; }
        }

        [Column(Storage = "_BillDate")]
        public DateTime? BillDate
        {
            get { return _BillDate; }
            set { _BillDate = value; }
        }
    }

    [Serializable]
    public class PaymentDetails
    {
        public string PaymentDate { get; set; }
        public string PaymentTime { get; set; }
        public int UnitNo { get; set; }
        public string PayTMTxnID { get; set; }
        public int PaymentID { get; set; }
        public decimal TotalPaid { get; set; }
        public string Response { get; set; }

        public List<PaymentBillDetails> PaymentBillDetails { get; set; }
    }
    [Serializable]
    public class PaymentBillDetails
    {
        public int BillID { get; set; }
        public decimal PaidAmount { get; set; }
        public string PaymentStatus { get; set; }
    }
    [Serializable]
    public class SocietyDetails
    {
        private string _StateName;
        private string _City;
        private string _SocietyName;

        [Column(Storage = "_SocietyName")]
        public string SocietyName
        {
            get { return _SocietyName; }
            set { _SocietyName = value; }
        }
        [Column(Storage = "_City")]
        public string City
        {
            get { return _City; }
            set { _City = value; }
        }

        [Column(Storage = "_StateName")]
        public string StateName
        {
            get { return _StateName; }
            set { _StateName = value; }
        }
    }
}