var app = angular.module('myApp');

app.controller('PayTMHomeCtrl', function ($scope, $http, $location) {

    $scope.filter = { filterText: '' };
    $scope.UnitDetails = null;
    $scope.searchUnit = function () {
        $http({
            method: 'GET',
            url: 'api/PayTM/GetUnitBills/' + $scope.filter.filterText
        }).success(function (result) {
            $scope.UnitDetails = result;
        });
    };
    $scope.test = function () {
        var paymentData = {};
        paymentData.PaymentDate = '2018-01-26';
        paymentData.PaymentTime = '14:12:32';
        paymentData.UnitNo = 14;
        paymentData.PayTMTxnID = 'TJODH384574';
        paymentData.TotalPaid = 3437;
        paymentData.PaymentBillDetails = [];
        paymentData.PaymentBillDetails.push({ BillID: 60, PaidAmount: 3337 });
        paymentData.PaymentBillDetails.push({ BillID: 63, PaidAmount: 100 });

        $http({
            method: 'POST',
            url: 'api/PayTM/PostPayment/',
            data: JSON.stringify(paymentData)
        }).success(function (result) {
            $scope.UnitDetails = result;
        });
    };
   
});


app.controller('AuthKeyCtrl', function ($scope, $http, $location) {

    $scope.AuthKey = '';
  
    $scope.GenerateAuthKey = function () {
        if (confirm('After the generating new Auth Key, you must change it in your application to access SocietyInn APIs. Are you sure want to generate?') == true) {
            $http({
                method: 'GET',
                url: 'api/PayTM/GenerateAuthKey/'
            }).success(function (result) {
                $scope.AuthKey = result;
            });
        }
    };
    $scope.CopyAuthKey = function () {

    };
    window.setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/PayTM/GetAuthKey/'
        }).success(function (result) {
            $scope.AuthKey = result;
        });

    }, 200);
});