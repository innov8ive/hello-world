using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;
using SampleAngular.PayTM;

namespace SampleAngularBL
{
    [Serializable]
    public class PayTMBL
    {

        #region Declaration
        private string connectionString;
        #endregion

        #region Constructor
        public PayTMBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private PayTMDL CreateDL()
        {
            return new PayTMDL(connectionString);
        }

        public UnitDetails GetUnitDetails(int UnitNo)
        {
            var PayTMDLObj = this.CreateDL();
            return PayTMDLObj.GetUnitDetails(UnitNo);
        }
        public List<SocietyDetails> GetSocietyList(string stateName, string city)
        {
            var PayTMDLObj = this.CreateDL();
            return PayTMDLObj.GetSocietyList(stateName, city);
        }
        #endregion
    }
}
