﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Linq;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using SampleAngular.PayTM;

namespace SampleAngularDL
{
    public class PayTMDL
    {
        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public PayTMDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        public UnitDetails GetUnitDetails(int RoomID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            UnitDetails objUnitDetails = new UnitDetails();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get UnitDetails
                var resultUnitDetails = dc.ExecuteQuery<UnitDetails>(@"select S.SocName,S.SocAddress1,S.SocAddress2,
S.City,S.ZipCode,ST.StateName,S.BankAccountNo,S.BankBranch,S.BankIFSC,S.BankName,Convert(varchar,R.RoomID) as UnitNo
from Rooms R 
inner join Soc S ON R.SocID=S.SocID
left join State ST ON S.StateID=ST.StateID
where R.RoomID={0}", RoomID).ToList();
                if (resultUnitDetails.Count > 0)
                {
                    objUnitDetails = resultUnitDetails[0];
                }
                var resultRoomBills = dc.ExecuteQuery<BillDetails>(@"select TotalBillAmount,BillID,
Cast(case when BSID>0 then 1 else 0 end as bit) as PartialPaymentAccept,
Cast(case when BSID>0 then 1 else 0 end as bit) as AdvancedPaymentAccept,
BillTitle,BillDate,DATEADD(dd,Term,BillDate)as  DueDate
from Bills where PaidDate is NULL and IsNewBill=1
and not exists (select 1 from BillPaymentReq BPR where Bills.BillID=BPR.BillID)
 and RoomID={0}", RoomID).ToList();

                objUnitDetails.Bills = resultRoomBills;

                dc.Dispose();
                return objUnitDetails;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public List<SocietyDetails> GetSocietyList(string stateName, string city)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            List<SocietyDetails> objSocList = new List<SocietyDetails>();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get UnitDetails
                objSocList = dc.ExecuteQuery<SocietyDetails>(@"select ST.StateName,S.City,S.SocName as SocietyName from Soc S 
left join State ST ON S.StateID=ST.StateID where ({0}='' OR ST.StateName={0}) and ({1}='' OR S.City={1})", stateName, city).ToList();


                dc.Dispose();
                return objSocList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
    }
}