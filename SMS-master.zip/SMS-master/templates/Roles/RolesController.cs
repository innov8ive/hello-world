using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;

namespace SampleAngular.Api
{
    public class RolesController : ApiController
    {
        // GET api/Roles
        [Route("api/RolesList/")]
        [HttpPost]
        public AngularGridData GetRoles([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.UserRoles, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = "Select * from Roles where SocID=" + objLoggedUser.SocID;
            objAngularDataBinder.ValueField = "RoleID";
            return objAngularDataBinder.GetData();
        }

        // GET api/Roles/Id
        [Route("api/Roles/{Id}")]
        public string GetRoles(int Id)
        {
            Common.IsValidForm(Constants.Forms.UserRoles, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            RolesBL objRolesBL = new RolesBL(Common.GetConString());
            objRolesBL.Load(Id, objLoggedUser.SocID);

            Roles objRoles = objRolesBL.Data;
            if (Common.ToInt(objRoles.SocID) > 0 && objRoles.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            return JsonConvert.SerializeObject(objRolesBL.Data);
        }

        // POST api/Roles/
        public string Post([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.UserRoles, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            Roles objRoles = objJObject.ToObject<Roles>();
            RolesBL objRolesBL = new RolesBL(Common.GetConString());
            objRolesBL.Data = objRoles;

            RolesValidator validator = new RolesValidator();
            ValidationResult results = validator.Validate(objRoles);
            if (objRolesBL.IsNew)
            {
                objRoles.SocID = objLoggedUser.SocID;
            }
            if (results.IsValid)
            {
                objRolesBL.Update();
                return JsonConvert.SerializeObject(objRolesBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        // DELETE api/Roles/5
        [Route("api/Roles/{Id}")]
        [HttpDelete]
        public bool Delete(int Id)
        {
            Common.IsValidForm(Constants.Forms.UserRoles, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            RolesBL objRolesBL = new RolesBL(Common.GetConString());
            objRolesBL.Load(Id, objLoggedUser.SocID);

            Roles objRoles = objRolesBL.Data;
            if (Common.ToInt(objRoles.SocID) > 0 && objRoles.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            return objRolesBL.Delete(Id);
        }
    }
    public class RolesValidator : AbstractValidator<Roles>
    {
        public RolesValidator()
        {
            RuleFor(obj => obj.RoleName).NotEmpty();
        }
    }
}

