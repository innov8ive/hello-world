using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
    public class RolesDL
    {
        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public RolesDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public Roles Load(int RoleID, int SocID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            Roles objRoles = new Roles();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get Roles
                var resultRoles = dc.ExecuteQuery<Roles>("exec Get_Roles {0}", RoleID).ToList();
                if (resultRoles.Count > 0)
                {
                    objRoles = resultRoles[0];
                }
                //Get FormRoles
                objRoles.SelectedFormID = dc.ExecuteQuery<int>("exec Get_FormRoles {0},{1}", RoleID, SocID).ToList();
                var resultFormRoles = dc.ExecuteQuery<FormRoles>("exec Get_AllFormRoles").ToList();
                objRoles.FormRolesList = resultFormRoles;

                dc.Dispose();
                return objRoles;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllRoles()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_Roles", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(Roles objRoles)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update Roles
                UpdateRoles(objRoles, trn);
                if (objRoles.RoleID > 0)
                {

                    //Update FormRoles
                    DeleteFormRoles(Convert.ToInt32(objRoles.RoleID), trn);
                    foreach (var formID in objRoles.SelectedFormID)
                    {
                        FormRoles objFormRoles = new FormRoles();
                        objFormRoles.RoleID = objRoles.RoleID;
                        objFormRoles.FormID = formID;
                        objFormRoles.SocID = objRoles.SocID;
                        InsertIntoFormRoles(objFormRoles, trn);
                    }
                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int RoleID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete FormRoles
                DeleteFormRoles(RoleID, trn);
                //Delete Roles
                DeleteRoles(RoleID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateRoles(Roles objRoles, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_Roles", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = objRoles.ID;
                cmd.Parameters["@ID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@RoleID", SqlDbType.Int).Value = objRoles.RoleID;
                cmd.Parameters["@RoleID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@RoleName", SqlDbType.VarChar, 100).Value = objRoles.RoleName;
                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = objRoles.SocID;

                cmd.ExecuteNonQuery();

                //after updating the Roles, update RoleID
                objRoles.RoleID = Convert.ToInt32(cmd.Parameters["@RoleID"].Value);
                objRoles.ID = Convert.ToInt32(cmd.Parameters["@ID"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteRoles(int RoleID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from Roles where RoleID=@RoleID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@RoleID", SqlDbType.Int).Value = RoleID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        public bool DeleteFormRoles(int RoleID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from FormRoles where RoleID=@RoleID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@RoleID", SqlDbType.Int).Value = RoleID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        public bool InsertIntoFormRoles(FormRoles objFormRoles, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Into_FormRoles", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Transaction = trn;


                cmd.Parameters.Add("@FormID", SqlDbType.Int).Value = objFormRoles.FormID;
                cmd.Parameters.Add("@RoleID", SqlDbType.Int).Value = objFormRoles.RoleID;
                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = objFormRoles.SocID;

                cmd.ExecuteNonQuery();

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        #endregion
    }
}
