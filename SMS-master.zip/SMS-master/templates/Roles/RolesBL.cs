using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
    [Serializable]
    public class RolesBL
    {

        #region Declaration
        private string connectionString;
        Roles _Roles;
        public Roles Data
        {
            get { return _Roles; }
            set { _Roles = value; }
        }
        public bool IsNew
        {
            get { return (_Roles.RoleID <= 0 || _Roles.RoleID == null); }
        }
        #endregion

        #region Constructor
        public RolesBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private RolesDL CreateDL()
        {
            return new RolesDL(connectionString);
        }
        public void New()
        {
            _Roles = new Roles();
        }
        public void Load(int RoleID, int SocID)
        {
            var RolesObj = this.CreateDL();
            _Roles = RoleID <= 0 ? RolesObj.Load(-1, SocID) : RolesObj.Load(RoleID, SocID);
        }
        public DataTable LoadAllRoles()
        {
            var RolesDLObj = CreateDL();
            return RolesDLObj.LoadAllRoles();
        }
        public bool Update()
        {
            var RolesDLObj = CreateDL();
            return RolesDLObj.Update(this.Data);
        }
        public bool Delete(int RoleID)
        {
            var RolesDLObj = CreateDL();
            return RolesDLObj.Delete(RoleID);
        }
        #endregion
    }
}
