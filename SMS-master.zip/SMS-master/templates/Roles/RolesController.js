var app = angular.module('myApp');

app.controller('RolesListCtrl', function ($scope, $http, $location, GridData) {

    $scope = readyAngularGrid($scope, $http, 'api/RolesList', 'RoleID', GridData, 'Roles');
    $scope.gridOptions.columnDefs = [

    { displayName: 'Role Name', field: 'RoleName' } ];
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchRoles = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };
    $scope.newRoles = function () {
        saveGridData($scope, GridData, 'Roles');
        $location.path('/Roles/0');
    };
    $scope.editRoles = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            saveGridData($scope, GridData, 'Roles');
            $location.path('/Roles/' + selected[0].RoleID);
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.deleteRoles = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'DELETE',
                url: 'api/Roles/' + selected[0].RoleID
            }).success(function (result) {
                if (result == true)
                    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
            });
        }
        else {
            alert('Please select a record to edit.');
        }
    };
})

.controller('RolesCtrl', function ($scope, $http, $location, $routeParams) {
    var RoleID = $routeParams.RoleID;
    $scope.Roles = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.RolesSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.RolesSubmitted = true;
        if ($scope.formRoles.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/Roles', $scope.Roles, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.Roles = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/RolesList');
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/Roles/' + RoleID
        }).success(function (Roles) {
            $scope.Roles = JSON.parse(Roles);
        });
    }, 100);
    $scope.FormRoles = {};
    $scope.FormRolesSubmitted = false;
    var FormRoles = [];
    $scope.editFormRoles = function (indx) {
        $scope.EditMode = true;
        $scope.FormRoles = $scope.Roles.FormRolesList[indx];
        FormRoles = angular.copy($scope.Roles.FormRolesList);
    };
    $scope.deleteFormRoles = function (indx) {
        if (confirm('Are you sure want to delete?') == true) {
            $scope.Roles.FormRolesList.splice(indx, 1);
        }
    };
    $scope.newFormRoles = function () {
        $scope.EditMode = true;
        $scope.FormRolesSubmitted = false;
        FormRoles = angular.copy($scope.Roles.FormRolesList);
        $scope.FormRoles = {};
        $scope.Roles.FormRolesList.push($scope.FormRoles);
    };
    $scope.cancelFormRoles = function () {
        $scope.EditMode = false;
        $scope.FormRoles = {};
        angular.copy(FormRoles, $scope.Roles.FormRolesList);
    };
    $scope.updateFormRoles = function (indx) {
        $scope.FormRolesSubmitted = true;
        if ($scope.formFormRoles.$invalid == true) return;
        $scope.EditMode = false;
        $scope.FormRoles = {};
    };
});
app.directive('formroles', function () {
    return {
        restrict: 'E',
        replace: true,
        templateUrl: 'templates/Roles/FormRoles.html'
    }
});
