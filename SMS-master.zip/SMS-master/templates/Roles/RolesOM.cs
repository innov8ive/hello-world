using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

    [Serializable]
    [Table(Name = "dbo.Roles")]
    public class Roles
    {
        private System.Nullable<int> _ID;
        private System.Nullable<int> _RoleID;
        private string _RoleName;
        private System.Nullable<int> _SocID;

        [Column(Storage = "_ID")]
        public System.Nullable<int> ID
        {
            get
            {
                return _ID;
            }
            set
            {
                _ID = value;
            }
        }

        [Column(Storage = "_RoleID")]
        public System.Nullable<int> RoleID
        {
            get
            {
                return _RoleID;
            }
            set
            {
                _RoleID = value;
            }
        }

        [Column(Storage = "_RoleName")]
        public string RoleName
        {
            get
            {
                return _RoleName;
            }
            set
            {
                _RoleName = value;
            }
        }

        [Column(Storage = "_SocID")]
        public System.Nullable<int> SocID
        {
            get
            {
                return _SocID;
            }
            set
            {
                _SocID = value;
            }
        }


        public System.Collections.Generic.List<FormRoles> FormRolesList { get; set; }
        public List<int> SelectedFormID { get; set; }
        public Hashtable Types { get; set; }
    }


    [Serializable]
    [Table(Name = "dbo.FormRoles")]
    public class FormRoles
    {
        private System.Nullable<int> _FormID;
        private System.Nullable<int> _RoleID;
        private System.Nullable<int> _SocID;
        private System.Nullable<bool> _Selected;
        private string _FormName;

        [Column(Storage = "_FormName")]
        public string FormName
        {
            get { return _FormName; }
            set { _FormName = value; }
        }

        [Column(Storage = "_Selected")]
        public System.Nullable<bool> Selected
        {
            get { return _Selected; }
            set { _Selected = value; }
        }

        [Column(Storage = "_FormID")]
        public System.Nullable<int> FormID
        {
            get
            {
                return _FormID;
            }
            set
            {
                _FormID = value;
            }
        }

        [Column(Storage = "_RoleID")]
        public System.Nullable<int> RoleID
        {
            get
            {
                return _RoleID;
            }
            set
            {
                _RoleID = value;
            }
        }

        [Column(Storage = "_SocID")]
        public System.Nullable<int> SocID
        {
            get
            {
                return _SocID;
            }
            set
            {
                _SocID = value;
            }
        }
    }
}
