var app = angular.module('myApp');

app.controller('PaymentReqListCtrl', function ($scope, $http, $location, GridData) {

    $scope = readyAngularGrid($scope, $http, 'api/PaymentReqList', 'ReqID', GridData, 'PaymentReq');
    $scope.gridOptions.columnDefs = [
    { displayName: 'Unit No.', field: 'RoomNo' },
    { displayName: 'Request Date', field: 'ReqDate', cellFilter: 'date:\'dd-MMM-yyyy\'' },
    { displayName: 'Paid Amount', field: 'Amount' },
    { displayName: 'Payment Mode', field: 'PaymentMode' },
    { displayName: 'Ref No', field: 'PaidRefNo' },
    { displayName: 'Paid Date', field: 'PaidRefDate', cellFilter: 'date:\'dd-MMM-yyyy\'' },
    { displayName: 'Paid To GL', field: 'AccountName' }];
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchPaymentReq = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };
    $scope.editPaymentReq = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $location.path('/Payments/0/' + selected[0].RoomID + '/0/' + selected[0].ReqID);
        }
        else {
            alert('Please select a record to Edit.');
        }
    };
    $scope.approvePaymentReq = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'POST',
                url: 'api/PaymentReq/Approve/',
                data: JSON.stringify({ ReqID: selected[0].ReqID })
            }).success(function (result) {
                $scope.searchPaymentReq();
            });
        }
        else {
            alert('Please select a record to Approve.');
        }
    };
    $scope.PaymentReq = {};
    $scope.showModal = false;
    $scope.reject = function () {
        $scope.PaymentReq.Remarks = '';
        $scope.showModal = true;
    };
    $scope.rejectPaymentReq = function () {
        if ($scope.PaymentReq.Remarks == '') {
            alert('Please enter Remarks');
            return;
        }
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $scope.showModal = false;
            $http({
                method: 'POST',
                url: 'api/PaymentReq/Reject/',
                data: JSON.stringify({
                    ReqID: selected[0].ReqID,
                    Remarks: $scope.PaymentReq.Remarks, BillID: selected[0].BillID
                })
            }).success(function (result) {
                $scope.searchPaymentReq();
                $scope.showModal = false;
            });
        }
        else {
            alert('Please select a record to Approve.');
        }
    };
})
.controller('PaymentReqCtrl', function ($scope, $http, $location, $routeParams) {
    var ReqID = $routeParams.ReqID;
    $scope.PaymentReq = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.PaymentReqSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.PaymentReqSubmitted = true;
        if ($scope.formPaymentReq.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/PaymentReq', $scope.PaymentReq, config)
        .success(function (data, status, headers, config) {
            var result = data;
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.PaymentReq = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/PaymentReqList');
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/PaymentReq/' + ReqID
        }).success(function (PaymentReq) {
            $scope.PaymentReq = PaymentReq;
        });
    }, 100);
});
app.controller('PayAndDueCtrl', function ($scope, $http, $filter) {
    $scope.bindDues = function () {
        $http({
            method: 'POST',
            url: 'api/Home/BillList/'
        }).success(function (result) {
            $scope.BillList = result;
        });
    };
    var BillID = 0;
    var RoomID = 0;
    $scope.bindDues();
    $scope.showPayReqWin = false;
    $scope.PaymentReq = {};
    $scope.createReq = function (itm) {
        BillID = itm.BillID;
        RoomID = itm.RoomID;
        setTimeout(function () {
            $http({
                method: 'GET',
                url: 'api/PaymentReq/' + itm.ReqID
            }).success(function (Payments) {
                $scope.PaymentReq = Payments;
                $scope.PaymentReq.Amount = itm.Amount;
                $scope.PaymentReq.BSID = itm.BSID;
                var date = new Date();
                $scope.PaymentReq.PaymentDate = $filter('date')(date, 'dd-MMM-yyyy');
                $scope.bindCreditTo();
                $scope.showPayReqWin = true;
            });
        }, 100);
    };
    $scope.credittolist = [];
    $scope.bindCreditTo = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetContraGLList', Data: null })
        }).success(function (data) {
            $scope.credittolist = data;
        });
    };

    $scope.PaymentReqSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.PaymentReqSubmitted = true;
        if ($scope.formPaymentReq.$invalid == true) return;
        $scope.PaymentReq.BillID = BillID;
        $scope.PaymentReq.RoomID = RoomID;
        $scope.showPayReqWin = false;
        $http.post('api/PaymentReq', $scope.PaymentReq, config)
        .success(function (data, status, headers, config) {
            var result = data;
            if (result.ErrorCode == 1) {
                $scope.ErrorMessages = result.data;
                $scope.showPayReqWin = true;
            }
            else {
                $scope.ErrorMessages = [];
                $scope.PaymentReq = result.data;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
                $scope.bindDues();
                $scope.showPayReqWin = false;
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };
    $scope.showModal = false;
    $scope.printUrl = 'blankPage.html';
    $scope.openBill = function (billID) {
        $scope.printUrl = 'PrintBill.aspx?BillID=' + billID;
        $scope.showModal = true;
    };
    $scope.openRec = function (billID) {
        $scope.printUrl = 'PrintReciept.aspx?BillID=' + billID;
        $scope.showModal = true;
    };
});
app.controller('PaymentHistoryCtrl', function ($scope, $http) {
    $scope.printUrl = 'blankPage.html';
    $scope.bindPaymentHistory = function () {
        $http({
            method: 'POST',
            url: 'api/PaymentReq/History/'
        }).success(function (result) {
            $scope.BillList = result;
        });
    };
    $scope.bindPaymentHistory();

    $scope.showModal = false;

    $scope.openRec = function (billID) {
        $scope.printUrl = 'PrintReciept.aspx?BillID=' + billID;
        $scope.showModal = true;
    };
});