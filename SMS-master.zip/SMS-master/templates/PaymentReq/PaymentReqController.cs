using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;
using System.Text;
using System.Web.Http.Cors;

namespace SampleAngular.Api
{

    public class PaymentReqController : ApiController
    {
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/PaymentReq/History/")]
        [HttpPost]
        public DataTable PaymentHistory([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            DataTable dt = Common.GetDBResultParameterized(@"select B.RoomID,B.TotalBillAmount as Amount
,B.BillTitle,B.BillID,B.Remarks,B.PaidToGLID,
W.WingName+' '+R.RoomNo as RoomNo,DateAdd(DD,B.Term,B.BillDate) as DueDate,
B.BillDate,B.PaidDate
,ISNULL(B.TotalBillAmount,0)-ISNULL(PaidAmount,0)-ISNULL(Discount,0) as Outstanding
,ISNULL(PaidAmount,0) as PaidAmount from Bills B
inner join Rooms R ON B.RoomID=R.RoomID
inner join Wings W ON W.WingID=R.WingID
inner join Soc S ON R.SocID=S.SocID
inner join Payments P ON B.BillID=P.BillID
where exists (select 1 from UserRooms U where U.RoomID=B.RoomID and U.SocID=B.SocID and U.UserID=@UserID)
and B.SocID=@SocID
Order By B.BillDate desc",
    "@UserID", SqlDbType.Int, objLoggedUser.UserID,
    "@SocID", SqlDbType.Int, objLoggedUser.SocID);

            return dt;
        }

        [Route("api/PaymentReq/Approve/")]
        [HttpPost]
        public string PaymentReqApprove([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            Common.IsValidForm(Constants.Forms.PaymentReconcilation, Request);

            try
            {
                int ReqID = Common.ToInt(value.ReqID);
                PaymentReqBL objPayReqBL = new PaymentReqBL(Common.GetConString());
                objPayReqBL.Load(ReqID);
                PaymentReq objPayReq = objPayReqBL.Data;
                if (objPayReq.ReqID > 0)
                {
                    Payments objPayments = new Payments();
                    PaymentsBL objPaymentsBL = new PaymentsBL(Common.GetConString());
                    objPayments.Amount = objPayReq.Amount;
                    objPayments.BillID = objPayReq.BillID;
                    objPayments.PaidGEGroupID = 0;
                    objPayments.PaidRefDate = objPayReq.PaidRefDate;
                    objPayments.PaidRefNo = objPayReq.PaidRefNo;
                    objPayments.PaidToGLID = objPayReq.PaidToGLID;
                    objPayments.PaymentDate = objPayReq.ReqDate;
                    objPayments.PaymentID = 0;
                    objPayments.PaymentMode = objPayReq.PaymentMode;
                    //objPayments.Remarks = objPayReq.Remarks;
                    objPayments.RoomID = objPayReq.RoomID;
                    objPayments.SocID = objPayReq.SocID;

                    objPayments.BillPaymentsList = new List<BillPayments>();
                    foreach (var obj in objPayReq.BillPaymentReqList)
                    {
                        objPayments.BillPaymentsList.Add(new BillPayments()
                        {
                            BillID = obj.BillID,
                            PaidAmount = obj.PaidAmount
                        });
                    }

                    objPaymentsBL.Data = objPayments;
                    if (objPaymentsBL.Update())
                    {
                        Common.UpdatePostPayment(objLoggedUser.SocID, objLoggedUser.SocName, objPayments);
                        Common.ExecuteNonQuery("Update PaymentReq set Status='Approved',RejectRemarks='' where ReqID=" + ReqID);
                    }
                }
            }
            catch (Exception Ex)
            {
                return "Error:" + Ex.Message;
            }
            return "Success";
        }

        [Route("api/PaymentReq/Reject/")]
        [HttpPost]
        public string PaymentReqReject([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            Common.IsValidForm(Constants.Forms.PaymentReconcilation, Request);
            int ReqID = Common.ToInt(value.ReqID);
            DataTable dtRequester = Common.GetDBResult("Select * from Users U inner join PaymentReq PR ON U.UserID=PR.ReqBy where PR.ReqID=" + ReqID);
            if (dtRequester.Rows.Count > 0)
            {
                PaymentReqBL objPayReqBL = new PaymentReqBL(Common.GetConString());
                objPayReqBL.Load(ReqID);
                PaymentReq objPayReq = objPayReqBL.Data;
                if (objPayReq.ReqID > 0)
                {
                    foreach (var obj in objPayReq.BillPaymentReqList)
                    {
                        Common.ExecuteNonQuery(@"Update Bills set PaymentReqDate=NULL where BillID=@BillID;
                Update PaymentReq set Status='Rejected',RejectRemarks=@RejectRemarks where ReqID=" + ReqID,
                            "@RejectRemarks", SqlDbType.VarChar, Common.ToString(value.Remarks),
                            "@BillID", SqlDbType.Int, Common.ToInt(obj.BillID));
                        Common.SendSMS(Common.ToString(dtRequester.Rows[0]["MobileNo"]), "Payment Rejected. Reason:" + Common.ToString(value.Remarks), 0);
                        Common.InsertIntoAlerts("Payment Rejected. Reason:" + Common.ToString(value.Remarks), objLoggedUser.SocID, Common.ToInt(dtRequester.Rows[0]["UserID"]), "PAYMENTREQ");
                    }
                }
            }
            return "Success";
        }

        [Route("api/PaymentReqList/")]
        [HttpPost]
        public AngularGridData GetPaymentReq([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            Common.IsValidForm(Constants.Forms.PaymentReconcilation, Request);
            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = @"Select W.WingName+' '+R.RoomNo as RoomNo,PR.RoomID, ReqID, PR.Amount, PR.PaymentMode
,PR.ReqDate,PR.PaidRefNo,U.FirstName+ISNULL(' '+U.LastName,'') as RequestedBy
,A.AccountName from PaymentReq PR 
inner join Users U ON U.UserID = PR.ReqBy
inner join Rooms R ON PR.RoomID=R.RoomID
inner join Wings W ON R.WingID=W.WingID
inner join Accounts A ON A.AccountID = PR.PaidToGLID and A.SocID=PR.SocID
where PR.Status is null and PR.SocID=" + objLoggedUser.SocID;
            objAngularDataBinder.ValueField = "ReqID";
            return objAngularDataBinder.GetData();
        }

        // GET api/PaymentReq/Id
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/PaymentReq/{Id}")]
        public object GetPaymentReq(int Id)
        {
            PaymentReqBL objPaymentReqBL = new PaymentReqBL(Common.GetConString());
            objPaymentReqBL.Load(Id);
            return JsonConvert.DeserializeObject(JsonConvert.SerializeObject(objPaymentReqBL.Data));
        }

        // POST api/PaymentReq/
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        public object Post([FromBody]dynamic value)
        {
            PostResponse objPostResponse = new PostResponse();
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            JObject objJObject = value;
            PaymentReq objPaymentReq = objJObject.ToObject<PaymentReq>();
            PaymentReqBL objPaymentReqBL = new PaymentReqBL(Common.GetConString());
            objPaymentReqBL.Load(Common.ToInt(objPaymentReq.ReqID));
            objPaymentReqBL.Data = objPaymentReq;

            PaymentReqValidator validator = new PaymentReqValidator();
            ValidationResult results = validator.Validate(objPaymentReq);
            objPaymentReq.SocID = objLoggedUser.SocID;
            objPaymentReq.ReqBy = objLoggedUser.UserID;
            objPaymentReq.ReqDate = DateTime.Now;

            objPaymentReq.BillPaymentReqList = new List<BillPaymentReq>();
            objPaymentReq.BillPaymentReqList.Add(new BillPaymentReq()
            {
                BillID = objPaymentReq.BillID,
                PaidAmount = objPaymentReq.Amount
            });

            if (results.IsValid)
            {
                objPaymentReqBL.Update();
                Common.ExecuteNonQuery(@"Update Bills set PaymentReqDate=@PaymentReqDate where BillID=@BillID;
Update PaymentReq set status=NULL, RejectRemarks=NULL where ReqID=@ReqID",
               "@PaymentReqDate", SqlDbType.DateTime, objPaymentReq.ReqDate,
               "@BillID", SqlDbType.Int, Common.ToInt(objPaymentReq.BillID),
               "@ReqID", SqlDbType.Int, Common.ToInt(objPaymentReq.ReqID));
                DataTable dt = Common.GetDBResult(@"select U.EmailID,U.MobileNo,
U.FirstName+ISNULL(' '+U.LastName,'') as UserName
from Soc S inner join Users U ON S.UserID=U.UserID
where S.SocID=" + objLoggedUser.SocID);
                if (dt.Rows.Count > 0)
                {
                    StringBuilder sb = new StringBuilder();
                    sb.AppendFormat("Dear {0}<br/>", Common.ToString(dt.Rows[0]["UserName"]));
                    sb.AppendFormat("A Payment Requset is made against bill number <b>{0}</b>",
                        objPaymentReq.BillID);
                    sb.AppendFormat("Please login to societyinn.com to Approve/Reject.<br/><br/>");
                    Common.SendEmailSendGrid(Common.ToString(dt.Rows[0]["EmailID"]), sb.ToString(), "Payment Request Received!");

                    string mobileNo = Common.ToString(dt.Rows[0]["MobileNo"]);
                    Common.SendSMS(mobileNo, "New Payment Request Received. " + objLoggedUser.SocName, 0);
                    Common.InsertIntoAlerts("New Payment Request Received. " + objLoggedUser.SocName, objLoggedUser.SocID, 0, "BILL");
                }
                objPostResponse.ErrorCode = 0;
                objPostResponse.data = JsonConvert.DeserializeObject(JsonConvert.SerializeObject(objPaymentReqBL.Data));
                return objPostResponse;
            }
            objPostResponse.ErrorCode = 1;
            objPostResponse.data = JsonConvert.DeserializeObject(JsonConvert.SerializeObject(results.Errors));
            objPostResponse.ErrorMessage = Common.ErrorToString(results);
            return objPostResponse;
        }

        // DELETE api/PaymentReq/5
        [Route("api/PaymentReq/{Id}")]
        [HttpDelete]
        public bool Delete(int Id)
        {
            PaymentReqBL objPaymentReqBL = new PaymentReqBL(Common.GetConString());
            return objPaymentReqBL.Delete(Id);
        }
    }
    public class PaymentReqValidator : AbstractValidator<PaymentReq>
    {
        public PaymentReqValidator()
        {
            RuleFor(obj => obj.Amount).NotEmpty();
            RuleFor(obj => obj.BillID).NotEmpty();
            RuleFor(obj => obj.PaymentMode).NotEmpty();
            RuleFor(obj => obj.RoomID).NotEmpty();
        }
    }
}

