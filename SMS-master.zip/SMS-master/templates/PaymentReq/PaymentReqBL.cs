using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
    [Serializable]
    public class PaymentReqBL
    {

        #region Declaration
        private string connectionString;
        PaymentReq _PaymentReq;
        public PaymentReq Data
        {
            get { return _PaymentReq; }
            set { _PaymentReq = value; }
        }
        public bool IsNew
        {
            get { return (_PaymentReq.ReqID <= 0 || _PaymentReq.ReqID == null); }
        }
        #endregion

        #region Constructor
        public PaymentReqBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private PaymentReqDL CreateDL()
        {
            return new PaymentReqDL(connectionString);
        }
        public void New()
        {
            _PaymentReq = new PaymentReq();
        }
        public void Load(int ReqID)
        {
            var PaymentReqObj = this.CreateDL();
            _PaymentReq = ReqID <= 0 ? PaymentReqObj.Load(-1) : PaymentReqObj.Load(ReqID);
        }
        public void LoadByBillID(int BillID)
        {
            var PaymentReqObj = this.CreateDL();
            _PaymentReq = BillID <= 0 ? PaymentReqObj.LoadByBillID(-1) : PaymentReqObj.LoadByBillID(BillID);
        }
        public DataTable LoadAllPaymentReq()
        {
            var PaymentReqDLObj = CreateDL();
            return PaymentReqDLObj.LoadAllPaymentReq();
        }
        public bool Update()
        {
            var PaymentReqDLObj = CreateDL();
            return PaymentReqDLObj.Update(this.Data);
        }
        public bool Delete(int ReqID)
        {
            var PaymentReqDLObj = CreateDL();
            return PaymentReqDLObj.Delete(ReqID);
        }
        #endregion
    }
}
