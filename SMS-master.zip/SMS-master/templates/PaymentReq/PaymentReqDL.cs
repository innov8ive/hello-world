using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
    public class PaymentReqDL
    {

        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public PaymentReqDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public PaymentReq Load(int ReqID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            PaymentReq objPaymentReq = new PaymentReq();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get PaymentReq
                var resultPaymentReq = dc.ExecuteQuery<PaymentReq>("exec Get_PaymentReq {0}", ReqID).ToList();
                if (resultPaymentReq.Count > 0)
                {
                    objPaymentReq = resultPaymentReq[0];
                }
                objPaymentReq.BillPaymentReqList = dc.ExecuteQuery<BillPaymentReq>(@"Select PR.*,B.TotalBillAmount,B.BSID from BillPaymentReq PR inner join
Bills B ON PR.BillID=B.BillID where ReqID={0}", ReqID).ToList();
                dc.Dispose();
                return objPaymentReq;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public PaymentReq LoadByBillID(int BillID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            PaymentReq objPaymentReq = new PaymentReq();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get PaymentReq
                var resultPaymentReq = dc.ExecuteQuery<PaymentReq>("Select * from PaymentReq where BillID = {0}", BillID).ToList();
                if (resultPaymentReq.Count > 0)
                {
                    objPaymentReq = resultPaymentReq[0];
                }
                dc.Dispose();
                return objPaymentReq;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllPaymentReq()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_PaymentReq", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(PaymentReq objPaymentReq)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update PaymentReq
                UpdatePaymentReq(objPaymentReq, trn);
                if (objPaymentReq.ReqID > 0)
                {
                    DeleteBillPaymentReq(Convert.ToInt32(objPaymentReq.ReqID), trn);
                    foreach (BillPaymentReq objBillPaymentReq in objPaymentReq.BillPaymentReqList)
                    {
                        objBillPaymentReq.ReqID = objPaymentReq.ReqID;
                        InsertIntoBillPaymentReq(objBillPaymentReq, trn);
                    }

                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int ReqID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete PaymentReq
                DeletePaymentReq(ReqID, trn);
                DeleteBillPaymentReq(ReqID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdatePaymentReq(PaymentReq objPaymentReq, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_PaymentReq", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@Amount", SqlDbType.Decimal).Value = objPaymentReq.Amount;
                cmd.Parameters.Add("@BillID", SqlDbType.Int).Value = objPaymentReq.BillID;
                cmd.Parameters.Add("@PaidRefDate", SqlDbType.DateTime).Value = objPaymentReq.PaidRefDate;
                cmd.Parameters.Add("@PaidRefNo", SqlDbType.VarChar, 20).Value = objPaymentReq.PaidRefNo;
                cmd.Parameters.Add("@PaidToGLID", SqlDbType.Int).Value = objPaymentReq.PaidToGLID;
                cmd.Parameters.Add("@PaymentMode", SqlDbType.VarChar, 20).Value = objPaymentReq.PaymentMode;
                cmd.Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = objPaymentReq.Remarks;
                cmd.Parameters.Add("@ReqBy", SqlDbType.Int).Value = objPaymentReq.ReqBy;
                cmd.Parameters.Add("@ReqDate", SqlDbType.DateTime).Value = objPaymentReq.ReqDate;
                cmd.Parameters.Add("@ReqID", SqlDbType.Int).Value = objPaymentReq.ReqID;
                cmd.Parameters["@ReqID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@RoomID", SqlDbType.Int).Value = objPaymentReq.RoomID;
                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = objPaymentReq.SocID;

                cmd.ExecuteNonQuery();

                //after updating the PaymentReq, update ReqID
                objPaymentReq.ReqID = Convert.ToInt32(cmd.Parameters["@ReqID"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeletePaymentReq(int ReqID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from PaymentReq where ReqID=@ReqID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@ReqID", SqlDbType.Int).Value = ReqID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }

        public bool InsertIntoBillPaymentReq(BillPaymentReq objBillPaymentReq, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Into_BillPaymentReq", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Transaction = trn;
                cmd.Parameters.Add("@BillID", SqlDbType.Int).Value = objBillPaymentReq.BillID;
                cmd.Parameters.Add("@ReqID", SqlDbType.Int).Value = objBillPaymentReq.ReqID;
                cmd.Parameters.Add("@PaidAmount", SqlDbType.Decimal).Value = objBillPaymentReq.PaidAmount;

                cmd.ExecuteNonQuery();

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }

        public bool DeleteBillPaymentReq(int ReqID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from BillPaymentReq where ReqID=@ReqID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@ReqID", SqlDbType.Int).Value = ReqID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }

        #endregion
    }
}
