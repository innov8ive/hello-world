using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

    [Serializable]
    [Table(Name = "dbo.PaymentReq")]
    public class PaymentReq
    {

        private System.Nullable<decimal> _Amount;
        private System.Nullable<int> _BillID;
        private System.Nullable<DateTime> _PaidRefDate;
        private string _PaidRefNo;
        private System.Nullable<int> _PaidToGLID;
        private string _PaymentMode;
        private string _Remarks;
        private System.Nullable<int> _ReqBy;
        private System.Nullable<DateTime> _ReqDate;
        private System.Nullable<int> _ReqID;
        private System.Nullable<int> _RoomID;
        private System.Nullable<int> _SocID;
        private string _BillIDs;

        [Column(Storage = "_BillIDs")]
        public string BillIDs
        {
            get { return _BillIDs; }
            set { _BillIDs = value; }
        }

        [Column(Storage = "_Amount")]
        public System.Nullable<decimal> Amount
        {
            get
            {
                return _Amount;
            }
            set
            {
                _Amount = value;
            }
        }



        [Column(Storage = "_BillID")]
        public System.Nullable<int> BillID
        {
            get
            {
                return _BillID;
            }
            set
            {
                _BillID = value;
            }
        }



        [Column(Storage = "_PaidRefDate")]
        public System.Nullable<DateTime> PaidRefDate
        {
            get
            {
                return _PaidRefDate;
            }
            set
            {
                _PaidRefDate = value;
            }
        }



        [Column(Storage = "_PaidRefNo")]
        public string PaidRefNo
        {
            get
            {
                return _PaidRefNo;
            }
            set
            {
                _PaidRefNo = value;
            }
        }



        [Column(Storage = "_PaidToGLID")]
        public System.Nullable<int> PaidToGLID
        {
            get
            {
                return _PaidToGLID;
            }
            set
            {
                _PaidToGLID = value;
            }
        }



        [Column(Storage = "_PaymentMode")]
        public string PaymentMode
        {
            get
            {
                return _PaymentMode;
            }
            set
            {
                _PaymentMode = value;
            }
        }



        [Column(Storage = "_Remarks")]
        public string Remarks
        {
            get
            {
                return _Remarks;
            }
            set
            {
                _Remarks = value;
            }
        }



        [Column(Storage = "_ReqBy")]
        public System.Nullable<int> ReqBy
        {
            get
            {
                return _ReqBy;
            }
            set
            {
                _ReqBy = value;
            }
        }



        [Column(Storage = "_ReqDate")]
        public System.Nullable<DateTime> ReqDate
        {
            get
            {
                return _ReqDate;
            }
            set
            {
                _ReqDate = value;
            }
        }



        [Column(Storage = "_ReqID")]
        public System.Nullable<int> ReqID
        {
            get
            {
                return _ReqID;
            }
            set
            {
                _ReqID = value;
            }
        }



        [Column(Storage = "_RoomID")]
        public System.Nullable<int> RoomID
        {
            get
            {
                return _RoomID;
            }
            set
            {
                _RoomID = value;
            }
        }



        [Column(Storage = "_SocID")]
        public System.Nullable<int> SocID
        {
            get
            {
                return _SocID;
            }
            set
            {
                _SocID = value;
            }
        }

        public List<BillPaymentReq> BillPaymentReqList { get; set; }

    }


    [Serializable]
    [Table(Name = "dbo.BillPaymentReq")]
    public class BillPaymentReq
    {
        private System.Nullable<int> _BillID;
        private System.Nullable<int> _ReqID;
        private Nullable<decimal> _PaidAmount;
        private Nullable<decimal> _TotalBillAmount;
        private System.Nullable<int> _BSID;

        [Column(Storage = "_BSID")]
        public System.Nullable<int> BSID
        {
            get { return _BSID; }
            set { _BSID = value; }
        }

        [Column(Storage = "_TotalBillAmount")]
        public Nullable<decimal> TotalBillAmount
        {
            get { return _TotalBillAmount; }
            set { _TotalBillAmount = value; }
        }

        [Column(Storage = "_PaidAmount")]
        public Nullable<decimal> PaidAmount
        {
            get { return _PaidAmount; }
            set { _PaidAmount = value; }
        }

        [Column(Storage = "_BillID")]
        public System.Nullable<int> BillID
        {
            get
            {
                return _BillID;
            }
            set
            {
                _BillID = value;
            }
        }

        [Column(Storage = "_ReqID")]
        public System.Nullable<int> ReqID
        {
            get
            {
                return _ReqID;
            }
            set
            {
                _ReqID = value;
            }
        }
    }
}
