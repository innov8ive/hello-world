using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;
using System.IO;
using System.Text;

namespace SampleAngular.Api
{
    public class GKController : ApiController
    {
        // GET api/Users
        [Route("api/GKList/")]
        [HttpPost]
        public AngularGridData GetGK([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.GateKeeper, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);

            StringBuilder query = new StringBuilder("Select * from Users");
            query.Append(" where UserType=9 and CreatedBy=").Append(objLoggedUser.UserID);//GK

            if (!String.IsNullOrEmpty(objAngularGrid.SearchText))
            {
                query.Append(" and (UserName like '%'+@Text+'%' OR FirstName like '%'+@Text+'%' OR LastName like '%'+@Text+'%' OR EmailID like '%'+@Text+'%')");
                Hashtable ht = new Hashtable();
                ht["@Text"] = objAngularGrid.SearchText;
                objAngularDataBinder.Parameters = ht;
            }

            objAngularDataBinder.Query = query.ToString();
            objAngularDataBinder.ValueField = "UserID";
            return objAngularDataBinder.GetData();
        }

        // GET api/Users/Id
        [Route("api/GK/{Id}")]
        public string GetUsers(int Id)
        {
            Common.IsValidForm(Constants.Forms.GateKeeper, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            UsersBL objUsersBL = new UsersBL(Common.GetConString());
            objUsersBL.Load(Id, objLoggedUser.SocID);
            objUsersBL.Data.Password = String.Empty;

            Users objUser = objUsersBL.Data;
            if (objUsersBL.IsNew == false && objUser.UserType != 9)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            return JsonConvert.SerializeObject(objUsersBL.Data);
        }

        // DELETE api/Users/5
        [Route("api/GKDelete/{Id}")]
        [HttpPost]
        public bool GKDelete(int Id)
        {
            Common.IsValidForm(Constants.Forms.GateKeeper, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            UsersBL objUsersBL = new UsersBL(Common.GetConString());

            objUsersBL.Load(Id, objLoggedUser.SocID);
            Users objUser = objUsersBL.Data;
            if (objUsersBL.IsNew == false && (objUser.UserType != 9 || objUser.CreatedBy != objLoggedUser.UserID))
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            return objUsersBL.Delete(Id);
        }
    }
    public class GKValidator : AbstractValidator<Users>
    {
        public GKValidator()
        {
            RuleFor(obj => obj.FirstName).NotEmpty();
            RuleFor(obj => obj.LastName).NotEmpty();
            RuleFor(obj => obj.UserType).NotEmpty();
            RuleFor(obj => obj.Password).NotEmpty().When(obj => Common.ToInt(obj.UserID) <= 0);
        }
    }
}

