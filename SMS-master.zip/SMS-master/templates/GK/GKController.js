var app = angular.module('myApp');

app.controller('GKListCtrl', function ($scope, $http, $location, GridData) {

    $scope = readyAngularGrid($scope, $http, 'api/GKList', 'UserID', GridData, 'Users');
    $scope.gridOptions.columnDefs = [
    { displayName: 'First Name', field: 'FirstName' },
    { displayName: 'Last Name', field: 'LastName' },
    { displayName: 'Mobile No.', field: 'MobileNo' },
    { displayName: 'EmailID', field: 'EmailID' },
    { displayName: 'Assigned Gate', field: 'AssignedGate' },
    ];
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchUsers = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };
    $scope.newUsers = function () {
        saveGridData($scope, GridData, 'Users');
        $location.path('/GK/0');
    };
    $scope.editUsers = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            saveGridData($scope, GridData, 'Users');
            $location.path('/GK/' + selected[0].UserID);
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.deleteUsers = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'POST',
                url: 'api/GKDelete/' + selected[0].UserID
            }).success(function (result) {
                if (result == true)
                    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
            });
        }
        else {
            alert('Please select a record to delete.');
        }
    };
})

.controller('GKCtrl', function ($scope, $http, $location, $routeParams, $window) {
    var UserID = $routeParams.GKID;
    $scope.roomID = $routeParams.RoomID;
    $scope.Users = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.UsersSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.UsersSubmitted = true;
        if ($scope.formUsers.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        if ($scope.Users.UserID <= 0 && $scope.UsernameAvailable == 'false') return;
        if ($scope.Users.MobileNo != null && $scope.Users.MobileNo.length != 0
            && $scope.Users.MobileNo.length != 10) {
            alert('Mobile No. should be 10 digit only');
            return;
        }
        $scope.Users.UserType = 9;//GK
        $http.post('api/Users', $scope.Users, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.Users = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        // $location.path('/UsersList');
        $window.history.back();
    };
    $scope.userAvailable = function () {
        $http({
            method: 'POST',
            url: 'api/Users/Available/',
            data: JSON.stringify($scope.Users.UserName)
        }).success(function (result) {
            $scope.UsernameAvailable = result;
        });
    };
    $scope.removePhoto = function () {
        if (confirm('Are you sure, want to remove photo?')) {
            $http({
                method: 'POST',
                url: 'api/Users/RemovePhoto/',
                data: JSON.stringify($scope.Users.UserID + '.' + $scope.Users.ImageUrl)
            }).success(function (result) {
                if (result == 'true')
                    $scope.Users.ImageUrl = '';
            });
        }
    };
    $scope.uploadPhoto = function () {
        AttachImage($scope.photoUploaded);
    };
    $scope.photoUploaded = function (fileGUIDName, fileName, fileID) {
        $scope.Users.ImageUrl = fileGUIDName;
        $http({
            method: 'POST',
            url: 'api/Users/AttachPhoto/',
            data: JSON.stringify($scope.Users.UserID + '.' + $scope.Users.ImageUrl)
        }).success(function (result) {

        });
    };
    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/GK/' + UserID
        }).success(function (Users) {
            $scope.Users = JSON.parse(Users);
            $scope.Users.IsActive = $scope.Users.IsActive == null ? true : $scope.Users.IsActive;
        });
    }, 100);
});
