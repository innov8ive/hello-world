var app = angular.module('myApp');

app.controller('ChatListCtrl', function ($scope, $http, $location, User) {
    $scope.filterOptions = { filterText: '' };
    var groupHub = $.connection.chatHub;
    $scope.ChatUserList = [];
    $scope.ShowList = false;
    $scope.ToUserName = '';
    $scope.ChatList = [];
    var FromUserID = User.UserID;
    var ToUser;
    var IsGroup;
    var GroupName;
    var pageCount;
    var pageNumber;
    $scope.backToChatList = function () {
        $scope.ShowList = false;
    };
    $scope.getChatUserList = function () {
        $http({
            method: 'POST',
            url: 'api/Chat/ChatList/',
            data: JSON.stringify({ text: $scope.filterOptions.filterText })
        }).success(function (result) {
            $scope.ChatUserList = result;
        });
    };
    $scope.getChatUserList();

    $scope.userSelected = function (itm, Obj, $event) {
        $($event.currentTarget).find('.delete-me').remove();
        IsGroup = itm.IsGroup;
        GroupName = itm.GroupGUID;
        var toUserID = itm.UserID;
        //$('#<%=hdnGroupID.ClientID%>').val(toUserID);
        pageCount = 0;
        pageNumber = 1;
        $scope.ShowList = true;
        $scope.ToUserName = itm.UserName;
        //$('#chatHeading').html(Obj.innerHTML).find('.label').remove();
        $('#btnSend').removeAttr('disabled');
        //$('#btnAttach').removeAttr('disabled');
        //$('#btnScreenshot').removeAttr('disabled');
        $('#txtMessage').removeAttr('disabled');
        //$('#btnEmoticons').removeAttr('disabled');
        ToUserID = toUserID;
        groupHub.server.joinChat(User.UserID, toUserID, GroupName);
        $(".list-group-item.text-center").hide().prependTo('body');
        $('#chatBody').html('');
        $(".list-group-item.text-center").prependTo('#chatBody');
        $scope.bindUserChat(false);
    };

    $scope.SendMessage = function () {
        var message = $('#txtMessage').val();
        if (message.length > 0) {
            groupHub.server.sendMessage(message, User.UserID, ToUserID, GroupName);
            //addMyChat(message);
            $('#txtMessage').val('');
        }
    };

    $scope.bindUserChat = function (scrollToTop) {
        var FromUserID = User.UserID;
        $.ajax({
            type: "POST",
            url: "api/Chat/UserChats",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: JSON.stringify({ toUserID: ToUserID, pageNumber: pageNumber, groupID: GroupName }),
            success: function (result) {
                var resultObj = JSON.parse(result);
                var messages = resultObj.data;
                pageCount = resultObj.TotalPages;
                var html = '';
                var readUnRead = '';
                for (var j = messages.length - 1; j >= 0 ; j--) {
                    var dateString = '<time class=\"timeago\" datetime=\"' + messages[j].ChatDateString + '\"></time>';

                    var deleteString = '';
                    if (messages[j].IsDeleted == true)
                        deleteString = '';
                    else
                        deleteString = '<span class=\"fa fa-trash pull-right\" onclick=\"deleteChat(this);\"></span>';

                    if (IsGroup == '0') {
                        if (messages[j].IsRead == 'Read')
                            readUnRead = '<i class=\"fa fa-check read\"></i>';
                        else
                            readUnRead = '<i class=\"fa fa-check\"></i>';
                    }

                    var sender = '';
                    sender = '<p class=\"user-group\">' + messages[j].SentByName + '</p>';

                    if (messages[j].FromID == FromUserID)
                        html += '<li UniqueID=\"' + messages[j].UniqueID + '\" class=\"list-group-item text-right\">' + sender + toMarkup(messages[j].Msg) + dateString + deleteString + readUnRead + '</li>';
                    else
                        html += '<li UniqueID=\"' + messages[j].UniqueID + '\" class=\"list-group-item\">' + sender + toMarkup(messages[j].Msg) + dateString + '</li>';

                }
                $('#chatBody').prepend(html);
                $(".list-group-item.text-center").prependTo("#chatBody");
                if (pageNumber < pageCount)
                    $(".list-group-item.text-center").show();
                else
                    $(".list-group-item.text-center").hide();


                var objDiv = document.getElementById("chatBody").parentNode;
                if (scrollToTop == false)
                    window.setTimeout(function () { objDiv.scrollTop = objDiv.scrollHeight; }, 500);
                else
                    window.setTimeout(function () { objDiv.scrollTop = 0; }, 500);

                jQuery("time.timeago").timeago();
            }
        });
    };

    $scope.messageSent = function (Msg, fromUser, toUser, uniqueID, groupName, sentBy) {
        if (fromUser == ToUserID) {
            groupHub.server.messageOpened(fromUser, toUser, groupName);
            $scope.addMyChat(Msg, false, uniqueID, groupName, sentBy);
        }
        else if (fromUser == User.UserID)
            $scope.addMyChat(Msg, true, uniqueID, groupName, sentBy);
        else if (groupName == GroupName)
            $scope.addMyChat(Msg, (fromUser == User.UserID), uniqueID, groupName, sentBy);
        $scope.saveLastRead();
        var objDiv = document.getElementById("chatBody").parentNode;
        objDiv.scrollTop = objDiv.scrollHeight;
    };

    $scope.addMyChat = function (Msg, isMychat, uniqueID, groupName, sentBy) {
        var deleteString = '<span class=\"fa fa-trash pull-right\" onclick=\"deleteChat(this);\"></span>';
        var readUnRead = '<i class=\"fa fa-check\"></i>';
        var dateString = '<time class=\"timeago\" datetime=\"' + (new Date()).toISOString() + '\"></time>';
        sender = '<p class=\"user-group\">' + sentBy + '</p>';
        if (IsGroup == '1') {
            readUnRead = '';
        }
        if (isMychat == false)
            $('#chatBody').append('<li UniqueID=\"' + uniqueID + '\" class=\"list-group-item\">' + sender + toMarkup(Msg) + dateString + '</li>');
        else
            $('#chatBody').append('<li UniqueID=\"' + uniqueID + '\" class=\"list-group-item text-right\">' + sender + toMarkup(Msg) + dateString + deleteString + readUnRead + '</li>');
        jQuery("time.timeago").timeago();
    };
    $scope.saveLastRead = function () {
        $.ajax({
            type: "POST",
            url: "api/Chat/SaveLastRead",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: JSON.stringify({ userID: User.UserID, groupName: GroupName }),
            success: function (result) {

            }
        });
    };

   

    $scope.othersMessageRecieved = function (groupName) {
       
        if (groupName != GroupName) {
            var chList = $scope.ChatList;
            for (var j = 0; j < chList.length; j++) {
                if (chList[j].GroupGUID == groupName) {
                    chList[j].LastChatDate = new Date();
                }
            }
            $scope.ChatList = chList;
        }
    };

    $scope.loadMore = function () {
        pageNumber++;
        $scope.bindUserChat(true);
    };
    $scope.othersComesOnline = function (fromUserID) {
        if (fromUserID != FromUserID) {
            $("#ulUsers li[userid='" + fromUserID + "']").find('.label-status').css('color', 'green');
        }
    };
    $scope.othersGoesOffline = function (fromUserID) {
        if (fromUserID != FromUserID) {
            $("#ulUsers li[userid='" + fromUserID + "']").find('.label-status').css('color', 'gray');
        }
    };
});
app.controller('ChatCtrl', function ($scope, $http, $location, User) {
    $scope.ChatList = [];
    var FromUserID = User.UserID;
    var ToUser;
    var IsGroup, GroupName;
    var pageCount;
    var pageNumber;
    $scope.getChatList = function () {
        $http({
            method: 'POST',
            url: 'api/Chat/ChatList/'
        }).success(function (result) {
            $scope.ChatList = JSON.parse(result);
        });
    };
    $scope.getChatList();

    $scope.userSelected = function (itm) {
        IsGroup = itm.IsGroup;
        GroupName = itm.GroupGUID;
        var toUserID = itm.UserID;

        //$('#<%=hdnGroupID.ClientID%>').val(toUserID);
        pageCount = 0;
        pageNumber = 1;
        //$(Obj).find('.delete-me').remove();
        $('#chatHeading').html(Obj.innerHTML).find('.label').remove();
        $('#btnSend').removeAttr('disabled');
        $('#btnAttach').removeAttr('disabled');
        $('#btnScreenshot').removeAttr('disabled');
        $('#txtMessage').removeAttr('disabled');
        $('#btnEmoticons').removeAttr('disabled');
        ToUserID = toUserID;
        groupHub.server.joinChat(FromUserID, toUserID, GroupName);
        $(".list-group-item.text-center").hide().prependTo('body');
        $('#chatBody').html('');
        $(".list-group-item.text-center").prependTo('#chatBody');
        bindUserChat(false);
    };
});