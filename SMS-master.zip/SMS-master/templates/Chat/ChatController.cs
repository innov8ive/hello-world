using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;
using System.Web.Http.Cors;

namespace SampleAngular.Api
{
    public class ChatController : ApiController
    {
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/Chat/ChatList")]
        [HttpPost]
        public DataTable GetChatList([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            DataTable dt = Common.GetDBResultParameterized(@"select NULL as SignalRConnectID,CG.GroupID as UserID,CG.GroupName as UserName,
CG.ImageUrl,CG.GroupGUID,NULL as LastChatDate,1 as IsGroup,CG.CreatedBy,'' as UnitNo from ChatGroup CG 
where exists (select 1 from ChatGroupUsers CGU where CGU.GroupID=CG.GroupID and CGU.UserID=@UserID)
UNION ALL
Select Users.SignalRConnectID,Users.UserID,Users.FirstName+ISNULL(' '+Users.LastName,'') as UserName,ISNULL(Users.ImageUrl,'') as ImageUrl,
Case when @UserID>Users.UserID then CONVERT(varchar,Users.UserID)+'-'+CONVERT(varchar,@UserID)
else CONVERT(varchar,@UserID)+'-'+CONVERT(varchar,Users.UserID) end as GroupName,
VCR.LastChatDate,0 as IsGroup,NULL as CreatedBy,RoomNos
from Users Users left join VW_Users VU ON Users.UserID=VU.UserID
left join VW_ChatRead VCR ON VCR.ToID=@UserID 
and Case when @UserID>Users.UserID then CONVERT(varchar,Users.UserID)+'-'+CONVERT(varchar,@UserID)
else CONVERT(varchar,@UserID)+'-'+CONVERT(varchar,Users.UserID) end=VCR.GroupName
 where Users.UserID<>@UserID
and exists (
select 1 from Soc S where 
UserID=(select ISNULL(CreatedBy,UserID) from Users U where 
U.UserID=@UserID) and (S.UserID=Users.UserID OR Users.CreatedBy=S.UserID))
and Users.UserID<>@UserID and (Users.FirstName like '%'+@Name+'%'
OR Users.LastName like '%'+@Name+'%' 
OR VU.RoomNos like '%'+@Name+'%') Order By LastChatDate Desc;", "@UserID", SqlDbType.Int, objLoggedUser.UserID,
                                                            "@Name", SqlDbType.VarChar, Common.ToString(value.text));
            return dt;
        }
        
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/Chat/GetUserDetails")]
        [HttpPost]
        public DataTable GetUserDetails([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            DataTable dt = Common.GetDBResultParameterized(@"select NULL as SignalRConnectID,CG.GroupID as UserID,CG.GroupName as UserName,
CG.ImageUrl,CG.GroupGUID,NULL as LastChatDate,1 as IsGroup,CG.CreatedBy from ChatGroup CG 
where exists (select 1 from ChatGroupUsers CGU where CGU.GroupID=CG.GroupID and CGU.UserID=@UserID)
UNION ALL
Select SignalRConnectID,UserID,FirstName+ISNULL(' '+LastName,'') as UserName,ISNULL(ImageUrl,'') as ImageUrl,
Case when @UserID>UserID then CONVERT(varchar,UserID)+'-'+CONVERT(varchar,@UserID)
else CONVERT(varchar,@UserID)+'-'+CONVERT(varchar,UserID) end as GroupName,
VCR.LastChatDate,0 as IsGroup,NULL as CreatedBy
from Users
left join VW_ChatRead VCR ON VCR.ToID=@UserID 
and Case when @UserID>UserID then CONVERT(varchar,UserID)+'-'+CONVERT(varchar,@UserID)
else CONVERT(varchar,@UserID)+'-'+CONVERT(varchar,UserID) end=VCR.GroupName
 where UserID<>@UserID
and exists (
select 1 from Soc S where 
UserID=(select ISNULL(CreatedBy,UserID) from Users U where 
U.UserID=@UserID) and (S.UserID=Users.UserID OR Users.CreatedBy=S.UserID))
and Users.UserID=@GroupID  Order By LastChatDate Desc;", 
                "@UserID", SqlDbType.Int, objLoggedUser.UserID,
                "@GroupID", SqlDbType.Int, Common.ToInt(value.GroupID));
            return dt;
        }

        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/Chat/UserChats")]
        [HttpPost]
        public Hashtable GetUserChats([FromBody]dynamic value)
        {
            int toUserID = Common.ToInt(value.toUserID);
            int pageNumber = Common.ToInt(value.pageNumber);
            string groupID = Common.ToString(value.groupID);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            Hashtable ht = Common.GetPagedData(@"Select case when (cr.LastRead IS NULL OR C.ChatDate < cr.LastRead) then 'Read' else 'UnRead' end as IsRead,
CONVERT(varchar(19),C.ChatDate,126)+'Z' as ChatDateString,
C.UniqueID,C.FromID,c.ChatDate,c.IsDeleted,c.Msg,C.ToID,cr.LastRead,U.FirstName+ISNULL(' '+U.LastName,'') as SentByName,C.GroupID from VW_Chat C
left join VW_Chatread cr on cr.ToID=@ToID
left join Users U ON C.FromID=U.UserID
where C.GroupID=@GroupID",
                "UniqueID", "ChatDate", "Desc", pageNumber, 20,
                "@FromID", SqlDbType.Int, objLoggedUser.UserID,
                 "@ToID", SqlDbType.Int, toUserID,
                 "@GroupID", SqlDbType.VarChar, groupID);


            return ht;
        }

        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/Chat/SaveLastRead")]
        [HttpPost]
        public string SaveLastRead([FromBody]dynamic value)
        {
            int userID = Common.ToInt(value.userID);
            string groupName = Common.ToString(value.groupName);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            ChatHelper.SaveLastRead(userID, groupName);
            return JsonConvert.SerializeObject(true, Formatting.Indented);
        }

        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/Chat/HasUnReadChat")]
        [HttpPost]
        public string HasUnReadChat([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            int count = Common.ToInt(Common.GetDBScalar("select COUNT(*) from VW_ChatRead CR where CR.ToID=" + objLoggedUser.UserID));
            return JsonConvert.SerializeObject(count, Formatting.Indented);

            //int userID = Common.ToInt(value.userID);
            //string groupName = Common.ToString(value.groupName);
            //LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            //ChatHelper.SaveLastRead(userID, groupName);
            //return JsonConvert.SerializeObject(true, Formatting.Indented);
        }
    }
}

