using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

[Serializable][Table(Name = "dbo.AL")]public class AL{
private System.Nullable<int> _ALID;
private string _ALName;
private System.Nullable<DateTime> _CreatedDate;
private System.Nullable<int> _SocID;
 
[Column(Storage = "_ALID")]
public System.Nullable<int> ALID{get {return _ALID;}set { _ALID=value;}}
[Column(Storage = "_ALName")]
public string ALName{get {return _ALName;}set { _ALName=value;}}
[Column(Storage = "_CreatedDate")]
public System.Nullable<DateTime> CreatedDate{get {return _CreatedDate;}set { _CreatedDate=value;}}
[Column(Storage = "_SocID")]
public System.Nullable<int> SocID{get {return _SocID;}set { _SocID=value;}}
}}
