using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;
using System.IO;
using System.Web.Http.Cors;

namespace SampleAngular.Api
{
    public class ALController : ApiController
    {
        // GET api/AL
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/ALList/")]
        [HttpPost]
        public DataTable GetAL([FromBody]dynamic value)
        {
            //Common.IsValidForm(Constants.Forms.Service, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            DataTable dt = Common.GetDBResultParameterized(@"Select * from AL where SocID=@SocID and ALName like '%'+@Name+'%' Order By ALName",
"@SocID", SqlDbType.Int, objLoggedUser.SocID,
"@Name", SqlDbType.VarChar, Common.ToString(value.filterText));

            return dt;
        }

        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/AL/ImgList/")]
        [HttpPost]
        public DataTable ImgList([FromBody]dynamic value)
        {
            //Common.IsValidForm(Constants.Forms.Service, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            DataTable dt = Common.GetDBResultParameterized(@"Select * from Img where SocID=@SocID and ALID=@ALID",
"@SocID", SqlDbType.Int, objLoggedUser.SocID,
"@ALID", SqlDbType.Int, Common.ToInt(value.ALID));

            return dt;
        }

        // GET api/AL/Id
        [Route("api/AL/{Id}")]
        public string GetAL(int Id)
        {
            //Common.IsValidForm(Constants.Forms.Service, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            ALBL objALBL = new ALBL(Common.GetConString());
            objALBL.Load(Id);

            AL objAL = objALBL.Data;
            if (Common.ToInt(objAL.SocID) > 0 && objAL.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            return JsonConvert.SerializeObject(objALBL.Data);
        }

        // POST api/AL/
        public string Post([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.Gallery, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            AL objAL = objJObject.ToObject<AL>();
            ALBL objALBL = new ALBL(Common.GetConString());
            objALBL.Data = objAL;
            if (objALBL.IsNew)
            {
                objAL.CreatedDate = DateTime.Now;
                objAL.SocID = objLoggedUser.SocID;
            }

            ALValidator validator = new ALValidator();
            ValidationResult results = validator.Validate(objAL);

            if (results.IsValid)
            {
                objALBL.Update();
                return JsonConvert.SerializeObject(objALBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        // DELETE api/AL/5
        [Route("api/AL/{Id}")]
        [HttpDelete]
        public bool Delete(int Id)
        {
            Common.IsValidForm(Constants.Forms.Gallery, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            ALBL objALBL = new ALBL(Common.GetConString());
            objALBL.Load(Id);

            AL objAL = objALBL.Data;
            if (Common.ToInt(objAL.SocID) > 0 && objAL.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            return objALBL.Delete(Id);
        }

        [Route("api/AL/DeleteAL")]
        [HttpPost]
        public string DeleteAL([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.Gallery, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            int totalChildFiles = Common.ToInt(Common.GetDBScalar("Select COUNT(*) from Img where ALID=@ALID and SocID=@SocID",
                "@ALID", SqlDbType.Int, Common.ToInt(value.ALID),
                "@SocID", SqlDbType.Int, objLoggedUser.SocID));

            if (totalChildFiles > 0)
            {
                return "Error: You can not delete this AL, because is has some child File(s). Please delete the Child items first.";
            }
            else
            {
                Common.ExecuteNonQuery("Delete from AL where ALID=@ALID and SocID=@SocID",
                 "@ALID", SqlDbType.Int, Common.ToInt(value.ALID),
                 "@SocID", SqlDbType.Int, objLoggedUser.SocID);
                return "AL Deleted Successfully";
            }
        }

        [Route("api/AL/DeleteImage")]
        [HttpPost]
        public string DeleteImage([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.Gallery, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            string imageUrl = Common.ToString(value.ImageUrl);
            int ImgID = Common.ToInt(value.ImgID);
            string filePath = HttpContext.Current.Server.MapPath("~/images/profile") + "/" + imageUrl;
            File.Delete(filePath);

            Common.ExecuteNonQuery("Delete from Img where ImgID=" + ImgID);
            return "Image Deleted Successfully";
        }
    }
    public class ALValidator : AbstractValidator<AL>
    {
        public ALValidator()
        {
            RuleFor(obj => obj.ALName).NotEmpty();
        }
    }
}

