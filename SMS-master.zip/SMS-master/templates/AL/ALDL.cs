using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
public class ALDL
{

#region Private Members
private string connectionString;
#endregion

#region Constructor
public ALDL(string conString)
{
connectionString = conString;
}
#endregion

#region Main Methods
public AL Load(int ALID)
{
SqlConnection SqlCon = new SqlConnection(connectionString);
AL objAL = new AL();
var dc = new DataContext(SqlCon);
try
{
//Get AL
var resultAL = dc.ExecuteQuery<AL>("exec Get_AL {0}", ALID).ToList();
if (resultAL.Count > 0)
{
objAL = resultAL[0];
}
dc.Dispose();
return objAL;
}
catch (Exception ex)
{
throw new Exception(ex.Message);
}
finally
{
if (SqlCon.State == ConnectionState.Open)
{
SqlCon.Close();
}
SqlCon.Dispose();
}
}
public DataTable LoadAllAL()
{
DataTable dt = new DataTable();
SqlConnection con = new SqlConnection(connectionString);
SqlCommand cmd = new SqlCommand("exec Get_AL",con);

con.Open();
dt.Load(cmd.ExecuteReader());
con.Close();

return dt;
}
public bool Update(AL objAL)
{
SqlConnection con = new SqlConnection(connectionString);
con.Open();
SqlTransaction trn = con.BeginTransaction();
try
{
//update AL
UpdateAL(objAL,trn);
if (objAL.ALID > 0)
{

trn.Commit();
}
return true;
}
catch
{
trn.Rollback();
return false;
}
finally
{
con.Dispose();
}
}
public bool Delete(int ALID)
{
SqlConnection con = new SqlConnection(connectionString);
con.Open();
SqlTransaction trn = con.BeginTransaction();
try
{
//Delete AL
DeleteAL(ALID,trn);
trn.Commit();
return true;
}
catch
{
trn.Rollback();
return false;
}
finally
{
con.Dispose();
}
}

public bool UpdateAL(AL objAL,SqlTransaction trn){SqlCommand cmd=new SqlCommand("Insert_Update_AL",trn.Connection);try{cmd.CommandType=CommandType.StoredProcedure; cmd.Transaction = trn;
cmd.Parameters.Add("@ALID",SqlDbType.Int).Value=objAL.ALID;
cmd.Parameters["@ALID"].Direction=ParameterDirection.InputOutput;
cmd.Parameters.Add("@ALName",SqlDbType.VarChar,100).Value=objAL.ALName;
cmd.Parameters.Add("@CreatedDate",SqlDbType.DateTime).Value=objAL.CreatedDate;
cmd.Parameters.Add("@SocID",SqlDbType.Int).Value=objAL.SocID;
cmd.ExecuteNonQuery();//after updating the AL, update ALIDobjAL.ALID=Convert.ToInt32(cmd.Parameters["@ALID"].Value);return true;}catch{ trn.Rollback();return false;}finally{cmd.Dispose();}}
public bool DeleteAL(int ALID, SqlTransaction trn){try{SqlCommand cmd=new SqlCommand("Delete from AL where ALID=@ALID", trn.Connection);cmd.Transaction = trn;cmd.Parameters.Add("@ALID",SqlDbType.Int).Value=ALID;cmd.ExecuteNonQuery();return true;}catch{trn.Rollback();return false;}}#endregion
}
}
