using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

[Serializable][Table(Name = "dbo.Img")]public class Img{
private System.Nullable<int> _ALID;
private string _ImageUrl;
private System.Nullable<int> _ImgID;
private System.Nullable<int> _SocID;
 
[Column(Storage = "_ALID")]
public System.Nullable<int> ALID{get {return _ALID;}set { _ALID=value;}}
[Column(Storage = "_ImageUrl")]
public string ImageUrl{get {return _ImageUrl;}set { _ImageUrl=value;}}
[Column(Storage = "_ImgID")]
public System.Nullable<int> ImgID{get {return _ImgID;}set { _ImgID=value;}}
[Column(Storage = "_SocID")]
public System.Nullable<int> SocID{get {return _SocID;}set { _SocID=value;}}
}}
