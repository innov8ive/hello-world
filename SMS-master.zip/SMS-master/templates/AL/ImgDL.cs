using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
public class ImgDL
{

#region Private Members
private string connectionString;
#endregion

#region Constructor
public ImgDL(string conString)
{
connectionString = conString;
}
#endregion

#region Main Methods
public Img Load(int ImgID)
{
SqlConnection SqlCon = new SqlConnection(connectionString);
Img objImg = new Img();
var dc = new DataContext(SqlCon);
try
{
//Get Img
var resultImg = dc.ExecuteQuery<Img>("exec Get_Img {0}", ImgID).ToList();
if (resultImg.Count > 0)
{
objImg = resultImg[0];
}
dc.Dispose();
return objImg;
}
catch (Exception ex)
{
throw new Exception(ex.Message);
}
finally
{
if (SqlCon.State == ConnectionState.Open)
{
SqlCon.Close();
}
SqlCon.Dispose();
}
}
public DataTable LoadAllImg()
{
DataTable dt = new DataTable();
SqlConnection con = new SqlConnection(connectionString);
SqlCommand cmd = new SqlCommand("exec Get_Img",con);

con.Open();
dt.Load(cmd.ExecuteReader());
con.Close();

return dt;
}
public bool Update(Img objImg)
{
SqlConnection con = new SqlConnection(connectionString);
con.Open();
SqlTransaction trn = con.BeginTransaction();
try
{
//update Img
UpdateImg(objImg,trn);
if (objImg.ImgID > 0)
{

trn.Commit();
}
return true;
}
catch
{
trn.Rollback();
return false;
}
finally
{
con.Dispose();
}
}
public bool Delete(int ImgID)
{
SqlConnection con = new SqlConnection(connectionString);
con.Open();
SqlTransaction trn = con.BeginTransaction();
try
{
//Delete Img
DeleteImg(ImgID,trn);
trn.Commit();
return true;
}
catch
{
trn.Rollback();
return false;
}
finally
{
con.Dispose();
}
}

public bool UpdateImg(Img objImg,SqlTransaction trn){SqlCommand cmd=new SqlCommand("Insert_Update_Img",trn.Connection);try{cmd.CommandType=CommandType.StoredProcedure; cmd.Transaction = trn;
cmd.Parameters.Add("@ALID",SqlDbType.Int).Value=objImg.ALID;
cmd.Parameters.Add("@ImageUrl",SqlDbType.VarChar,50).Value=objImg.ImageUrl;
cmd.Parameters.Add("@ImgID",SqlDbType.Int).Value=objImg.ImgID;
cmd.Parameters["@ImgID"].Direction=ParameterDirection.InputOutput;
cmd.Parameters.Add("@SocID",SqlDbType.Int).Value=objImg.SocID;
cmd.ExecuteNonQuery();//after updating the Img, update ImgIDobjImg.ImgID=Convert.ToInt32(cmd.Parameters["@ImgID"].Value);return true;}catch{ trn.Rollback();return false;}finally{cmd.Dispose();}}
public bool DeleteImg(int ImgID, SqlTransaction trn){try{SqlCommand cmd=new SqlCommand("Delete from Img where ImgID=@ImgID", trn.Connection);cmd.Transaction = trn;cmd.Parameters.Add("@ImgID",SqlDbType.Int).Value=ImgID;cmd.ExecuteNonQuery();return true;}catch{trn.Rollback();return false;}}#endregion
}
}
