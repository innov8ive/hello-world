using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
[Serializable]
public class ALBL
{

#region Declaration
private string connectionString;
AL _AL;
public AL Data
{
get { return _AL; }
set { _AL = value; }
}
public bool IsNew
{
get { return (_AL.ALID <= 0 || _AL.ALID ==null); }
}
#endregion

#region Constructor
public ALBL(string conString)
{
connectionString = conString;
}
#endregion

#region Main Methods
private ALDL CreateDL()
{
return new ALDL(connectionString);
}
public void New()
{
_AL = new AL();
}
public void Load(int ALID)
{
var ALObj = this.CreateDL();
_AL = ALID <= 0 ? ALObj.Load(-1) : ALObj.Load(ALID);
}
public DataTable LoadAllAL()
{
var ALDLObj = CreateDL();
return ALDLObj.LoadAllAL();
}
public bool Update()
{
var ALDLObj = CreateDL();
return ALDLObj.Update(this.Data);
}
public bool Delete(int ALID)
{
var ALDLObj = CreateDL();
return ALDLObj.Delete(ALID);
}
#endregion
}
}
