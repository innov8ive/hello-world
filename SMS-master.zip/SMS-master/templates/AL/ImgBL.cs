using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
[Serializable]
public class ImgBL
{

#region Declaration
private string connectionString;
Img _Img;
public Img Data
{
get { return _Img; }
set { _Img = value; }
}
public bool IsNew
{
get { return (_Img.ImgID <= 0 || _Img.ImgID ==null); }
}
#endregion

#region Constructor
public ImgBL(string conString)
{
connectionString = conString;
}
#endregion

#region Main Methods
private ImgDL CreateDL()
{
return new ImgDL(connectionString);
}
public void New()
{
_Img = new Img();
}
public void Load(int ImgID)
{
var ImgObj = this.CreateDL();
_Img = ImgID <= 0 ? ImgObj.Load(-1) : ImgObj.Load(ImgID);
}
public DataTable LoadAllImg()
{
var ImgDLObj = CreateDL();
return ImgDLObj.LoadAllImg();
}
public bool Update()
{
var ImgDLObj = CreateDL();
return ImgDLObj.Update(this.Data);
}
public bool Delete(int ImgID)
{
var ImgDLObj = CreateDL();
return ImgDLObj.Delete(ImgID);
}
#endregion
}
}
