using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
[Serializable]
public class VMBL
{

#region Declaration
private string connectionString;
VM _VM;
public VM Data
{
get { return _VM; }
set { _VM = value; }
}
public bool IsNew
{
get { return (_VM.VMID <= 0 || _VM.VMID ==null); }
}
#endregion

#region Constructor
public VMBL(string conString)
{
connectionString = conString;
}
#endregion

#region Main Methods
private VMDL CreateDL()
{
return new VMDL(connectionString);
}
public void New()
{
_VM = new VM();
}
public void Load(int VMID)
{
var VMObj = this.CreateDL();
_VM = VMID <= 0 ? VMObj.Load(-1) : VMObj.Load(VMID);
}
public DataTable LoadAllVM()
{
var VMDLObj = CreateDL();
return VMDLObj.LoadAllVM();
}
public bool Update()
{
var VMDLObj = CreateDL();
return VMDLObj.Update(this.Data);
}
public bool Delete(int VMID)
{
var VMDLObj = CreateDL();
return VMDLObj.Delete(VMID);
}
#endregion
}
}
