using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;
using System.Text;
using System.Web.Http.Cors;

namespace SampleAngular.Api
{
    public class VMController : ApiController
    {
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/VMListing/")]
        [HttpPost]
        public DataTable GetVMListing([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (Common.ToInt(objLoggedUser.UserType) != 1)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            StringBuilder rooms = new StringBuilder("0");
            foreach (int r in objLoggedUser.RoomID)
            {
                rooms.Append(",").Append(r);
            }
            string Query = @"Select W.WingName+' '+R.RoomNo as RoomNo, VM.PName,VM.LogDate,VM.VMID,
SUBSTRING(CONVERT(varchar, DATEADD(MI,VM.InTime,'2017-11-11') ,100),13,8) as InTime,
SUBSTRING(CONVERT(varchar, DATEADD(MI,VM.OutTime,'2017-11-11') ,100),13,8) as OutTime,
VM.MeetTo,VM.Reason,VM.GT,VM.VMobileNo from VM 
inner join Rooms R ON R.RoomID = VM.RMID
inner join Wings W ON W.WingID = R.WingID
inner join Users U ON U.UserID = VM.UserID where VM.SocID=" + objLoggedUser.SocID + " and VM.RMID in (" + rooms + @")
 and (W.WingName+' '+R.RoomNo like '%'+@Name+'%' OR VM.PName like '%'+@Name+'%' OR VM.LogDate like '%'+@Name+'%'
OR VM.VMobileNo like '%'+@Name+'%' OR VM.MeetTo like '%'+@Name+'%' )";
            DataTable dt = Common.GetDBResultParameterized(Query,
                "@Name", SqlDbType.VarChar, Common.ToString(value == null ? "" : value.SearchText));

            return dt;
        }

        [Route("api/VMList/")]
        [HttpPost]
        public AngularGridData GetVM([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (Common.ToInt(objLoggedUser.UserType) != 2 && Common.ToInt(objLoggedUser.UserType) != 9)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = @"Select W.WingName+' '+R.RoomNo as RoomNo, VM.PName
,VM.LogDate,VM.VMID,
SUBSTRING(CONVERT(varchar, DATEADD(MI,VM.InTime,'2017-11-11') ,100),13,8) as InTime,
SUBSTRING(CONVERT(varchar, DATEADD(MI,VM.OutTime,'2017-11-11') ,100),13,8) as OutTime,
VM.MeetTo,VM.Reason,VM.GT,VM.VMobileNo from VM 
inner join Rooms R ON R.RoomID = VM.RMID
inner join Wings W ON W.WingID = R.WingID
inner join Users U ON U.UserID = VM.UserID where VM.SocID=@SocID
and (W.WingName+' '+R.RoomNo like '%'+@Name+'%' OR VM.PName like '%'+@Name+'%' OR VM.LogDate like '%'+@Name+'%'
OR VM.VMobileNo like '%'+@Name+'%' OR VM.MeetTo like '%'+@Name+'%' )";
            objAngularDataBinder.ValueField = "VMID";
            objAngularDataBinder.OrderBy = "VMID";
            objAngularDataBinder.OrderDir = "Desc";
            Hashtable ht = new Hashtable();
            ht["@SocID"] = objLoggedUser.SocID;
            ht["@Name"] = Common.ToString(value.SearchText);
            objAngularDataBinder.Parameters = ht;
            return objAngularDataBinder.GetData();
        }
        [Route("api/VMDetails/")]
        [HttpPost]
        public DataTable VMDetails([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.VisitDetails, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            DataTable dt = Common.GetDBResult(@"Select W.WingName+' '+R.RoomNo as RoomNo, VM.PName
,VM.LogDate,VM.VMID,
SUBSTRING(CONVERT(varchar, DATEADD(MI,VM.InTime,'2017-11-11') ,100),13,8) as InTime,
SUBSTRING(CONVERT(varchar, DATEADD(MI,VM.OutTime,'2017-11-11') ,100),13,8) as OutTime,
VM.MeetTo,VM.Reason,VM.GT,VM.VMobileNo from VM 
inner join Rooms R ON R.RoomID = VM.RMID
inner join Wings W ON W.WingID = R.WingID
inner join Users U ON U.UserID = VM.UserID where VM.VMID=" + Common.ToInt(value.VMID));

            return dt;
        }
        // GET api/VM/Id
        [Route("api/VM/{Id}")]
        public string GetVM(int Id)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (Common.ToInt(objLoggedUser.UserType) != 2 && Common.ToInt(objLoggedUser.UserType) != 9)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            VMBL objVMBL = new VMBL(Common.GetConString());
            objVMBL.Load(Id);
            if (objVMBL.IsNew)
            {
                objVMBL.Data.LogDate = DateTime.Now;
            }
            VM objVM = objVMBL.Data;
            if (Common.ToInt(objVM.SocID) > 0 && objVM.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            return JsonConvert.SerializeObject(objVMBL.Data);
        }

        // POST api/VM/
        public string Post([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (Common.ToInt(objLoggedUser.UserType) != 2 && Common.ToInt(objLoggedUser.UserType) != 9)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            JObject objJObject = value;
            VM objVM = objJObject.ToObject<VM>();
            VMBL objVMBL = new VMBL(Common.GetConString());
            objVMBL.Data = objVM;
            if (objVMBL.IsNew)
            {
                objVM.SocID = objLoggedUser.SocID;
                objVM.UserID = objLoggedUser.UserID;
            }
            if (Common.ToInt(objVM.SocID) > 0 && objVM.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
          
            VMValidator validator = new VMValidator();
            ValidationResult results = validator.Validate(objVM);
            if (objVM.VMobileNo.Length != 10)
            {
                results.Errors.Add(new ValidationFailure("VMobileNo", "Mobile No. should be 10 digit only"));
            }
            if (objVM.VMobileNo.Length > 0 && Common.ToDouble(objVM.VMobileNo) < 0)
            {
                results.Errors.Add(new ValidationFailure("VMobileNo", "Mobile No. should be 10 digit only"));
            }
            if (results.IsValid)
            {
                objVMBL.Update();
                return JsonConvert.SerializeObject(objVMBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        // DELETE api/VM/5
        [Route("api/VM/{Id}")]
        [HttpDelete]
        public bool Delete(int Id)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (Common.ToInt(objLoggedUser.UserType) != 2 && Common.ToInt(objLoggedUser.UserType) != 9)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            VMBL objVMBL = new VMBL(Common.GetConString());
            objVMBL.Load(Id);

            VM objVM = objVMBL.Data;
            if (Common.ToInt(objVM.SocID) > 0 && objVM.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            return objVMBL.Delete(Id);
        }
    }
    public class VMValidator : AbstractValidator<VM>
    {
        public VMValidator()
        {

            RuleFor(obj => obj.InTime).NotEmpty();
            RuleFor(obj => obj.LogDate).NotEmpty();
            RuleFor(obj => obj.MeetTo).NotEmpty();
            RuleFor(obj => obj.OutTime).NotEmpty();
            RuleFor(obj => obj.PName).NotEmpty();
            RuleFor(obj => obj.Reason).NotEmpty();
            RuleFor(obj => obj.RMID).NotEmpty();
            RuleFor(obj => obj.SocID).NotEmpty();
            RuleFor(obj => obj.UserID).NotEmpty();
            RuleFor(obj => obj.VMobileNo).NotEmpty();
        }
    }
}

