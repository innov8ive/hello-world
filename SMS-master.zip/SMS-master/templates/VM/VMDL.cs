using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
    public class VMDL
    {
        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public VMDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public VM Load(int VMID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            VM objVM = new VM();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get VM
                var resultVM = dc.ExecuteQuery<VM>("exec Get_VM {0}", VMID).ToList();
                if (resultVM.Count > 0)
                {
                    objVM = resultVM[0];
                }
                dc.Dispose();
                return objVM;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllVM()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_VM", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(VM objVM)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update VM
                UpdateVM(objVM, trn);
                if (objVM.VMID > 0)
                {

                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int VMID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete VM
                DeleteVM(VMID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateVM(VM objVM, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_VM", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@InTime", SqlDbType.Int).Value = objVM.InTime;
                cmd.Parameters.Add("@LogDate", SqlDbType.DateTime).Value = objVM.LogDate;
                cmd.Parameters.Add("@MeetTo", SqlDbType.VarChar, 100).Value = objVM.MeetTo;
                cmd.Parameters.Add("@OutTime", SqlDbType.Int).Value = objVM.OutTime;
                cmd.Parameters.Add("@PName", SqlDbType.VarChar, 100).Value = objVM.PName;
                cmd.Parameters.Add("@Reason", SqlDbType.VarChar, 100).Value = objVM.Reason;
                cmd.Parameters.Add("@RMID", SqlDbType.Int).Value = objVM.RMID;
                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = objVM.SocID;
                cmd.Parameters.Add("@UserID", SqlDbType.Int).Value = objVM.UserID;
                cmd.Parameters.Add("@VMID", SqlDbType.Int).Value = objVM.VMID;
                cmd.Parameters["@VMID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@GT", SqlDbType.VarChar, 20).Value = objVM.GT;
                cmd.Parameters.Add("@VMobileNo", SqlDbType.VarChar, 15).Value = objVM.VMobileNo;

                cmd.ExecuteNonQuery();

                //after updating the VM, update VMID
                objVM.VMID = Convert.ToInt32(cmd.Parameters["@VMID"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteVM(int VMID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from VM where VMID=@VMID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@VMID", SqlDbType.Int).Value = VMID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        #endregion
    }
}
