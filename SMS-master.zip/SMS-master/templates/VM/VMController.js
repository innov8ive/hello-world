var app = angular.module('myApp');

app.controller('VMListCtrl', function ($scope, $http, $location, GridData,User) {
    $scope.UserType = User.UserType;
    $scope = readyAngularGrid($scope, $http, 'api/VMList', 'VMID', GridData, 'VM');
    $scope.gridOptions.columnDefs = [

    { displayName: 'Visitor Name', field: 'PName' },
    { displayName: 'Mobile No.', field: 'VMobileNo' },
    { displayName: 'Log Date', field: 'LogDate', cellFilter: 'date:\'dd-MMM-yyyy\'' },
    { displayName: 'Meet To', field: 'MeetTo' },
    { displayName: 'In Time', field: 'InTime' },
    { displayName: 'Out Time', field: 'OutTime' },
    { displayName: 'Gate', field: 'GT' },
    { displayName: 'Room No.', field: 'RoomNo' }];
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchVM = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };
    $scope.newVM = function () {
        saveGridData($scope, GridData, 'VM');
        $location.path('/VM/0');
    };
    $scope.editVM = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            saveGridData($scope, GridData, 'VM');
            $location.path('/VM/' + selected[0].VMID);
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.deleteVM = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'DELETE',
                url: 'api/VM/' + selected[0].VMID
            }).success(function (result) {
                if (result == true)
                    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
            });
        }
        else {
            alert('Please select a record to edit.');
        }
    };
})

.controller('VMCtrl', function ($scope, $http, $location, $routeParams) {
    var VMID = $routeParams.VMID;
    $scope.VM = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.VMSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.VMSubmitted = true;
        if ($scope.formVM.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        if ($scope.VM.OutTime != null && $scope.VM.OutTime > 0 && $scope.VM.OutTime <= $scope.VM.InTime) {
            alert('Out-Time should be greater than In-Time');
            return;
        }

        $http.post('api/VM', $scope.VM, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.VM = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/VMList');
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/VM/' + VMID
        }).success(function (VM) {
            $scope.VM = JSON.parse(VM);
        });
    }, 100);

    $scope.timelist = [];
    $scope.bindTime = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetTimeList', Data: null })
        }).success(function (data) {
            $scope.timelist = data;
        });
    }
    $scope.bindTime();

    $scope.rmlist = [];
    $scope.bindRoom = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetRoomList', Data: null })
        }).success(function (data) {
            $scope.rmlist = data;
        });
    }
    $scope.bindRoom();
});
app.controller('VMListingCtrl', function ($scope, $http, $location) {
    
    setTimeout(function () {
        $http({
            method: 'POST',
            url: 'api/VMListing'
        }).success(function (result) {
            $scope.VMList = result;
        });
    }, 100);

});
