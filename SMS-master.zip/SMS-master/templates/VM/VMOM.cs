using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

    [Serializable]
    [Table(Name = "dbo.VM")]
    public class VM
    {
        private System.Nullable<int> _InTime;
        private System.Nullable<DateTime> _LogDate;
        private string _MeetTo;
        private System.Nullable<int> _OutTime;
        private string _PName;
        private string _Reason;
        private System.Nullable<int> _RMID;
        private System.Nullable<int> _SocID;
        private System.Nullable<int> _UserID;
        private System.Nullable<int> _VMID;
        private string _GT;
        private string _VMobileNo;

        [Column(Storage = "_VMobileNo")]
        public string VMobileNo
        {
            get { return _VMobileNo; }
            set { _VMobileNo = value; }
        }

        [Column(Storage = "_GT")]
        public string GT
        {
            get { return _GT; }
            set { _GT = value; }
        }

        [Column(Storage = "_InTime")]
        public System.Nullable<int> InTime
        {
            get
            {
                return _InTime;
            }
            set
            {
                _InTime = value;
            }
        }



        [Column(Storage = "_LogDate")]
        public System.Nullable<DateTime> LogDate
        {
            get
            {
                return _LogDate;
            }
            set
            {
                _LogDate = value;
            }
        }



        [Column(Storage = "_MeetTo")]
        public string MeetTo
        {
            get
            {
                return _MeetTo;
            }
            set
            {
                _MeetTo = value;
            }
        }



        [Column(Storage = "_OutTime")]
        public System.Nullable<int> OutTime
        {
            get
            {
                return _OutTime;
            }
            set
            {
                _OutTime = value;
            }
        }



        [Column(Storage = "_PName")]
        public string PName
        {
            get
            {
                return _PName;
            }
            set
            {
                _PName = value;
            }
        }



        [Column(Storage = "_Reason")]
        public string Reason
        {
            get
            {
                return _Reason;
            }
            set
            {
                _Reason = value;
            }
        }



        [Column(Storage = "_RMID")]
        public System.Nullable<int> RMID
        {
            get
            {
                return _RMID;
            }
            set
            {
                _RMID = value;
            }
        }



        [Column(Storage = "_SocID")]
        public System.Nullable<int> SocID
        {
            get
            {
                return _SocID;
            }
            set
            {
                _SocID = value;
            }
        }



        [Column(Storage = "_UserID")]
        public System.Nullable<int> UserID
        {
            get
            {
                return _UserID;
            }
            set
            {
                _UserID = value;
            }
        }



        [Column(Storage = "_VMID")]
        public System.Nullable<int> VMID
        {
            get
            {
                return _VMID;
            }
            set
            {
                _VMID = value;
            }
        }

    }


}
