using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

    [Serializable]
    [Table(Name = "dbo.Bookings")]
    public class Bookings
    {

        private string _BookedBy;
        private System.Nullable<DateTime> _BookingDate;
        private System.Nullable<int> _BookingID;
        private System.Nullable<decimal> _Charge;
        private System.Nullable<int> _FCID;
        private System.Nullable<DateTime> _FromTime;
        private System.Nullable<int> _SocID;
        private System.Nullable<DateTime> _ToTime;
        private Nullable<int> _InTime;
        private Nullable<int> _OutTime;
        private Nullable<int> _RoomID;
        private Nullable<bool> _Approved;
        private Nullable<int> _BookedByUser;

        [Column(Storage = "_BookedByUser")]
        public Nullable<int> BookedByUser
        {
            get { return _BookedByUser; }
            set { _BookedByUser = value; }
        }

        [Column(Storage = "_Approved")]
        public Nullable<bool> Approved
        {
            get { return _Approved; }
            set { _Approved = value; }
        }

        [Column(Storage = "_RoomID")]
        public Nullable<int> RoomID
        {
            get { return _RoomID; }
            set { _RoomID = value; }
        
        }

        [Column(Storage = "_OutTime")]
        public Nullable<int> OutTime
        {
            get { return _OutTime; }
            set { _OutTime = value; }
        }

        [Column(Storage = "_InTime")]
        public Nullable<int> InTime
        {
            get { return _InTime; }
            set { _InTime = value; }
        }

        [Column(Storage = "_BookedBy")]
        public string BookedBy
        {
            get
            {
                return _BookedBy;
            }
            set
            {
                _BookedBy = value;
            }
        }



        [Column(Storage = "_BookingDate")]
        public System.Nullable<DateTime> BookingDate
        {
            get
            {
                return _BookingDate;
            }
            set
            {
                _BookingDate = value;
            }
        }



        [Column(Storage = "_BookingID")]
        public System.Nullable<int> BookingID
        {
            get
            {
                return _BookingID;
            }
            set
            {
                _BookingID = value;
            }
        }



        [Column(Storage = "_Charge")]
        public System.Nullable<decimal> Charge
        {
            get
            {
                return _Charge;
            }
            set
            {
                _Charge = value;
            }
        }



        [Column(Storage = "_FCID")]
        public System.Nullable<int> FCID
        {
            get
            {
                return _FCID;
            }
            set
            {
                _FCID = value;
            }
        }



        [Column(Storage = "_FromTime")]
        public System.Nullable<DateTime> FromTime
        {
            get
            {
                return _FromTime;
            }
            set
            {
                _FromTime = value;
            }
        }



        [Column(Storage = "_SocID")]
        public System.Nullable<int> SocID
        {
            get
            {
                return _SocID;
            }
            set
            {
                _SocID = value;
            }
        }



        [Column(Storage = "_ToTime")]
        public System.Nullable<DateTime> ToTime
        {
            get
            {
                return _ToTime;
            }
            set
            {
                _ToTime = value;
            }
        }

    }


}
