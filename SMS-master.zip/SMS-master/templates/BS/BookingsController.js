var app = angular.module('myApp');

app.controller('BookingsListCtrl', function ($scope, $http, $location, GridData) {

    $scope = readyAngularGrid($scope, $http, 'api/BookingsList', 'BookingID', GridData, 'Bookings');
    $scope.gridOptions.columnDefs = [

    { displayName: 'Status', field: 'Status' },
    { displayName: 'Booked By', field: 'BookedBy' },
    { displayName: 'Facility Name', field: 'FCName' },
    { displayName: 'Booking Date', field: 'BookingDate', cellFilter: 'date:\'dd-MMM-yyyy\'' },
    { displayName: 'Charge', field: 'Charge' },
    { displayName: 'From Time', field: 'FromTime', cellFilter: 'date:\'dd-MMM-yy hh:mm a\'' },
    { displayName: 'To Time', field: 'ToTime', cellFilter: 'date:\'dd-MMM-yy hh:mm a\'' }, ];
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchBookings = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };
    $scope.newBookings = function () {
        saveGridData($scope, GridData, 'Bookings');
        $location.path('/BS/0');
    };
    $scope.editBookings = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            saveGridData($scope, GridData, 'Bookings');
            $location.path('/BS/' + selected[0].BookingID);
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.deleteBookings = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'DELETE',
                url: 'api/Bookings/' + selected[0].BookingID
            }).success(function (result) {
                if (result == true)
                    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
            });
        }
        else {
            alert('Please select a record to edit.');
        }
    };
})

.controller('BookingsCtrl', function ($scope, $http, $location, $routeParams, User) {
    $scope.UserType = User.UserType;
    var BookingID = $routeParams.BookingID;
    $scope.Bookings = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.BookingsSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.BookingsSubmitted = true;
        if ($scope.formBookings.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        if ($scope.UserType == 2 && ($scope.Bookings.Charge == null || $scope.Bookings.Charge == 0)) {
            alert('Please enter Charge!');
            return false;
        }
        $http.post('api/Bookings', $scope.Bookings, config)
        .success(function (data, status, headers, config) {
            var result = data;
            if (result.ErrorCode == 1)
                $scope.ErrorMessages = result.data;
            else {
                $scope.ErrorMessages = [];
                $scope.Bookings = result.data;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        if ($scope.UserType == 2)
            $location.path('/BookingsList');
        else
            $location.path('/BookingsListing');
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/Bookings/' + BookingID
        }).success(function (Bookings) {
            $scope.Bookings = Bookings;
        });
    }, 100);

    $scope.timelist = [];
    $scope.bindTime = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetTimeList', Data: null })
        }).success(function (data) {
            $scope.timelist = data;
        });
    }
    $scope.bindTime();

    $scope.fclist = [];
    $scope.bindFC = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetFCList', Data: null })
        }).success(function (data) {
            $scope.fclist = data;
        });
    }
    $scope.bindFC();

    $scope.roomlist = [];
    $scope.bindRoom = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: $scope.UserType == 2 ? 'GetRoomList' : 'GetMyRoomList', Data: null })
        }).success(function (data) {
            $scope.roomlist = data;
        });
    }
    $scope.bindRoom();

    $scope.approveReject = function (ar) {
        $http({
            method: 'POST',
            url: 'api/Bookings/ApproveReject/',
            data: JSON.stringify({ ApproveReject: ar, BookingID: BookingID })
        }).success(function (data) {
            swal({ title: ar + "!", type: "success", timer: 1000, showConfirmButton: false });
            if (ar == 'Approved')
                $scope.Bookings.Approved = 1;
            else
                $scope.Bookings.Approved = 0;
        });
    };
});
app.controller('BookingsListingCtrl', function ($scope, $http, $location, GridData) {

    $scope.filter = { filterText: '' };
    $scope.BookingList = [];
    $scope.searchBookings = function () {
        $http({
            method: 'POST',
            url: 'api/Bookings/BookingsListUser/',
            data: JSON.stringify({ filterText: $scope.filter.filterText })
        }).success(function (data) {
            $scope.BookingList = data;
        });
    };
    window.setTimeout(function () { $scope.searchBookings(); }, 200);
    $scope.newBookings = function () {
        $location.path('/BS/0');
    };

})