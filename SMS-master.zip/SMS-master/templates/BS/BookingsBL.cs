using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
[Serializable]
public class BookingsBL
{

#region Declaration
private string connectionString;
Bookings _Bookings;
public Bookings Data
{
get { return _Bookings; }
set { _Bookings = value; }
}
public bool IsNew
{
get { return (_Bookings.BookingID <= 0 || _Bookings.BookingID ==null); }
}
#endregion

#region Constructor
public BookingsBL(string conString)
{
connectionString = conString;
}
#endregion

#region Main Methods
private BookingsDL CreateDL()
{
return new BookingsDL(connectionString);
}
public void New()
{
_Bookings = new Bookings();
}
public void Load(int BookingID)
{
var BookingsObj = this.CreateDL();
_Bookings = BookingID <= 0 ? BookingsObj.Load(-1) : BookingsObj.Load(BookingID);
}
public DataTable LoadAllBookings()
{
var BookingsDLObj = CreateDL();
return BookingsDLObj.LoadAllBookings();
}
public bool Update()
{
var BookingsDLObj = CreateDL();
return BookingsDLObj.Update(this.Data);
}
public bool Delete(int BookingID)
{
var BookingsDLObj = CreateDL();
return BookingsDLObj.Delete(BookingID);
}
#endregion
}
}
