using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
    public class BookingsDL
    {

        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public BookingsDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public Bookings Load(int BookingID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            Bookings objBookings = new Bookings();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get Bookings
                var resultBookings = dc.ExecuteQuery<Bookings>("exec Get_Bookings {0}", BookingID).ToList();
                if (resultBookings.Count > 0)
                {
                    objBookings = resultBookings[0];
                }
                dc.Dispose();
                return objBookings;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllBookings()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_Bookings", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(Bookings objBookings)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update Bookings
                UpdateBookings(objBookings, trn);
                if (objBookings.BookingID > 0)
                {

                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int BookingID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete Bookings
                DeleteBookings(BookingID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateBookings(Bookings objBookings, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_Bookings", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@BookedBy", SqlDbType.VarChar, 100).Value = objBookings.BookedBy;
                cmd.Parameters.Add("@BookingDate", SqlDbType.DateTime).Value = objBookings.BookingDate;
                cmd.Parameters.Add("@BookingID", SqlDbType.Int).Value = objBookings.BookingID;
                cmd.Parameters["@BookingID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@Charge", SqlDbType.Decimal).Value = objBookings.Charge;
                cmd.Parameters.Add("@FCID", SqlDbType.Int).Value = objBookings.FCID;
                cmd.Parameters.Add("@FromTime", SqlDbType.DateTime).Value = objBookings.FromTime;
                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = objBookings.SocID;
                cmd.Parameters.Add("@ToTime", SqlDbType.DateTime).Value = objBookings.ToTime;
                cmd.Parameters.Add("@RoomID", SqlDbType.Int).Value = objBookings.RoomID;
                cmd.Parameters.Add("@Approved", SqlDbType.Bit).Value = objBookings.Approved;
                cmd.Parameters.Add("@BookedByUser", SqlDbType.Int).Value = objBookings.BookedByUser;

                cmd.ExecuteNonQuery();

                //after updating the Bookings, update BookingID
                objBookings.BookingID = Convert.ToInt32(cmd.Parameters["@BookingID"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteBookings(int BookingID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from Bookings where BookingID=@BookingID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@BookingID", SqlDbType.Int).Value = BookingID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        #endregion
    }
}
