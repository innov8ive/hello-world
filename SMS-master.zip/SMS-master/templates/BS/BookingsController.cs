using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;
using System.Web.Http.Cors;

namespace SampleAngular.Api
{
    public class BookingsController : ApiController
    {
        [Route("api/Bookings/ApproveReject/")]
        [HttpPost]
        public string ApproveReject([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.FacilityBooking, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            Common.ExecuteNonQuery("Update Bookings set Approved=@Approved where SocID=@SocID and BookingID=@BookingID",
                "@Approved", SqlDbType.Bit, Common.ToString(value.ApproveReject) == "Approved" ? true : false,
                "@SocID", SqlDbType.Int, objLoggedUser.SocID,
                "@BookingID", SqlDbType.Int, Common.ToInt(value.BookingID));

            //get requested by email and mobile
            DataTable dtAdmin = Common.GetDBResultParameterized(@"Select MobileNo,EmailID,UserID from Users
where UserID=(select BookedByUser from Bookings where BookingID=@BookingID)", "@BookingID", SqlDbType.Int, Common.ToInt(value.BookingID));
            if (dtAdmin.Rows.Count > 0)
            {
                string mobileNo = Common.ToString(dtAdmin.Rows[0]["MobileNo"]);
                string emailID = Common.ToString(dtAdmin.Rows[0]["EmailID"]);
                int UserID = Common.ToInt(dtAdmin.Rows[0]["UserID"]);
                Common.SendSMS(mobileNo, "Your Facility Booking request has been " + Common.ToString(value.ApproveReject) + "." + objLoggedUser.SocName, 0);
                Common.InsertIntoAlerts("Your Facility Booking request is " + Common.ToString(value.ApproveReject) + "." + objLoggedUser.SocName, objLoggedUser.SocID, UserID, "FACILITY");
            }

            return "Success";
        }

        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/Bookings/BookingsListUser/")]
        [HttpPost]
        public DataTable GetBookingsUser([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            DataTable dt = Common.GetDBResultParameterized(@"Select B.*,FC.FCName,S.SocName from Bookings B 
inner join FC ON B.FCID=FC.FCID
inner join Soc S ON B.SocID=S.SocID where B.BookedByUser=@BookedByUser and (FC.FCName like '%'+@Text+'%' OR 
S.SocName like '%'+@Text+'%') Order By BookingDate desc",
"@BookedByUser", SqlDbType.Int, objLoggedUser.UserID,
"@Text", SqlDbType.VarChar, Common.ToString(value.filterText));

            return dt;
        }

        [Route("api/BookingsList/")]
        [HttpPost]
        public AngularGridData GetBookings([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.FacilityBooking, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = @"Select B.*,FC.FCName
,Case when Approved IS NULL then 'Pending' when Approved=1 then 'Approved' when Approved=0 then 'Rejected' end as Status
            from Bookings B inner join FC ON B.FCID=FC.FCID where B.SocID=" + objLoggedUser.SocID;
            objAngularDataBinder.ValueField = "BookingID";
            objAngularDataBinder.OrderBy = "BookingDate";
            objAngularDataBinder.OrderDir = "Desc";
            return objAngularDataBinder.GetData();
        }

        [EnableCors(origins: "*", headers: "*", methods: "*")]
        // GET api/Bookings/Id
        [Route("api/Bookings/{Id}")]
        public object GetBookings(int Id)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            BookingsBL objBookingsBL = new BookingsBL(Common.GetConString());
            objBookingsBL.Load(Id);
            Bookings objBookings = objBookingsBL.Data;
            if (Common.ToInt(objBookings.SocID) > 0 && objBookings.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            if (objBookings.FromTime != null)
            {
                objBookings.InTime = objBookings.FromTime.Value.Hour * 60 + objBookings.FromTime.Value.Minute;
                objBookings.FromTime = objBookings.FromTime.Value.Date;
            }
            if (objBookings.ToTime != null)
            {
                objBookings.OutTime = objBookings.ToTime.Value.Hour * 60 + objBookings.ToTime.Value.Minute;
                objBookings.ToTime = objBookings.ToTime.Value.Date;
            }
            return JsonConvert.DeserializeObject(JsonConvert.SerializeObject(objBookingsBL.Data));
        }

        [EnableCors(origins: "*", headers: "*", methods: "*")]
        // POST api/Bookings/
        public object Post([FromBody]dynamic value)
        {
            PostResponse objPostResponse = new PostResponse();
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            Bookings objBookings = objJObject.ToObject<Bookings>();
            BookingsBL objBookingsBL = new BookingsBL(Common.GetConString());
            objBookingsBL.Data = objBookings;

            bool sendNotification = false;

            if (objBookingsBL.IsNew)
            {
                objBookings.SocID = objLoggedUser.SocID;
                objBookings.BookingDate = DateTime.Now;
                objBookings.BookedByUser = objLoggedUser.UserID;
                if (objLoggedUser.UserType == 2)//Admin
                {
                    objBookings.Approved = true;
                }
                else
                {
                    objBookings.Approved = null;
                    sendNotification = true;
                }
            }
            if (Common.ToInt(objBookings.SocID) > 0 && objBookings.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            if (objBookings.InTime != null)
            {
                objBookings.FromTime = objBookings.FromTime.Value.Date.AddMinutes(objBookings.InTime.Value);
            }
            if (objBookings.OutTime != null)
            {
                objBookings.ToTime = objBookings.ToTime.Value.Date.AddMinutes(objBookings.OutTime.Value);
            }

            BookingsValidator validator = new BookingsValidator();
            ValidationResult results = validator.Validate(objBookings);
            int count = Common.ToInt(Common.GetDBScalar(@"Select COUNT(*) from Bookings where SocID=@SocID and FCID=@FCID 
and (@Date1 between FromTime and ToTime OR @Date2 between FromTime and ToTime) and BookingID<>@BookingID and Approved=1",
"@SocID", SqlDbType.Int, objBookings.SocID,
"@FCID", SqlDbType.Int, objBookings.FCID,
"@Date1", SqlDbType.DateTime, objBookings.FromTime,
"@Date2", SqlDbType.DateTime, objBookings.ToTime,
"@BookingID", SqlDbType.Int, Common.ToInt(objBookings.BookingID)));
            if (count > 0)
            {
                results.Errors.Add(new ValidationFailure("FromTime", "This FC is already booked for selected Date"));
            }
            if (results.IsValid)
            {
                if (objBookingsBL.Update())
                {
                    if (sendNotification)
                    {
                        Common.InsertIntoAlerts("Facility Booking Request", objLoggedUser.SocID, 0, "FB");

                        //get soc admin email and mobile
                        DataTable dtAdmin = Common.GetDBResultParameterized(@"Select MobileNo,EmailID from Users
where UserID=(select UserID from Soc where SocID=@SocID)", "@SocID", SqlDbType.Int, objLoggedUser.SocID);
                        if (dtAdmin.Rows.Count > 0)
                        {
                            string mobileNo = Common.ToString(dtAdmin.Rows[0]["MobileNo"]);
                            string emailID = Common.ToString(dtAdmin.Rows[0]["EmailID"]);
                            Common.SendSMS(mobileNo, "Facility Booking Request Received", 0);
                            Common.InsertIntoAlerts("Facility Booking Request Received", objLoggedUser.SocID, 0, "FACILITY");
                        }
                    }
                }
                objBookings.FromTime = objBookings.FromTime.Value.Date;
                objBookings.ToTime = objBookings.ToTime.Value.Date;

                objPostResponse.ErrorCode = 0;
                objPostResponse.data = JsonConvert.DeserializeObject(JsonConvert.SerializeObject(objBookingsBL.Data));
                return objPostResponse;
            }
            objPostResponse.ErrorCode = 1;
            objPostResponse.data = JsonConvert.DeserializeObject(JsonConvert.SerializeObject(results.Errors));
            objPostResponse.ErrorMessage = Common.ErrorToString(results);
            return objPostResponse;
        }

        // DELETE api/Bookings/5
        [Route("api/Bookings/{Id}")]
        [HttpDelete]
        public bool Delete(int Id)
        {
            Common.IsValidForm(Constants.Forms.FacilityBooking, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            BookingsBL objBookingsBL = new BookingsBL(Common.GetConString());
            objBookingsBL.Load(Id);
            Bookings objBookings = objBookingsBL.Data;
            if (Common.ToInt(objBookings.SocID) > 0 && objBookings.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            return objBookingsBL.Delete(Id);
        }
    }
    public class BookingsValidator : AbstractValidator<Bookings>
    {
        public BookingsValidator()
        {

            RuleFor(obj => obj.BookedBy).NotEmpty();
            RuleFor(obj => obj.BookingDate).NotEmpty();
            RuleFor(obj => obj.FCID).NotEmpty();
            RuleFor(obj => obj.FromTime).NotEmpty();
            RuleFor(obj => obj.ToTime).NotEmpty();
        }
    }
}

