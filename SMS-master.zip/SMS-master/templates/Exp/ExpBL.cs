using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularDL;
using SampleAngularOM;

namespace SampleAngularBL
{
    [Serializable]
    public class ExpBL
    {
        #region Declaration
        private string connectionString;
        Exp _Exp;
        public Exp Data
        {
            get { return _Exp; }
            set { _Exp = value; }
        }
        public bool IsNew
        {
            get { return (_Exp.ExpID <= 0 || _Exp.ExpID == null); }
        }
        #endregion

        #region Constructor
        public ExpBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private ExpDL CreateDL()
        {
            return new ExpDL(connectionString);
        }
        public void New()
        {
            _Exp = new Exp();
        }
        public void Load(int ExpID)
        {
            var ExpObj = this.CreateDL();
            _Exp = ExpID <= 0 ? ExpObj.Load(-1) : ExpObj.Load(ExpID);
        }
        public DataTable LoadAllExp()
        {
            var ExpDLObj = CreateDL();
            return ExpDLObj.LoadAllExp();
        }
        public bool Update()
        {
            var ExpDLObj = CreateDL();
            return ExpDLObj.Update(this.Data);
        }
        public bool Delete(int ExpID)
        {
            var ExpDLObj = CreateDL();
            return ExpDLObj.Delete(ExpID);
        }
        #endregion
    }
}
