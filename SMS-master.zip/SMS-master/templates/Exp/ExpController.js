var app = angular.module('myApp');

app.controller('ExpListCtrl', function ($scope, $http, $location, GridData) {
    $scope.Filter = { ExpType: null, Date: '' };
    
    $scope = readyAngularGrid($scope, $http, 'api/ExpList', 'ExpID', GridData, 'Exp');
    $scope.gridOptions.columnDefs = [

    { displayName: 'Ref No.', field: 'RefNo' },
    { displayName: 'Ref Date', field: 'RefDate', cellFilter: 'date:\'dd-MMM-yyyy\'' },
    { displayName: 'Amount', field: 'Amount' },
    { displayName: 'Expense Type', field: 'GroupName' },
    { displayName: 'Expense A/C', field: 'FromGL' },
    { displayName: 'Debited from A/C', field: 'ToGL' },
    { displayName: 'Vendor', field: 'VendorGL' },
    { displayName: 'Remark', field: 'Remark' },
    ];
    
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchExp = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };
    $scope.newExp = function () {
        saveGridData($scope, GridData, 'Exp');
        $location.path('/Exp/0');
    };
    $scope.editExp = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            saveGridData($scope, GridData, 'Exp');
            $location.path('/Exp/' + selected[0].ExpID);
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.deleteExp = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'DELETE',
                url: 'api/Exp/' + selected[0].ExpID
            }).success(function (result) {
                if (result == true)
                    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
            });
        }
        else {
            alert('Please select a record to edit.');
        }
    };


    $scope.exptypelist = [];
    $scope.bindExpType = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetOverheadGLList', Data: null, query: '18' })//In-Direct Expense
        }).success(function (data) {
            $scope.exptypelist = data;
        });
    }
    $scope.bindExpType();

    $scope.monthlist = [];
    $scope.bindMonth = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetMonthList', Data: null })
        }).success(function (data) {
            $scope.monthlist = data;
        });
    }
    $scope.bindMonth();

    $scope.exportExpense = function () {
        window.open('api/AccountReport/DownloadExpenseRegister?date=' + $scope.Filter.Date + '&name=' + $scope.filter.filterText);
    };
    $scope.exportExpensePdf = function () {
        window.open('api/AccountReport/DownloadExpenseRegisterPdf?date=' + $scope.Filter.Date + '&name=' + $scope.filter.filterText);
    };

    $scope.printExp = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            var ExpID = selected[0].ExpID;
            window.open('PrintExpense.aspx?ExpID=' + ExpID, '', 'height=600,width=900');
        }
        else {
            alert('Please select a record to print.');
        }
    };
})

.controller('ExpCtrl', function ($scope, $http, $location, $routeParams) {
    var ID = $routeParams.ExpID;
    $scope.Exp = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.ExpSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.ExpSubmitted = true;
        if ($scope.formExp.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/Exp', $scope.Exp, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.Exp = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/ExpList');
    }

    $scope.exptypelist = [];
    $scope.bindExpenseGroup = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetExpenseGroupList', Data: null })
        }).success(function (data) {
            $scope.exptypelist = data;
            //$scope.bindOverHead();
        });
    }
    $scope.bindExpenseGroup();
    $scope.onExpTypeSelected = function ($item, $select) {
        //$scope.bindOverHead(true);
    }
    $scope.overheadlist = [];
    $scope.bindOverHead = function (clear) {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetOverheadGLList', Data: null, query: $scope.Exp.FromGroupID })
        }).success(function (data) {
            $scope.overheadlist = data;
            if (clear == true) $scope.Exp.FromGLID = null;
        });
    };

    $scope.vendorlist = [];
    $scope.bindVendors = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetVendorGLList', Data: null })
        }).success(function (data) {
            $scope.vendorlist = data;
        });
    }
    $scope.bindVendors();


    $scope.getText = function (model, array) {
        for (var j = 0; j < array.length; j++) {
            if (model == array[j].Key) {
                return array[j].Value;
            }
        }
        return '';
    }


    $scope.debitfromlist = [];
    $scope.bindDebitFrom = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetContraGLList', Data: null })
        }).success(function (data) {
            $scope.debitfromlist = data;
        });
    }
    $scope.bindDebitFrom();

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/Exp/' + ID
        }).success(function (Exp) {
            $scope.Exp = JSON.parse(Exp);
            $scope.bindYear();
            //$scope.bindOverHead();
        });
    }, 100);
    $scope.$watch('Exp', function (newVal, oldVal) {
        if (newVal.FromGroupID !== oldVal.FromGroupID) {
            $scope.bindOverHead();
        }
    }, true);

    $scope.yearlist = [];
    $scope.bindYear = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetYearList', Data: null })
        }).success(function (data) {
            $scope.yearlist = data;
        });
    };
    
});
