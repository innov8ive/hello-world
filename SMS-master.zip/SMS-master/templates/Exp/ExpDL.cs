using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
    public class ExpDL
    {
        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public ExpDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public Exp Load(int ExpID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            Exp objExp = new Exp();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get Exp
                var resultExp = dc.ExecuteQuery<Exp>("exec Get_Exp {0}", ExpID).ToList();
                if (resultExp.Count > 0)
                {
                    objExp = resultExp[0];
                }
                dc.Dispose();
                return objExp;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllExp()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_Exp", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(Exp objExp)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update Exp
                UpdateExp(objExp, trn);
                if (objExp.ExpID > 0)
                {

                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int ExpID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete Exp
                DeleteExp(ExpID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateExp(Exp objExp, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_Exp", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;
                cmd.Parameters.Add("@Amount", SqlDbType.Decimal).Value = objExp.Amount;
                cmd.Parameters.Add("@CompanyID", SqlDbType.Int).Value = objExp.CompanyID;
                cmd.Parameters.Add("@CrGEID", SqlDbType.Int).Value = objExp.CrGEID;
                cmd.Parameters.Add("@DrGEID", SqlDbType.Int).Value = objExp.DrGEID;
                cmd.Parameters.Add("@ExpID", SqlDbType.Int).Value = objExp.ExpID;
                cmd.Parameters["@ExpID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@FromGLID", SqlDbType.Int).Value = objExp.FromGLID;
                cmd.Parameters.Add("@FromGroupID", SqlDbType.Int).Value = objExp.FromGroupID;
                cmd.Parameters.Add("@LocationID", SqlDbType.Int).Value = objExp.LocationID;
                cmd.Parameters.Add("@RefDate", SqlDbType.DateTime).Value = objExp.RefDate;
                cmd.Parameters.Add("@RefNo", SqlDbType.VarChar, 100).Value = objExp.RefNo;
                cmd.Parameters["@RefNo"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@Remark", SqlDbType.VarChar, 500).Value = objExp.Remark;
                cmd.Parameters.Add("@ToGLID", SqlDbType.Int).Value = objExp.ToGLID;
                cmd.Parameters.Add("@WPID", SqlDbType.Int).Value = objExp.WPID;
                cmd.Parameters.Add("@TransID", SqlDbType.Int).Value = objExp.TransID;
                cmd.Parameters.Add("@TransNo", SqlDbType.VarChar, 100).Value = objExp.TransNo;
                cmd.Parameters.Add("@VendorGLID", SqlDbType.Int).Value = objExp.VendorGLID;

                cmd.ExecuteNonQuery();

                //after updating the Exp, update ExpID
                objExp.ExpID = Convert.ToInt32(cmd.Parameters["@ExpID"].Value);
                objExp.RefNo = cmd.Parameters["@RefNo"].Value.ToString();

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteExp(int ExpID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from Exp where ExpID=@ExpID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@ExpID", SqlDbType.Int).Value = ExpID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        #endregion
    }
}
