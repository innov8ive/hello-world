using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;
using System.IO;

namespace SampleAngular.Api
{
    public class ExpController : ApiController
    {
        // GET api/Exp
        [Route("api/ExpList/")]
        [HttpPost]
        public AngularGridData GetExp([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.Expense, Request);
            LoggedUser objLoggedUser = HttpContext.Current.Session["LoggedUser"] as LoggedUser;

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = Common.GetExpListQuery();
            DateTime date = Common.ToDate(value.OtherFilter.Date);
            Hashtable ht = new Hashtable();
            ht["@FGL"] = Common.ToInt(0);
            ht["@SocID"] = objLoggedUser.SocID;
            ht["@Month"] = date.Month;
            ht["@Year"] = date.Year;
            ht["@Name"] = Common.ToString(value.SearchText);
            objAngularDataBinder.Parameters = ht;
            objAngularDataBinder.ValueField = "ExpID";
            return objAngularDataBinder.GetData();
        }

        // GET api/Exp/Id
        [Route("api/Exp/{Id}")]
        public string GetExp(int Id)
        {
            Common.IsValidForm(Constants.Forms.Expense, Request);
            LoggedUser objLoggedUser = HttpContext.Current.Session["LoggedUser"] as LoggedUser;

            ExpBL objExpBL = new ExpBL(Common.GetConString());
            objExpBL.Load(Id);
            if (objExpBL.IsNew)
            {
                objExpBL.Data.WPID = objLoggedUser.WPID;
            }
            if (objExpBL.IsNew == false && objExpBL.Data.CompanyID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            return JsonConvert.SerializeObject(objExpBL.Data);
        }

        // POST api/Exp/
        public string Post([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.Expense, Request);
            LoggedUser objLoggedUser = HttpContext.Current.Session["LoggedUser"] as LoggedUser;

            JObject objJObject = value;
            Exp objExp = objJObject.ToObject<Exp>();
            ExpBL objExpBL = new ExpBL(Common.GetConString());
            objExpBL.Data = objExp;
            bool isNew = objExpBL.IsNew;

            ExpValidator validator = new ExpValidator();
            ValidationResult results = validator.Validate(objExp);
            if (objLoggedUser.WPID <= 0 || objExp.WPID <= 0)
            {
                results.Errors.Add(new ValidationFailure("WPID", "Working Period Not Selected"));
            }
            if (objExp.RefDate > objLoggedUser.EndDate || objExp.RefDate < objLoggedUser.StartDate)
            {
                results.Errors.Add(new ValidationFailure("RefDate", "Expense Date is not in Working Period Range"));
            }
            if (results.IsValid)
            {
                if (isNew)
                {
                    objExp.CompanyID = objLoggedUser.SocID;
                }
                else
                {
                    if (objExpBL.Data.CompanyID != objLoggedUser.SocID)
                        throw new HttpResponseException(HttpStatusCode.Unauthorized);
                }
                if (objExpBL.Update())
                {
                    int GEGroupID = Common.ToInt(objExp.ExpGEGroupID);
                    Common.ExecuteNonQuery("delete from GE where CompanyID=" + objExp.CompanyID + " and GEGroupID=" + GEGroupID);
                    GE objGE = GECommon.GEntry(GEGroupID, Common.ToInt(objExp.FromGLID), Common.ToDecimal(objExp.Amount), 0,
                        Common.ToInt(objExp.ExpID), objExp.RefNo, objExp.Remark,
                        Common.ToDate(objExp.RefDate),
                        objLoggedUser.SocID, 0, "ExpPayable");
                    GEGroupID = Common.ToInt(objGE.GEGroupID);

                    GECommon.GEntry(GEGroupID, Common.ToInt(objExp.VendorGLID), 0, Common.ToDecimal(objExp.Amount),
                        Common.ToInt(objExp.ExpID), objExp.RefNo, objExp.Remark,
                        Common.ToDate(objExp.RefDate),
                        objLoggedUser.SocID, 0, "ExpPayable");

                    GECommon.GEntry(GEGroupID, Common.ToInt(objExp.VendorGLID), Common.ToDecimal(objExp.Amount), 0,
                        Common.ToInt(objExp.ExpID), objExp.RefNo, objExp.Remark,
                        Common.ToDate(objExp.RefDate),
                        objLoggedUser.SocID, 0, "ExpPaid");

                    GECommon.GEntry(GEGroupID, Common.ToInt(objExp.ToGLID), 0, Common.ToDecimal(objExp.Amount),
                       Common.ToInt(objExp.ExpID), objExp.RefNo, objExp.Remark,
                       Common.ToDate(objExp.RefDate),
                       objLoggedUser.SocID, 0, "ExpPaid");

                    Common.ExecuteNonQuery("Update Exp set ExpGEGroupID=@ExpGEGroupID where ExpID=@ExpID",
                        "@ExpGEGroupID", SqlDbType.Int, GEGroupID,
                        "@ExpID", SqlDbType.Int, Common.ToInt(objExp.ExpID));
                    objExp.ExpGEGroupID = GEGroupID;

                }
                return JsonConvert.SerializeObject(objExpBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        // DELETE api/Exp/5
        [Route("api/Expense/{Id}")]
        [HttpDelete]
        public bool Delete(int Id)
        {
            Common.IsValidForm(Constants.Forms.Expense, Request);
            LoggedUser objLoggedUser = HttpContext.Current.Session["LoggedUser"] as LoggedUser;


            ExpBL objExpBL = new ExpBL(Common.GetConString());
            objExpBL.Load(Id);
            Exp objExp = objExpBL.Data;
            if (objExp.CompanyID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            Common.ExecuteNonQuery("Delete from GE where CompanyID=" + objExp.CompanyID + " and GEGroupID=" + Common.ToInt(objExp.ExpGEGroupID));
            return objExpBL.Delete(Id);
        }
    }
    public class ExpValidator : AbstractValidator<Exp>
    {
        public ExpValidator()
        {
            RuleFor(obj => obj.Remark).NotEmpty();
        }
    }
}

