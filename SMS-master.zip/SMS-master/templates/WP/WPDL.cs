using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
public class WPDL
{

#region Private Members
private string connectionString;
#endregion

#region Constructor
public WPDL(string conString)
{
connectionString = conString;
}
#endregion

#region Main Methods
public WP Load(int WPID)
{
SqlConnection SqlCon = new SqlConnection(connectionString);
WP objWP = new WP();
var dc = new DataContext(SqlCon);
try
{
//Get WP
var resultWP = dc.ExecuteQuery<WP>("exec Get_WP {0}", WPID).ToList();
if (resultWP.Count > 0)
{
objWP = resultWP[0];
}
dc.Dispose();
return objWP;
}
catch (Exception ex)
{
throw new Exception(ex.Message);
}
finally
{
if (SqlCon.State == ConnectionState.Open)
{
SqlCon.Close();
}
SqlCon.Dispose();
}
}
public DataTable LoadAllWP()
{
DataTable dt = new DataTable();
SqlConnection con = new SqlConnection(connectionString);
SqlCommand cmd = new SqlCommand("exec Get_WP",con);

con.Open();
dt.Load(cmd.ExecuteReader());
con.Close();

return dt;
}
public bool Update(WP objWP)
{
SqlConnection con = new SqlConnection(connectionString);
con.Open();
SqlTransaction trn = con.BeginTransaction();
try
{
//update WP
UpdateWP(objWP,trn);
if (objWP.WPID > 0)
{

trn.Commit();
}
return true;
}
catch
{
trn.Rollback();
return false;
}
finally
{
con.Dispose();
}
}
public bool Delete(int WPID)
{
SqlConnection con = new SqlConnection(connectionString);
con.Open();
SqlTransaction trn = con.BeginTransaction();
try
{
//Delete WP
DeleteWP(WPID,trn);
trn.Commit();
return true;
}
catch
{
trn.Rollback();
return false;
}
finally
{
con.Dispose();
}
}

public bool UpdateWP(WP objWP,SqlTransaction trn){SqlCommand cmd=new SqlCommand("Insert_Update_WP",trn.Connection);try{cmd.CommandType=CommandType.StoredProcedure; cmd.Transaction = trn;
cmd.Parameters.Add("@EndDate",SqlDbType.DateTime).Value=objWP.EndDate;
cmd.Parameters.Add("@SocID",SqlDbType.Int).Value=objWP.SocID;
cmd.Parameters.Add("@StartDate",SqlDbType.DateTime).Value=objWP.StartDate;
cmd.Parameters.Add("@WPID",SqlDbType.Int).Value=objWP.WPID;
cmd.Parameters["@WPID"].Direction=ParameterDirection.InputOutput;
cmd.ExecuteNonQuery();//after updating the WP, update WPIDobjWP.WPID=Convert.ToInt32(cmd.Parameters["@WPID"].Value);return true;}catch{ trn.Rollback();return false;}finally{cmd.Dispose();}}
public bool DeleteWP(int WPID, SqlTransaction trn){try{SqlCommand cmd=new SqlCommand("Delete from WP where WPID=@WPID", trn.Connection);cmd.Transaction = trn;cmd.Parameters.Add("@WPID",SqlDbType.Int).Value=WPID;cmd.ExecuteNonQuery();return true;}catch{trn.Rollback();return false;}}#endregion
}
}
