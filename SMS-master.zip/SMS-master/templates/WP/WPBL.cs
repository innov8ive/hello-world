using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
[Serializable]
public class WPBL
{

#region Declaration
private string connectionString;
WP _WP;
public WP Data
{
get { return _WP; }
set { _WP = value; }
}
public bool IsNew
{
get { return (_WP.WPID <= 0 || _WP.WPID ==null); }
}
#endregion

#region Constructor
public WPBL(string conString)
{
connectionString = conString;
}
#endregion

#region Main Methods
private WPDL CreateDL()
{
return new WPDL(connectionString);
}
public void New()
{
_WP = new WP();
}
public void Load(int WPID)
{
var WPObj = this.CreateDL();
_WP = WPID <= 0 ? WPObj.Load(-1) : WPObj.Load(WPID);
}
public DataTable LoadAllWP()
{
var WPDLObj = CreateDL();
return WPDLObj.LoadAllWP();
}
public bool Update()
{
var WPDLObj = CreateDL();
return WPDLObj.Update(this.Data);
}
public bool Delete(int WPID)
{
var WPDLObj = CreateDL();
return WPDLObj.Delete(WPID);
}
#endregion
}
}
