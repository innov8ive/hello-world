using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

[Serializable][Table(Name = "dbo.WP")]public class WP{
private System.Nullable<DateTime> _EndDate;
private System.Nullable<int> _SocID;
private System.Nullable<DateTime> _StartDate;
private System.Nullable<int> _WPID;
 
[Column(Storage = "_EndDate")]
public System.Nullable<DateTime> EndDate{get {return _EndDate;}set { _EndDate=value;}}
[Column(Storage = "_SocID")]
public System.Nullable<int> SocID{get {return _SocID;}set { _SocID=value;}}
[Column(Storage = "_StartDate")]
public System.Nullable<DateTime> StartDate{get {return _StartDate;}set { _StartDate=value;}}
[Column(Storage = "_WPID")]
public System.Nullable<int> WPID{get {return _WPID;}set { _WPID=value;}}
}}
