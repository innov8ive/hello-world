using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;

namespace SampleAngular.Api
{
    public class WPController : ApiController
    {
        // GET api/WP
        [Route("api/WPList/")]
        [HttpPost]
        public AngularGridData GetWP([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.FinacialYear, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = "Select * from WP where SocID="+objLoggedUser.SocID;
            objAngularDataBinder.OrderBy = "StartDate";
            objAngularDataBinder.OrderDir = "Desc";
            objAngularDataBinder.ValueField = "WPID";
            return objAngularDataBinder.GetData();
        }

        // GET api/WP/Id
        [Route("api/WP/{Id}")]
        public string GetWP(int Id)
        {
            Common.IsValidForm(Constants.Forms.FinacialYear, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            WPBL objWPBL = new WPBL(Common.GetConString());
            objWPBL.Load(Id);
            WP objWP = objWPBL.Data;
            if (Common.ToInt(objWP.SocID) > 0 && objWP.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            return JsonConvert.SerializeObject(objWPBL.Data);
        }

        // POST api/WP/
        public string Post([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.FinacialYear, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            WP objWP = objJObject.ToObject<WP>();
            WPBL objWPBL = new WPBL(Common.GetConString());
            objWPBL.Data = objWP;
            if (objWPBL.IsNew)
            {
                objWP.SocID = objLoggedUser.SocID;
            }
            if (Common.ToInt(objWP.SocID) > 0 && objWP.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            WPValidator validator = new WPValidator();
            ValidationResult results = validator.Validate(objWP);

            DataTable dt = Common.GetDBResultParameterized(@"Select * from WP where SocID=@SocID and (@StartDate between StartDate and EndDate
                OR @EndDate between StartDate and EndDate) and WPID<>@WPID",
                "@StartDate", SqlDbType.DateTime, objWP.StartDate,
                "@EndDate", SqlDbType.DateTime, objWP.StartDate,
                "@SocID", SqlDbType.Int, objWP.SocID,
                "@WPID", SqlDbType.Int, Common.ToInt(objWP.WPID));
            if (dt.Rows.Count > 0)
            {
                results.Errors.Add(new ValidationFailure("StartDate", "The Date Range is not valid. There is already Financial Year defined for the Date Range"));
            }
            if (objWP.StartDate >= objWP.EndDate)
            {
                results.Errors.Add(new ValidationFailure("EndDate", "The End Date should be grater that Start Date"));
            }
            if (results.IsValid)
            {
                objWPBL.Update();
                return JsonConvert.SerializeObject(objWPBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        // DELETE api/WP/5
        [Route("api/WP/{Id}")]
        [HttpDelete]
        public bool Delete(int Id)
        {
            Common.IsValidForm(Constants.Forms.FinacialYear, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            WPBL objWPBL = new WPBL(Common.GetConString());
            objWPBL.Load(Id);
            WP objWP = objWPBL.Data;
            if (Common.ToInt(objWP.SocID) > 0 && objWP.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            return objWPBL.Delete(Id);
        }
    }
    public class WPValidator : AbstractValidator<WP>
    {
        public WPValidator()
        {
            RuleFor(obj => obj.EndDate).NotEmpty();
            RuleFor(obj => obj.StartDate).NotEmpty();
        }
    }
}

