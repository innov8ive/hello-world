var app = angular.module('myApp');

app.controller('WPListCtrl', function ($scope, $http, $location, GridData) {

    $scope = readyAngularGrid($scope, $http, 'api/WPList', 'WPID', GridData, 'WP');
    $scope.gridOptions.columnDefs = [

    { displayName: 'Start Date', field: 'StartDate', cellFilter: 'date:\'dd-MMM-yyyy\'' },
    { displayName: 'End Date', field: 'EndDate', cellFilter: 'date:\'dd-MMM-yyyy\'' }, ];
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchWP = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };
    $scope.newWP = function () {
        saveGridData($scope, GridData, 'WP');
        $location.path('/WP/0');
    };
    $scope.editWP = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            saveGridData($scope, GridData, 'WP');
            $location.path('/WP/' + selected[0].WPID);
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.deleteWP = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'DELETE',
                url: 'api/WP/' + selected[0].WPID
            }).success(function (result) {
                if (result == true)
                    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
            });
        }
        else {
            alert('Please select a record to edit.');
        }
    };
})

.controller('WPCtrl', function ($scope, $http, $location, $routeParams) {
    var WPID = $routeParams.WPID;
    $scope.WP = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.WPSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.WPSubmitted = true;
        if ($scope.formWP.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/WP', $scope.WP, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.WP = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/WPList');
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/WP/' + WPID
        }).success(function (WP) {
            $scope.WP = JSON.parse(WP);
        });
    }, 100);
});
