using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

    [Serializable]
    [Table(Name = "dbo.Payments")]
    public class Payments
    {
        private System.Nullable<decimal> _Amount;
        private System.Nullable<int> _BillID;
        private System.Nullable<int> _PaidGEGroupID;
        private System.Nullable<DateTime> _PaidRefDate;
        private string _PaidRefNo;
        private System.Nullable<int> _PaidToGLID;
        private System.Nullable<DateTime> _PaymentDate;
        private System.Nullable<int> _PaymentID;
        private string _PaymentMode;
        private string _Remarks;
        private System.Nullable<int> _SocID;
        private System.Nullable<decimal> _BillAmount;
        private Nullable<DateTime> _BillDate;
        public Bills objBills { get; set; }
        private Nullable<int> _RoomID;
        private Nullable<bool> _Approved;
        private string _UnitNo;
        private string _BillIDs;
        private Nullable<int> _ReqID;

        [Column(Storage = "_ReqID")]
        public Nullable<int> ReqID
        {
            get { return _ReqID; }
            set { _ReqID = value; }
        }

        [Column(Storage = "_BillIDs")]
        public string BillIDs
        {
            get { return _BillIDs; }
            set { _BillIDs = value; }
        }

        [Column(Storage = "_UnitNo")]
        public string UnitNo
        {
            get { return _UnitNo; }
            set { _UnitNo = value; }
        }

        [Column(Storage = "_Approved")]
        public Nullable<bool> Approved
        {
            get { return _Approved; }
            set { _Approved = value; }
        }

        [Column(Storage = "_RoomID")]
        public Nullable<int> RoomID
        {
            get
            {
                return _RoomID;
            }
            set
            {
                _RoomID = value;
            }
        }

        [Column(Storage = "_BillDate")]
        public Nullable<DateTime> BillDate
        {
            get { return _BillDate; }
            set { _BillDate = value; }
        }

        [Column(Storage = "_BillAmount")]
        public System.Nullable<decimal> BillAmount
        {
            get { return _BillAmount; }
            set { _BillAmount = value; }
        }

        [Column(Storage = "_SocID")]
        public System.Nullable<int> SocID
        {
            get { return _SocID; }
            set { _SocID = value; }
        }

        [Column(Storage = "_Amount")]
        public System.Nullable<decimal> Amount
        {
            get
            {
                return _Amount;
            }
            set
            {
                _Amount = value;
            }
        }



        [Column(Storage = "_BillID")]
        public System.Nullable<int> BillID
        {
            get
            {
                return _BillID;
            }
            set
            {
                _BillID = value;
            }
        }



        [Column(Storage = "_PaidGEGroupID")]
        public System.Nullable<int> PaidGEGroupID
        {
            get
            {
                return _PaidGEGroupID;
            }
            set
            {
                _PaidGEGroupID = value;
            }
        }



        [Column(Storage = "_PaidRefDate")]
        public System.Nullable<DateTime> PaidRefDate
        {
            get
            {
                return _PaidRefDate;
            }
            set
            {
                _PaidRefDate = value;
            }
        }



        [Column(Storage = "_PaidRefNo")]
        public string PaidRefNo
        {
            get
            {
                return _PaidRefNo;
            }
            set
            {
                _PaidRefNo = value;
            }
        }



        [Column(Storage = "_PaidToGLID")]
        public System.Nullable<int> PaidToGLID
        {
            get
            {
                return _PaidToGLID;
            }
            set
            {
                _PaidToGLID = value;
            }
        }



        [Column(Storage = "_PaymentDate")]
        public System.Nullable<DateTime> PaymentDate
        {
            get
            {
                return _PaymentDate;
            }
            set
            {
                _PaymentDate = value;
            }
        }



        [Column(Storage = "_PaymentID")]
        public System.Nullable<int> PaymentID
        {
            get
            {
                return _PaymentID;
            }
            set
            {
                _PaymentID = value;
            }
        }



        [Column(Storage = "_PaymentMode")]
        public string PaymentMode
        {
            get
            {
                return _PaymentMode;
            }
            set
            {
                _PaymentMode = value;
            }
        }



        [Column(Storage = "_Remarks")]
        public string Remarks
        {
            get
            {
                return _Remarks;
            }
            set
            {
                _Remarks = value;
            }
        }

        public List<BillPayments> BillPaymentsList { get; set; }
    }

    [Serializable]
    [Table(Name = "dbo.BillPayments")]
    public class BillPayments
    {
        private System.Nullable<int> _BillID;
        private System.Nullable<int> _PaymentID;
        private Nullable<decimal> _PaidAmount;
        private Nullable<decimal> _TotalBillAmount;
        private System.Nullable<int> _BSID;

        [Column(Storage = "_BSID")]
        public System.Nullable<int> BSID
        {
            get { return _BSID; }
            set { _BSID = value; }
        }

        [Column(Storage = "_TotalBillAmount")]
        public Nullable<decimal> TotalBillAmount
        {
            get { return _TotalBillAmount; }
            set { _TotalBillAmount = value; }
        }

        [Column(Storage = "_PaidAmount")]
        public Nullable<decimal> PaidAmount
        {
            get { return _PaidAmount; }
            set { _PaidAmount = value; }
        }

        [Column(Storage = "_BillID")]
        public System.Nullable<int> BillID
        {
            get
            {
                return _BillID;
            }
            set
            {
                _BillID = value;
            }
        }

        [Column(Storage = "_PaymentID")]
        public System.Nullable<int> PaymentID
        {
            get
            {
                return _PaymentID;
            }
            set
            {
                _PaymentID = value;
            }
        }
    }
}
