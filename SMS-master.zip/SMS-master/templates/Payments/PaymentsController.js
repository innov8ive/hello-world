var app = angular.module('myApp');

app.controller('PaymentsListCtrl', function ($scope, $http, $location, GridData) {

    $scope = readyAngularGrid($scope, $http, 'api/PaymentsList', 'PaymentID', GridData, 'Payments');
    $scope.gridOptions.columnDefs = [

    { displayName: 'Amount', field: 'Amount' },
    { displayName: 'BillID', field: 'BillID' },
    { displayName: 'PaidGEGroupID', field: 'PaidGEGroupID' },
    { displayName: 'PaidRefDate', field: 'PaidRefDate', cellFilter: 'date:\'dd-MMM-yyyy\'' },
    { displayName: 'PaidRefNo', field: 'PaidRefNo' },
    { displayName: 'PaidToGLID', field: 'PaidToGLID' },
    { displayName: 'PaymentDate', field: 'PaymentDate', cellFilter: 'date:\'dd-MMM-yyyy\'' },
    { displayName: 'PaymentMode', field: 'PaymentMode' },
    { displayName: 'Remarks', field: 'Remarks' }, ];
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchPayments = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };

    $scope.editPayments = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            saveGridData($scope, GridData, 'Payments');
            $location.path('/Payments/' + selected[0].PaymentID);
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.deletePayments = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'DELETE',
                url: 'api/Payments/' + selected[0].PaymentID
            }).success(function (result) {
                if (result == true)
                    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
            });
        }
        else {
            alert('Please select a record to edit.');
        }
    };
})

.controller('PaymentsCtrl', function ($scope, $http, $location, $routeParams) {
    var PaymentID = $routeParams.PaymentID;
    var BillID = $routeParams.BillID;
    var RoomID = $routeParams.RoomID;
    var ReqID = $routeParams.ReqID;
    $scope.BillID = BillID;
    $scope.Payments = {};
    $scope.ErrorMessages = [];
    $scope.isClicked = false;
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.PaymentsSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.Update = function () {
        $scope.Payments.Approved = false;
        $scope.update();
    };
    $scope.UpdateApproved = function () {
        $scope.Payments.Approved = true;
        $scope.update();
    };
    $scope.update = function () {

        $scope.PaymentsSubmitted = true;
        if ($scope.formPayments.$invalid == true) return;

        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        var BillIDs = '';
        var BillList = [];
        for (var j = 0; j < $scope.Payments.BillPaymentsList.length; j++) {
            BillList.push($scope.Payments.BillPaymentsList[j]);
            BillIDs += ',' + $scope.Payments.BillPaymentsList[j].BillID;
        }
        if (BillList.length > 0)
            BillIDs = BillIDs.substring(1, BillIDs.length - 1);
        $scope.Payments.Amount = $scope.TotalBillAmt;
        //if (($scope.Payments.PaymentID <= 0 || $scope.Payments.PaymentID == null)
        //    && BillList.length == 0) {
        //    swal({ title: "Please select Bill(s)!", type: "error", timer: 1000, showConfirmButton: false });
        //}
        if (($scope.Payments.PaymentID <= 0 || $scope.Payments.PaymentID == null)
            && $scope.Payments.Amount != $scope.TotalBillAmt) {
            swal({ title: "The entered Amount should be equal to Total Bill Amount", type: "error", showConfirmButton: true });
            return;
        }
        for (var j = 0; j < $scope.Payments.BillPaymentsList.length; j++) {
            var theBilPayment = $scope.Payments.BillPaymentsList[j];
            var payableAmt = theBilPayment.TotalBillAmount;
            var paidAmt = theBilPayment.PaidAmount;
            var bsID = theBilPayment.BSID;
            var billID = theBilPayment.BillID;
            if (bsID == 0 && paidAmt > payableAmt) {
                swal({ title: "The entered Amount should be less or equal to Bill Amount, Bill No. - " + billID, type: "error", showConfirmButton: true });
                return;
            }
        }
        $scope.isClicked = true;
        $http({
            method: 'POST',
            url: 'api/Payments',
            data: JSON.stringify($scope.Payments)
        }).success(function (data) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.Payments = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
                if ($scope.Payments.Approved == true) {
                    if (BillID > 0)
                        $location.path('/OutstandingBills');
                    else
                        $location.path('/PaidBills');
                }
            }
        }).error(function (data, status, header, config) {
            alert('error');
        });

        //$http.post('api/Payments', $scope.Payments, config)
        //.success(function (data, status, headers, config) {
        //    var result = JSON.parse(data);
        //    if ($.isArray(result))
        //        $scope.ErrorMessages = result;
        //    else {
        //        $scope.ErrorMessages = [];
        //        $scope.Payments = result;
        //        swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
        //    }
        //})
        //.error(function (data, status, header, config) {
        //    alert('error');
        //});
    };

    $scope.cancel = function () {
        $location.path('/PaidBills');
        history.back(-1);
    }
    $scope.backToOutstanding = function () {
        //$location.path('/OutstandingBills');
        history.back(-1);
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/Payments/' + PaymentID + '/' + RoomID + '/' + ReqID
        }).success(function (Payments) {
            $scope.Payments = JSON.parse(Payments);
            $scope.bindCreditTo();
        });
    }, 100);

    $scope.credittolist = [];
    $scope.bindCreditTo = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetContraGLList', Data: null })
        }).success(function (data) {
            $scope.credittolist = data;
        });
    };

    $scope.TotalBillAmt = 0;
    $scope.$watch('Payments.BillPaymentsList', function (newVal, oldVal) {
        if (newVal !== oldVal) {
            $scope.TotalBillAmt = 0;
            for (var j = 0; j < $scope.Payments.BillPaymentsList.length; j++) {
                $scope.TotalBillAmt += parseFloatEx($scope.Payments.BillPaymentsList[j].PaidAmount);
            }
            $scope.TotalBillAmt = $scope.TotalBillAmt.toFixed(2);
        }
    }, true);
});
