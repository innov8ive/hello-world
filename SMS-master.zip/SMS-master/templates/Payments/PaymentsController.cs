using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;
using System.Text;

namespace SampleAngular.Api
{
    public class PaymentsController : ApiController
    {
        [Route("api/Payments/UploadPayment/")]
        [HttpPost]
        public string UploadPayment([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.MakePayment, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JArray objJObject = value;
            DataTable dt = objJObject.ToObject<DataTable>();
            dt.Columns.Add("RoomID", typeof(int));
            dt.Columns.Add("BillDate", typeof(DateTime));
            dt.AcceptChanges();
            StringBuilder errorMessage = new StringBuilder();
            DataTable dtValidBills = Common.GetDBResultParameterized(@"select B.BillID,
W.WingName+' '+R.RoomNo as RoomNo,B.BillDate,B.RoomID
,ISNULL(B.TotalBillAmount,0)-ISNULL(PaidAmount,0) as Outstanding,
0 as Amount,null as PaymentDate,'Cash' as PaymentMode,'' as PaymentRefNo,
'' as PaymentRefDate
 from Bills B
inner join Rooms R ON B.RoomID=R.RoomID
inner join Wings W ON W.WingID=R.WingID
where B.SocID=@SocID and PaidDate IS NULL
and B.IsNewBill=1 and B.BSID>0", "@SocID", SqlDbType.Int, objLoggedUser.SocID);
            int rowNumber = 0;
            int validRow = 0;
            foreach (DataRow dr in dt.Rows)
            {
                rowNumber++;
                if (Common.ToDecimal(dr["Amount"]) > 0)
                {
                    DataRow[] drBill = dtValidBills.Select("BillID=" + Common.ToInt(dr["BillID"]));
                    if (drBill.Count() == 0)
                    {
                        errorMessage.Append("\nInvalid Bill No. at row " + rowNumber);
                    }
                    else
                    {
                        dr["RoomID"] = Common.ToInt(drBill[0]["RoomID"]);
                        dr["BillDate"] = Common.ToDate(drBill[0]["BillDate"]);
                        if (Common.ToString(drBill[0]["RoomNo"]) != Common.ToString(dr["RoomNo"]))
                        {
                            errorMessage.Append("\nInvalid Unit No. at row " + rowNumber);
                        }
                        if (Common.ToDate(dr["PaymentDate"], null) != null &&
                            Common.ToDate(dr["PaymentDate"]) < Common.ToDate(drBill[0]["BillDate"]))
                        {
                            errorMessage.Append("\nInvalid Payment Date, it should be greater than Bill Date. at row " + rowNumber);
                        }
                    }
                    if (Common.ToDate(dr["PaymentDate"], null) == null)
                    {
                        errorMessage.Append("\nPayment Date is blank/invalid at row " + rowNumber);
                    }
                    //if (Common.ToDecimal(dr["Amount"]) > Common.ToDecimal(dr["Outstanding"]))
                    //{
                    //    errorMessage.Append("\nAmount is exeeding to Total Bill Amount at row " + rowNumber);
                    //}
                    if (Common.ToString(dr["PaymentMode"]) != "Cash")
                    {
                        if (Common.ToString(dr["PaymentRefNo"]).Length < 6)
                        {
                            errorMessage.Append("\nCheque No. is blank/invalid at row " + rowNumber);
                        }
                        if (Common.ToDate(dr["PaymentRefDate"], null) == null)
                        {
                            errorMessage.Append("\nCheque Date is blank/invalid at row " + rowNumber);
                        }
                    }
                    if (Common.ToString(dr["PaymentMode"]) == "Cash")
                    {
                        if (Common.ToString(dr["PaymentRefNo"]).Length > 0)
                        {
                            errorMessage.Append("\nCheque No. should be blank at row " + rowNumber);
                        }
                        if (Common.ToDate(dr["PaymentRefDate"], null) != null)
                        {
                            errorMessage.Append("\nCheque Date should be blank at row " + rowNumber);
                        }
                    }

                    if (dt.Columns.Contains("CreditToAccount") == false || Common.ToInt(dr["CreditToAccount"]) <= 0)
                    {
                        errorMessage.Append("\nCredit to A/C is blank/invalid at row " + rowNumber);
                    }
                }
            }


            PaymentsBL objPaymentBL = new PaymentsBL(Common.GetConString());
            if (errorMessage.Length == 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    if (Common.ToDecimal(dr["Amount"]) > 0)
                    {
                        validRow++;
                        Payments objPayments = new Payments();
                        objPayments.Amount = Common.ToDecimal(dr["Amount"]);
                        objPayments.BillID = Common.ToInt(dr["BillID"]);
                        objPayments.BillDate = Common.ToDate(dr["BillDate"]);
                        objPayments.PaymentDate = Common.ToDate(dr["PaymentDate"]);
                        objPayments.PaymentID = 0;
                        objPayments.PaymentMode = Common.ToString(dr["PaymentMode"]);
                        objPayments.RoomID = Common.ToInt(dr["RoomID"]);
                        objPayments.SocID = objLoggedUser.SocID;
                        objPayments.PaidRefNo = Common.ToString(dr["PaymentRefNo"]);
                        objPayments.PaidRefDate = Common.ToDate(dr["PaymentRefDate"]);
                        objPayments.PaidToGLID = Common.ToInt(dr["CreditToAccount"]);

                        objPayments.BillPaymentsList = new List<BillPayments>();
                        objPayments.BillPaymentsList.Add(new BillPayments()
                        {
                            BillID = Common.ToInt(dr["BillID"]),
                            PaidAmount = Common.ToDecimal(dr["Amount"])
                        });

                        objPaymentBL.Data = objPayments;
                        if (objPaymentBL.Update() == false)
                        {
                            errorMessage.Append("\nPayment Failed for Bill No. " + objPayments.BillID);
                        }
                        else
                        {
                            Common.ExecuteNonQuery(@"declare @TotalPaid decimal,@PaymentDate datetime;
Select @TotalPaid=SUM(Amount),@PaymentDate=MAX(PaymentDate) from Payments where BillID=@BillID;
Update Bills set PaidAmount=@TotalPaid,PaidDate=@PaymentDate where BillID=@BillID",
                        "@BillID", SqlDbType.Int, Common.ToInt(objPayments.BillID));
                            GECommon.GEEntryPayment(objPayments, objLoggedUser.SocID);

                            decimal totalDue = Common.ToDecimal(Common.GetDBScalar(@"Select ISNULL(SUM(Amount),0)+ISNULL(SUM(LF),0)-ISNULL(SUM(PaidAmount),0)
from Bills where RoomID=" + objPayments.RoomID));

                            Common.SendPaymentNotification(Common.ToDecimal(objPayments.Amount),
                       Common.ToDate(objPayments.PaymentDate).ToString("dd-MMM-yyyy"),
                       Common.ToInt(objPayments.BillID),
                       Common.ToDate(objPayments.BillDate).ToString("dd-MMM-yyyy"),
                       totalDue, objLoggedUser.SocName, Common.ToInt(objPayments.RoomID));
                        }
                    }
                }
            }
            if (validRow == 0)
            {
                errorMessage.Append("\n ");
            }
            return JsonConvert.SerializeObject(errorMessage.ToString().Split('\n'), Formatting.Indented);
        }
        // GET api/Payments
        [Route("api/PaymentsList/")]
        [HttpPost]
        public AngularGridData GetPayments([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.MakePayment, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = "Select * from Payments";
            objAngularDataBinder.ValueField = "PaymentID";
            return objAngularDataBinder.GetData();
        }

        // GET api/Payments/Id
        [Route("api/Payments/{Id}/{RoomID}/{ReqID}")]
        public string GetPayments(int Id, int RoomID, int ReqID)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            //Common.IsValidForm(Constants.Forms.User, Request);

            PaymentsBL objPaymentsBL = new PaymentsBL(Common.GetConString());
            objPaymentsBL.Load(Id);

            Payments objPayments = objPaymentsBL.Data;
            if (Common.ToInt(objPayments.SocID) > 0 && objPayments.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            if (String.IsNullOrEmpty(objPayments.UnitNo))
            {
                objPayments.RoomID = RoomID;
                objPayments.UnitNo = Common.ToString(Common.GetDBScalar(@"select W.WingName+'-'+R.RoomNo as UnitNo from Rooms R left join Wings W ON R.WingID=W.WingID
where R.RoomID=@RoomID and R.SocID=@SocID", "@RoomID", SqlDbType.Int, RoomID,
                                          "@SocID", SqlDbType.Int, objLoggedUser.SocID));
            }
            if (Id <= 0 && ReqID > 0)
            {
                PaymentReqBL objPaymentReqBL = new PaymentReqBL(Common.GetConString());
                objPaymentReqBL.Load(ReqID);
                PaymentReq objPaymentReq = objPaymentReqBL.Data;

                objPayments.Amount = objPaymentReq.Amount;
                objPayments.BillIDs = objPaymentReq.BillIDs;
                objPayments.BillPaymentsList = new List<BillPayments>();
                foreach (var obj in objPaymentReq.BillPaymentReqList)
                {
                    objPayments.BillPaymentsList.Add(new BillPayments()
                    {
                        BillID = obj.BillID,
                        TotalBillAmount = obj.TotalBillAmount,
                        PaidAmount = obj.PaidAmount,
                        BSID = obj.BSID
                    });
                }
                objPayments.PaidRefDate = objPaymentReq.PaidRefDate;
                objPayments.PaidRefNo = objPaymentReq.PaidRefNo;
                objPayments.PaidToGLID = objPaymentReq.PaidToGLID;
                objPayments.PaymentDate = objPaymentReq.ReqDate;
                objPayments.PaymentMode = objPaymentReq.PaymentMode;
                objPayments.Remarks = objPaymentReq.Remarks;
                objPayments.RoomID = objPaymentReq.RoomID;
                objPayments.SocID = objPaymentReq.SocID;
                objPayments.ReqID = objPaymentReq.ReqID;
            }
            else if (Id <= 0 && ReqID <= 0 && RoomID > 0)
            {
                DataTable dt = Common.GetDBResultParameterized(@"select ISNULL(B.TotalBillAmount,0)-ISNULL(PAY.BPAmount,0) as TotalBillAmount,B.BillID,B.BSID 
from Bills B
outer apply
(
select SUM(BPAmount) as BPAmount
from BillPayments BP
where BP.BillID=B.BillID
) as PAY
where ISNULL(B.TotalBillAmount,0)-ISNULL(PAY.BPAmount,0)>0 and B.IsNewBill=1
and not exists (select 1 from BillPaymentReq BPR where B.BillID=BPR.BillID) and B.RoomID=@RoomID
and B.SocID=@SocID", "@RoomID", SqlDbType.Int, RoomID,
                "@SocID", SqlDbType.Int, objLoggedUser.SocID);
                objPayments.BillPaymentsList = new List<BillPayments>();
                foreach (DataRow dr in dt.Rows)
                {
                    objPayments.BillPaymentsList.Add(new BillPayments()
                    {
                        BillID = Common.ToInt(dr["BillID"]),
                        TotalBillAmount = Common.ToDecimal(dr["TotalBillAmount"]),
                        PaidAmount = Common.ToDecimal(dr["TotalBillAmount"]),
                        BSID = Common.ToInt(dr["BSID"])
                    });
                }
            }

            return JsonConvert.SerializeObject(objPaymentsBL.Data);
        }

        // POST api/Payments/
        public string Post([FromBody]dynamic value)
        {

            //Common.IsValidForm(Constants.Forms.User, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            Payments objPayments = objJObject.ToObject<Payments>();
            PaymentsValidator validator = new PaymentsValidator();
            ValidationResult results = validator.Validate(objPayments);

            PaymentsBL objPaymentsBL = new PaymentsBL(Common.GetConString());
            objPaymentsBL.Data = objPayments;
            if (objPaymentsBL.IsNew)
            {
                objPayments.SocID = objLoggedUser.SocID;
            }
            if (Common.ToInt(objPayments.SocID) > 0 && objPayments.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            try
            {
                if (objPayments.PaymentMode != "Cash" && String.IsNullOrEmpty(objPayments.PaidRefNo))
                {
                    results.Errors.Add(new ValidationFailure("PaidRefNo", "Please enter " + objPayments.PaymentMode + " No."));
                }
                if (objPayments.PaymentMode != "Cash" && objPayments.PaidRefDate == null)
                {
                    results.Errors.Add(new ValidationFailure("PaidRefDate", "Please enter " + objPayments.PaymentMode + " Date."));
                }
                //if (objPayments.Amount > objPayments.objBills.TotalBillAmount)
                //{
                //    results.Errors.Add(new ValidationFailure("Amount", "Amount is exeeding to Total Bill Amount"));
                //}
                //if (objPayments.PaymentDate < objPayments.objBills.BillDate)
                //{
                //    results.Errors.Add(new ValidationFailure("PaymentDate", "Invalid Payment Date, it should be greater than Bill Date."));
                //}
                if (results.IsValid)
                {
                    if (Common.ToBool(objPayments.Approved) == true)
                    {
                        //remove those bills which has 0 amount
                        objPaymentsBL.Data.BillPaymentsList.RemoveAll(Obj => Common.ToDecimal(Obj.PaidAmount) <= 0);
                        if (objPaymentsBL.Update())
                        {
                            Common.UpdatePostPayment(objLoggedUser.SocID, objLoggedUser.SocName, objPayments);
                        }
                    }
                    else
                    {
                        SaveInPaymentReq(objPayments);
                    }
                    return JsonConvert.SerializeObject(objPaymentsBL.Data);
                }
            }
            catch (Exception ex)
            {
                results.Errors.Add(new ValidationFailure("Amount", ex.Message + "," + ex.StackTrace));
            }
            return JsonConvert.SerializeObject(results.Errors);
        }

        private void SaveInPaymentReq(Payments objPayments)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            PaymentReqBL objPaymentReqBL = new PaymentReqBL(Common.GetConString());
            objPaymentReqBL.Load(Common.ToInt(objPayments.ReqID));

            PaymentReq objPaymentReq = objPaymentReqBL.Data;
            objPaymentReq.Amount = objPayments.Amount;
            objPaymentReq.BillID = objPayments.BillID;
            objPaymentReq.PaidRefDate = objPayments.PaidRefDate;
            objPaymentReq.PaidRefNo = objPayments.PaidRefNo;
            objPaymentReq.PaidToGLID = objPayments.PaidToGLID;
            objPaymentReq.PaymentMode = objPayments.PaymentMode;
            objPaymentReq.Remarks = objPayments.Remarks;
            objPaymentReq.ReqBy = objLoggedUser.UserID;
            objPaymentReq.ReqDate = objPayments.PaymentDate;
            objPaymentReq.RoomID = objPayments.RoomID;
            objPaymentReq.SocID = objPayments.SocID;

            objPaymentReq.BillPaymentReqList = new List<BillPaymentReq>();
            foreach (var obj in objPayments.BillPaymentsList)
            {
                if (obj.PaidAmount > 0)
                {
                    objPaymentReq.BillPaymentReqList.Add(new BillPaymentReq()
                    {
                        BillID = obj.BillID,
                        PaidAmount = obj.PaidAmount
                    });
                }
            }

            objPaymentReqBL.Update();
            Common.ExecuteNonQuery("Update PaymentReq set Status=NULL where ReqID=@ReqID",
                   "@ReqID", SqlDbType.Int, Common.ToInt(objPaymentReq.ReqID));
            objPayments.ReqID = objPaymentReqBL.Data.ReqID;

            foreach (var obj in objPaymentReq.BillPaymentReqList)
            {
                Common.ExecuteNonQuery("Update Bills set PaymentReqDate=@PaymentReqDate where BillID=@BillID",
                    "@PaymentReqDate", SqlDbType.DateTime, objPaymentReq.ReqDate,
                    "@BillID", SqlDbType.Int, Common.ToInt(obj.BillID));
            }
        }



        // DELETE api/Payments/5
        [Route("api/Payments/{Id}")]
        [HttpDelete]
        public bool Delete(int Id)
        {
            Common.IsValidForm(Constants.Forms.MakePayment, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            PaymentsBL objPaymentsBL = new PaymentsBL(Common.GetConString());
            Payments objPayments = objPaymentsBL.Data;
            if (Common.ToInt(objPayments.SocID) > 0 && objPayments.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            return objPaymentsBL.Delete(Id);
        }
    }
    public class PaymentsValidator : AbstractValidator<Payments>
    {
        public PaymentsValidator()
        {

            RuleFor(obj => obj.Amount).NotEmpty();
            RuleFor(obj => obj.PaidToGLID).NotEmpty();
            RuleFor(obj => obj.PaymentDate).NotEmpty();
            RuleFor(obj => obj.PaymentMode).NotEmpty();
        }
    }
}

