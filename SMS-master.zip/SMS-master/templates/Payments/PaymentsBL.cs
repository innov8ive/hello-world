using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
    [Serializable]
    public class PaymentsBL
    {

        #region Declaration
        private string connectionString;
        Payments _Payments;
        public Payments Data
        {
            get { return _Payments; }
            set { _Payments = value; }
        }
        public bool IsNew
        {
            get { return (_Payments.PaymentID <= 0 || _Payments.PaymentID == null); }
        }
        #endregion

        #region Constructor
        public PaymentsBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private PaymentsDL CreateDL()
        {
            return new PaymentsDL(connectionString);
        }
        public void New()
        {
            _Payments = new Payments();
        }
        public void Load(int PaymentID)
        {
            var PaymentsObj = this.CreateDL();
            _Payments = PaymentID <= 0 ? PaymentsObj.Load(-1) : PaymentsObj.Load(PaymentID);
        }
        public DataTable LoadAllPayments()
        {
            var PaymentsDLObj = CreateDL();
            return PaymentsDLObj.LoadAllPayments();
        }
        public bool Update()
        {
            var PaymentsDLObj = CreateDL();
            return PaymentsDLObj.Update(this.Data);
        }
        public bool Delete(int PaymentID)
        {
            var PaymentsDLObj = CreateDL();
            return PaymentsDLObj.Delete(PaymentID);
        }
        #endregion
    }
}
