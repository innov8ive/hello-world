using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
    [Serializable]
    public class SocBL
    {

        #region Declaration
        private string connectionString;
        Soc _Soc;
        public Soc Data
        {
            get { return _Soc; }
            set { _Soc = value; }
        }
        public bool IsNew
        {
            get { return (_Soc.SocID <= 0 || _Soc.SocID == null); }
        }
        #endregion

        #region Constructor
        public SocBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private SocDL CreateDL()
        {
            return new SocDL(connectionString);
        }
        public void New()
        {
            _Soc = new Soc();
        }
        public void Load(int SocID)
        {
            var SocObj = this.CreateDL();
            _Soc = SocID <= 0 ? SocObj.Load(-1) : SocObj.Load(SocID);
        }
        public DataTable LoadAllSoc()
        {
            var SocDLObj = CreateDL();
            return SocDLObj.LoadAllSoc();
        }
        public bool Update()
        {
            var SocDLObj = CreateDL();
            return SocDLObj.Update(this.Data);
        }
        public bool Delete(int SocID)
        {
            var SocDLObj = CreateDL();
            return SocDLObj.Delete(SocID);
        }
        public bool CreateDefaultGL(int SocID, List<GL> objDefaultGLList)
        {
            var SocDLObj = CreateDL();
            return SocDLObj.CreateDefaultGL(SocID, objDefaultGLList);
        }
        #endregion
    }
}
