using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

    [Serializable]
    [Table(Name = "dbo.Soc")]
    public class Soc
    {

        private string _City;
        private string _ContactNo;
        private string _SocAddress1;
        private string _SocAddress2;
        private System.Nullable<int> _SocID;
        private string _SocName;
        private System.Nullable<int> _StateID;
        private System.Nullable<int> _UserID;
        private string _ZipCode;
        private string _RegNo;
        private string _SocEmail;
        private Nullable<int> _RecGap;
        private string _BankAccountNo;
        private string _BankIFSC;
        private string _BankName;
        private string _BankBranch;
        private string _BankAccountName;
        private string _ImageUrl;

        [Column(Storage = "_ImageUrl")]
        public string ImageUrl
        {
            get { return _ImageUrl; }
            set { _ImageUrl = value; }
        }

        [Column(Storage = "_BankAccountName")]
        public string BankAccountName
        {
            get { return _BankAccountName; }
            set { _BankAccountName = value; }
        }

        [Column(Storage = "_BankBranch")]
        public string BankBranch
        {
            get { return _BankBranch; }
            set { _BankBranch = value; }
        }

        [Column(Storage = "_BankName")]
        public string BankName
        {
            get { return _BankName; }
            set { _BankName = value; }
        }

        [Column(Storage = "_BankIFSC")]
        public string BankIFSC
        {
            get { return _BankIFSC; }
            set { _BankIFSC = value; }
        }

        [Column(Storage = "_BankAccountNo")]
        public string BankAccountNo
        {
            get { return _BankAccountNo; }
            set { _BankAccountNo = value; }
        }

        [Column(Storage = "_RecGap")]
        public Nullable<int> RecGap
        {
            get { return _RecGap; }
            set { _RecGap = value; }
        }

        [Column(Storage = "_SocEmail")]
        public string SocEmail
        {
            get { return _SocEmail; }
            set { _SocEmail = value; }
        }

        [Column(Storage = "_RegNo")]
        public string RegNo
        {
            get { return _RegNo; }
            set { _RegNo = value; }
        }


        [Column(Storage = "_City")]
        public string City
        {
            get
            {
                return _City;
            }
            set
            {
                _City = value;
            }
        }



        [Column(Storage = "_ContactNo")]
        public string ContactNo
        {
            get
            {
                return _ContactNo;
            }
            set
            {
                _ContactNo = value;
            }
        }



        [Column(Storage = "_SocAddress1")]
        public string SocAddress1
        {
            get
            {
                return _SocAddress1;
            }
            set
            {
                _SocAddress1 = value;
            }
        }



        [Column(Storage = "_SocAddress2")]
        public string SocAddress2
        {
            get
            {
                return _SocAddress2;
            }
            set
            {
                _SocAddress2 = value;
            }
        }



        [Column(Storage = "_SocID")]
        public System.Nullable<int> SocID
        {
            get
            {
                return _SocID;
            }
            set
            {
                _SocID = value;
            }
        }



        [Column(Storage = "_SocName")]
        public string SocName
        {
            get
            {
                return _SocName;
            }
            set
            {
                _SocName = value;
            }
        }



        [Column(Storage = "_StateID")]
        public System.Nullable<int> StateID
        {
            get
            {
                return _StateID;
            }
            set
            {
                _StateID = value;
            }
        }



        [Column(Storage = "_UserID")]
        public System.Nullable<int> UserID
        {
            get
            {
                return _UserID;
            }
            set
            {
                _UserID = value;
            }
        }



        [Column(Storage = "_ZipCode")]
        public string ZipCode
        {
            get
            {
                return _ZipCode;
            }
            set
            {
                _ZipCode = value;
            }
        }

    }

    
}
