using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;
using System.Threading;
using System.IO;

namespace SampleAngular.Api
{
    public class SocController : ApiController
    {
        // GET api/Soc
        [Route("api/SocList/")]
        [HttpPost]
        public AngularGridData GetSoc([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser == null) throw new HttpResponseException(HttpStatusCode.Unauthorized);

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = @"Select S.*,ST.StateName,U.FirstName+ISNULL(' '+U.LastName,'') as AdminName,U.EmailID,U.MobileNo from Soc S 
left join Users U ON  S.UserID=U.UserID
inner join State ST ON S.StateID=ST.StateID where (@SocID=1 OR S.UserID=@UserID)";
            Hashtable ht = new Hashtable();
            ht["@UserID"] = objLoggedUser.UserID;
            ht["@SocID"] = objLoggedUser.SocID;
            objAngularDataBinder.Parameters = ht;
            objAngularDataBinder.ValueField = "S.SocID";
            return objAngularDataBinder.GetData();
        }

        // GET api/Soc/Id
        [Route("api/Soc/{Id}")]
        public string GetSoc(int Id)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (Id == 0 || (objLoggedUser != null && objLoggedUser.SocID > 1))
            {
                Id = objLoggedUser.SocID;
            }
            SocBL objSocBL = new SocBL(Common.GetConString());
            objSocBL.Load(Id);

            return JsonConvert.SerializeObject(objSocBL.Data);
        }

        // POST api/Soc/
        public string Post([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser == null) throw new HttpResponseException(HttpStatusCode.Unauthorized);

            JObject objJObject = value;
            Soc objSoc = objJObject.ToObject<Soc>();

            if (Common.ToInt(objSoc.SocID) > 0)
            {
                if (objLoggedUser.UserID != objSoc.UserID) throw new HttpResponseException(HttpStatusCode.Unauthorized);
            }
            objSoc.UserID = objLoggedUser.UserID;
            SocBL objSocBL = new SocBL(Common.GetConString());
            objSocBL.Data = objSoc;

            SocValidator validator = new SocValidator();
            ValidationResult results = validator.Validate(objSoc);

            if (results.IsValid)
            {
                objSocBL.Update();
                return JsonConvert.SerializeObject(objSocBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        [Route("api/SocRegister/")]
        [HttpPost]
        public string SocRegister([FromBody]dynamic value)
        {
            JObject objJObjectUser = value.User;
            Users objUsers = objJObjectUser.ToObject<Users>();

            JObject objJObjectSoc = value.Soc;
            Soc objSoc = objJObjectSoc.ToObject<Soc>();
            string verifyCode = Guid.NewGuid().ToString();
            UsersBL objUsersBL = new UsersBL(Common.GetConString());
            objUsersBL.Data = objUsers;
            objUsers.UserName = objUsers.EmailID;
            objUsers.UserType = 2;//Admin
            objUsers.IsActive = true;
            objUsers.Verified = false;
            objUsers.Code = verifyCode;
            UsersValidator validator = new UsersValidator();
            ValidationResult results = validator.Validate(objUsers);
            if (Common.ToString(objUsers.MobileNo).Length > 0)
            {
                DataTable dt = Common.GetDBResultParameterized(@"Select 1 from Users where MobileNo=@MobileNo"
                    , "@MobileNo", SqlDbType.VarChar, Common.ToString(objUsers.MobileNo));
                if (dt.Rows.Count > 0)
                {
                    ValidationFailure emailError = new ValidationFailure("MobileNo", "Mobile is already registered, please choose another Mobile");
                    results.Errors.Add(emailError);
                }
            }
            else
            {
                ValidationFailure emailError = new ValidationFailure("MobileNo", "Please enter Mobile No.");
                results.Errors.Add(emailError);
            }
            if (Common.ToString(objUsers.EmailID).Length > 0)
            {
                DataTable dt = Common.GetDBResultParameterized(@"Select 1 from Users where EmailID=@EmailID"
                    , "@EmailID", SqlDbType.VarChar, Common.ToString(objUsers.EmailID));
                if (dt.Rows.Count > 0)
                {
                    ValidationFailure emailError = new ValidationFailure("EmailID", "EmailID already registered, please choose another EmailID");
                    results.Errors.Add(emailError);
                }
            }
            else
            {
                ValidationFailure emailError = new ValidationFailure("EmailID", "Please enter EmailID");
                results.Errors.Add(emailError);
            }
            if (objUsers.MobileNo.Length != 10)
            {
                results.Errors.Add(new ValidationFailure("MobileNo", "Mobile No. should be 10 digit only"));
            }
            if (Common.ToInt(objSoc.ZipCode) < 100000)
            {
                results.Errors.Add(new ValidationFailure("ZipCode", "Invalid Zipcode"));
            }
            if (Common.ToString(objSoc.ContactNo).Length > 0 && Common.ToInt(objSoc.ContactNo) < 10000000)
            {
                results.Errors.Add(new ValidationFailure("ContactNo", "Invalid Contact No."));
            }
            if (Common.ToInt(objUsers.MobileNo.Substring(0, 1)) < 6)
            {
                results.Errors.Add(new ValidationFailure("MobileNo", "Invalid Mobile No."));
            }
            if (results.IsValid && results.Errors.Count <= 0)
            {
                string password = Guid.NewGuid().ToString().Substring(0, 6);
                objUsers.Password = password;
                if (objUsersBL.Update() == true)
                {
                    objSoc.UserID = objUsers.UserID;
                    SocBL objSocBL = new SocBL(Common.GetConString());
                    objSocBL.Data = objSoc;

                    SocValidator socvalidator = new SocValidator();
                    results = socvalidator.Validate(objSoc);

                    if (results.IsValid)
                    {
                        GLBL objGLBL = new GLBL(Common.GetConString());
                        if (objSocBL.Update())
                        {
                            Common.CreateSchedule(Common.ToInt(objSoc.SocID));
                            Common.CreateAccounts(Common.ToInt(objSoc.SocID));
                            Common.CreateVType(Common.ToInt(objSoc.SocID));
                            new Thread(() =>
                            {
                                Thread.CurrentThread.IsBackground = true;
                                Common.SendSMS(Common.ToString(objUsers.MobileNo), "Your admin account created on SocietyInn.com. Password is " + password, 0);

                                Common.SendEmailSendGrid(objUsers.EmailID, @"Dear Member,<br/>Thank you for showing your interest. 
Please activate your account by clicking <a href='" + Constants.Values.WebsiteHost + "verifyaccount/" + verifyCode + "'>here</a>.<br/>Regards,<br/>SocietyInn Team", "Welcome to SocietyInn.com");
                            }).Start();


                            //objSocBL.CreateDefaultGL(Common.ToInt(objSoc.SocID), objGLBL.LoadDefaultGLs());
                        }
                    }
                }
                return JsonConvert.SerializeObject(objSoc);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        // DELETE api/Soc/5
        [Route("api/Soc/{Id}")]
        [HttpDelete]
        public bool Delete(int Id)
        {
            SocBL objSocBL = new SocBL(Common.GetConString());
            objSocBL.Load(Id);
            if (Common.ToInt(objSocBL.Data.SocID) > 0)
            {
                LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
                if (objLoggedUser == null) throw new HttpResponseException(HttpStatusCode.Unauthorized);
                if (objLoggedUser.UserID != objSocBL.Data.UserID) throw new HttpResponseException(HttpStatusCode.Unauthorized);
            }
            return objSocBL.Delete(Id);
        }

        [Route("api/Soc/VerifyAccount/")]
        [HttpPost]
        public string VerifyAccount([FromBody]dynamic param)
        {
            int count = Common.ExecuteNonQuery("Update Users set Verified=1 where Code=@Code",
                "@Code", SqlDbType.VarChar, Common.ToString(param));
            if (count > 0)
            {
                string emailID = Common.GetDBScalar("Select EmailID from Users where Code=@Code",
                    "@Code", SqlDbType.VarChar, Common.ToString(param));
                Common.SendEmailSendGrid(emailID, @"Dear Member,<br/>Your account has been verified.<br/>Regards,<br/>SocietyInn Team", "Account Verified - SocietyInn.com");
            }
            return JsonConvert.SerializeObject(count);
        }

        [Route("api/Soc/RemovePhoto/")]
        [HttpPost]
        public string SocRemovePhoto([FromBody]dynamic param)
        {
            int userID = 0;
            string imageUrl;
            string data = param;
            if (data.Contains("."))
            {
                userID = Common.ToInt(data.Substring(0, data.IndexOf(".")));
                imageUrl = data.Substring(data.IndexOf(".") + 1);
                int count = Common.ExecuteNonQuery("Update Soc Set ImageUrl='' where SocID=@SocID", "@SocID", SqlDbType.Int, Common.ToInt(userID));
                if (count > 0)
                {
                    try
                    {
                        string filePath = HttpContext.Current.Server.MapPath("~/images/profile") + "/" + imageUrl;
                        File.Delete(filePath);
                    }
                    catch { }
                    return "true";
                }
                else
                {
                    return "false";
                }
            }
            return "false";
        }
        [Route("api/Soc/AttachPhoto/")]
        [HttpPost]
        public string SocAttachPhoto([FromBody]dynamic param)
        {
            int userID = 0;
            string imageUrl;
            string data = param;
            if (data.Contains("."))
            {
                userID = Common.ToInt(data.Substring(0, data.IndexOf(".")));
                imageUrl = data.Substring(data.IndexOf(".") + 1);

                int count = Common.ExecuteNonQuery("Update Soc Set ImageUrl=@ImageUrl where SocID=@SocID"
                    , "@SocID", SqlDbType.Int, userID
                    , "@ImageUrl", SqlDbType.VarChar, imageUrl);
                if (count > 0)
                {
                    return imageUrl;
                }
                else
                {
                    return String.Empty;
                }
            }
            return String.Empty;
        }
    }
    public class SocValidator : AbstractValidator<Soc>
    {
        public SocValidator()
        {

            RuleFor(obj => obj.City).NotEmpty();
            RuleFor(obj => obj.SocAddress1).NotEmpty();
            RuleFor(obj => obj.SocAddress2).NotEmpty();
            RuleFor(obj => obj.SocName).NotEmpty();
            RuleFor(obj => obj.StateID).NotEmpty();
            RuleFor(obj => obj.UserID).NotEmpty();
            RuleFor(obj => obj.ZipCode).NotEmpty();
        }
    }
}

