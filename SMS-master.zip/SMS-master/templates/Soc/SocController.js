var app = angular.module('myApp');

app.controller('SocListCtrl', function ($scope, $http, $location, GridData) {

    $scope = readyAngularGrid($scope, $http, 'api/SocList', 'SocID', GridData, 'Soc');
    $scope.gridOptions.columnDefs = [
    { displayName: 'Society Name', field: 'SocName' },
    { displayName: 'Address1', field: 'SocAddress1' },
    { displayName: 'Address2', field: 'SocAddress2' },
    { displayName: 'City', field: 'City' },
    { displayName: 'Admin Name', field: 'AdminName' },
    { displayName: 'EmailID', field: 'EmailID',width:300 },
    { displayName: 'Mobile No.', field: 'MobileNo',width:100 }];
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchSoc = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };
    $scope.newSoc = function () {
        saveGridData($scope, GridData, 'Soc');
        $location.path('/Soc/0');
    };
    $scope.editSoc = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            saveGridData($scope, GridData, 'Soc');
            $location.path('/Soc/' + selected[0].SocID);
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.deleteSoc = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'DELETE',
                url: 'api/Soc/' + selected[0].SocID
            }).success(function (result) {
                if (result == true)
                    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
            });
        }
        else {
            alert('Please select a record to edit.');
        }
    };
})

.controller('SocCtrl', function ($scope, $http, $location, $routeParams, User) {
    
    $scope.IsSysAdmin = User.UserID == 1 ? true : false;
    var SocID = $routeParams.SocID;

    $scope.Soc = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.SocSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.SocSubmitted = true;
        if ($scope.formSoc.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/Soc', $scope.Soc, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.Soc = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/SocList');
    }

    $scope.statelist = [];
    $scope.bindState = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetStateList', Data: null })
        }).success(function (data) {
            $scope.statelist = data;
            $scope.bindCity();
        });
    }
    $scope.bindState();
    $scope.$watch('Soc.StateID', function (newVal, oldVal) {
        if (newVal !== oldVal) {
            $scope.bindCity(true);
        }
    }, true);
   

    $scope.citylist = [];
    $scope.bindCity = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetCityList', Data: null, query: $scope.Soc.StateID })
        }).success(function (data) {
            $scope.citylist = data;
            if (clear == true) $scope.Soc.City = null;
        });
    };
    $scope.getText = function (model, array) {
        for (var j = 0; j < array.length; j++) {
            if (model == array[j].Key) {
                return array[j].Value;
            }
        }
        return '';
    };

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/Soc/' + SocID
        }).success(function (Soc) {
            $scope.Soc = JSON.parse(Soc);
            if ($scope.Soc.SocID == null || $scope.Soc.SocID <= 0)
                $location.path('/login');
        });
    }, 100);

    $scope.removePhoto = function () {
        if (confirm('Are you sure, want to remove photo?')) {
            $http({
                method: 'POST',
                url: 'api/Soc/RemovePhoto/',
                data: JSON.stringify($scope.Soc.SocID + '.' + $scope.Soc.ImageUrl)
            }).success(function (result) {
                if (result == 'true')
                    $scope.Soc.ImageUrl = '';
            });
        }
    };
    $scope.uploadPhoto = function () {
        AttachImage($scope.photoUploaded);
    };
    $scope.photoUploaded = function (fileGUIDName, fileName, fileID) {
        $scope.Soc.ImageUrl = fileGUIDName;
        $http({
            method: 'POST',
            url: 'api/Soc/AttachPhoto/',
            data: JSON.stringify($scope.Soc.SocID + '.' + $scope.Soc.ImageUrl)
        }).success(function (result) {

        });
    };
})

.controller('SocRegisterCtrl', function ($scope, $http, $location) {
    $scope.Soc = {};
    $scope.Users = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.SocSubmitted = false;
    $scope.UsersSubmitted = false;
    $scope.UsernameAvailable = null;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.SocSubmitted = $scope.UsersSubmitted = true;
        if ($scope.formSoc.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        if ($scope.UsernameAvailable == 'false' || $scope.UsernameAvailable == null) return;
        //if ($scope.Users.Password != $scope.Users.ConfirmPassword) {
        //    alert('Password and Confirm Password should be same');
        //    return;
        //}

        $http.post('api/SocRegister', { Soc: $scope.Soc, User: $scope.Users }, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.Soc = result;
                alert("Society Details saved successfully. Password has been sent to your Mobile. A Verification has sent to your email id. Please Verify your account!");
                $location.path('/login');
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };
    $scope.userAvailable = function () {
        if ($scope.formSoc.emailidTextBox.$invalid == true) return;
        $http({
            method: 'POST',
            url: 'api/Users/Available/',
            data: JSON.stringify($scope.Users.EmailID)
        }).success(function (result) {
            $scope.UsernameAvailable = result;
        });
    };
    $scope.cancel = function () {
        $location.path('/login');
    }

    $scope.statelist = [];
    $scope.bindState = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetStateList', Data: null })
        }).success(function (data) {
            $scope.statelist = data;
            $scope.bindCity();
        });
    }
    $scope.bindState();
    $scope.onStateSelected = function ($item, $select) {
        $scope.bindCity(true);
    }
    //GetCityList
    $scope.citylist = [];
    $scope.bindCity = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetCityList', Data: null, query: $scope.Soc.StateID })
        }).success(function (data) {
            $scope.citylist = data;
            if (clear == true) $scope.Soc.City = null;
        });
    };
    $scope.getText = function (model, array) {
        for (var j = 0; j < array.length; j++) {
            if (model == array[j].Key) {
                return array[j].Value;
            }
        }
        return '';
    };


    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/Soc/0'
        }).success(function (Soc) {
            $scope.Soc = JSON.parse(Soc);
        });
        $http({
            method: 'GET',
            url: 'api/Users/0'
        }).success(function (Users) {
            $scope.Users = JSON.parse(Users);
        });
    }, 100);
});
app.controller('VerifyAccountController', function ($scope, $http, $location, $routeParams) {
    var code = $routeParams.code;
    $scope.Verified = false;
    $scope.VerifyAccount = function () {
        $http({
            method: 'POST',
            url: 'api/Soc/VerifyAccount/',
            data: JSON.stringify(code)
        }).success(function (result) {
            $scope.Verified = parseInt(result);
        });
    };

    setTimeout(function () { $scope.VerifyAccount(); }, 100);
});