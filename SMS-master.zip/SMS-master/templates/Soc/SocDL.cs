using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
    public class SocDL
    {
        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public SocDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public Soc Load(int SocID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            Soc objSoc = new Soc();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get Soc
                var resultSoc = dc.ExecuteQuery<Soc>("exec Get_Soc {0}", SocID).ToList();
                if (resultSoc.Count > 0)
                {
                    objSoc = resultSoc[0];
                }
                dc.Dispose();
                return objSoc;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllSoc()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_Soc", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(Soc objSoc)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update Soc
                UpdateSoc(objSoc, trn);
                if (objSoc.SocID > 0)
                {

                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int SocID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete Soc
                DeleteSoc(SocID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateSoc(Soc objSoc, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_Soc", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@City", SqlDbType.VarChar, 100).Value = objSoc.City;
                cmd.Parameters.Add("@ContactNo", SqlDbType.VarChar, 50).Value = objSoc.ContactNo;
                cmd.Parameters.Add("@SocAddress1", SqlDbType.VarChar, 250).Value = objSoc.SocAddress1;
                cmd.Parameters.Add("@SocAddress2", SqlDbType.VarChar, 250).Value = objSoc.SocAddress2;
                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = objSoc.SocID;
                cmd.Parameters["@SocID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@SocName", SqlDbType.VarChar, 500).Value = objSoc.SocName;
                cmd.Parameters.Add("@StateID", SqlDbType.Int).Value = objSoc.StateID;
                cmd.Parameters.Add("@UserID", SqlDbType.Int).Value = objSoc.UserID;
                cmd.Parameters.Add("@ZipCode", SqlDbType.VarChar, 6).Value = objSoc.ZipCode;
                cmd.Parameters.Add("@RegNo", SqlDbType.VarChar, 250).Value = objSoc.RegNo;
                cmd.Parameters.Add("@SocEmail", SqlDbType.VarChar, 200).Value = objSoc.SocEmail;
                cmd.Parameters.Add("@RecGap", SqlDbType.Int).Value = objSoc.RecGap;
                cmd.Parameters.Add("@BankAccountNo", SqlDbType.VarChar, 20).Value = objSoc.BankAccountNo;
                cmd.Parameters.Add("@BankIFSC", SqlDbType.VarChar, 15).Value = objSoc.BankIFSC;
                cmd.Parameters.Add("@BankName", SqlDbType.VarChar, 100).Value = objSoc.BankName;
                cmd.Parameters.Add("@BankBranch", SqlDbType.VarChar, 100).Value = objSoc.BankBranch;
                cmd.Parameters.Add("@BankAccountName", SqlDbType.VarChar, 200).Value = objSoc.BankAccountName;

                cmd.ExecuteNonQuery();

                //after updating the Soc, update SocID
                objSoc.SocID = Convert.ToInt32(cmd.Parameters["@SocID"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteSoc(int SocID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from Soc where SocID=@SocID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = SocID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        public bool CreateDefaultGL(int SocID, List<GL> objDefaultGLList)
        {
            GLDL objGLDL = new GLDL(connectionString);
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                foreach (GL objDefaultGL in objDefaultGLList)
                {
                    GL objGL = new GL();
                    objGL.CompanyID = SocID;
                    objGL.GLID = 0;
                    objGL.GLName = objDefaultGL.GLName;
                    objGL.GLNo = objDefaultGL.GLNo;
                    objGL.GroupID = objDefaultGL.GroupID;
                    objGL.GroupName = objDefaultGL.GroupName;
                    objGL.IsSysDefined = objDefaultGL.IsSysDefined;
                    objGL.OnCredit = 0;
                    objGL.OnDebit = 0;
                    objGL.OrgID = null;
                    objGL.SrNo = objDefaultGL.SrNo;
                    objGLDL.UpdateGL(objGL, trn);

                }
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        #endregion
    }
}
