using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
[Serializable]
public class FCBL
{

#region Declaration
private string connectionString;
FC _FC;
public FC Data
{
get { return _FC; }
set { _FC = value; }
}
public bool IsNew
{
get { return (_FC.FCID <= 0 || _FC.FCID ==null); }
}
#endregion

#region Constructor
public FCBL(string conString)
{
connectionString = conString;
}
#endregion

#region Main Methods
private FCDL CreateDL()
{
return new FCDL(connectionString);
}
public void New()
{
_FC = new FC();
}
public void Load(int FCID)
{
var FCObj = this.CreateDL();
_FC = FCID <= 0 ? FCObj.Load(-1) : FCObj.Load(FCID);
}
public DataTable LoadAllFC()
{
var FCDLObj = CreateDL();
return FCDLObj.LoadAllFC();
}
public bool Update()
{
var FCDLObj = CreateDL();
return FCDLObj.Update(this.Data);
}
public bool Delete(int FCID)
{
var FCDLObj = CreateDL();
return FCDLObj.Delete(FCID);
}
#endregion
}
}
