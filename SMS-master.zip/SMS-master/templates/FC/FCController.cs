using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;

namespace SampleAngular.Api
{
    public class FCController : ApiController
    {
        // GET api/FC
        [Route("api/FCList/")]
        [HttpPost]
        public AngularGridData GetFC([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.FacilityDetails, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = "Select * from FC where FC.SocID=" + objLoggedUser.SocID;
            objAngularDataBinder.ValueField = "FCID";
            return objAngularDataBinder.GetData();
        }

        // GET api/FC/Id
        [Route("api/FC/{Id}")]
        public string GetFC(int Id)
        {
            Common.IsValidForm(Constants.Forms.FacilityDetails, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            FCBL objFCBL = new FCBL(Common.GetConString());
            objFCBL.Load(Id);
            FC objFC = objFCBL.Data;
            if (objFCBL.IsNew)
            {
                objFC.IsActive = true;
            }
            
            if (Common.ToInt(objFC.SocID) > 0 && objFC.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            return JsonConvert.SerializeObject(objFCBL.Data);
        }

        // POST api/FC/
        public string Post([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.FacilityDetails, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            FC objFC = objJObject.ToObject<FC>();
            FCBL objFCBL = new FCBL(Common.GetConString());
            objFCBL.Data = objFC;
            if (objFCBL.IsNew)
            {
                objFC.SocID = objLoggedUser.SocID;
            }
            if (Common.ToInt(objFC.SocID) > 0 && objFC.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            FCValidator validator = new FCValidator();
            ValidationResult results = validator.Validate(objFC);

            if (results.IsValid)
            {
                objFCBL.Update();
                return JsonConvert.SerializeObject(objFCBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        // DELETE api/FC/5
        [Route("api/FC/{Id}")]
        [HttpDelete]
        public bool Delete(int Id)
        {
            Common.IsValidForm(Constants.Forms.FacilityDetails, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            FCBL objFCBL = new FCBL(Common.GetConString());
            objFCBL.Load(Id);

            FC objFC = objFCBL.Data;
            if (Common.ToInt(objFC.SocID) > 0 && objFC.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            return objFCBL.Delete(Id);
        }
    }
    public class FCValidator : AbstractValidator<FC>
    {
        public FCValidator()
        {

            RuleFor(obj => obj.FCName).NotEmpty();
            RuleFor(obj => obj.SocID).NotEmpty();
        }
    }
}

