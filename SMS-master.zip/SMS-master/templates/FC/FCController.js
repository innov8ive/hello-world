var app = angular.module('myApp');

app.controller('FCListCtrl', function ($scope, $http, $location, GridData) {

    $scope = readyAngularGrid($scope, $http, 'api/FCList', 'FCID', GridData, 'FC');
    $scope.gridOptions.columnDefs = [

    { displayName: 'Facility Name', field: 'FCName' }];
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchFC = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };
    $scope.newFC = function () {
        saveGridData($scope, GridData, 'FC');
        $location.path('/FC/0');
    };
    $scope.editFC = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            saveGridData($scope, GridData, 'FC');
            $location.path('/FC/' + selected[0].FCID);
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.deleteFC = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'DELETE',
                url: 'api/FC/' + selected[0].FCID
            }).success(function (result) {
                if (result == true)
                    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
            });
        }
        else {
            alert('Please select a record to edit.');
        }
    };
})

.controller('FCCtrl', function ($scope, $http, $location, $routeParams) {
    var FCID = $routeParams.FCID;
    $scope.FC = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.FCSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.FCSubmitted = true;
        if ($scope.formFC.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/FC', $scope.FC, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.FC = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/FCList');
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/FC/' + FCID
        }).success(function (FC) {
            $scope.FC = JSON.parse(FC);
        });
    }, 100);
});
