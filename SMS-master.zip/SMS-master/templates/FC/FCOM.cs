using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

    [Serializable]
    [Table(Name = "dbo.FC")]
    public class FC
    {

        private System.Nullable<int> _FCID;
        private string _FCName;
        private System.Nullable<bool> _IsActive;
        private System.Nullable<int> _SocID;


        [Column(Storage = "_FCID")]
        public System.Nullable<int> FCID
        {
            get
            {
                return _FCID;
            }
            set
            {
                _FCID = value;
            }
        }



        [Column(Storage = "_FCName")]
        public string FCName
        {
            get
            {
                return _FCName;
            }
            set
            {
                _FCName = value;
            }
        }



        [Column(Storage = "_IsActive")]
        public System.Nullable<bool> IsActive
        {
            get
            {
                return _IsActive;
            }
            set
            {
                _IsActive = value;
            }
        }



        [Column(Storage = "_SocID")]
        public System.Nullable<int> SocID
        {
            get
            {
                return _SocID;
            }
            set
            {
                _SocID = value;
            }
        }

    }


}
