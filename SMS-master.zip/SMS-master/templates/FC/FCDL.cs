using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
public class FCDL
{

#region Private Members
private string connectionString;
#endregion

#region Constructor
public FCDL(string conString)
{
connectionString = conString;
}
#endregion

#region Main Methods
public FC Load(int FCID)
{
SqlConnection SqlCon = new SqlConnection(connectionString);
FC objFC = new FC();
var dc = new DataContext(SqlCon);
try
{
//Get FC
var resultFC = dc.ExecuteQuery<FC>("exec Get_FC {0}", FCID).ToList();
if (resultFC.Count > 0)
{
objFC = resultFC[0];
}
dc.Dispose();
return objFC;
}
catch (Exception ex)
{
throw new Exception(ex.Message);
}
finally
{
if (SqlCon.State == ConnectionState.Open)
{
SqlCon.Close();
}
SqlCon.Dispose();
}
}
public DataTable LoadAllFC()
{
DataTable dt = new DataTable();
SqlConnection con = new SqlConnection(connectionString);
SqlCommand cmd = new SqlCommand("exec Get_FC",con);

con.Open();
dt.Load(cmd.ExecuteReader());
con.Close();

return dt;
}
public bool Update(FC objFC)
{
SqlConnection con = new SqlConnection(connectionString);
con.Open();
SqlTransaction trn = con.BeginTransaction();
try
{
//update FC
UpdateFC(objFC,trn);
if (objFC.FCID > 0)
{

trn.Commit();
}
return true;
}
catch
{
trn.Rollback();
return false;
}
finally
{
con.Dispose();
}
}
public bool Delete(int FCID)
{
SqlConnection con = new SqlConnection(connectionString);
con.Open();
SqlTransaction trn = con.BeginTransaction();
try
{
//Delete FC
DeleteFC(FCID,trn);
trn.Commit();
return true;
}
catch
{
trn.Rollback();
return false;
}
finally
{
con.Dispose();
}
}

public bool UpdateFC(FC objFC,SqlTransaction trn){SqlCommand cmd=new SqlCommand("Insert_Update_FC",trn.Connection);try{cmd.CommandType=CommandType.StoredProcedure; cmd.Transaction = trn;
cmd.Parameters.Add("@FCID",SqlDbType.Int).Value=objFC.FCID;
cmd.Parameters["@FCID"].Direction=ParameterDirection.InputOutput;
cmd.Parameters.Add("@FCName",SqlDbType.VarChar,100).Value=objFC.FCName;
cmd.Parameters.Add("@IsActive",SqlDbType.Bit).Value=objFC.IsActive;
cmd.Parameters.Add("@SocID",SqlDbType.Int).Value=objFC.SocID;
cmd.ExecuteNonQuery();//after updating the FC, update FCIDobjFC.FCID=Convert.ToInt32(cmd.Parameters["@FCID"].Value);return true;}catch{ trn.Rollback();return false;}finally{cmd.Dispose();}}
public bool DeleteFC(int FCID, SqlTransaction trn){try{SqlCommand cmd=new SqlCommand("Delete from FC where FCID=@FCID", trn.Connection);cmd.Transaction = trn;cmd.Parameters.Add("@FCID",SqlDbType.Int).Value=FCID;cmd.ExecuteNonQuery();return true;}catch{trn.Rollback();return false;}}#endregion
}
}
