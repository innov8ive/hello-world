using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
[Serializable]
public class FolderBL
{

#region Declaration
private string connectionString;
Folder _Folder;
public Folder Data
{
get { return _Folder; }
set { _Folder = value; }
}
public bool IsNew
{
get { return (_Folder.FolderID <= 0 || _Folder.FolderID ==null); }
}
#endregion

#region Constructor
public FolderBL(string conString)
{
connectionString = conString;
}
#endregion

#region Main Methods
private FolderDL CreateDL()
{
return new FolderDL(connectionString);
}
public void New()
{
_Folder = new Folder();
}
public void Load(int FolderID)
{
var FolderObj = this.CreateDL();
_Folder = FolderID <= 0 ? FolderObj.Load(-1) : FolderObj.Load(FolderID);
}
public DataTable LoadAllFolder()
{
var FolderDLObj = CreateDL();
return FolderDLObj.LoadAllFolder();
}
public bool Update()
{
var FolderDLObj = CreateDL();
return FolderDLObj.Update(this.Data);
}
public bool Delete(int FolderID)
{
var FolderDLObj = CreateDL();
return FolderDLObj.Delete(FolderID);
}
#endregion
}
}
