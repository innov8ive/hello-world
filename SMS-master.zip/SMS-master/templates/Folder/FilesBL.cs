using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularDL;
using SampleAngularOM;

namespace SampleAngularBL
{
    [Serializable]
    public class FilesBL
    {

        #region Declaration
        private string connectionString;
        Files _Files;
        public Files Data
        {
            get { return _Files; }
            set { _Files = value; }
        }
        public bool IsNew
        {
            get { return (_Files.FileID <= 0 || _Files.FileID == null); }
        }
        #endregion

        #region Constructor
        public FilesBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private FilesDL CreateDL()
        {
            return new FilesDL(connectionString);
        }
        public void New()
        {
            _Files = new Files();
        }
        public void Load(int FileID)
        {
            var FilesObj = this.CreateDL();
            _Files = FileID <= 0 ? FilesObj.Load(-1) : FilesObj.Load(FileID);
        }
        public DataTable LoadAllFiles()
        {
            var FilesDLObj = CreateDL();
            return FilesDLObj.LoadAllFiles();
        }
        public bool Update()
        {
            var FilesDLObj = CreateDL();
            return FilesDLObj.Update(this.Data);
        }
        public bool Delete(int FileID)
        {
            var FilesDLObj = CreateDL();
            return FilesDLObj.Delete(FileID);
        }
        public bool Delete(string FileGUID)
        {
            var FilesDLObj = CreateDL();
            return FilesDLObj.Delete(FileGUID);
        }
        #endregion
    }
}
