using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
    public class FilesDL
    {

        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public FilesDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public Files Load(int FileID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            Files objFiles = new Files();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get Files
                var resultFiles = dc.ExecuteQuery<Files>("select * from Files where FileID={0}", FileID).ToList();
                if (resultFiles.Count > 0)
                {
                    objFiles = resultFiles[0];
                }
                dc.Dispose();
                return objFiles;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllFiles()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_Files", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(Files objFiles)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update Files
                UpdateFiles(objFiles, trn);
                if (objFiles.FileID > 0)
                {

                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int FileID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete Files
                DeleteFiles(FileID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(string FileGUID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete Files
                DeleteFiles(FileGUID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateFiles(Files objFiles, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_Files", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;
                cmd.Parameters.Add("@FileGUID", SqlDbType.VarChar, 50).Value = objFiles.FileGUID;
                cmd.Parameters.Add("@FileID", SqlDbType.Int).Value = objFiles.FileID;
                cmd.Parameters["@FileID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@FileName", SqlDbType.VarChar, 250).Value = objFiles.FileName;
                cmd.Parameters.Add("@FolderID", SqlDbType.Int).Value = objFiles.FolderID;
                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = objFiles.SocID;

                cmd.ExecuteNonQuery();

                //after updating the Files, update FileID
                objFiles.FileID = Convert.ToInt32(cmd.Parameters["@FileID"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteFiles(int FileID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from Files where FileID=@FileID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@FileID", SqlDbType.Int).Value = FileID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        public bool DeleteFiles(string FileGUID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from Files where FileGUID=@FileGUID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@FileGUID", SqlDbType.VarChar, 50).Value = FileGUID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        #endregion
    }
}
