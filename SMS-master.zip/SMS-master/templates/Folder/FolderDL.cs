using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
public class FolderDL
{

#region Private Members
private string connectionString;
#endregion

#region Constructor
public FolderDL(string conString)
{
connectionString = conString;
}
#endregion

#region Main Methods
public Folder Load(int FolderID)
{
SqlConnection SqlCon = new SqlConnection(connectionString);
Folder objFolder = new Folder();
var dc = new DataContext(SqlCon);
try
{
//Get Folder
var resultFolder = dc.ExecuteQuery<Folder>("exec Get_Folder {0}", FolderID).ToList();
if (resultFolder.Count > 0)
{
objFolder = resultFolder[0];
}
dc.Dispose();
return objFolder;
}
catch (Exception ex)
{
throw new Exception(ex.Message);
}
finally
{
if (SqlCon.State == ConnectionState.Open)
{
SqlCon.Close();
}
SqlCon.Dispose();
}
}
public DataTable LoadAllFolder()
{
DataTable dt = new DataTable();
SqlConnection con = new SqlConnection(connectionString);
SqlCommand cmd = new SqlCommand("exec Get_Folder",con);

con.Open();
dt.Load(cmd.ExecuteReader());
con.Close();

return dt;
}
public bool Update(Folder objFolder)
{
SqlConnection con = new SqlConnection(connectionString);
con.Open();
SqlTransaction trn = con.BeginTransaction();
try
{
//update Folder
UpdateFolder(objFolder,trn);
if (objFolder.FolderID > 0)
{

trn.Commit();
}
return true;
}
catch
{
trn.Rollback();
return false;
}
finally
{
con.Dispose();
}
}
public bool Delete(int FolderID)
{
SqlConnection con = new SqlConnection(connectionString);
con.Open();
SqlTransaction trn = con.BeginTransaction();
try
{
//Delete Folder
DeleteFolder(FolderID,trn);
trn.Commit();
return true;
}
catch
{
trn.Rollback();
return false;
}
finally
{
con.Dispose();
}
}

public bool UpdateFolder(Folder objFolder,SqlTransaction trn){SqlCommand cmd=new SqlCommand("Insert_Update_Folder",trn.Connection);try{cmd.CommandType=CommandType.StoredProcedure; cmd.Transaction = trn;
cmd.Parameters.Add("@CreatedDate",SqlDbType.DateTime).Value=objFolder.CreatedDate;
cmd.Parameters.Add("@FolderID",SqlDbType.Int).Value=objFolder.FolderID;
cmd.Parameters["@FolderID"].Direction=ParameterDirection.InputOutput;
cmd.Parameters.Add("@FolderName",SqlDbType.VarChar,100).Value=objFolder.FolderName;
cmd.Parameters.Add("@ParentFolderID",SqlDbType.Int).Value=objFolder.ParentFolderID;
cmd.Parameters.Add("@SocID",SqlDbType.Int).Value=objFolder.SocID;
cmd.ExecuteNonQuery();//after updating the Folder, update FolderIDobjFolder.FolderID=Convert.ToInt32(cmd.Parameters["@FolderID"].Value);return true;}catch{ trn.Rollback();return false;}finally{cmd.Dispose();}}
public bool DeleteFolder(int FolderID, SqlTransaction trn){try{SqlCommand cmd=new SqlCommand("Delete from Folder where FolderID=@FolderID", trn.Connection);cmd.Transaction = trn;cmd.Parameters.Add("@FolderID",SqlDbType.Int).Value=FolderID;cmd.ExecuteNonQuery();return true;}catch{trn.Rollback();return false;}}#endregion
}
}
