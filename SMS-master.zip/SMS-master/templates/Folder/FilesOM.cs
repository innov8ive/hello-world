using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;

namespace SampleAngularOM
{

    [Serializable]
    [Table(Name = "dbo.Files")]
    public class Files
    {
        private string _FileGUID;
        private System.Nullable<int> _FileID;
        private string _FileName;
        private System.Nullable<int> _FolderID;
        private Nullable<int> _SocID;

        [Column(Storage = "_SocID")]
        public Nullable<int> SocID
        {
            get { return _SocID; }
            set { _SocID = value; }
        }

        [Column(Storage = "_FolderID")]
        public System.Nullable<int> FolderID
        {
            get
            {
                return _FolderID;
            }
            set
            {
                _FolderID = value;
            }
        }
        [Column(Storage = "_FileGUID")]
        public string FileGUID
        {
            get
            {
                return _FileGUID;
            }
            set
            {
                _FileGUID = value;
            }
        }
        [Column(Storage = "_FileID")]
        public System.Nullable<int> FileID
        {
            get
            {
                return _FileID;
            }
            set
            {
                _FileID = value;
            }
        }
        [Column(Storage = "_FileName")]
        public string FileName
        {
            get
            {
                return _FileName;
            }
            set
            {
                _FileName = value;
            }
        }
    }


}
