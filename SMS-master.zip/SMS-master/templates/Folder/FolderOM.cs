using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

[Serializable][Table(Name = "dbo.Folder")]public class Folder{
private System.Nullable<DateTime> _CreatedDate;
private System.Nullable<int> _FolderID;
private string _FolderName;
private System.Nullable<int> _ParentFolderID;
private System.Nullable<int> _SocID;
 
[Column(Storage = "_CreatedDate")]
public System.Nullable<DateTime> CreatedDate{get {return _CreatedDate;}set { _CreatedDate=value;}}
[Column(Storage = "_FolderID")]
public System.Nullable<int> FolderID{get {return _FolderID;}set { _FolderID=value;}}
[Column(Storage = "_FolderName")]
public string FolderName{get {return _FolderName;}set { _FolderName=value;}}
[Column(Storage = "_ParentFolderID")]
public System.Nullable<int> ParentFolderID{get {return _ParentFolderID;}set { _ParentFolderID=value;}}
[Column(Storage = "_SocID")]
public System.Nullable<int> SocID{get {return _SocID;}set { _SocID=value;}}
}}
