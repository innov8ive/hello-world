using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;
using System.IO;

namespace SampleAngular.Api
{
    public class FolderController : ApiController
    {
        // GET api/Folder
        [Route("api/FolderList/")]
        [HttpPost]
        public string GetFolders([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.FileRepository, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            DataTable dt = Common.GetDBResultParameterized(@"Select * from Folder where SocID=@SocID 
and FolderName like '%'+@Name+'%' and ((@FolderID=0 and ParentFolderID is NULL) OR (@FolderID=ParentFolderID)) Order By FolderName",
"@SocID", SqlDbType.Int, objLoggedUser.SocID,
"@FolderID", SqlDbType.Int, Common.ToString(value.FolderID),
"@Name", SqlDbType.VarChar, Common.ToString(value.filterText));

            return JsonConvert.SerializeObject(dt, Formatting.Indented);
        }

        [Route("api/FileList/")]
        [HttpPost]
        public string GetFiles([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.FileRepository, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            DataTable dt = Common.GetDBResultParameterized(@"Select * from Files where SocID=@SocID 
and FileName like '%'+@Name+'%' and ((@FolderID=0 and FolderID is NULL) OR (@FolderID=FolderID)) Order By FileName",
"@SocID", SqlDbType.Int, objLoggedUser.SocID,
"@FolderID", SqlDbType.Int, Common.ToString(value.FolderID),
"@Name", SqlDbType.VarChar, Common.ToString(value.filterText));

            return JsonConvert.SerializeObject(dt, Formatting.Indented);
        }

        [Route("api/Folder/DeleteFolder")]
        [HttpPost]
        public string DeleteFolder([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.FileRepository, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            int totalChildFolders = Common.ToInt(Common.GetDBScalar("Select COUNT(*) from Folder where ParentFolderID=@FolderID and SocID=@SocID",
                "@FolderID", SqlDbType.Int, Common.ToInt(value.FolderID),
                "@SocID", SqlDbType.Int, objLoggedUser.SocID));
            int totalChildFiles = Common.ToInt(Common.GetDBScalar("Select COUNT(*) from Files where FolderID=@FolderID and SocID=@SocID",
                "@FolderID", SqlDbType.Int, Common.ToInt(value.FolderID),
                "@SocID", SqlDbType.Int, objLoggedUser.SocID));

            if (totalChildFiles + totalChildFolders > 0)
            {
                return "Error: You can not delete this Folder, because is has some child File(s)/Folder(s). Please delete the Child items first.";
            }
            else
            {
                Common.ExecuteNonQuery("Delete from Folder where FolderID=@FolderID and SocID=@SocID",
                 "@FolderID", SqlDbType.Int, Common.ToInt(value.FolderID),
                 "@SocID", SqlDbType.Int, objLoggedUser.SocID);
                return "Folder Deleted Successfully";
            }
        }

        [Route("api/Folder/DeleteFile")]
        [HttpPost]
        public int DeleteFile([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.FileRepository, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            int result = Common.ExecuteNonQuery("Delete from Files where FileID=@FileID and SocID=@SocID",
                "@FileID", SqlDbType.Int, Common.ToInt(value.FileID),
                "@SocID", SqlDbType.Int, objLoggedUser.SocID);
            try
            {
                if (result > 0)
                    File.Delete(HttpContext.Current.Server.MapPath("~/AttachedFiles/") + Common.ToString(value.FileGUID));
            }
            finally { }
            return result;
        }

        // POST api/Folder/
        public string Post([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.FileRepository, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            Folder objFolder = objJObject.ToObject<Folder>();
            FolderBL objFolderBL = new FolderBL(Common.GetConString());
            objFolderBL.Data = objFolder;

            FolderValidator validator = new FolderValidator();
            ValidationResult results = validator.Validate(objFolder);
            if(objFolderBL.IsNew)
            {
                objFolder.CreatedDate = DateTime.Now;
                objFolder.SocID = objLoggedUser.SocID;
            }
            if (objFolder.ParentFolderID <= 0) objFolder.ParentFolderID = null;

            if (results.IsValid)
            {
                objFolderBL.Update();
                return JsonConvert.SerializeObject(objFolderBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        
    }
    public class FolderValidator : AbstractValidator<Folder>
    {
        public FolderValidator()
        {
            RuleFor(obj => obj.FolderName).NotEmpty();
        }
    }
}

