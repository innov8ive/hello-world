using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
[Serializable]
public class WingsBL
{

#region Declaration
private string connectionString;
Wings _Wings;
public Wings Data
{
get { return _Wings; }
set { _Wings = value; }
}
public bool IsNew
{
get { return (_Wings.WingID <= 0 || _Wings.WingID ==null); }
}
#endregion

#region Constructor
public WingsBL(string conString)
{
connectionString = conString;
}
#endregion

#region Main Methods
private WingsDL CreateDL()
{
return new WingsDL(connectionString);
}
public void New()
{
_Wings = new Wings();
}
public void Load(int WingID)
{
var WingsObj = this.CreateDL();
_Wings = WingID <= 0 ? WingsObj.Load(-1) : WingsObj.Load(WingID);
}
public DataTable LoadAllWings()
{
var WingsDLObj = CreateDL();
return WingsDLObj.LoadAllWings();
}
public bool Update()
{
var WingsDLObj = CreateDL();
return WingsDLObj.Update(this.Data);
}
public bool Delete(int WingID)
{
var WingsDLObj = CreateDL();
return WingsDLObj.Delete(WingID);
}
#endregion
}
}
