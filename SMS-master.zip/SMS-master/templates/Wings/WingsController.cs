using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;

namespace SampleAngular.Api
{
    public class WingsController : ApiController
    {
        // GET api/Wings
        [Route("api/WingsList/")]
        [HttpPost]
        public AngularGridData GetWings([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.NoticeBoard, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = "Select * from Wings where SocID=@SocID";
            objAngularDataBinder.ValueField = "WingID";
            Hashtable ht = new Hashtable();
            ht["@SocID"] = objLoggedUser.SocID;
            objAngularDataBinder.Parameters = ht;
            return objAngularDataBinder.GetData();
        }

        // GET api/Wings/Id
        [Route("api/Wings/{Id}")]
        public string GetWings(int Id)
        {
            Common.IsValidForm(Constants.Forms.NoticeBoard, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            WingsBL objWingsBL = new WingsBL(Common.GetConString());
            objWingsBL.Load(Id);
            Wings objWings = objWingsBL.Data;
            if (Common.ToInt(objWings.SocID) > 0 && objWings.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            return JsonConvert.SerializeObject(objWingsBL.Data);
        }

        // POST api/Wings/
        public string Post([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.NoticeBoard, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            Wings objWings = objJObject.ToObject<Wings>();
            WingsBL objWingsBL = new WingsBL(Common.GetConString());
            objWingsBL.Data = objWings;
            if (objWingsBL.IsNew)
            {
                objWings.SocID = objLoggedUser.SocID;
            }
            WingsValidator validator = new WingsValidator();
            ValidationResult results = validator.Validate(objWings);
            if (Common.ToInt(objWings.SocID) > 0 && objWings.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            if (objLoggedUser.UserType != 2)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            if (!Common.IsUniqueInTable("Wings", "WingName",
               Common.ToString(objWings.WingName),
               "WingID", Common.ToInt(objWings.WingID).ToString(), "SocID=" + Common.ToInt(objWings.SocID).ToString()))
            {
                results.Errors.Add(new ValidationFailure("WingName", "This Block/Wing Name is already added"));
            }
            if (results.IsValid)
            {
                objWings.SocID = objLoggedUser.SocID;
                objWingsBL.Update();
                return JsonConvert.SerializeObject(objWingsBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        // DELETE api/Wings/5
        [Route("api/Wings/{Id}")]
        [HttpDelete]
        public string Delete(int Id)
        {
            Common.IsValidForm(Constants.Forms.NoticeBoard, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            WingsBL objWingsBL = new WingsBL(Common.GetConString());
            objWingsBL.Load(Id);
            Wings objWings = objWingsBL.Data;
            if (Common.ToInt(objWings.SocID) > 0 && objWings.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            int countUnit = Common.ToInt(Common.GetDBScalar("Select COUNT(*) from Rooms where WingID=" + Id + " and SocID = " + objLoggedUser.SocID));
            if (countUnit > 0)
            {
                return "You cannot delete this Block/Wing!";
            }
            bool result = objWingsBL.Delete(Id);
            if (result)
                return String.Empty;
            else
                return "Block/Wing not deleted!";
        }
    }
    public class WingsValidator : AbstractValidator<Wings>
    {
        public WingsValidator()
        {
            RuleFor(obj => obj.WingName).NotEmpty();
        }
    }
}

