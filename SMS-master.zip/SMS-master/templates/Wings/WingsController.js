var app = angular.module('myApp');

app.controller('WingsListCtrl', function ($scope, $http, $location, GridData) {

    $scope = readyAngularGrid($scope, $http, 'api/WingsList', 'WingID', GridData, 'Wings');
    $scope.gridOptions.columnDefs = [

    { displayName: 'Block/Wing Name', field: 'WingName' }, 
    { displayName: 'No. Of Flats', field: 'NoOfFlats' }, ];
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchWings = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };
    $scope.newWings = function () {
        saveGridData($scope, GridData, 'Wings');
        $location.path('/Wings/0');
    };
    $scope.editWings = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            saveGridData($scope, GridData, 'Wings');
            $location.path('/Wings/' + selected[0].WingID);
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.deleteWings = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'DELETE',
                url: 'api/Wings/' + selected[0].WingID
            }).success(function (result) {
                if (result.length == 0) {
                    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
                    swal({ title: "Record deleted successfully!", type: "success", timer: 1000, showConfirmButton: false });
                }
                else
                    alert(result);
            });
        }
        else {
            alert('Please select a record to edit.');
        }
    };
})

.controller('WingsCtrl', function ($scope, $http, $location, $routeParams) {
    var WingID = $routeParams.WingID;
    $scope.Wings = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.WingsSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.WingsSubmitted = true;
        if ($scope.formWings.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/Wings', $scope.Wings, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.Wings = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/WingsList');
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/Wings/' + WingID
        }).success(function (Wings) {
            $scope.Wings = JSON.parse(Wings);
        });
    }, 100);
});
