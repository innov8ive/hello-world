using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

    [Serializable]
    [Table(Name = "dbo.Wings")]
    public class Wings
    {

        private System.Nullable<int> _SocID;
        private System.Nullable<int> _WingID;
        private string _WingName;
        private Nullable<int> _NoOfFlats;

        [Column(Storage = "_NoOfFlats")]
        public Nullable<int> NoOfFlats
        {
            get { return _NoOfFlats; }
            set { _NoOfFlats = value; }
        }


        [Column(Storage = "_SocID")]
        public System.Nullable<int> SocID
        {
            get
            {
                return _SocID;
            }
            set
            {
                _SocID = value;
            }
        }



        [Column(Storage = "_WingID")]
        public System.Nullable<int> WingID
        {
            get
            {
                return _WingID;
            }
            set
            {
                _WingID = value;
            }
        }



        [Column(Storage = "_WingName")]
        public string WingName
        {
            get
            {
                return _WingName;
            }
            set
            {
                _WingName = value;
            }
        }

    }


}
