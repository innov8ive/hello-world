using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
    public class WingsDL
    {

        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public WingsDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public Wings Load(int WingID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            Wings objWings = new Wings();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get Wings
                var resultWings = dc.ExecuteQuery<Wings>("exec Get_Wings {0}", WingID).ToList();
                if (resultWings.Count > 0)
                {
                    objWings = resultWings[0];
                }
                dc.Dispose();
                return objWings;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllWings()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_Wings", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(Wings objWings)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update Wings
                UpdateWings(objWings, trn);
                if (objWings.WingID > 0)
                {

                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int WingID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete Wings
                DeleteWings(WingID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateWings(Wings objWings, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_Wings", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = objWings.SocID;
                cmd.Parameters.Add("@WingID", SqlDbType.Int).Value = objWings.WingID;
                cmd.Parameters["@WingID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@WingName", SqlDbType.VarChar, 50).Value = objWings.WingName;
                cmd.Parameters.Add("@NoOfFlats", SqlDbType.Int).Value = objWings.NoOfFlats;

                cmd.ExecuteNonQuery();

                //after updating the Wings, update WingID
                objWings.WingID = Convert.ToInt32(cmd.Parameters["@WingID"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteWings(int WingID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from Wings where WingID=@WingID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@WingID", SqlDbType.Int).Value = WingID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        #endregion
    }
}
