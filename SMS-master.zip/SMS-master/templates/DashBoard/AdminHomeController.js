﻿var app = angular.module('myApp');

app.controller('AdminHomeController', function ($scope, $http, $location, User) {
    $scope.TotalFlats = null;
    $scope.TotalUsers = null;
    $scope.TotalCollection = null;
    $scope.TotalBills = null;
    $scope.Meetings = null;
    $scope.Polls = null;
    $scope.Vehicles = null;
    $scope.SMSCredit = null;
    window.setTimeout(function () {
        $http({
            method: 'POST',
            url: 'api/AdminHome/Meetings/'
        }).success(function (result) {
            $scope.Meetings = result;
        });
        $http({
            method: 'POST',
            url: 'api/AdminHome/Polls/'
        }).success(function (result) {
            $scope.Polls = result;
        });
        $http({
            method: 'POST',
            url: 'api/AdminHome/Vehicles/'
        }).success(function (result) {
            $scope.Vehicles = result;
        });
        $http({
            method: 'POST',
            url: 'api/AdminHome/SMSCredit/'
        }).success(function (result) {
            $scope.SMSCredit = result;
        });
        $http({
            method: 'POST',
            url: 'api/AdminHome/TotalFlats/'
        }).success(function (result) {
            $scope.TotalFlats = result;
        });

        $http({
            method: 'POST',
            url: 'api/AdminHome/TotalUsers/'
        }).success(function (result) {
            $scope.TotalUsers = result;
        });

        $http({
            method: 'POST',
            url: 'api/AdminHome/TotalCollection/'
        }).success(function (result) {
            $scope.TotalCollection = result;
        });

        $http({
            method: 'POST',
            url: 'api/AdminHome/TotalBills/'
        }).success(function (result) {
            $scope.TotalBills = result;
        });
    }, 100);

    window.setTimeout(function () {
        $http({
            method: 'POST',
            url: 'api/AdminHome/RecentForum/'
        }).success(function (result) {
            $scope.RecentForum = JSON.parse(result);
        });
    }, 100);

    $scope.Forums = null;
    $scope.editForums = function (ForumID) {
        $scope.loading = true;
        setTimeout(function () {
            $http({
                method: 'GET',
                url: 'api/Forums/' + ForumID
            }).success(function (Forums) {
                $scope.showModal = true;
                $scope.loading = false;
                $scope.Forums = JSON.parse(Forums);
            });
        }, 100);
    };

    $scope.viewDefaulters = function () {
        $location.path('/Defaulters');
    };
    window.setTimeout(function () {
        $http({
            method: 'POST',
            url: 'api/AdminHome/RecentIncome/'
        }).success(function (result) {
            $scope.RecentIncome = JSON.parse(result);
        });

        $http({
            method: 'POST',
            url: 'api/AdminHome/RecentExpense/'
        }).success(function (result) {
            $scope.RecentExpense = JSON.parse(result);
        });

        $http({
            method: 'POST',
            url: 'api/AdminHome/Defaulters/'
        }).success(function (result) {
            $scope.Defaulters = JSON.parse(result);
        });
        $http({
            method: 'POST',
            url: 'api/AdminHome/UnitUsage/'
        }).success(function (result) {
            var pieChartCanvas = $("#pieChart").get(0).getContext("2d");
            var pieChart = new Chart(pieChartCanvas);
            var PieData = JSON.parse(result);
            var pieOptions = {
                segmentShowStroke: true,
                segmentStrokeColor: "#fff",
                segmentStrokeWidth: 2,
                percentageInnerCutout: 50,
                animationSteps: 100,
                animationEasing: "easeOutBounce",
                animateRotate: true,
                animateScale: false,
                responsive: true,
                maintainAspectRatio: true,
                legendTemplate: "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<segments.length; i++){%><li><span style=\"background-color:<%=segments[i].fillColor%>\"></span><%if(segments[i].label){%><%=segments[i].label%><%}%></li><%}%></ul>",
            };
            pieChart.Doughnut(PieData, pieOptions);
        });


    }, 500);
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.closeComplaint = function (itm) {
        $scope.loading = true;
        $http({
            method: 'POST',
            url: 'api/Forums/CloseComplaint/',
            data: JSON.stringify(itm)
        }).success(function (result) {
            $scope.loading = false;
            itm.Status = 'Closed';
            $scope.showModal = false;
            $scope.searchForums();
        });
    };
    $scope.addComment = function (itm) {
        if (itm.CurrentRemarks == '') return;
        $scope.loading = true;
        $scope.commentBox = {};
        $scope.commentBox.ForumID = itm.ForumID;
        $scope.commentBox.Remarks = itm.CurrentRemarks;
        $http.post('api/Comments', $scope.commentBox, config)
        .success(function (data, status, headers, config) {
            $scope.loading = false;
            var result = data;
            if (result.ErrorCode == 1)
                $scope.ErrorMessages = result.data;
            else {
                $scope.ErrorMessages = [];
                itm.CurrentRemarks = '';
                var curDate = (new Date()).toJSON();
                itm.Comments.push({
                    Remarks: $scope.commentBox.Remarks,
                    CommentedByName: User.FirstName + ' ' + User.LastName,
                    CommentedByImageUrl: User.ImageUrl,
                    CommentDate: curDate
                });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.Msg = { SMS: [] };
    var mobilelist = [];
    $scope.bindMobileList = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetMobileList' })
        }).success(function (data) {
            data.splice(0, 0, { Key: '0', Value: 'All' });
            $scope.mobilelist = data;
        });
    };
    $scope.bindMobileList();

    $scope.send = function () {
        if ($scope.Msg.Message == null || $scope.Msg.Message == '') {
            alert('Please enter message');
            return;
        }
        $http({
            method: 'POST',
            url: 'api/Msg/SendSMS',
            data: JSON.stringify({ val: $scope.Msg.SMS, Msg: $scope.Msg.Message, Group: [] })
        }).success(function (data) {
            if (data == "Success") {
                alert('Message Sent!');
                $scope.Msg.SMS = [];
                $scope.Msg.SMSGroup = [];
                $scope.Msg.Message = '';
                $http({
                    method: 'POST',
                    url: 'api/AdminHome/SMSCredit/'
                }).success(function (result) {
                    $scope.SMSCredit = result;
                });
            }
            else {
                alert(data);
            }
        });
    };
});

app.controller('HomeController', function ($scope, $http, $location) {
    $scope.TotalFlats = null;
    $scope.TotalOutstanding = null;
    window.setTimeout(function () {
        $http({
            method: 'POST',
            url: 'api/Home/TotalNB/'
        }).success(function (result) {
            $scope.TotalNB = result;
        });
        $http({
            method: 'POST',
            url: 'api/Home/TotalFM/'
        }).success(function (result) {
            $scope.TotalFM = result;
        });
        $http({
            method: 'POST',
            url: 'api/Home/TotalStaff/'
        }).success(function (result) {
            $scope.TotalStaff = result;
        });
        $http({
            method: 'POST',
            url: 'api/AdminHome/Polls/'
        }).success(function (result) {
            $scope.Polls = result;
        });
        $http({
            method: 'POST',
            url: 'api/Home/Vehicles/'
        }).success(function (result) {
            $scope.Vehicles = result;
        });
        $http({
            method: 'POST',
            url: 'api/Home/TotalOutstanding/'
        }).success(function (result) {
            $scope.TotalOutstanding = result;
        });

        $http({
            method: 'POST',
            url: 'api/Home/TotalFlats/'
        }).success(function (result) {
            $scope.TotalFlats = result;
        });

        $http({
            method: 'POST',
            url: 'api/Home/BillList/'
        }).success(function (result) {
            $scope.BillList = result;
        });

        $http({
            method: 'POST',
            url: 'api/Home/RoomList/'
        }).success(function (result) {
            $scope.RoomList = result;
        });

        $http({
            method: 'POST',
            url: 'api/Home/ParkList/'
        }).success(function (result) {
            $scope.ParkList = result;
        });
    }, 100);

    $scope.RecentForum = [];
    window.setTimeout(function () {
        $http({
            method: 'POST',
            url: 'api/Home/RecentForum/'
        }).success(function (result) {
            $scope.RecentForum = result;
        });
    }, 100);

    $scope.Forums = null;
    $scope.editForums = function (ForumID, ForumType) {
        debugger;
        $location.path('/Forums/' + ForumType + '/' + ForumID);
    };

});
