using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;
using System.IO;
using System.Web.Http.Cors;

namespace SampleAngular.Api
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class HomeController : ApiController
    {
        [Route("api/Home/AllDashBoard")]
        [HttpPost]
        public Hashtable AllDashBoard([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            Hashtable ht = new Hashtable();
            ht["Vehicles"] = Vehicles(value);
            ht["TotalFlats"] = TotalFlats(value);
            ht["TotalNB"] = TotalNB(value);
            ht["TotalFM"] = TotalFM(value);
            ht["TotalStaff"] = TotalStaff(value);
            ht["TotalOutstanding"] = TotalOutstanding(value);
            DataTable dtForum = RecentForum(value);
            ht["RecentForum"] = dtForum;
            ht["TotalComplaint"] = dtForum.Rows.Count;
            ht["Carousel"] = Common.GetDBResult("Select * from Carousel where CategoryID=" + objLoggedUser.SocID);
            ht["Polls"] = Common.ToInt(Common.GetDBScalar("select COUNT(*) from PL where ShowTill>=GETDATE() and SocID=@SocID",
                "@SocID", SqlDbType.Int, objLoggedUser.SocID)); ;
            return ht;
        }
        [Route("api/Home/Vehicles")]
        [HttpPost]
        public int Vehicles([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            int totalFlats = Common.ToInt(Common.GetDBScalar(@"select COUNT(*) from CP
where exists (select 1 from UserRooms U where U.RoomID=CP.RMID and U.SocID=CP.SocID and U.UserID=@UserID)",
                 "@UserID", SqlDbType.Int, objLoggedUser.UserID,
                 "@SocID", SqlDbType.Int, objLoggedUser.SocID));
            return totalFlats;
        }
        [Route("api/Home/TotalFlats")]
        [HttpPost]
        public int TotalFlats([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            int totalFlats = Common.ToInt(Common.GetDBScalar("Select COUNT(*) from UserRooms where UserID=@UserID and SocID=@SocID",
                "@UserID", SqlDbType.Int, objLoggedUser.UserID,
                "@SocID", SqlDbType.Int, objLoggedUser.SocID));
            return totalFlats;
        }
        [Route("api/Home/TotalNB")]
        [HttpPost]
        public int TotalNB([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            int totalFlats = Common.ToInt(Common.GetDBScalar("Select COUNT(*) from NB where IsActive=1 and ShowTillDate>=GetDate() and SocID=@SocID",
                "@SocID", SqlDbType.Int, objLoggedUser.SocID));
            return totalFlats;
        }
        [Route("api/Home/TotalFM")]
        [HttpPost]
        public int TotalFM([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            int totalFlats = Common.ToInt(Common.GetDBScalar("Select COUNT(*) from FM where FMType='FM' and AddedBy=@AddedBy",
                "@AddedBy", SqlDbType.Int, objLoggedUser.UserID));
            return totalFlats;
        }
        [Route("api/Home/TotalStaff")]
        [HttpPost]
        public int TotalStaff([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            int totalFlats = Common.ToInt(Common.GetDBScalar("Select COUNT(*) from FM where FM.SocID=@SocID and FMType='Staffs' and AddedBy=@AddedBy",
                "@AddedBy", SqlDbType.Int, objLoggedUser.UserID,
                "@SocID", SqlDbType.Int, objLoggedUser.SocID));
            return totalFlats;
        }
        [Route("api/Home/TotalOutstanding")]
        [HttpPost]
        public decimal TotalOutstanding([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            decimal totalFlats = Common.ToDecimal(Common.GetDBScalar(@"select 
ISNULL(SUM(B.Amount),0)+ISNULL(SUM(B.LF),0)-ISNULL(SUM(PaidAmount),0)-ISNULL(SUM(Discount),0) as Outstanding from Bills B
where exists (select 1 from UserRooms U where U.RoomID=B.RoomID and U.SocID=B.SocID and U.UserID=@UserID) and B.SocID=@SocID",
                "@UserID", SqlDbType.Int, objLoggedUser.UserID,
                "@SocID", SqlDbType.Int, objLoggedUser.SocID));
            return totalFlats;
        }
        [Route("api/Home/BillList")]
        [HttpPost]
        public DataTable BillList([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            DataTable dt = Common.GetDBResultParameterized(@"
select B.RoomID,B.TotalBillAmount as Amount,B.BSID
,B.BillTitle,B.BillID,B.Remarks,B.PaidToGLID,
W.WingName+' '+R.RoomNo as RoomNo,DateAdd(DD,B.Term,B.BillDate) as DueDate,
B.BillDate,ISNULL(PR.ReqID,0) as ReqID,B.PaidDate,
case when PR.ReqID IS NULL and B.PaidDate is NULL then 'Not Paid'
when PR.ReqID IS NOT NULL and B.PaidDate is NULL then case when PR.Status is NULL then 'Paid - Not Approved' else PR.Status end
when B.PaidDate is NOT NULL then 'Paid' end as Status
,ISNULL(B.TotalBillAmount,0)-ISNULL(B.PaidAmount,0)-ISNULL(Discount,0) as Outstanding
,ISNULL(BPR.PaidAmount,0) as PaidAmount,PR.RejectRemarks from Bills B
inner join Rooms R ON B.RoomID=R.RoomID
inner join Wings W ON W.WingID=R.WingID
inner join Soc S ON R.SocID=S.SocID
left join BillPaymentReq BPR ON B.BillID=BPR.BillID
left join PaymentReq PR ON PR.ReqID=BPR.ReqID
where exists (select 1 from UserRooms U where U.RoomID=B.RoomID and U.SocID=B.SocID and U.UserID=@UserID)
and B.SocID=@SocID
 and B.IsNewBill=1 and B.PaidDate IS NULL Order By B.BillDate desc",
                "@UserID", SqlDbType.Int, objLoggedUser.UserID,
                "@SocID", SqlDbType.Int, objLoggedUser.SocID);
            return dt;
        }
        [Route("api/Home/RoomList")]
        [HttpPost]
        public DataTable RoomList([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            DataTable dt = Common.GetDBResultParameterized(@"select R.*,W.WingName from UserRooms UR
inner join Rooms R ON UR.RoomID=R.RoomID
inner join Wings W ON R.WingID=W.WingID
where UR.UserID=@UserID and UR.SocID=@SocID",
                "@UserID", SqlDbType.Int, objLoggedUser.UserID,
                "@SocID", SqlDbType.Int, objLoggedUser.SocID);
            return dt;
        }

        [Route("api/Home/ParkList")]
        [HttpPost]
        public DataTable ParkList([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            DataTable dt = Common.GetDBResultParameterized(@"select CP.* from CP 
where exists (select 1 from UserRooms U where U.RoomID=CP.RMID and U.SocID=CP.SocID and U.UserID=@UserID) and CP.SocID=@SocID",
                "@UserID", SqlDbType.Int, objLoggedUser.UserID,
                "@SocID", SqlDbType.Int, objLoggedUser.SocID);
            return dt;
        }

        [Route("api/Home/RecentForum")]
        [HttpPost]
        public DataTable RecentForum([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            DataTable dt = Common.GetDBResultParameterized(@"Select top 5 F.*,U.FirstName+ISNULL(' '+U.LastName,'') as CreatedByName
,U.ImageUrl,W.WingName+' '+R.RoomNo As RoomNo from Forums F 
inner join Users U ON F.CreatedBy=U.UserID
left join Rooms R ON F.RoomID=R.RoomID
left join Wings W ON R.WingID=W.WingID
 where F.CreatedBy=@CreatedBy and F.SocID=@SocID and Type='Complaint Box' Order By F.LastUpdateDate Desc",
                "@CreatedBy", SqlDbType.Int, objLoggedUser.UserID,
                 "@SocID", SqlDbType.Int, objLoggedUser.SocID);

            return dt;
        }
    }
}

