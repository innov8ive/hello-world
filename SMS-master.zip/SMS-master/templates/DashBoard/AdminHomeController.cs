using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;
using System.IO;
using System.Web.Http.Cors;

namespace SampleAngular.Api
{
    public class AdminHomeController : ApiController
    {
        [Route("api/AdminHome/AllDashBoard")]
        [HttpPost]
        public Hashtable AllDashBoard([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            Hashtable ht = new Hashtable();
            ht["SMSCredit"] = SMSCredit(value);
            ht["Vehicles"] = Vehicles(value);
            ht["Meetings"] = Meetings(value);
            ht["TotalFlats"] = TotalFlats(value);
            ht["TotalUsers"] = TotalUsers(value);
            ht["TotalCollection"] = TotalCollection(value);
            ht["TotalBills"] = TotalBills(value);
            string dtForum = RecentForum(value);
            ht["RecentForum"] = dtForum;
            ht["Polls"] = Common.ToInt(Common.GetDBScalar("select COUNT(*) from PL where ShowTill>=GETDATE() and SocID=@SocID",
                "@SocID", SqlDbType.Int, objLoggedUser.SocID));
            return ht;
        }
        [Route("api/AdminHome/SMSCredit")]
        [HttpPost]
        public int SMSCredit([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.Members, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            return Common.GetSMSCredit(objLoggedUser.SocID);
        }

        [Route("api/AdminHome/Vehicles")]
        [HttpPost]
        public int Vehicles([FromBody]dynamic value)
        {

            //Common.IsValidForm(Constants.Forms.User, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            int totalFlats = Common.ToInt(Common.GetDBScalar("select COUNT(*) from CP where SocID=@SocID",
                "@SocID", SqlDbType.Int, objLoggedUser.SocID));
            return totalFlats;
        }

        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/AdminHome/Polls")]
        [HttpPost]
        public int Polls([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            int totalFlats = Common.ToInt(Common.GetDBScalar("select COUNT(*) from PL where ShowTill>=GETDATE() and SocID=@SocID",
                "@SocID", SqlDbType.Int, objLoggedUser.SocID));
            return totalFlats;
        }

        [Route("api/AdminHome/Meetings")]
        [HttpPost]
        public int Meetings([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            int totalFlats = Common.ToInt(Common.GetDBScalar("select COUNT(*) from MT where MDate>=GETDATE() and SocID=@SocID",
                "@SocID", SqlDbType.Int, objLoggedUser.SocID));
            return totalFlats;
        }

        [Route("api/AdminHome/TotalFlats")]
        [HttpPost]
        public int TotalFlats([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.Members, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            int totalFlats = Common.ToInt(Common.GetDBScalar("Select COUNT(*) from Rooms where SocID=@SocID",
                "@SocID", SqlDbType.Int, objLoggedUser.SocID));
            return totalFlats;
        }

        [Route("api/AdminHome/TotalUsers")]
        [HttpPost]
        public int TotalUsers([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.Members, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            int totalUsers = Common.ToInt(Common.GetDBScalar("Select COUNT(*) from Users where (CreatedBy=@UserID OR UserID=@UserID)",
                "@UserID", SqlDbType.Int, objLoggedUser.UserID));
            return totalUsers;
        }

        [Route("api/AdminHome/TotalCollection")]
        [HttpPost]
        public decimal TotalCollection([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.Members, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            decimal totalCollection = Common.ToDecimal(Common.GetDBScalar("select Sum(PaidAmount) from Bills where SocID=@SocID",
                "@SocID", SqlDbType.Int, objLoggedUser.SocID));
            return totalCollection;
        }
        
        [Route("api/AdminHome/TotalBills")]
        [HttpPost]
        public decimal TotalBills([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.Members, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            decimal totalBills = Common.ToDecimal(Common.GetDBScalar("select ISNULL(Sum(Amount),0)+ISNULL(SUM(LF),0) from Bills where SocID=@SocID",
                "@SocID", SqlDbType.Int, objLoggedUser.SocID));
            return totalBills;
        }

        [Route("api/AdminHome/RecentForum")]
        [HttpPost]
        public string RecentForum([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.Members, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            DataTable dt = Common.GetDBResultParameterized(@"Select top 5 F.*,U.FirstName+ISNULL(' '+U.LastName,'') as CreatedByName
,U.ImageUrl,W.WingName+' '+R.RoomNo As RoomNo from Forums F 
inner join Users U ON F.CreatedBy=U.UserID
left join Rooms R ON F.RoomID=R.RoomID
left join Wings W ON R.WingID=W.WingID
 where F.SocID=@SocID and Type='Complaint Box' Order By F.LastUpdateDate Desc",
                "@SocID", SqlDbType.Int, objLoggedUser.SocID);
            
            string json = JsonConvert.SerializeObject(dt, Formatting.Indented);
            return json;
        }

        [Route("api/AdminHome/RecentIncome")]
        [HttpPost]
        public string RecentIncome([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.Members, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            DataTable dt = Common.GetDBResultParameterized(@"select I.Amount,I.RefDate,FGL.GLName as FromGL,
TGL.GLName as ToGL from Income I 
inner join GL FGL ON I.FromGLID=FGL.GLID
inner join GL TGL ON I.ToGLID=TGL.GLID where I.CompanyID=@SocID 
and Month(I.RefDate)=Month(@Date) and Year(I.RefDate)=Year(@Date) Order By I.RefDate Desc",
                "@SocID", SqlDbType.Int, objLoggedUser.SocID,
                "@Date", SqlDbType.DateTime, DateTime.Today);

            string json = JsonConvert.SerializeObject(dt, Formatting.Indented);
            return json;
        }

        [Route("api/AdminHome/RecentExpense")]
        [HttpPost]
        public string RecentExpense([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.Members, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            DataTable dt = Common.GetDBResultParameterized(@"select I.Amount,I.RefDate,FGL.GLName as FromGL,
TGL.GLName as ToGL from Exp I
inner join GL FGL ON I.FromGLID=FGL.GLID
inner join GL TGL ON I.ToGLID=TGL.GLID 
where I.CompanyID=@SocID 
and Month(I.RefDate)=Month(@Date) and Year(I.RefDate)=Year(@Date) Order By I.RefDate Desc",
                "@SocID", SqlDbType.Int, objLoggedUser.SocID,
                "@Date", SqlDbType.DateTime, DateTime.Today);

            string json = JsonConvert.SerializeObject(dt, Formatting.Indented);
            return json;
        }

        [Route("api/AdminHome/Defaulters")]
        [HttpPost]
        public string Defaulters([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.Members, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            DataTable dt = Common.GetDefaulters(objLoggedUser.SocID, 8);

            string json = JsonConvert.SerializeObject(dt, Formatting.Indented);
            return json;
        }

        [Route("api/AdminHome/UnitUsage")]
        [HttpPost]
        public string UnitUsage([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.Members, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            DataTable dt = Common.GetDBResultParameterized(@" select 
 COUNT(case when MemberType='Owner' then 1 else NULL end) as TotalOwners
 ,COUNT(case when MemberType='Tenant' then 1 else NULL end) as TotalTenants from Users 
 where CreatedBy=@CreatedBy and IsActive=1", "@CreatedBy", SqlDbType.Int, objLoggedUser.UserID);

            //#f56954,#00a65a,#f39c12

            DataTable dtPie = new DataTable();
            dtPie.Columns.Add("value", typeof(int));
            dtPie.Columns.Add("color", typeof(string));
            dtPie.Columns.Add("highlight", typeof(string));
            dtPie.Columns.Add("label", typeof(string));
            DataRow dr = dtPie.NewRow();
            dr["value"] = Common.ToInt(dt.Rows[0]["TotalOwners"]);
            dr["color"] = "#f56954";
            dr["highlight"] = "#f56954";
            dr["label"] = "Total Owners";
            dtPie.Rows.Add(dr);

            dr = dtPie.NewRow();
            dr["value"] = Common.ToInt(dt.Rows[0]["TotalTenants"]);
            dr["color"] = "#00a65a";
            dr["highlight"] = "#00a65a";
            dr["label"] = "Total Tenants";
            dtPie.Rows.Add(dr);

            string json = JsonConvert.SerializeObject(dtPie, Formatting.Indented);
            return json;
        }
    }
}

