using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
    [Serializable]
    public class VoucherTypeBL
    {

        #region Declaration
        private string connectionString;
        VoucherType _VoucherType;
        public VoucherType Data
        {
            get { return _VoucherType; }
            set { _VoucherType = value; }
        }
        public bool IsNew
        {
            get { return (_VoucherType.VTID <= 0 || _VoucherType.VTID == null); }
        }
        #endregion

        #region Constructor
        public VoucherTypeBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private VoucherTypeDL CreateDL()
        {
            return new VoucherTypeDL(connectionString);
        }
        public void New()
        {
            _VoucherType = new VoucherType();
        }
        public void Load(int ID, int SocID)
        {
            var VoucherTypeObj = this.CreateDL();
            _VoucherType = ID <= 0 ? VoucherTypeObj.Load(-1, SocID) : VoucherTypeObj.Load(ID, SocID);
        }
        public DataTable LoadAllVoucherType()
        {
            var VoucherTypeDLObj = CreateDL();
            return VoucherTypeDLObj.LoadAllVoucherType();
        }
        public bool Update()
        {
            var VoucherTypeDLObj = CreateDL();
            return VoucherTypeDLObj.Update(this.Data);
        }
        public bool Delete(int ID, int SocID)
        {
            var VoucherTypeDLObj = CreateDL();
            return VoucherTypeDLObj.Delete(ID, SocID);
        }
        #endregion
    }
}
