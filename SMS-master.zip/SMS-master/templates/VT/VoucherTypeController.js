var app = angular.module('myApp');

app.controller('VoucherTypeListCtrl', function ($scope, $http, $location, GridData) {

    $scope = readyAngularGrid($scope, $http, 'api/VoucherTypeList', 'VTID', GridData, 'VoucherType');
    $scope.gridOptions.columnDefs = [
    { displayName: 'Voucher Type', field: 'VoucherTypeName' },
    { displayName: 'Credit Group', field: 'CrScheduleName' },
    { displayName: 'Debit Group', field: 'DrScheduleName' },
    ];
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchVoucherType = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };
    $scope.newVoucherType = function () {
        saveGridData($scope, GridData, 'VoucherType');
        $location.path('/VoucherType/0');
    };
    $scope.editVoucherType = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            saveGridData($scope, GridData, 'VoucherType');
            $location.path('/VoucherType/' + selected[0].VTID);
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.deleteVoucherType = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'DELETE',
                url: 'api/VoucherType/' + selected[0].VTID
            }).success(function (result) {
                if (result.length == 0) {
                    swal({ title: "Record deleted successfully!", type: "success", timer: 1000, showConfirmButton: false });
                    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
                }
                else
                    swal({ title: result, type: "error", timer: 1000, showConfirmButton: false });
            });
        }
        else {
            alert('Please select a record to edit.');
        }
    };
})

.controller('VoucherTypeCtrl', function ($scope, $http, $location, $routeParams) {
    var VTID = $routeParams.VTID;
    $scope.VoucherType = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.VoucherTypeSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.VoucherTypeSubmitted = true;
        if ($scope.formVoucherType.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/VoucherType', $scope.VoucherType, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.VoucherType = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/VoucherTypeList');
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/VoucherType/' + VTID
        }).success(function (VoucherType) {
            $scope.VoucherType = JSON.parse(VoucherType);
        });
    }, 100);

    var selectedType = '';
    $scope.showModal = false;
    $scope.showGroupWindow = function (type) {
        selectedType = type;
        $scope.showModal = true;
        $http({
            method: 'POST',
            url: 'api/GetScheduleList',
            data: JSON.stringify({ onlyGroup: true })
        }).success(function (result) {
            tree = JSON.parse(result);
            $('#tree').treeview({
                data: tree,
            });
            $('#tree').treeview('expandAll', { silent: true });
        });
    };

    $scope.saveGroup = function () {
        var selectedNodes = $('#tree').treeview(true).getSelected();
        if (selectedNodes.length > 0) {
            var node = selectedNodes[0];
            if (selectedType == 'dr') {
                $scope.VoucherType.DrScheduleName = node.text;
                $scope.VoucherType.DrScheduleID = node.ScheduleID;
            } else if (selectedType == 'cr') {
                $scope.VoucherType.CrScheduleName = node.text;
                $scope.VoucherType.CrScheduleID = node.ScheduleID;
            }
            $scope.showModal = false;
        }
        else {
            alert('Please select a Group!');
        }
    };
});
