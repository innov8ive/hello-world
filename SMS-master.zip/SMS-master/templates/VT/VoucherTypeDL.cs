using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
    public class VoucherTypeDL
    {
        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public VoucherTypeDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public VoucherType Load(int VTID, int SocID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            VoucherType objVoucherType = new VoucherType();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get VoucherType
                var resultVoucherType = dc.ExecuteQuery<VoucherType>("exec Get_VoucherType {0},{1}", VTID, SocID).ToList();
                if (resultVoucherType.Count > 0)
                {
                    objVoucherType = resultVoucherType[0];
                }
                dc.Dispose();
                return objVoucherType;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllVoucherType()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_VoucherType", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(VoucherType objVoucherType)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update VoucherType
                UpdateVoucherType(objVoucherType, trn);
                if (objVoucherType.VTID > 0)
                {

                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int ID, int SocID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete VoucherType
                DeleteVoucherType(ID, SocID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateVoucherType(VoucherType objVoucherType, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_VoucherType", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@CrScheduleID", SqlDbType.Int).Value = objVoucherType.CrScheduleID;
                cmd.Parameters.Add("@DrScheduleID", SqlDbType.Int).Value = objVoucherType.DrScheduleID;
                cmd.Parameters.Add("@VTID", SqlDbType.Int).Value = objVoucherType.VTID;
                cmd.Parameters["@VTID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = objVoucherType.SocID;
                cmd.Parameters.Add("@VoucherTypeID", SqlDbType.Int).Value = objVoucherType.VoucherTypeID;
                cmd.Parameters["@VoucherTypeID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@VoucherTypeName", SqlDbType.VarChar, 200).Value = objVoucherType.VoucherTypeName;
                cmd.Parameters.Add("@IsSysDefined", SqlDbType.Bit).Value = objVoucherType.IsSysDefined;

                cmd.ExecuteNonQuery();

                //after updating the VoucherType, update ID
                objVoucherType.VTID = Convert.ToInt32(cmd.Parameters["@VTID"].Value);
                objVoucherType.VoucherTypeID = Convert.ToInt32(cmd.Parameters["@VoucherTypeID"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteVoucherType(int VTID, int SocID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from VoucherType where VTID=@VTID and SocID=@SocID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@VTID", SqlDbType.Int).Value = VTID;
                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = SocID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        #endregion
    }
}
