using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;

namespace SampleAngular.Api
{
    public class VoucherTypeController : ApiController
    {
        // GET api/VoucherType
        [Route("api/VoucherTypeList/")]
        [HttpPost]
        public AngularGridData GetVoucherType([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.VoucherType, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = @"SELECT VTID,VT.VoucherTypeName,DrS.ScheduleName as DrScheduleName,CrS.ScheduleName as CrScheduleName FROM VoucherType VT
left join Schedule DrS ON VT.DrScheduleID=DrS.ScheduleID and VT.SocID=DrS.SocID
left join Schedule CrS ON VT.CrScheduleID=CrS.ScheduleID and VT.SocID=CrS.SocID where VT.SocID=" + objLoggedUser.SocID;
            objAngularDataBinder.ValueField = "VTID";
            return objAngularDataBinder.GetData();
        }
        // GET api/VoucherType/Id
        [Route("api/VoucherType/{Id}")]
        public string GetVoucherType(int Id)
        {
            Common.IsValidForm(Constants.Forms.VoucherType, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            VoucherTypeBL objVoucherTypeBL = new VoucherTypeBL(Common.GetConString());
            objVoucherTypeBL.Load(Id, objLoggedUser.SocID);
            return JsonConvert.SerializeObject(objVoucherTypeBL.Data);
        }

        // POST api/VoucherType/
        public string Post([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.VoucherType, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            VoucherType objVoucherType = objJObject.ToObject<VoucherType>();
            VoucherTypeBL objVoucherTypeBL = new VoucherTypeBL(Common.GetConString());
            objVoucherTypeBL.Data = objVoucherType;

            if (Common.ToInt(objVoucherTypeBL.Data.SocID) > 0 && objVoucherTypeBL.Data.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            if (objVoucherTypeBL.IsNew)
            {
                objVoucherTypeBL.Data.IsSysDefined = false;
                objVoucherTypeBL.Data.SocID = objLoggedUser.SocID;
            }

            VoucherTypeValidator validator = new VoucherTypeValidator();
            ValidationResult results = validator.Validate(objVoucherType);

            if (results.IsValid)
            {
                objVoucherTypeBL.Update();
                return JsonConvert.SerializeObject(objVoucherTypeBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        // DELETE api/VoucherType/5
        [Route("api/VoucherType/{Id}")]
        [HttpDelete]
        public string Delete(int Id)
        {
            Common.IsValidForm(Constants.Forms.VoucherType, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            VoucherTypeBL objVoucherTypeBL = new VoucherTypeBL(Common.GetConString());
            objVoucherTypeBL.Load(Id, objLoggedUser.SocID);
            if (Common.ToInt(objVoucherTypeBL.Data.SocID) > 0 && objVoucherTypeBL.Data.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            if (objVoucherTypeBL.Data.IsSysDefined == true)
                return "You cannot delete this Voucher Type!";
            else
            {
                bool result = objVoucherTypeBL.Delete(Id, objLoggedUser.SocID);
                if (result == true)
                    return String.Empty;
                else
                    return "Voucher Type not deleted!";
            }
        }
    }
    public class VoucherTypeValidator : AbstractValidator<VoucherType>
    {
        public VoucherTypeValidator()
        {
            RuleFor(obj => obj.CrScheduleID).NotEmpty();
            RuleFor(obj => obj.DrScheduleID).NotEmpty();
            RuleFor(obj => obj.VoucherTypeName).NotEmpty();
        }
    }
}

