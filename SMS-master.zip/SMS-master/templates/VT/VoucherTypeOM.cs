using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

    [Serializable]
    [Table(Name = "dbo.VoucherType")]
    public class VoucherType
    {
        private System.Nullable<int> _CrScheduleID;
        private System.Nullable<int> _DrScheduleID;
        private System.Nullable<int> _VTID;
        private System.Nullable<int> _SocID;
        private System.Nullable<int> _VoucherTypeID;
        private string _VoucherTypeName;
        private string _DrScheduleName;
        private string _CrScheduleName;
        private Nullable<bool> _IsSysDefined;

        [Column(Storage = "_IsSysDefined")]
        public Nullable<bool> IsSysDefined
        {
            get { return _IsSysDefined; }
            set { _IsSysDefined = value; }
        }

        [Column(Storage = "_CrScheduleName")]
        public string CrScheduleName
        {
            get { return _CrScheduleName; }
            set { _CrScheduleName = value; }
        }

        [Column(Storage = "_DrScheduleName")]
        public string DrScheduleName
        {
            get { return _DrScheduleName; }
            set { _DrScheduleName = value; }
        }

        [Column(Storage = "_CrScheduleID")]
        public System.Nullable<int> CrScheduleID
        {
            get
            {
                return _CrScheduleID;
            }
            set
            {
                _CrScheduleID = value;
            }
        }

        [Column(Storage = "_DrScheduleID")]
        public System.Nullable<int> DrScheduleID
        {
            get
            {
                return _DrScheduleID;
            }
            set
            {
                _DrScheduleID = value;
            }
        }

        [Column(Storage = "_VTID")]
        public System.Nullable<int> VTID
        {
            get
            {
                return _VTID;
            }
            set
            {
                _VTID = value;
            }
        }

        [Column(Storage = "_SocID")]
        public System.Nullable<int> SocID
        {
            get
            {
                return _SocID;
            }
            set
            {
                _SocID = value;
            }
        }

        [Column(Storage = "_VoucherTypeID")]
        public System.Nullable<int> VoucherTypeID
        {
            get
            {
                return _VoucherTypeID;
            }
            set
            {
                _VoucherTypeID = value;
            }
        }

        [Column(Storage = "_VoucherTypeName")]
        public string VoucherTypeName
        {
            get
            {
                return _VoucherTypeName;
            }
            set
            {
                _VoucherTypeName = value;
            }
        }
    }


}
