using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

    [Serializable]
    [Table(Name = "dbo.Schedule")]
    public class Schedule
    {
        private string _BPT;
        private System.Nullable<bool> _HasChild;
        private System.Nullable<int> _ID;
        private System.Nullable<int> _MasterScheduleID;
        private string _Nature;
        private System.Nullable<int> _ScheduleID;
        private string _ScheduleName;
        private System.Nullable<int> _SocID;
        private string _SchType;

        [Column(Storage = "_SchType")]
        public string SchType
        {
            get { return _SchType; }
            set { _SchType = value; }
        }       

        [Column(Storage = "_BPT")]
        public string BPT
        {
            get
            {
                return _BPT;
            }
            set
            {
                _BPT = value;
            }
        }
        
        [Column(Storage = "_HasChild")]
        public System.Nullable<bool> HasChild
        {
            get
            {
                return _HasChild;
            }
            set
            {
                _HasChild = value;
            }
        }
        
        [Column(Storage = "_ID")]
        public System.Nullable<int> ID
        {
            get
            {
                return _ID;
            }
            set
            {
                _ID = value;
            }
        }

        [Column(Storage = "_MasterScheduleID")]
        public System.Nullable<int> MasterScheduleID
        {
            get
            {
                return _MasterScheduleID;
            }
            set
            {
                _MasterScheduleID = value;
            }
        }

        [Column(Storage = "_Nature")]
        public string Nature
        {
            get
            {
                return _Nature;
            }
            set
            {
                _Nature = value;
            }
        }

        [Column(Storage = "_ScheduleID")]
        public System.Nullable<int> ScheduleID
        {
            get
            {
                return _ScheduleID;
            }
            set
            {
                _ScheduleID = value;
            }
        }
        
        [Column(Storage = "_ScheduleName")]
        public string ScheduleName
        {
            get
            {
                return _ScheduleName;
            }
            set
            {
                _ScheduleName = value;
            }
        }

        [Column(Storage = "_SocID")]
        public System.Nullable<int> SocID
        {
            get
            {
                return _SocID;
            }
            set
            {
                _SocID = value;
            }
        }
    }
}
