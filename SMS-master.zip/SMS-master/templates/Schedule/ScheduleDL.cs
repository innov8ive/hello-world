using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
    public class ScheduleDL
    {

        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public ScheduleDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public Schedule Load(int ID, int SocID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            Schedule objSchedule = new Schedule();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get Schedule
                var resultSchedule = dc.ExecuteQuery<Schedule>("exec Get_Schedule {0},{1}", ID, SocID).ToList();
                if (resultSchedule.Count > 0)
                {
                    objSchedule = resultSchedule[0];
                }
                dc.Dispose();
                return objSchedule;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllSchedule()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_Schedule", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(Schedule objSchedule)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update Schedule
                UpdateSchedule(objSchedule, trn);
                if (objSchedule.ID > 0)
                {

                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int ID, int SocID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete Schedule
                DeleteSchedule(ID, SocID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateSchedule(Schedule objSchedule, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_Schedule", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@BPT", SqlDbType.VarChar, 100).Value = objSchedule.BPT;
                cmd.Parameters.Add("@HasChild", SqlDbType.Bit).Value = objSchedule.HasChild;
                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = objSchedule.ID;
                cmd.Parameters["@ID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@MasterScheduleID", SqlDbType.Int).Value = objSchedule.MasterScheduleID;
                cmd.Parameters.Add("@Nature", SqlDbType.VarChar, 200).Value = objSchedule.Nature;
                cmd.Parameters.Add("@ScheduleID", SqlDbType.Int).Value = objSchedule.ScheduleID;
                cmd.Parameters["@ScheduleID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@ScheduleName", SqlDbType.VarChar, 100).Value = objSchedule.ScheduleName;
                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = objSchedule.SocID;
                cmd.Parameters.Add("@SchType", SqlDbType.VarChar, 20).Value = objSchedule.SchType;


                cmd.ExecuteNonQuery();

                //after updating the Schedule, update ID
                objSchedule.ID = Convert.ToInt32(cmd.Parameters["@ID"].Value);
                objSchedule.ScheduleID = Convert.ToInt32(cmd.Parameters["@ScheduleID"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteSchedule(int ID, int SocID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from Schedule where ScheduleID=@ID and SocID=@SocID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = ID;
                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = SocID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        #endregion
    }
}
