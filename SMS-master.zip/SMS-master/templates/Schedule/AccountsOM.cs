using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

    [Serializable]
    [Table(Name = "dbo.Accounts")]
    public class Accounts
    {

        private System.Nullable<int> _AccountID;
        private string _AccountName;
        private string _AccountType;
        private System.Nullable<decimal> _CrAmount;
        private System.Nullable<decimal> _DrAmount;
        private System.Nullable<int> _ID;
        private string _PrintName;
        private System.Nullable<int> _ScheduleID;
        private System.Nullable<int> _SocID;
        private Nullable<bool> _IsEditable;
        private string _AccountGroup;
        private System.Nullable<int> _OrgID;
        private System.Nullable<int> _ChgID;
        private System.Nullable<int> _VendorID;
        private System.Nullable<decimal> _DrAmountInt;

        [Column(Storage = "_DrAmountInt")]
        public System.Nullable<decimal> DrAmountInt
        {
            get { return _DrAmountInt; }
            set { _DrAmountInt = value; }
        }

        [Column(Storage = "_VendorID")]
        public System.Nullable<int> VendorID
        {
            get { return _VendorID; }
            set { _VendorID = value; }
        }

        [Column(Storage = "_ChgID")]
        public System.Nullable<int> ChgID
        {
            get { return _ChgID; }
            set { _ChgID = value; }
        }

        [Column(Storage = "_OrgID")]
        public System.Nullable<int> OrgID
        {
            get { return _OrgID; }
            set { _OrgID = value; }
        }

        [Column(Storage = "_AccountGroup")]
        public string AccountGroup
        {
            get { return _AccountGroup; }
            set { _AccountGroup = value; }
        }

        [Column(Storage = "_IsEditable")]
        public Nullable<bool> IsEditable
        {
            get { return _IsEditable; }
            set { _IsEditable = value; }
        }

        [Column(Storage = "_AccountID")]
        public System.Nullable<int> AccountID
        {
            get
            {
                return _AccountID;
            }
            set
            {
                _AccountID = value;
            }
        }

        [Column(Storage = "_AccountName")]
        public string AccountName
        {
            get
            {
                return _AccountName;
            }
            set
            {
                _AccountName = value;
            }
        }

        [Column(Storage = "_AccountType")]
        public string AccountType
        {
            get
            {
                return _AccountType;
            }
            set
            {
                _AccountType = value;
            }
        }

        [Column(Storage = "_CrAmount")]
        public System.Nullable<decimal> CrAmount
        {
            get
            {
                return _CrAmount;
            }
            set
            {
                _CrAmount = value;
            }
        }

        [Column(Storage = "_DrAmount")]
        public System.Nullable<decimal> DrAmount
        {
            get
            {
                return _DrAmount;
            }
            set
            {
                _DrAmount = value;
            }
        }

        [Column(Storage = "_ID")]
        public System.Nullable<int> ID
        {
            get
            {
                return _ID;
            }
            set
            {
                _ID = value;
            }
        }

        [Column(Storage = "_PrintName")]
        public string PrintName
        {
            get
            {
                return _PrintName;
            }
            set
            {
                _PrintName = value;
            }
        }

        [Column(Storage = "_ScheduleID")]
        public System.Nullable<int> ScheduleID
        {
            get
            {
                return _ScheduleID;
            }
            set
            {
                _ScheduleID = value;
            }
        }

        [Column(Storage = "_SocID")]
        public System.Nullable<int> SocID
        {
            get
            {
                return _SocID;
            }
            set
            {
                _SocID = value;
            }
        }
    }
}
