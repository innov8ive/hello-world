using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
    [Serializable]
    public class AccountsBL
    {

        #region Declaration
        private string connectionString;
        Accounts _Accounts;
        public Accounts Data
        {
            get { return _Accounts; }
            set { _Accounts = value; }
        }
        public bool IsNew
        {
            get { return (_Accounts.ID <= 0 || _Accounts.ID == null); }
        }
        #endregion

        #region Constructor
        public AccountsBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private AccountsDL CreateDL()
        {
            return new AccountsDL(connectionString);
        }
        public void New()
        {
            _Accounts = new Accounts();
        }
        public void Load(int ID, int SocID)
        {
            var AccountsObj = this.CreateDL();
            _Accounts = ID <= 0 ? AccountsObj.Load(-1, SocID) : AccountsObj.Load(ID, SocID);
        }
        public Accounts LoadByOrgID(int orgID)
        {
            var AccountsDLObj = CreateDL();
            return AccountsDLObj.LoadByOrgID(orgID);
        }
        public DataTable LoadAllAccounts()
        {
            var AccountsDLObj = CreateDL();
            return AccountsDLObj.LoadAllAccounts();
        }
        public bool Update()
        {
            var AccountsDLObj = CreateDL();
            return AccountsDLObj.Update(this.Data);
        }
        public bool Delete(int ID, int SocID)
        {
            var AccountsDLObj = CreateDL();
            return AccountsDLObj.Delete(ID, SocID);
        }
        #endregion
    }
}
