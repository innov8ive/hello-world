using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;

namespace SampleAngular.Api
{
    public class ScheduleController : ApiController
    {
        DataTable dtGL;
        DataTable dtGroup;
        [Route("api/GetScheduleList/")]
        [HttpPost]
        public string GetScheduleList([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.ChartsofAccount, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            bool onlyGroup = Common.ToBool(value.onlyGroup);

            dtGroup = Common.GetDBResultParameterized("Select * from Schedule where SocID=" + objLoggedUser.SocID);
            dtGL = Common.GetDBResultParameterized("Select * from Accounts where SocID=" + objLoggedUser.SocID);

            List<ScheduleNode> treeNodes = new List<ScheduleNode>();
            foreach (DataRow dr in dtGroup.Select("MasterScheduleID=0"))
            {
                ScheduleNode node = new ScheduleNode();
                node.ID = Common.ToInt(dr["ID"]);
                node.ScheduleID = Common.ToInt(dr["ScheduleID"]);
                node.text = Common.ToString(dr["ScheduleName"]);
                node.ItemType = Common.ToString(dr["SchType"]);
                node.Type = "Main";
                node.icon = "fa fa-folder";
                node.color = "#1d9d74";
                node.nodes = new List<ScheduleNode>();
                AddScheduleNode(node.ScheduleID, node, onlyGroup);
                treeNodes.Add(node);
            }
            return JsonConvert.SerializeObject(treeNodes);
        }

        private void AddScheduleNode(int ScheduleID, ScheduleNode node,bool onlyGroup)
        {
            foreach (DataRow dr in dtGroup.Select("MasterScheduleID=" + ScheduleID))
            {
                ScheduleNode childNode = new ScheduleNode();
                childNode.ID = Common.ToInt(dr["ID"]);
                childNode.ScheduleID = Common.ToInt(dr["ScheduleID"]);
                childNode.text = Common.ToString(dr["ScheduleName"]);
                childNode.ItemType = Common.ToString(dr["SchType"]);
                childNode.Type = "Sub";
                childNode.icon = "fa fa-folder-open";
                childNode.color = "#563d7c";
                childNode.nodes = new List<ScheduleNode>();
                AddScheduleNode(childNode.ScheduleID, childNode, onlyGroup);
                node.nodes.Add(childNode);
            }
            if (onlyGroup == false)
            {
                foreach (DataRow dr in dtGL.Select("ScheduleID=" + ScheduleID))
                {
                    ScheduleNode childNode = new ScheduleNode();
                    childNode.ID = Common.ToInt(dr["AccountID"]);
                    childNode.ScheduleID = Common.ToInt(dr["ScheduleID"]);
                    childNode.text = Common.ToString(dr["AccountName"]);
                    childNode.ItemType = Common.ToString(dr["AccountType"]);
                    childNode.Type = "Account";
                    childNode.icon = "fa fa-file-text-o";
                    childNode.color = "#e44b23";
                    node.nodes.Add(childNode);
                }
            }
            if (node.nodes.Count == 0)
                node.nodes = null;
        }
        private void AddGLNode(int ScheduleID, ScheduleNode node)
        {
            node.nodes = new List<ScheduleNode>();
            foreach (DataRow dr in dtGL.Select("ScheduleID=" + ScheduleID))
            {
                ScheduleNode childNode = new ScheduleNode();
                childNode.ID = Common.ToInt(dr["AccountsID"]);
                childNode.ScheduleID = Common.ToInt(dr["ScheduleID"]);
                childNode.text = Common.ToString(dr["AccountName"]);
                childNode.Type = "Account";
                node.nodes.Add(childNode);
            }
            if (node.nodes.Count == 0)
                node.nodes = null;
        }      

        // GET api/Schedule
        [Route("api/ScheduleList/")]
        [HttpPost]
        public AngularGridData GetSchedule([FromBody]dynamic value)
        {
            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = "Select * from Schedule";
            objAngularDataBinder.ValueField = "ID";
            return objAngularDataBinder.GetData();
        }

        [Route("api/GetScheduleDetails/")]
        [HttpPost]
        public string GetScheduleDetails([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.ChartsofAccount, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            int Id = Common.ToInt(value.ID);
            int MasterID = Common.ToInt(value.MasterID);

            ScheduleBL objScheduleBL = new ScheduleBL(Common.GetConString());
            if (Id == 0)
            {
                objScheduleBL.Load(MasterID, objLoggedUser.SocID);
                if (Common.ToInt(objScheduleBL.Data.SocID) == 0 || (Common.ToInt(objScheduleBL.Data.SocID) > 0 && objScheduleBL.Data.SocID != objLoggedUser.SocID))
                    throw new HttpResponseException(HttpStatusCode.Unauthorized);

                //sub group has sub group
                int countChildAccounts = Common.ToInt(Common.GetDBScalar("Select COUNT(*) from Accounts where ScheduleID=" + MasterID + " and SocID = " + objLoggedUser.SocID));
                if (objScheduleBL.Data.MasterScheduleID == 0 || (objScheduleBL.Data.MasterScheduleID > 0 && countChildAccounts == 0))
                {
                    string nature = objScheduleBL.Data.Nature;
                    string bpt = objScheduleBL.Data.BPT;
                    objScheduleBL.Load(0, objLoggedUser.SocID);
                    objScheduleBL.Data.MasterScheduleID = MasterID;
                    objScheduleBL.Data.Nature = nature;
                    objScheduleBL.Data.BPT = bpt;
                }
                else
                {
                    throw new HttpResponseException(HttpStatusCode.Unauthorized);
                }
            }
            else
            {
                objScheduleBL.Load(Id, objLoggedUser.SocID);
                if (Common.ToInt(objScheduleBL.Data.SocID) > 0 && objScheduleBL.Data.SocID != objLoggedUser.SocID)
                    throw new HttpResponseException(HttpStatusCode.Unauthorized);
            }

            return JsonConvert.SerializeObject(objScheduleBL.Data);
        }

        // POST api/Schedule/
        public string Post([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.ChartsofAccount, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            Schedule objSchedule = objJObject.ToObject<Schedule>();
            ScheduleBL objScheduleBL = new ScheduleBL(Common.GetConString());
            objScheduleBL.Data = objSchedule;

            if (Common.ToInt(objScheduleBL.Data.SocID) > 0 && objScheduleBL.Data.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            if (objScheduleBL.IsNew)
            {
                objSchedule.SocID = objLoggedUser.SocID;
            }
            ScheduleValidator validator = new ScheduleValidator();
            ValidationResult results = validator.Validate(objSchedule);

            if (results.IsValid)
            {
                objScheduleBL.Update();
                return JsonConvert.SerializeObject(objScheduleBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        // DELETE api/Schedule/5
        [Route("api/Schedule/{Id}")]
        [HttpDelete]
        public string Delete(int Id)
        {
            Common.IsValidForm(Constants.Forms.ChartsofAccount, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            int countChildGroup = Common.ToInt(Common.GetDBScalar("Select COUNT(*) from Schedule where MasterScheduleID=" + Id + " and SocID = " + objLoggedUser.SocID));
            int countChildAccounts = Common.ToInt(Common.GetDBScalar("Select COUNT(*) from Accounts where ScheduleID=" + Id + " and SocID = " + objLoggedUser.SocID));
            int countVT = Common.ToInt(Common.GetDBScalar("Select COUNT(*) from VoucherType where (DrScheduleID=" + Id + " OR CrScheduleID=" + Id + ") and SocID = " + objLoggedUser.SocID));


            ScheduleBL objScheduleBL = new ScheduleBL(Common.GetConString());
            objScheduleBL.Load(Id, objLoggedUser.SocID);
            if (Common.ToInt(objScheduleBL.Data.SocID) > 0 && objScheduleBL.Data.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            if (!String.IsNullOrEmpty(objScheduleBL.Data.SchType))
                return "You cannot delete this Sub Group!";

            if (countChildGroup > 0 || countChildAccounts > 0)
            {
                return "You cannot delete this Sub Group!";
            }
            else
            {
                bool result = objScheduleBL.Delete(Id, objLoggedUser.SocID);
                if (result)
                    return String.Empty;
                else
                    return "Sub Group not deleted!";
            }
        }
    }
    public class ScheduleValidator : AbstractValidator<Schedule>
    {
        public ScheduleValidator()
        {
            RuleFor(obj => obj.BPT).NotEmpty();
            RuleFor(obj => obj.MasterScheduleID).NotEmpty();
            RuleFor(obj => obj.Nature).NotEmpty();
            RuleFor(obj => obj.ScheduleName).NotEmpty();
        }
    }
    public class ScheduleNode
    {
        public string text { get; set; }
        public int ID { get; set; }
        public int ScheduleID { get; set; }
        public string Type { get; set; }
        public string ItemType { get; set; }
        public string icon { get; set; }
        public string color { get; set; }
        public List<ScheduleNode> nodes { get; set; }
    }
}

