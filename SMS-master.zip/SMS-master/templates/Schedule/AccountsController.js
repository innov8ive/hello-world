var app = angular.module('myApp');
app.controller('AccountsCtrl', function ($scope, $http, $location, $routeParams) {
    var ID = $routeParams.ID;
    var ScheduleID = $routeParams.ScheduleID;
    $scope.Accounts = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.AccountsSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.AccountsSubmitted = true;
        if ($scope.formAccounts.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/Accounts', $scope.Accounts, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.Accounts = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/ScheduleList');
    }

    setTimeout(function () {
        $http({
            method: 'POST',
            url: 'api/GetAccountDetails/',
            data: JSON.stringify({ ID: ID, ScheduleID: ScheduleID })
        }).success(function (Accounts) {
            $scope.Accounts = JSON.parse(Accounts);
        });
    }, 100);
});
