using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
    [Serializable]
    public class ScheduleBL
    {

        #region Declaration
        private string connectionString;
        Schedule _Schedule;
        public Schedule Data
        {
            get { return _Schedule; }
            set { _Schedule = value; }
        }
        public bool IsNew
        {
            get { return (_Schedule.ID <= 0 || _Schedule.ID == null); }
        }
        #endregion

        #region Constructor
        public ScheduleBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private ScheduleDL CreateDL()
        {
            return new ScheduleDL(connectionString);
        }
        public void New()
        {
            _Schedule = new Schedule();
        }
        public void Load(int ID, int SocID)
        {
            var ScheduleObj = this.CreateDL();
            _Schedule = ID <= 0 ? ScheduleObj.Load(-1, SocID) : ScheduleObj.Load(ID, SocID);
        }
        public DataTable LoadAllSchedule()
        {
            var ScheduleDLObj = CreateDL();
            return ScheduleDLObj.LoadAllSchedule();
        }
        public bool Update()
        {
            var ScheduleDLObj = CreateDL();
            return ScheduleDLObj.Update(this.Data);
        }
        public bool Delete(int ID, int SocID)
        {
            var ScheduleDLObj = CreateDL();
            return ScheduleDLObj.Delete(ID, SocID);
        }
        #endregion
    }
}
