var app = angular.module('myApp');

app.controller('ScheduleListCtrl', function ($scope, $http, $location) {
    var tree = [];
    var Schedules = [];
    $scope.filter = {};
    $scope.editModeSchedule = false;
    $scope.searchSchedule = function () {
        $('#tree').treeview('collapseAll', { silent: true });
        $('#tree').treeview('search', [$scope.filter.filterText, {
            ignoreCase: true,     // case insensitive
            exactMatch: false,    // like or equals
            revealResults: true,  // reveal matching nodes
        }]);
    };

    $scope.newSchedule = function () {
        var selectedNodes = $('#tree').treeview(true).getSelected();
        if (selectedNodes.length > 0) {
            var node = selectedNodes[0];
            if (node.Type == 'Main' || (node.Type == 'Sub' && (node.nodes == null
                || findByValue(node.nodes, 'Type', 'Account', 1).length == 0))) {
                $location.path('/Schedule/0/' + node.ScheduleID);
            }
            else {
                alert('Please select a Group to Add new Sub Group.');
            }
        }
        else {
            alert('Please select a Group to Add new Sub Group.');
        }
    };
    $scope.newAccount = function () {
        var selectedNodes = $('#tree').treeview(true).getSelected();
        if (selectedNodes.length > 0) {
            var node = selectedNodes[0];
            if (node.Type == 'Sub' && (node.nodes == null || findByValue(node.nodes, 'Type', 'Sub', 1).length == 0)) {
                $location.path('/Accounts/0/' + node.ScheduleID);
            }
            else {
                alert('Please select a Sub-Group to Add new Account.');
            }
        }
        else {
            alert('Please select a Sub-Group to Add new Account.');
        }
    };
    $scope.editSchedule = function () {
        var selectedNode = $('#tree').treeview(true).getSelected();
        if (selectedNode.length > 0) {
            if (selectedNode[0].ItemType != '' && selectedNode[0].Type == 'Sub') {
                alert('You cannot Edit this Item');
            }
            else if (selectedNode[0].Type == 'Sub') {
                $location.path('/Schedule/' + selectedNode[0].ScheduleID + '/0');
            }
            else if (selectedNode[0].Type == 'Account') {
                $location.path('/Accounts/' + selectedNode[0].ID + '/' + selectedNode[0].ScheduleID);
            }
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.deleteSchedule = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        var selectedNode = $('#tree').treeview(true).getSelected();
        if (selectedNode.length > 0) {
            if (selectedNode[0].ItemType != '') {
                alert('You cannot Delete this Item');
            }
            else if (selectedNode[0].Type == 'Sub') {
                $http({
                    method: 'DELETE',
                    url: 'api/Schedule/' + selectedNode[0].ScheduleID
                }).success(function (result) {
                    if (result.length == 0) {
                        loadScheduleList();
                        swal({ title: "Record deleted successfully!", type: "success", timer: 1000, showConfirmButton: false });
                    }
                    else
                        alert(result);
                });
            }
            else if (selectedNode[0].Type == 'Account') {
                $http({
                    method: 'DELETE',
                    url: 'api/Accounts/' + selectedNode[0].ID
                }).success(function (result) {
                    if (result.length == 0) {
                        loadScheduleList();
                        swal({ title: "Record deleted successfully!", type: "success", timer: 1000, showConfirmButton: false });
                    }
                    else
                        alert(result);
                });
            }
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    window.setTimeout(function () {
        loadScheduleList();
    }, 200);
    var loadScheduleList = function () {
        $http({
            method: 'POST',
            url: 'api/GetScheduleList',
            data: JSON.stringify({ onlyGroup: false })
        }).success(function (result) {
            tree = JSON.parse(result);
            $('#tree').treeview({
                data: tree,
                onNodeSelected: function (event, data) {

                }
            });
            $('#tree').treeview('expandAll', { silent: true });
        });
    }
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.updateSchedule = function () {
        $scope.ScheduleSubmitted = true;
        if ($scope.formSchedule.$invalid == true) return;
        $http.post('api/Schedule', $scope.Schedule, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.Schedule = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
                $scope.editModeSchedule = false;
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };
})

.controller('ScheduleCtrl', function ($scope, $http, $location, $routeParams) {
    var ID = $routeParams.ID;
    var MasterID = $routeParams.MasterID;
    $scope.Schedule = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.ScheduleSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.ScheduleSubmitted = true;
        if ($scope.formSchedule.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/Schedule', $scope.Schedule, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.Schedule = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/ScheduleList');
    }

    setTimeout(function () {
        $http({
            method: 'POST',
            url: 'api/GetScheduleDetails/',
            data: JSON.stringify({ ID: ID, MasterID: MasterID })
        }).success(function (Schedule) {
            $scope.Schedule = JSON.parse(Schedule);
        });
    }, 100);
});
