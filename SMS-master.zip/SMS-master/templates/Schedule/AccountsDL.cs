using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
    public class AccountsDL
    {

        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public AccountsDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public Accounts Load(int ID, int SocID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            Accounts objAccounts = new Accounts();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get Accounts
                var resultAccounts = dc.ExecuteQuery<Accounts>("exec Get_Accounts {0},{1}", ID, SocID).ToList();
                if (resultAccounts.Count > 0)
                {
                    objAccounts = resultAccounts[0];
                }
                dc.Dispose();
                return objAccounts;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public Accounts LoadByOrgID(int orgID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            Accounts objAccounts = new Accounts();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get Accounts
                var resultAccounts = dc.ExecuteQuery<Accounts>("exec Get_Accounts_ByOrgID {0}", orgID).ToList();
                if (resultAccounts.Count > 0)
                {
                    objAccounts = resultAccounts[0];
                }
                dc.Dispose();
                return objAccounts;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }

        public Accounts LoadByVendorID(int VendorID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            Accounts objAccounts = new Accounts();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get Accounts
                var resultAccounts = dc.ExecuteQuery<Accounts>("exec Get_Accounts_ByVendorID {0}", VendorID).ToList();
                if (resultAccounts.Count > 0)
                {
                    objAccounts = resultAccounts[0];
                }
                dc.Dispose();
                return objAccounts;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
      
        public DataTable LoadAllAccounts()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_Accounts", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(Accounts objAccounts)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update Accounts
                UpdateAccounts(objAccounts, trn);
                if (objAccounts.ID > 0)
                {

                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int ID, int SocID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete Accounts
                DeleteAccounts(ID, SocID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateAccounts(Accounts objAccounts, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_Accounts", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@AccountID", SqlDbType.Int).Value = objAccounts.AccountID;
                cmd.Parameters["@AccountID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@AccountName", SqlDbType.VarChar, 200).Value = objAccounts.AccountName;
                cmd.Parameters.Add("@AccountType", SqlDbType.VarChar, 1000).Value = objAccounts.AccountType;
                cmd.Parameters.Add("@CrAmount", SqlDbType.Decimal).Value = objAccounts.CrAmount;
                cmd.Parameters.Add("@DrAmount", SqlDbType.Decimal).Value = objAccounts.DrAmount;
                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = objAccounts.ID;
                cmd.Parameters["@ID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@PrintName", SqlDbType.VarChar, 500).Value = objAccounts.PrintName;
                cmd.Parameters.Add("@ScheduleID", SqlDbType.Int).Value = objAccounts.ScheduleID;
                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = objAccounts.SocID;
                cmd.Parameters.Add("@OrgID", SqlDbType.Int).Value = objAccounts.OrgID;
                cmd.Parameters.Add("@ChgID", SqlDbType.Int).Value = objAccounts.ChgID;
                cmd.Parameters.Add("@VendorID", SqlDbType.Int).Value = objAccounts.VendorID;
                cmd.Parameters.Add("@DrAmountInt", SqlDbType.Decimal).Value = objAccounts.DrAmountInt;

                cmd.ExecuteNonQuery();

                //after updating the Accounts, update ID
                objAccounts.ID = Convert.ToInt32(cmd.Parameters["@ID"].Value);
                objAccounts.AccountID = Convert.ToInt32(cmd.Parameters["@AccountID"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteAccounts(int ID, int SocID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from Accounts where AccountID=@ID and SocID=@SocID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = ID;
                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = SocID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        #endregion
    }
}
