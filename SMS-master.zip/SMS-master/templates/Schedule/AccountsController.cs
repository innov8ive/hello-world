using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;

namespace SampleAngular.Api
{
    public class AccountsController : ApiController
    {
        // GET api/Accounts
        [Route("api/AccountsList/")]
        [HttpPost]
        public AngularGridData GetAccounts([FromBody]dynamic value)
        {
            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = "Select * from Accounts";
            objAngularDataBinder.ValueField = "ID";
            return objAngularDataBinder.GetData();
        }

        [Route("api/GetAccountDetails/")]
        [HttpPost]
        public string GetAccountDetails([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.ChartsofAccount, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            int Id = Common.ToInt(value.ID);
            int ScheduleID = Common.ToInt(value.ScheduleID);
            AccountsBL objAccountsBL = new AccountsBL(Common.GetConString());
            ScheduleBL objScheduleBL = new ScheduleBL(Common.GetConString());

            if (Id == 0)
            {
                objScheduleBL.Load(ScheduleID, objLoggedUser.SocID);
                if (Common.ToInt(objScheduleBL.Data.SocID) == 0 || (Common.ToInt(objScheduleBL.Data.SocID) > 0 && objScheduleBL.Data.SocID != objLoggedUser.SocID))
                    throw new HttpResponseException(HttpStatusCode.Unauthorized);

                //sub group has accounts
                int countChildGroup = Common.ToInt(Common.GetDBScalar("Select COUNT(*) from Schedule where MasterScheduleID=" + ScheduleID + " and SocID = " + objLoggedUser.SocID));

                if (objScheduleBL.Data.MasterScheduleID > 0 && countChildGroup == 0)
                {
                    objAccountsBL.Load(0, objLoggedUser.SocID);
                    objAccountsBL.Data.ScheduleID = ScheduleID;
                    //objAccountsBL.Data.AccountType = objScheduleBL.Data.SchType;
                    objAccountsBL.Data.AccountGroup = objScheduleBL.Data.ScheduleName;
                    objAccountsBL.Data.IsEditable = true;
                }
                else
                {
                    throw new HttpResponseException(HttpStatusCode.Unauthorized);
                }
            }
            else
            {
                objAccountsBL.Load(Id, objLoggedUser.SocID);

                objAccountsBL.Data.IsEditable = Common.ToInt(Common.GetDBScalar("Select COUNT(*) from GE where CompanyID=@SocID and GLID=@AccountID",
                    "@SocID", SqlDbType.Int, objLoggedUser.SocID,
                    "@AccountID", SqlDbType.Int, objAccountsBL.Data.AccountID)) <= 0;
                if (Common.ToInt(objAccountsBL.Data.SocID) > 0 && objAccountsBL.Data.SocID != objLoggedUser.SocID)
                    throw new HttpResponseException(HttpStatusCode.Unauthorized);
            }

            return JsonConvert.SerializeObject(objAccountsBL.Data);
        }

        // POST api/Accounts/
        public string Post([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.ChartsofAccount, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            Accounts objAccounts = objJObject.ToObject<Accounts>();
            AccountsBL objAccountsBL = new AccountsBL(Common.GetConString());
            objAccountsBL.Data = objAccounts;

            if (Common.ToInt(objAccountsBL.Data.SocID) > 0 && objAccountsBL.Data.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            if (objAccountsBL.IsNew)
            {
                objAccounts.SocID = objLoggedUser.SocID;
            }

            AccountsValidator validator = new AccountsValidator();
            ValidationResult results = validator.Validate(objAccounts);

            if (results.IsValid)
            {
                objAccountsBL.Update();
                return JsonConvert.SerializeObject(objAccountsBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        // DELETE api/Accounts/5
        [Route("api/Accounts/{Id}")]
        [HttpDelete]
        public string Delete(int Id)
        {
            Common.IsValidForm(Constants.Forms.ChartsofAccount, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            int countGE = Common.ToInt(Common.GetDBScalar("Select COUNT(*) from GE where AccountID=" + Id + " and SocID = " + objLoggedUser.SocID));

            AccountsBL objAccountsBL = new AccountsBL(Common.GetConString());
            objAccountsBL.Load(Id, objLoggedUser.SocID);
            if (Common.ToInt(objAccountsBL.Data.SocID) > 0 && objAccountsBL.Data.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            if (!String.IsNullOrEmpty(objAccountsBL.Data.AccountType))
                return "You cannot delete this Account!";

            if (countGE > 0)
            {
                return "You cannot delete this Account!";
            }
            else if (Common.ToInt(objAccountsBL.Data.OrgID) > 0 || Common.ToInt(objAccountsBL.Data.ChgID) > 0)
            {
                return "You cannot delete this Account!";
            }
            else
            {
                bool result = objAccountsBL.Delete(Id, objLoggedUser.SocID);
                if (result)
                    return String.Empty;
                else
                    return "Account not deleted!";
            }
        }
    }
    public class AccountsValidator : AbstractValidator<Accounts>
    {
        public AccountsValidator()
        {
            RuleFor(obj => obj.AccountName).NotEmpty();
            RuleFor(obj => obj.ScheduleID).NotEmpty();
        }
    }
}

