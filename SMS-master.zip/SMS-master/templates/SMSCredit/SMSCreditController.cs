using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;

namespace SampleAngular.Api
{
public class SMSCreditController : ApiController
{
// GET api/SMSCredit
[Route("api/SMSCreditList/")]
[HttpPost]
public AngularGridData GetSMSCredit([FromBody]dynamic value)
{
JObject objJObject = value;
AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
objAngularDataBinder.Query = "Select * from SMSCredit";
objAngularDataBinder.ValueField = "ID";
return objAngularDataBinder.GetData();
}

// GET api/SMSCredit/Id
[Route("api/SMSCredit/{Id}")]
public string GetSMSCredit(int Id)
{
SMSCreditBL objSMSCreditBL = new SMSCreditBL(Common.GetConString());
objSMSCreditBL.Load(Id);
return JsonConvert.SerializeObject(objSMSCreditBL.Data);
}

// POST api/SMSCredit/
public string Post([FromBody]dynamic value)
{
JObject objJObject = value;
SMSCredit objSMSCredit = objJObject.ToObject<SMSCredit>();
SMSCreditBL objSMSCreditBL = new SMSCreditBL(Common.GetConString());
objSMSCreditBL.Data = objSMSCredit;

SMSCreditValidator validator = new SMSCreditValidator();
ValidationResult results = validator.Validate(objSMSCredit);

if (results.IsValid)
{
objSMSCreditBL.Update();
return JsonConvert.SerializeObject(objSMSCreditBL.Data);
}

return JsonConvert.SerializeObject(results.Errors);
}

// DELETE api/SMSCredit/5
[Route("api/SMSCredit/{Id}")]
[HttpDelete]
public bool Delete(int Id)
{
SMSCreditBL objSMSCreditBL = new SMSCreditBL(Common.GetConString());
return objSMSCreditBL.Delete(Id);
}
}
public class SMSCreditValidator : AbstractValidator<SMSCredit>
{
public SMSCreditValidator()
{

RuleFor(obj => obj.Credit).NotEmpty();
RuleFor(obj => obj.CreditDate).NotEmpty();
RuleFor(obj => obj.Remarks).NotEmpty();
RuleFor(obj => obj.SocID).NotEmpty();}
}
}

