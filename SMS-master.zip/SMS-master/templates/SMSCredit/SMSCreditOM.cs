using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

[Serializable][Table(Name = "dbo.SMSCredit")]public class SMSCredit{
private System.Nullable<int> _Credit;
private System.Nullable<DateTime> _CreditDate;
private System.Nullable<int> _ID;
private string _Remarks;
private System.Nullable<int> _SocID;
 
[Column(Storage = "_Credit")]
public System.Nullable<int> Credit{get {return _Credit;}set { _Credit=value;}}
[Column(Storage = "_CreditDate")]
public System.Nullable<DateTime> CreditDate{get {return _CreditDate;}set { _CreditDate=value;}}
[Column(Storage = "_ID")]
public System.Nullable<int> ID{get {return _ID;}set { _ID=value;}}
[Column(Storage = "_Remarks")]
public string Remarks{get {return _Remarks;}set { _Remarks=value;}}
[Column(Storage = "_SocID")]
public System.Nullable<int> SocID{get {return _SocID;}set { _SocID=value;}}
}}
