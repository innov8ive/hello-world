using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
[Serializable]
public class SMSCreditBL
{

#region Declaration
private string connectionString;
SMSCredit _SMSCredit;
public SMSCredit Data
{
get { return _SMSCredit; }
set { _SMSCredit = value; }
}
public bool IsNew
{
get { return (_SMSCredit.ID <= 0 || _SMSCredit.ID ==null); }
}
#endregion

#region Constructor
public SMSCreditBL(string conString)
{
connectionString = conString;
}
#endregion

#region Main Methods
private SMSCreditDL CreateDL()
{
return new SMSCreditDL(connectionString);
}
public void New()
{
_SMSCredit = new SMSCredit();
}
public void Load(int ID)
{
var SMSCreditObj = this.CreateDL();
_SMSCredit = ID <= 0 ? SMSCreditObj.Load(-1) : SMSCreditObj.Load(ID);
}
public DataTable LoadAllSMSCredit()
{
var SMSCreditDLObj = CreateDL();
return SMSCreditDLObj.LoadAllSMSCredit();
}
public bool Update()
{
var SMSCreditDLObj = CreateDL();
return SMSCreditDLObj.Update(this.Data);
}
public bool Delete(int ID)
{
var SMSCreditDLObj = CreateDL();
return SMSCreditDLObj.Delete(ID);
}
#endregion
}
}
