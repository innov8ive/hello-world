using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
public class SMSCreditDL
{

#region Private Members
private string connectionString;
#endregion

#region Constructor
public SMSCreditDL(string conString)
{
connectionString = conString;
}
#endregion

#region Main Methods
public SMSCredit Load(int ID)
{
SqlConnection SqlCon = new SqlConnection(connectionString);
SMSCredit objSMSCredit = new SMSCredit();
var dc = new DataContext(SqlCon);
try
{
//Get SMSCredit
var resultSMSCredit = dc.ExecuteQuery<SMSCredit>("exec Get_SMSCredit {0}", ID).ToList();
if (resultSMSCredit.Count > 0)
{
objSMSCredit = resultSMSCredit[0];
}
dc.Dispose();
return objSMSCredit;
}
catch (Exception ex)
{
throw new Exception(ex.Message);
}
finally
{
if (SqlCon.State == ConnectionState.Open)
{
SqlCon.Close();
}
SqlCon.Dispose();
}
}
public DataTable LoadAllSMSCredit()
{
DataTable dt = new DataTable();
SqlConnection con = new SqlConnection(connectionString);
SqlCommand cmd = new SqlCommand("exec Get_SMSCredit",con);

con.Open();
dt.Load(cmd.ExecuteReader());
con.Close();

return dt;
}
public bool Update(SMSCredit objSMSCredit)
{
SqlConnection con = new SqlConnection(connectionString);
con.Open();
SqlTransaction trn = con.BeginTransaction();
try
{
//update SMSCredit
UpdateSMSCredit(objSMSCredit,trn);
if (objSMSCredit.ID > 0)
{

trn.Commit();
}
return true;
}
catch
{
trn.Rollback();
return false;
}
finally
{
con.Dispose();
}
}
public bool Delete(int ID)
{
SqlConnection con = new SqlConnection(connectionString);
con.Open();
SqlTransaction trn = con.BeginTransaction();
try
{
//Delete SMSCredit
DeleteSMSCredit(ID,trn);
trn.Commit();
return true;
}
catch
{
trn.Rollback();
return false;
}
finally
{
con.Dispose();
}
}

public bool UpdateSMSCredit(SMSCredit objSMSCredit,SqlTransaction trn){SqlCommand cmd=new SqlCommand("Insert_Update_SMSCredit",trn.Connection);try{cmd.CommandType=CommandType.StoredProcedure; cmd.Transaction = trn;
cmd.Parameters.Add("@Credit",SqlDbType.Int).Value=objSMSCredit.Credit;
cmd.Parameters.Add("@CreditDate",SqlDbType.DateTime).Value=objSMSCredit.CreditDate;
cmd.Parameters.Add("@ID",SqlDbType.Int).Value=objSMSCredit.ID;
cmd.Parameters["@ID"].Direction=ParameterDirection.InputOutput;
cmd.Parameters.Add("@Remarks",SqlDbType.VarChar,500).Value=objSMSCredit.Remarks;
cmd.Parameters.Add("@SocID",SqlDbType.Int).Value=objSMSCredit.SocID;
cmd.ExecuteNonQuery();//after updating the SMSCredit, update IDobjSMSCredit.ID=Convert.ToInt32(cmd.Parameters["@ID"].Value);return true;}catch{ trn.Rollback();return false;}finally{cmd.Dispose();}}
public bool DeleteSMSCredit(int ID, SqlTransaction trn){try{SqlCommand cmd=new SqlCommand("Delete from SMSCredit where ID=@ID", trn.Connection);cmd.Transaction = trn;cmd.Parameters.Add("@ID",SqlDbType.Int).Value=ID;cmd.ExecuteNonQuery();return true;}catch{trn.Rollback();return false;}}#endregion
}
}
