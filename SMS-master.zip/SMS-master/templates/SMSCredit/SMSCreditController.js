var app = angular.module('myApp');

app.controller('SMSCreditListCtrl', function ($scope, $http, $location, GridData) {

$scope = readyAngularGrid($scope, $http, 'api/SMSCreditList', 'ID', GridData, 'SMSCredit');
$scope.gridOptions.columnDefs = [

{ displayName: 'Credit', field: 'Credit' },
{ displayName: 'CreditDate', field: 'CreditDate', cellFilter: 'date:\'dd-MMM-yyyy\'' },
{ displayName: 'Remarks', field: 'Remarks' },
{ displayName: 'SocID', field: 'SocID' },];
$scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

$scope.searchSMSCredit = function () {
$scope.filterOptions.filterText = $scope.filter.filterText;
$scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
};
$scope.newSMSCredit = function () {
saveGridData($scope, GridData, 'SMSCredit');
$location.path('/SMSCredit/0');
};
$scope.editSMSCredit = function () {
var selected = $scope.gridOptions.ngGrid.config.selectedItems;
if (selected.length > 0) {
saveGridData($scope, GridData, 'SMSCredit');
$location.path('/SMSCredit/' + selected[0].ID);
}
else {
alert('Please select a record to edit.');
}
};

$scope.deleteSMSCredit = function () {
if (confirm('Are you sure want to delete?') == false) return;
var selected = $scope.gridOptions.ngGrid.config.selectedItems;
if (selected.length > 0) {
$http({
method: 'DELETE',
url: 'api/SMSCredit/' + selected[0].ID
}).success(function (result) {
if (result == true)
$scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
});
}
else {
alert('Please select a record to edit.');
}
};
})

.controller('SMSCreditCtrl', function ($scope, $http, $location, $routeParams) {
var ID = $routeParams.ID;
$scope.SMSCredit = {};
$scope.ErrorMessages = [];
$scope.dateOptions = {changeYear: true,changeMonth: true,dateFormat: 'dd-MM-yy'};
$scope.EditMode = false;
$scope.SMSCreditSubmitted = false;
var config = {
headers: {
'Content-Type': 'application/json'
}
};
$scope.update = function () {
$scope.SMSCreditSubmitted = true;
if ($scope.formSMSCredit.$invalid == true) return;
if ($scope.EditMode == true) { alert('Please update current tab data'); return;}
$http.post('api/SMSCredit', $scope.SMSCredit, config)
.success(function (data, status, headers, config) {
var result = JSON.parse(data);
if ($.isArray(result))
$scope.ErrorMessages = result;
else {
$scope.ErrorMessages = [];
$scope.SMSCredit = result;
swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
}
})
.error(function (data, status, header, config) {
alert('error');
});
};

$scope.cancel = function () {
$location.path('/SMSCreditList');
}

setTimeout(function () {
$http({
method: 'GET',
url: 'api/SMSCredit/' + ID
}).success(function (SMSCredit) {
$scope.SMSCredit = JSON.parse(SMSCredit);
});
}, 100);
});
