using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
    public class IncomeDL
    {
        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public IncomeDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public Income Load(int IncomeID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            Income objIncome = new Income();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get Income
                var resultIncome = dc.ExecuteQuery<Income>("exec Get_Income {0}", IncomeID).ToList();
                if (resultIncome.Count > 0)
                {
                    objIncome = resultIncome[0];
                }
                dc.Dispose();
                return objIncome;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllIncome()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_Income", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(Income objIncome)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update Income
                UpdateIncome(objIncome, trn);
                if (objIncome.IncomeID > 0)
                {

                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int IncomeID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete Income
                DeleteIncome(IncomeID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateIncome(Income objIncome, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_Income", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;
                cmd.Parameters.Add("@Amount", SqlDbType.Decimal).Value = objIncome.Amount;
                cmd.Parameters.Add("@CompanyID", SqlDbType.Int).Value = objIncome.CompanyID;
                cmd.Parameters.Add("@CrGEID", SqlDbType.Int).Value = objIncome.CrGEID;
                cmd.Parameters.Add("@DrGEID", SqlDbType.Int).Value = objIncome.DrGEID;
                cmd.Parameters.Add("@IncomeID", SqlDbType.Int).Value = objIncome.IncomeID;
                cmd.Parameters["@IncomeID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@FromGLID", SqlDbType.Int).Value = objIncome.FromGLID;
                cmd.Parameters.Add("@FromGroupID", SqlDbType.Int).Value = objIncome.FromGroupID;
                cmd.Parameters.Add("@LocationID", SqlDbType.Int).Value = objIncome.LocationID;
                cmd.Parameters.Add("@RefDate", SqlDbType.DateTime).Value = objIncome.RefDate;
                cmd.Parameters.Add("@RefNo", SqlDbType.VarChar, 100).Value = objIncome.RefNo;
                cmd.Parameters["@RefNo"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@Remark", SqlDbType.VarChar, 500).Value = objIncome.Remark;
                cmd.Parameters.Add("@ToGLID", SqlDbType.Int).Value = objIncome.ToGLID;
                cmd.Parameters.Add("@WPID", SqlDbType.Int).Value = objIncome.WPID;
                cmd.Parameters.Add("@TransID", SqlDbType.Int).Value = objIncome.TransID;
                cmd.Parameters.Add("@TransNo", SqlDbType.VarChar, 100).Value = objIncome.TransNo;

                cmd.ExecuteNonQuery();

                //after updating the Income, update IncomeID
                objIncome.IncomeID = Convert.ToInt32(cmd.Parameters["@IncomeID"].Value);
                objIncome.RefNo = cmd.Parameters["@RefNo"].Value.ToString();

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteIncome(int IncomeID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from Income where IncomeID=@IncomeID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@IncomeID", SqlDbType.Int).Value = IncomeID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        #endregion
    }
}
