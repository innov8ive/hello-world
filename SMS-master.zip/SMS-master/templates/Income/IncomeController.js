var app = angular.module('myApp');

app.controller('IncomeListCtrl', function ($scope, $http, $location, GridData) {
    $scope.Filter = { IncomeType: null };
    $scope = readyAngularGrid($scope, $http, 'api/IncomeList', 'IncomeID', GridData, 'Income');
    $scope.gridOptions.columnDefs = [

    { displayName: 'Ref No.', field: 'RefNo' },
    { displayName: 'Ref Date', field: 'RefDate', cellFilter: 'date:\'dd-MMM-yyyy\'' },
    { displayName: 'Amount', field: 'Amount' },
    { displayName: 'Income Head A/C', field: 'FGL' },
    { displayName: 'Debited from A/C', field: 'TGL' },
    { displayName: 'Remark', field: 'Remark' },
    ];
    
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchIncome = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };
    $scope.newIncome = function () {
        saveGridData($scope, GridData, 'Income');
        $location.path('/Income/0');
    };
    $scope.editIncome = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            saveGridData($scope, GridData, 'Income');
            $location.path('/Income/' + selected[0].IncomeID);
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.deleteIncome = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'DELETE',
                url: 'api/Income/' + selected[0].IncomeID
            }).success(function (result) {
                if (result == true)
                    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
            });
        }
        else {
            alert('Please select a record to edit.');
        }
    };


    $scope.Incometypelist = [];
    $scope.bindIncomeType = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetOverheadGLList', Data: null, query: '18' })//In-Direct Incomeense
        }).success(function (data) {
            $scope.Incometypelist = data;
        });
    }
    $scope.bindIncomeType();
})

.controller('IncomeCtrl', function ($scope, $http, $location, $routeParams) {
    var ID = $routeParams.IncomeID;
    $scope.Income = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.IncomeSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.IncomeSubmitted = true;
        if ($scope.formIncome.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/Income', $scope.Income, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.Income = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/IncomeList');
    }

    $scope.Incometypelist = [];
    $scope.bindIncomeGroup = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetIncomeGroupList', Data: null })
        }).success(function (data) {
            $scope.Incometypelist = data;
            $scope.bindYear();
           // $scope.bindOverHead();
        });
    }
    $scope.bindIncomeGroup();
    $scope.onIncomeTypeSelected = function ($item, $select) {
       // $scope.bindOverHead(true);
    }
    $scope.overheadlist = [];
    $scope.bindOverHead = function (clear) {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetOverheadGLList', Data: null, query: $scope.Income.FromGroupID })
        }).success(function (data) {
            $scope.overheadlist = data;
            if (clear == true) $scope.Income.FromGLID = null;
        });
    };
    $scope.getText = function (model, array) {
        for (var j = 0; j < array.length; j++) {
            if (model == array[j].Key) {
                return array[j].Value;
            }
        }
        return '';
    }


    $scope.debitfromlist = [];
    $scope.bindDebitFrom = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetContraGLList', Data: null })
        }).success(function (data) {
            $scope.debitfromlist = data;
        });
    }
    $scope.bindDebitFrom();

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/Income/' + ID
        }).success(function (Income) {
            $scope.Income = JSON.parse(Income);
        });
    }, 100);
    $scope.$watch('Income', function (newVal, oldVal) {
        if (newVal.FromGroupID !== oldVal.FromGroupID) {
            $scope.bindOverHead();
        }
    }, true);
    $scope.yearlist = [];
    $scope.bindYear = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetYearList', Data: null })
        }).success(function (data) {
            $scope.yearlist = data;
        });
    };
});
