using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;
using System.IO;

namespace SampleAngular.Api
{
    public class IncomeController : ApiController
    {
        // GET api/Income
        [Route("api/IncomeList/")]
        [HttpPost]
        public AngularGridData GetIncome([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.Income, Request);
            LoggedUser objLoggedUser = HttpContext.Current.Session["LoggedUser"] as LoggedUser;

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = @"SELECT E.Amount,E.IncomeID,E.RefDate,
E.RefNo,E.Remark,F.AccountName as FGL,T.AccountName as TGL FROM Income E 
left outer join Accounts F ON E.FromGLID = F.AccountID and E.CompanyID=F.SocID
left outer join Accounts T ON E.ToGLID=T.AccountID and E.CompanyID=T.SocID where
(@FGL=0 OR E.FromGLID=@FGL) and E.CompanyID=@SocID";
            Hashtable ht = new Hashtable();
            ht["@FGL"] = Common.ToInt(0);
            ht["@SocID"] = objLoggedUser.SocID;
            objAngularDataBinder.Parameters = ht;
            objAngularDataBinder.ValueField = "IncomeID";
            return objAngularDataBinder.GetData();
        }

        // GET api/Income/Id
        [Route("api/Income/{Id}")]
        public string GetIncome(int Id)
        {
            Common.IsValidForm(Constants.Forms.Income, Request);
            LoggedUser objLoggedUser = HttpContext.Current.Session["LoggedUser"] as LoggedUser;

            IncomeBL objIncomeBL = new IncomeBL(Common.GetConString());
            objIncomeBL.Load(Id);
            if (objIncomeBL.IsNew)
            {
                objIncomeBL.Data.WPID = objLoggedUser.WPID;
            }
            if (objIncomeBL.IsNew == false && objIncomeBL.Data.CompanyID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            return JsonConvert.SerializeObject(objIncomeBL.Data);
        }

        // POST api/Income/
        public string Post([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.Income, Request);
            LoggedUser objLoggedUser = HttpContext.Current.Session["LoggedUser"] as LoggedUser;

            JObject objJObject = value;
            Income objIncome = objJObject.ToObject<Income>();
            IncomeBL objIncomeBL = new IncomeBL(Common.GetConString());
            objIncomeBL.Data = objIncome;
            bool isNew = objIncomeBL.IsNew;

            IncomeValidator validator = new IncomeValidator();
            ValidationResult results = validator.Validate(objIncome);
            if (objLoggedUser.WPID <= 0 || objIncome.WPID <= 0)
            {
                results.Errors.Add(new ValidationFailure("WPID", "Working Period Not Selected"));
            }
            if (objIncome.RefDate > objLoggedUser.EndDate || objIncome.RefDate < objLoggedUser.StartDate)
            {
                results.Errors.Add(new ValidationFailure("RefDate", "Income Date is not in Working Period Range"));
            }
            if (results.IsValid)
            {
                if (isNew)
                {
                    objIncome.CompanyID = objLoggedUser.SocID;
                }
                else
                {
                    if (objIncomeBL.Data.CompanyID != objLoggedUser.SocID)
                        throw new HttpResponseException(HttpStatusCode.Unauthorized);
                }
                if (objIncomeBL.Update())
                {
                    int GEGroupID = Common.ToInt(objIncome.IncomeGEGroupID);
                    Common.ExecuteNonQuery("delete from GE where CompanyID=" + objIncome.CompanyID + " and GEGroupID=" + GEGroupID);

                    GE objGE = GECommon.GEntry(GEGroupID, Common.ToInt(objIncome.ToGLID), Common.ToDecimal(objIncome.Amount), 0,
                        Common.ToInt(objIncome.IncomeID), objIncome.RefNo, objIncome.Remark,
                         Common.ToDate(objIncome.RefDate),
                        objLoggedUser.SocID, 0, "Income");

                    GEGroupID = Common.ToInt(objGE.GEGroupID);
                    GECommon.GEntry(GEGroupID, Common.ToInt(objIncome.FromGLID), 0, Common.ToDecimal(objIncome.Amount),
                        Common.ToInt(objIncome.IncomeID), objIncome.RefNo, objIncome.Remark,
                       Common.ToDate(objIncome.RefDate),
                        objLoggedUser.SocID, 0, "Income");

                    Common.ExecuteNonQuery("Update Income set IncomeGEGroupID=@IncomeGEGroupID where IncomeID=@IncomeID",
                        "@IncomeGEGroupID", SqlDbType.Int, GEGroupID,
                        "@IncomeID", SqlDbType.Int, Common.ToInt(objIncome.IncomeID));
                    objIncome.IncomeGEGroupID = GEGroupID;
                }

                return JsonConvert.SerializeObject(objIncomeBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        // DELETE api/Income/5
        [Route("api/Income/{Id}")]
        [HttpDelete]
        public bool Delete(int Id)
        {
            Common.IsValidForm(Constants.Forms.Income, Request);
            LoggedUser objLoggedUser = HttpContext.Current.Session["LoggedUser"] as LoggedUser;


            IncomeBL objIncomeBL = new IncomeBL(Common.GetConString());
            objIncomeBL.Load(Id);
            Income objIncome = objIncomeBL.Data;
            if (objIncome.CompanyID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            Common.ExecuteNonQuery("Delete from GE where CompanyID=" + objIncome.CompanyID + " and GEGroupID=" + Common.ToInt(objIncome.IncomeGEGroupID));
            return objIncomeBL.Delete(Id);
        }
    }
    public class IncomeValidator : AbstractValidator<Income>
    {
        public IncomeValidator()
        {
            RuleFor(obj => obj.Remark).NotEmpty();
        }
    }
}

