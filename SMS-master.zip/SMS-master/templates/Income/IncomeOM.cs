using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;

namespace SampleAngularOM
{

    [Serializable]
    [Table(Name = "dbo.Income")]
    public class Income
    {
        private System.Nullable<decimal> _Amount;
        private System.Nullable<int> _CompanyID;
        private System.Nullable<int> _CrGEID;
        private System.Nullable<int> _DrGEID;
        private System.Nullable<int> _IncomeID;
        private System.Nullable<int> _FromGLID;
        private System.Nullable<int> _FromGroupID;
        private System.Nullable<int> _LocationID;
        private System.Nullable<DateTime> _RefDate;
        private string _RefNo;
        private string _Remark;
        private System.Nullable<int> _ToGLID;
        private System.Nullable<int> _WPID;
        private System.Nullable<int> _TransID;
        private string _TransNo;
        private System.Nullable<int> _IncomeGEGroupID;

        [Column(Storage = "_IncomeGEGroupID")]
        public System.Nullable<int> IncomeGEGroupID
        {
            get { return _IncomeGEGroupID; }
            set { _IncomeGEGroupID = value; }
        }

        [Column(Storage = "_Amount")]
        public System.Nullable<decimal> Amount
        {
            get
            {
                return _Amount;
            }
            set
            {
                _Amount = value;
            }
        }
        [Column(Storage = "_CompanyID")]
        public System.Nullable<int> CompanyID
        {
            get
            {
                return _CompanyID;
            }
            set
            {
                _CompanyID = value;
            }
        }
        [Column(Storage = "_CrGEID")]
        public System.Nullable<int> CrGEID
        {
            get
            {
                return _CrGEID;
            }
            set
            {
                _CrGEID = value;
            }
        }
        [Column(Storage = "_DrGEID")]
        public System.Nullable<int> DrGEID
        {
            get
            {
                return _DrGEID;
            }
            set
            {
                _DrGEID = value;
            }
        }
        [Column(Storage = "_IncomeID")]
        public System.Nullable<int> IncomeID
        {
            get
            {
                return _IncomeID;
            }
            set
            {
                _IncomeID = value;
            }
        }
        [Column(Storage = "_FromGLID")]
        public System.Nullable<int> FromGLID
        {
            get
            {
                return _FromGLID;
            }
            set
            {
                _FromGLID = value;
            }
        }
        [Column(Storage = "_FromGroupID")]
        public System.Nullable<int> FromGroupID
        {
            get
            {
                return _FromGroupID;
            }
            set
            {
                _FromGroupID = value;
            }
        }
        [Column(Storage = "_LocationID")]
        public System.Nullable<int> LocationID
        {
            get
            {
                return _LocationID;
            }
            set
            {
                _LocationID = value;
            }
        }
        [Column(Storage = "_RefDate")]
        public System.Nullable<DateTime> RefDate
        {
            get
            {
                return _RefDate;
            }
            set
            {
                _RefDate = value;
            }
        }
        [Column(Storage = "_RefNo")]
        public string RefNo
        {
            get
            {
                return _RefNo;
            }
            set
            {
                _RefNo = value;
            }
        }
        [Column(Storage = "_Remark")]
        public string Remark
        {
            get
            {
                return _Remark;
            }
            set
            {
                _Remark = value;
            }
        }
        [Column(Storage = "_ToGLID")]
        public System.Nullable<int> ToGLID
        {
            get
            {
                return _ToGLID;
            }
            set
            {
                _ToGLID = value;
            }
        }
        [Column(Storage = "_WPID")]
        public System.Nullable<int> WPID
        {
            get
            {
                return _WPID;
            }
            set
            {
                _WPID = value;
            }
        }
        [Column(Storage = "_TransID")]
        public System.Nullable<int> TransID
        {
            get
            {
                return _TransID;
            }
            set
            {
                _TransID = value;
            }
        }
        [Column(Storage = "_TransNo")]
        public string TransNo
        {
            get
            {
                return _TransNo;
            }
            set
            {
                _TransNo = value;
            }
        }
    }


}
