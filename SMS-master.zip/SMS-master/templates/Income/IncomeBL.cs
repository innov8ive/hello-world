using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularDL;
using SampleAngularOM;

namespace SampleAngularBL
{
    [Serializable]
    public class IncomeBL
    {
        #region Declaration
        private string connectionString;
        Income _Income;
        public Income Data
        {
            get { return _Income; }
            set { _Income = value; }
        }
        public bool IsNew
        {
            get { return (_Income.IncomeID <= 0 || _Income.IncomeID == null); }
        }
        #endregion

        #region Constructor
        public IncomeBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private IncomeDL CreateDL()
        {
            return new IncomeDL(connectionString);
        }
        public void New()
        {
            _Income = new Income();
        }
        public void Load(int IncomeID)
        {
            var IncomeObj = this.CreateDL();
            _Income = IncomeID <= 0 ? IncomeObj.Load(-1) : IncomeObj.Load(IncomeID);
        }
        public DataTable LoadAllIncome()
        {
            var IncomeDLObj = CreateDL();
            return IncomeDLObj.LoadAllIncome();
        }
        public bool Update()
        {
            var IncomeDLObj = CreateDL();
            return IncomeDLObj.Update(this.Data);
        }
        public bool Delete(int IncomeID)
        {
            var IncomeDLObj = CreateDL();
            return IncomeDLObj.Delete(IncomeID);
        }
        #endregion
    }
}
