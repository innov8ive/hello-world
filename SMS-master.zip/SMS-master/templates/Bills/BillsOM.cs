using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

    [Serializable]
    [Table(Name = "dbo.Bills")]
    public class Bills
    {
        private System.Nullable<decimal> _Amount;
        private System.Nullable<DateTime> _BillDate;
        private System.Nullable<int> _BillID;
        private string _BillType;
        private System.Nullable<decimal> _Discount;
        private string _OtherChargeHead;
        private System.Nullable<decimal> _OtherCharges;
        private System.Nullable<decimal> _PaidAmount;
        private System.Nullable<DateTime> _PaidDate;
        private System.Nullable<int> _RoomID;
        private System.Nullable<int> _SocID;
        private System.Nullable<decimal> _TotalBillAmount;
        private string _Remarks;
        private Nullable<int> _PaidToGLID;
        private string _RoomNo;
        private Users _User;
        private Soc _Soc;
        private System.Nullable<decimal> _LF;
        private Nullable<int> _BSID;
        private Nullable<int> _BillGEGroupID;
        private Nullable<int> _PaidGEGroupID;
        private Nullable<int> _WPID;
        private Nullable<int> _Term;
        private Nullable<decimal> _Outstanding;
        private Nullable<bool> _IsNewBill;
        private Nullable<int> _LFGEGroupID;
        private string _BillTitle;
        private Nullable<int> _GraceDays;
        private string _DiscountReason;
        private Nullable<decimal> _Adjustment;
        private Nullable<int> _ReqID;
        private string _Status;
        private string _RejectRemarks;

        [Column(Storage = "_RejectRemarks")]
        public string RejectRemarks
        {
            get { return _RejectRemarks; }
            set { _RejectRemarks = value; }
        }

        [Column(Storage = "_Status")]
        public string Status
        {
            get { return _Status; }
            set { _Status = value; }
        }

        [Column(Storage = "_ReqID")]
        public Nullable<int> ReqID
        {
            get { return _ReqID; }
            set { _ReqID = value; }
        }

        [Column(Storage = "_Adjustment")]
        public Nullable<decimal> Adjustment
        {
            get { return _Adjustment; }
            set { _Adjustment = value; }
        }

        [Column(Storage = "_DiscountReason")]
        public string DiscountReason
        {
            get { return _DiscountReason; }
            set { _DiscountReason = value; }
        }

        [Column(Storage = "_GraceDays")]
        public Nullable<int> GraceDays
        {
            get { return _GraceDays; }
            set { _GraceDays = value; }
        }

        [Column(Storage = "_BillTitle")]
        public string BillTitle
        {
            get { return _BillTitle; }
            set { _BillTitle = value; }
        }

        [Column(Storage = "_LFGEGroupID")]
        public Nullable<int> LFGEGroupID
        {
            get { return _LFGEGroupID; }
            set { _LFGEGroupID = value; }
        }

        [Column(Storage = "_IsNewBill")]
        public Nullable<bool> IsNewBill
        {
            get { return _IsNewBill; }
            set { _IsNewBill = value; }
        }

        [Column(Storage = "_Outstanding")]
        public Nullable<decimal> Outstanding
        {
            get { return _Outstanding; }
            set { _Outstanding = value; }
        }

        public System.Nullable<DateTime> DueDate
        {
            get
            {
                if (_BillDate != null)
                    return _BillDate.Value.AddDays(Convert.ToInt32(_Term));
                return _BillDate;
            }
        }

        [Column(Storage = "_Term")]
        public Nullable<int> Term
        {
            get { return _Term; }
            set { _Term = value; }
        }

        [Column(Storage = "_WPID")]
        public Nullable<int> WPID
        {
            get { return _WPID; }
            set { _WPID = value; }
        }

        [Column(Storage = "_PaidGEGroupID")]
        public Nullable<int> PaidGEGroupID
        {
            get { return _PaidGEGroupID; }
            set { _PaidGEGroupID = value; }
        }

        [Column(Storage = "_BillGEGroupID")]
        public Nullable<int> BillGEGroupID
        {
            get { return _BillGEGroupID; }
            set { _BillGEGroupID = value; }
        }

        [Column(Storage = "_BSID")]
        public Nullable<int> BSID
        {
            get { return _BSID; }
            set { _BSID = value; }
        }

        [Column(Storage = "_LF")]
        public System.Nullable<decimal> LF
        {
            get { return _LF; }
            set { _LF = value; }
        }

        public Soc Soc
        {
            get { return _Soc; }
            set { _Soc = value; }
        }

        public Users User
        {
            get { return _User; }
            set { _User = value; }
        }

        [Column(Storage = "_RoomNo")]
        public string RoomNo
        {
            get { return _RoomNo; }
            set { _RoomNo = value; }
        }

        [Column(Storage = "_PaidToGLID")]
        public Nullable<int> PaidToGLID
        {
            get { return _PaidToGLID; }
            set { _PaidToGLID = value; }
        }

        [Column(Storage = "_Remarks")]
        public string Remarks
        {
            get { return _Remarks; }
            set { _Remarks = value; }
        }

        [Column(Storage = "_Amount")]
        public System.Nullable<decimal> Amount
        {
            get
            {
                return _Amount;
            }
            set
            {
                _Amount = value;
            }
        }

        [Column(Storage = "_BillDate")]
        public System.Nullable<DateTime> BillDate
        {
            get
            {
                return _BillDate;
            }
            set
            {
                _BillDate = value;
            }
        }

        [Column(Storage = "_BillID")]
        public System.Nullable<int> BillID
        {
            get
            {
                return _BillID;
            }
            set
            {
                _BillID = value;
            }
        }

        [Column(Storage = "_BillType")]
        public string BillType
        {
            get
            {
                return _BillType;
            }
            set
            {
                _BillType = value;
            }
        }

        [Column(Storage = "_Discount")]
        public System.Nullable<decimal> Discount
        {
            get
            {
                return _Discount;
            }
            set
            {
                _Discount = value;
            }
        }

        [Column(Storage = "_OtherChargeHead")]
        public string OtherChargeHead
        {
            get
            {
                return _OtherChargeHead;
            }
            set
            {
                _OtherChargeHead = value;
            }
        }

        [Column(Storage = "_OtherCharges")]
        public System.Nullable<decimal> OtherCharges
        {
            get
            {
                return _OtherCharges;
            }
            set
            {
                _OtherCharges = value;
            }
        }

        [Column(Storage = "_PaidAmount")]
        public System.Nullable<decimal> PaidAmount
        {
            get
            {
                return _PaidAmount;
            }
            set
            {
                _PaidAmount = value;
            }
        }

        [Column(Storage = "_PaidDate")]
        public System.Nullable<DateTime> PaidDate
        {
            get
            {
                return _PaidDate;
            }
            set
            {
                _PaidDate = value;
            }
        }

        [Column(Storage = "_RoomID")]
        public System.Nullable<int> RoomID
        {
            get
            {
                return _RoomID;
            }
            set
            {
                _RoomID = value;
            }
        }

        [Column(Storage = "_SocID")]
        public System.Nullable<int> SocID
        {
            get
            {
                return _SocID;
            }
            set
            {
                _SocID = value;
            }
        }

        [Column(Storage = "_TotalBillAmount")]
        public System.Nullable<decimal> TotalBillAmount
        {
            get
            {
                return _TotalBillAmount;
            }
            set
            {
                _TotalBillAmount = value;
            }
        }
        public List<BChg> BChgList { get; set; }
    }

    [Serializable]
    [Table(Name = "dbo.BChg")]
    public class BChg
    {
        private System.Nullable<int> _BillID;
        private System.Nullable<int> _ChgID;
        private System.Nullable<decimal> _Amt;
        private System.Nullable<decimal> _CRGEID;

        [Column(Storage = "_CRGEID")]
        public System.Nullable<decimal> CRGEID
        {
            get { return _CRGEID; }
            set { _CRGEID = value; }
        }

        [Column(Storage = "_Amt")]
        public System.Nullable<decimal> Amt
        {
            get { return _Amt; }
            set { _Amt = value; }
        }

        [Column(Storage = "_ChgID")]
        public System.Nullable<int> ChgID
        {
            get { return _ChgID; }
            set { _ChgID = value; }
        }

        [Column(Storage = "_BillID")]
        public System.Nullable<int> BillID
        {
            get { return _BillID; }
            set { _BillID = value; }
        }
    }
}
