var app = angular.module('myApp');

app.controller('BillsListCtrl', function ($scope, $http, $location, GridData) {

    $scope = readyAngularGrid($scope, $http, 'api/BillsList', 'BillID', GridData, 'Bills');
    $scope.gridOptions.columnDefs = [

    { displayName: 'Amount', field: 'Amount' },
    { displayName: 'BillDate', field: 'BillDate', cellFilter: 'date:\'dd-MMM-yyyy\'' },
    { displayName: 'BillType', field: 'BillType' },
    { displayName: 'Discount', field: 'Discount' },
    { displayName: 'OtherChargeHead', field: 'OtherChargeHead' },
    { displayName: 'OtherCharges', field: 'OtherCharges' },
    { displayName: 'PaidAmount', field: 'PaidAmount' },
    { displayName: 'PaidDate', field: 'PaidDate', cellFilter: 'date:\'dd-MMM-yyyy\'' },
    { displayName: 'RoomID', field: 'RoomID' },
    { displayName: 'SocID', field: 'SocID' },
    { displayName: 'TotalBillAmount', field: 'TotalBillAmount' }, ];
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchBills = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };
    $scope.newBills = function () {
        saveGridData($scope, GridData, 'Bills');
        $location.path('/Bills/0');
    };
    $scope.editBills = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            saveGridData($scope, GridData, 'Bills');
            $location.path('/Bills/' + selected[0].BillID);
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.deleteBills = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'DELETE',
                url: 'api/Bills/' + selected[0].BillID
            }).success(function (result) {
                if (result == true)
                    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
            });
        }
        else {
            alert('Please select a record to edit.');
        }
    };
});
app.controller('PendingBillsCtrl', function ($scope, $http, $location, $filter) {
    $scope.filter = { filterText: $filter('date')(new Date(), '01-MMM-yyyy') };
    $scope.BillList = [];
    $scope.bindPendingBills = function () {
        $http({
            method: 'POST',
            url: 'api/Bills/GetPendingBills/',
            data: JSON.stringify({ month: $scope.filter.filterText })
        }).success(function (res) {
            var result = JSON.parse(res);
            if ($.isArray(result))
                $scope.BillList = result;
            else {
                alert(JSON.parse(res).Error);
            }
        });
    };
    $scope.bindPendingBills();

    $scope.searchBills = function () {
        $scope.bindPendingBills();
    };
    $scope.generateBills = function () {
        if (confirm('Are you sure, you want to Generate Bills?') == true) {

            $http({
                method: 'POST',
                url: 'api/Bills/GenerateBills3/',
                data: JSON.stringify({ month: $scope.filter.filterText })
            }).success(function (result) {
                if (result.length > 0) {
                    alert(result);
                }
                else {
                    $scope.searchBills();
                }
            });
        }
    };
});
app.controller('OutstandingBillsCtrl', function ($scope, $http, GridData, $location, $filter) {

    $scope = readyAngularGrid($scope, $http, 'api/Bills/GetOutstandingBills', 'BillID', GridData, 'OustandingBills');
    $scope.gridOptions.columnDefs = [

    { displayName: 'Bill Title', field: 'BillTitle' },
    { displayName: 'Name', field: 'PersonName' },
    { displayName: 'Unit No.', field: 'RoomNo' },
    { displayName: 'Billing Month', field: 'BillingMonth' },
    { displayName: 'Bill Amount', field: 'Amount' },
    { displayName: 'Paid Amount', field: 'PaidAmount' },
    { displayName: 'Outstanding', field: 'Outstanding' }];
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');


    $scope.searchBills = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };
    $scope.bulkPayment = function () {
        $location.path('/PaymentUpload');
    };
    $scope.Bills = [];
    $scope.showPaymentWin = function (objBills) {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            var RoomID = selected[0].RoomID;
            var BillID = selected[0].BillID;
            var ReqID = selected[0].ReqID;
            $location.path('/Payments/0/' + RoomID + '/' + BillID + '/' + ReqID);
        }
        else {
            alert('Please select a record to Make Payment.');
        }

    };
    $scope.savePayment = function () {
        if ($scope.Bills.PaidToGLID == null || $scope.Bills.PaidToGLID <= 0) {
            alert('Please select Credit to A/C');
            return;
        }
        $http({
            method: 'POST',
            url: 'api/Bills/SavePayment/',
            data: JSON.stringify($scope.Bills)
        }).success(function (result) {
            $scope.showModal = false;
            $scope.bindOutstandingBills();
            swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
        });
    };
    $scope.credittolist = [];
    $scope.bindCreditTo = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetContraGLList', Data: null })
        }).success(function (data) {
            $scope.credittolist = data;
        });
    }
    $scope.bindCreditTo();

});
app.controller('PaidBillsCtrl', function ($scope, $http, $location, $filter, GridData) {
    $scope.Filter = { showOldBill: false };
    $scope = readyAngularGrid($scope, $http, 'api/Bills/GetPaidBills', 'BillID', GridData, 'PaidBills');
    $scope.gridOptions.columnDefs = [
    { displayName: 'Bill No.', field: 'BillID' },
    { displayName: 'Name', field: 'PersonName' },
    { displayName: 'Unit No.', field: 'RoomNo' },
    { displayName: 'Bill Date', field: 'BillDate', cellFilter: 'date:\'dd-MMM-yyyy\'' },
    { displayName: 'Bill Amount', field: 'TotalBillAmount' },
    { displayName: 'Paid Amount', field: 'PaidAmount' },
    { displayName: 'Paid Date', field: 'PaidDate', cellFilter: 'date:\'dd-MMM-yyyy\'' },
    { displayName: 'Adjusted?', field: 'Adjusted' }];
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchBills = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };

    $scope.printAllBills = function () {
        window.open('PrintBill.aspx', '', 'height=600,width=900');
    };
    $scope.printBill = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            var BillID = selected[0].BillID;
            window.open('PrintBill.aspx?BillID=' + BillID, '', 'height=600,width=900');
        }
        else {
            alert('Please select a record to print bill.');
        }
    };
    $scope.printAllRec = function () {
        window.open('PrintReciept.aspx', '', 'height=600,width=900');
    };
    $scope.printRec = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            var BillID = selected[0].PaymentID;
            window.open('PrintReciept.aspx?BillID=' + BillID, '', 'height=600,width=900');
        }
        else {
            alert('Please select a record to print reciept.');
        }
    };
    $scope.editRec = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            if (selected[0].PaidDate != null) {
                var PaymentID = selected[0].PaymentID;
                $location.path('/Payments/' + PaymentID + '/0/0/0');
            } else {
                alert('Payment not made of selected bill, please use "Make Payment" option.');
            }
        }
        else {
            alert('Please select a to edit reciept.');
        }
    };
    $scope.showDiscountWin = false;
    $scope.Bill = {};
    $scope.editBill = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            if (selected[0].PaidDate == null) {
                var BillID = selected[0].BillID;
                $http({
                    method: 'GET',
                    url: 'api/Bills/' + BillID
                }).success(function (result) {
                    $scope.Bill = JSON.parse(result);
                    $scope.showDiscountWin = true;
                });

            } else {
                alert('You cannot edit this Bill because Payment hes been made.');
            }
        }
        else {
            alert('Please select a to edit Bill.');
        }
    };
    $scope.updateDiscount = function () {
        if ($scope.Bill.Discount <= 0) {
            alert('Please enter Discount');
            return;
        }
        $http({
            method: 'POST',
            url: 'api/Bills/UpdateDiscount/',
            data: JSON.stringify($scope.Bill)
        }).success(function (result) {
            $scope.searchBills();
            $scope.showDiscountWin = false;
        });
    };
    $scope.deleteBill = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            if (selected[0].PaidDate == null) {
                var BillID = selected[0].BillID;
                if (confirm('Are you sure want to delete the bill') == true) {
                    $http({
                        method: 'POST',
                        url: 'api/Bills/DeleteBills/',
                        data: JSON.stringify({ BillID: BillID })
                    }).success(function (result) {
                        $scope.searchBills();
                    });
                }
            } else {
                alert('You cannot delete this Bill because hes been Payment made.');
            }
        }
        else {
            alert('Please select a to delete bill.');
        }

    };
});
app.controller('MiscBillsCtrl', function ($scope, $http, $location, $filter, GridData) {
    $scope.Filter = { showOldBill: false };
    $scope = readyAngularGrid($scope, $http, 'api/Bills/GetMiscBills', 'BillID', GridData, 'MiscBills');
    $scope.gridOptions.columnDefs = [
    { displayName: 'Bill No.', field: 'BillID' },
    { displayName: 'Bill Title', field: 'BillTitle' },
    { displayName: 'Name', field: 'PersonName' },
    { displayName: 'Unit No.', field: 'RoomNo' },
    { displayName: 'Bill Date', field: 'BillDate', cellFilter: 'date:\'dd-MMM-yyyy\'' },
    { displayName: 'Bill Amount', field: 'TotalBillAmount' },
    { displayName: 'Paid Amount', field: 'PaidAmount' },
    { displayName: 'Paid Date', field: 'PaidDate', cellFilter: 'date:\'dd-MMM-yyyy\'' }];
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchBills = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };
    $scope.createBills = function () {
        $location.path('/MiscBillDetails');
    };
    $scope.printAllBills = function () {
        window.open('PrintBill.aspx?BillTitle=' + $scope.filterOptions.filterText, '', 'height=600,width=900');
    };
    $scope.printBill = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            var BillID = selected[0].BillID;
            window.open('PrintBill.aspx?BillID=' + BillID, '', 'height=600,width=900');
        }
        else {
            alert('Please select a record to print.');
        }
    };
    $scope.printAllRec = function () {
        window.open('PrintReciept.aspx?BillTitle=' + $scope.filterOptions.filterText, '', 'height=600,width=900');
    };
    $scope.printRec = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            if (selected[0].PaidDate != null) {
                var BillID = selected[0].BillID;
                window.open('PrintReciept.aspx?BillID=' + BillID, '', 'height=600,width=900');
            } else {
                alert('Payment not made of selected bill, please use "Make Payment" option.');
            }
        }
        else {
            alert('Please select a record to print.');
        }
    };
    $scope.editRec = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            if (selected[0].PaidDate != null) {
                var PaymentID = selected[0].PaymentID;
                $location.path('/Payments/' + PaymentID + '/0/0/0');
            } else {
                alert('Payment not made of selected bill, please use "Make Payment" option.');
            }
        }
        else {
            alert('Please select a to edit reciept.');
        }
    };
    $scope.deleteBill = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            if (selected[0].PaidDate == null) {
                var BillID = selected[0].BillID;
                if (confirm('Are you sure want to delete the bill') == true) {
                    $http({
                        method: 'POST',
                        url: 'api/Bills/DeleteBills/',
                        data: JSON.stringify({ BillID: BillID })
                    }).success(function (result) {
                        $scope.searchBills();
                    });
                }
            } else {
                alert('You cannot delete this Bill because hes been Payment made.');
            }
        }
        else {
            alert('Please select a to delete bill.');
        }

    };

    $scope.showDiscountWin = false;
    $scope.Bill = {};
    $scope.editBill = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            if (selected[0].PaidDate == null) {
                var BillID = selected[0].BillID;
                $http({
                    method: 'GET',
                    url: 'api/Bills/' + BillID
                }).success(function (result) {
                    $scope.Bill = JSON.parse(result);
                    $scope.showDiscountWin = true;
                });

            } else {
                alert('You cannot edit this Bill because Payment hes been made.');
            }
        }
        else {
            alert('Please select a to edit Bill.');
        }
    };
    $scope.updateDiscount = function () {
        if ($scope.Bill.Discount <= 0) {
            alert('Please enter Discount');
            return;
        }
        $http({
            method: 'POST',
            url: 'api/Bills/UpdateDiscount/',
            data: JSON.stringify($scope.Bill)
        }).success(function (result) {
            $scope.searchBills();
            $scope.showDiscountWin = false;
        });
    };
});
app.controller('EditMiscBillsCtrl', function ($scope, $http, $location, $routeParams) {
    var BSID = 0;
    $scope.BSU = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.BSUSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.BSUSubmitted = true;
        if ($scope.formBSU.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        if ($scope.BSU.BSUChgList == null || $scope.BSU.BSUChgList.length <= 0) {
            swal({ title: "Please add at least one Charge!", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        if (confirm('This option will create Bills which will not be editable. Please make sure you have added correct data. Are you sure want to Proceed and Update?') == true) {

            $http({
                method: 'POST',
                url: 'api/Bills/CreateBills/',
                data: JSON.stringify($scope.BSU)
            }).success(function (data) {
                var result = JSON.parse(data);
                if ($.isArray(result))
                    $scope.ErrorMessages = result;
                else {
                    $scope.ErrorMessages = [];
                    swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
                    $location.path('/MiscBills');
                }
            });

        }
    };

    $scope.cancel = function () {
        $location.path('/MiscBills');
    };

    setTimeout(function () {
        $http({
            method: 'POST',
            url: 'api/GetBSUBlank'
        }).success(function (BSU) {
            $scope.BSU = JSON.parse(BSU);
        });
    }, 100);


    $scope.BSUChg = {};
    $scope.UnitTypeChgList = [];
    $scope.WingChgList = [];
    $scope.BSUChgSubmitted = false;
    var BSUChg = [];
    $scope.editBSUChg = function (indx) {
        $scope.EditMode = true;
        $scope.BSUChg = $scope.BSU.BSUChgList[indx];
        BSUChg = angular.copy($scope.BSU.BSUChgList);
        var chgID = $scope.BSUChg.ChgID;
        $scope.GetUnitTypeChg(chgID);
        $scope.GetWingChg(chgID);
    };
    $scope.deleteBSUChg = function (indx) {
        if (confirm('Are you sure want to delete?') == true) {
            var chgID = $scope.BSU.BSUChgList[indx].ChgID;
            $scope.deleteWingChg(chgID);
            $scope.deleteUnitTypeChg(chgID);
            $scope.BSU.BSUChgList.splice(indx, 1);
        }
    };
    $scope.newBSUChg = function () {
        $scope.EditMode = true;
        $scope.BSUChgSubmitted = false;
        BSUChg = angular.copy($scope.BSU.BSUChgList);
        $scope.BSUChg = { Basis: 'Fixed' };
        $scope.BSU.BSUChgList.push($scope.BSUChg);

        $scope.GetUnitTypeChg(0);
        $scope.GetWingChg(0);
    };
    $scope.cancelBSUChg = function () {
        $scope.EditMode = false;
        $scope.BSUChg = {};
        angular.copy(BSUChg, $scope.BSU.BSUChgList);
    };
    $scope.updateBSUChg = function (indx) {
        $scope.BSUChgSubmitted = true;
        if ($scope.BSUChg.ChgID == null || $scope.BSUChg.ChgID <= 0) {
            swal({ title: "Please Select Charge", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        if (($scope.BSUChg.Amt == null || $scope.BSUChg.Amt <= 0) && ($scope.BSUChg.Basis == 'Fixed' || $scope.BSUChg.Basis == 'Per SQFT')) {
            swal({ title: "Please enter Amount", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        var x = findByValue($scope.BSU.BSUChgList, 'ChgID', $scope.BSUChg.ChgID);
        if (x.length > 1) {
            swal({ title: "This Charge is already added, please select another Charge.", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }

        if ($scope.BSUChg.Basis == 'Per Unit Type') {
            for (var j = 0; j < $scope.UnitTypeChgList.length; j++) {
                if ($scope.UnitTypeChgList[j].Amount == null || $scope.UnitTypeChgList[j].Amount <= 0) {
                    swal({ title: "Please enter Amount for Unit Type:" + $scope.UnitTypeChgList[j].UnitType, type: "error", timer: 1000, showConfirmButton: false });
                    return;
                }
            }
        }
        if ($scope.BSUChg.Basis == 'Per Block/Wing') {
            for (var j = 0; j < $scope.WingChgList.length; j++) {
                if ($scope.WingChgList[j].Amount == null || $scope.WingChgList[j].Amount <= 0) {
                    swal({ title: "Please enter Amount for Block/Wing:" + $scope.WingChgList[j].WingName, type: "error", timer: 1000, showConfirmButton: false });
                    return;
                }
            }
        }

        var chgID = $scope.BSUChg.ChgID;
        $scope.deleteWingChg(chgID);
        $scope.deleteUnitTypeChg(chgID);
        if ($scope.BSUChg.Basis == 'Per Unit Type')
            $scope.saveUnitTypeChg(chgID);
        if ($scope.BSUChg.Basis == 'Per Block/Wing')
            $scope.saveWingChg(chgID);
        $scope.EditMode = false;
        $scope.BSUChg = {};
    };
    $scope.chglist = [];
    $scope.bindChg = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetChgListAll', Data: null })
        }).success(function (data) {
            $scope.chglist = data;
        });
    }
    $scope.bindChg();

    $scope.billtolist = [];
    $scope.bindMiscBillToList = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetUnitListForMiscBill', Data: null })
        }).success(function (data) {
            $scope.billtolist = data;
        });
    }
    $scope.bindMiscBillToList();

    $scope.getText = function (model, array) {
        for (var j = 0; j < array.length; j++) {
            if (model == array[j].Key) {
                return array[j].Value;
            }
        }
        return '';
    };

    $scope.GetUnitTypeChg = function (chgID) {
        var result = [];
        if ($scope.BSU.BSUChgUnitTypeList != null)
            result = findByValue($scope.BSU.BSUChgUnitTypeList, 'ChgID', chgID, 0);
        if (result.length == 0)
            result = $scope.BSU.BSUChgUnitTypeTempList;
        $scope.UnitTypeChgList = result;
    };
    $scope.GetWingChg = function (chgID) {
        var result = [];
        if ($scope.BSU.BSUChgWingList != null)
            result = findByValue($scope.BSU.BSUChgWingList, 'ChgID', chgID, 0);
        if (result.length == 0)
            result = $scope.BSU.BSUChgWingTempList;
        $scope.WingChgList = result;
    };
    $scope.deleteUnitTypeChg = function (ChgID) {
        var result = [];
        for (var j = 0; j < $scope.BSU.BSUChgUnitTypeList.length; j++) {
            if ($scope.BSU.BSUChgUnitTypeList[j].ChgID != ChgID) {
                result.push($scope.BSU.BSUChgUnitTypeList[j]);
            }
        }
        $scope.BSU.BSUChgUnitTypeList = result;
    };
    $scope.deleteWingChg = function (ChgID) {
        var result = [];
        for (var j = 0; j < $scope.BSU.BSUChgWingList.length; j++) {
            if ($scope.BSU.BSUChgWingList[j].ChgID != ChgID) {
                result.push($scope.BSU.BSUChgWingList[j]);
            }
        }
        $scope.BSU.BSUChgWingList = result;
    };

    $scope.saveUnitTypeChg = function (ChgID) {

        for (var j = 0; j < $scope.UnitTypeChgList.length; j++) {
            $scope.UnitTypeChgList[j].ChgID = ChgID;
            $scope.BSU.BSUChgUnitTypeList.push($scope.UnitTypeChgList[j]);
        }
    };
    $scope.saveWingChg = function (ChgID) {

        for (var j = 0; j < $scope.WingChgList.length; j++) {
            $scope.WingChgList[j].ChgID = ChgID;
            $scope.BSU.BSUChgWingList.push($scope.WingChgList[j]);
        }
    };
})
.controller('BillsCtrl', function ($scope, $http, $location, $routeParams) {
    var BillID = $routeParams.BillID;
    $scope.Bills = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.BillsSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.BillsSubmitted = true;
        if ($scope.formBills.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/Bills', $scope.Bills, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.Bills = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/BillsList');
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/Bills/' + BillID
        }).success(function (Bills) {
            $scope.Bills = JSON.parse(Bills);
        });
    }, 100);
});
app.controller('DefaultersCtrl', function ($scope, $http, $location, $filter, GridData) {

    //$scope = readyAngularGrid($scope, $http, 'api/Bills/Defaulters/', 'RoomID', GridData, 'Defaulters');
    //$scope.gridOptions.columnDefs = [
    //{ displayName: 'Unit No.', field: 'RoomNo' },
    //{ displayName: 'Name', field: 'PersonName' },
    //{ displayName: 'Outstanding', field: 'Outstanding' }];
    //$scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');
    $scope.Data = [];
    $scope.searchBills = function () {
        //$scope.filterOptions.filterText = $scope.filter.filterText;
        //$scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
        $http({
            method: 'POST',
            url: 'api/Bills/Defaulters2/'
        }).success(function (res) {
            $scope.Data = JSON.parse(res);
        });
    };

    $scope.sendEmail = function () {
        $http({
            method: 'POST',
            url: 'api/Msg/SendEmailReminder/',
            data: JSON.stringify({ val: $scope.Data })
        }).success(function (res) {
            $scope.DefaulterList = JSON.parse(res);
        });
    };
    $scope.sendSMS = function () {
        $http({
            method: 'POST',
            url: 'api/Msg/SendSMSReminder/',
            data: JSON.stringify({ val: $scope.Data })
        }).success(function (res) {
            $scope.DefaulterList = JSON.parse(res);
        });
    };
    $scope.searchBills();
});
app.controller('BillRegisterCtrl', function ($scope, $http, $location, $filter, GridData) {

    $scope = readyAngularGrid($scope, $http, 'api/Bills/BillRegister/', 'BillID', GridData, 'BillRegister');
    $scope.gridOptions.columnDefs = [
    { displayName: 'Unit No.', field: 'UnitNo', width: 70 },
    { displayName: 'Member(s)', field: 'MemberName', width: 110 },
    { displayName: 'Bill No.', field: 'BillID', width: 50 },
    { displayName: 'Bill Title', field: 'BillTitle' },
    { displayName: 'Bill Date', field: 'BillDate', cellFilter: 'date:\'dd-MMM-yyyy\'', width: 80 },
    { displayName: 'Amount', field: 'Amount', width: 60 },
    { displayName: 'Previous Due', field: 'PreviousDue', width: 90 },
    { displayName: 'Interest', field: 'Interest', width: 60 },
    { displayName: 'Payable Amount', field: 'TotalBillAmount', width: 100 },
    { displayName: 'Paid Amount', field: 'PaidAmount', width: 80 },
    { displayName: 'Paid Date', field: 'PaidDate', cellFilter: 'date:\'dd-MMM-yyyy\'', width: 80 },
    { displayName: 'Payment Mode', field: 'PaymentMode', width: 100 },
    { displayName: 'Paid Ref No.', field: 'PaidRefNo', width: 100 }];
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');
    $scope.Filter = { Date: '' };
    $scope.searchBills = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };
    $scope.monthlist = [];
    $scope.bindMonth = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetMonthList', Data: null })
        }).success(function (data) {
            $scope.monthlist = data;
        });
    }
    $scope.bindMonth();


    $scope.exportBills = function () {
        window.open('api/AccountReport/DownloadBillRegister?date=' + $scope.Filter.Date + '&name=' + $scope.filter.filterText);
    };
    $scope.exportBillsPdf = function () {
        window.open('api/AccountReport/DownloadBillRegisterPdf?date=' + $scope.Filter.Date + '&name=' + $scope.filter.filterText);
    };
});
app.directive('bsumiscchg', function () {
    return {
        restrict: 'E',
        replace: true,
        templateUrl: 'templates/Bills/BSUMiscChg.html'
    }
});

