﻿using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;
using System.Web.Configuration;
using System.Text;

namespace SampleAngular.Api
{
    public class BillsController : ApiController
    {
        [Route("api/Bills/UpdateDiscount")]
        [HttpPost]
        public string UpdateDiscount([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.MakePayment, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser.UserType != 2)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            JObject objJObject = value;
            Bills objBills = objJObject.ToObject<Bills>();
            Common.ExecuteNonQuery(@"Update Bills set Discount=@Discount,DiscountReason=@DiscountReason where BillID=@BillID;
            update Bills set TotalBillAmount=ISNULL(Amount,0)+ISNULL(LF,0)+ISNULL(Outstanding,0)-ISNULL(Discount,0) where BillID=@BillID
            ", "@BillID", SqlDbType.Int, Common.ToInt(objBills.BillID),
             "@Discount", SqlDbType.Decimal, Common.ToDecimal(objBills.Discount),
             "@DiscountReason", SqlDbType.VarChar, Common.ToInt(objBills.DiscountReason));

            int GEGroupID = Common.ToInt(objBills.BillGEGroupID);
            //Get penalty ChgID
            int discountChgID = Common.ToInt(Common.GetDBScalar("Select AccountID from Accounts where AccountType='Discount' and SocID=" + objBills.SocID));
            if (discountChgID > 0)
            {
                Common.ExecuteNonQuery("delete from GE where CompanyID=" + objBills.SocID + " and GEGroupID=@GEGroupID and GLID=@GLID",
                    "@GEGroupID", SqlDbType.Int, GEGroupID,
                    "@GLID", SqlDbType.Int, discountChgID);
                //Post Discount in Discount GL Dr
                GECommon.GEntry(GEGroupID, discountChgID,
                                               Common.ToDecimal(objBills.Discount), 0,
                                               Common.ToInt(objBills.BillID),
                                               Common.ToString(objBills.BillID), String.Empty, Common.ToDate(objBills.BillDate),
                                               objLoggedUser.SocID,
                                               0, 0, "Bill");
                //Update GE of Unit GL
                //deduct Dr Amount of Unit
                int GLIDOfUnit = Common.ToInt(Common.GetDBScalar("Select AccountID from Accounts where OrgID=" + Common.ToInt(objBills.RoomID) + " and SocID=" + objLoggedUser.SocID));
                Common.ExecuteNonQuery("Update GE set Dr=@Dr where CompanyID=@SocID and GEGroupID=@GEGroupID and GLID=@GLID",
                    "@Dr", SqlDbType.Decimal, Common.ToDecimal(objBills.TotalBillAmount) - Common.ToDecimal(objBills.Discount),
                    "@SocID", SqlDbType.Int, objLoggedUser.SocID,
                    "@GEGroupID", SqlDbType.Int, GEGroupID,
                    "@GLID", SqlDbType.Int, GLIDOfUnit);

            }

            return JsonConvert.SerializeObject("true");
        }
        [Route("api/Bills/DeleteBills")]
        [HttpPost]
        public string DeleteBills([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.MakePayment, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser.UserType != 2)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            Common.ExecuteNonQuery(@"delete from BChg where BillID=@BillID;
            delete from BillPaymentReq where BillID=@BillID;
            delete from PaymentReq where BillID=@BillID;
            delete from GE where TransType='Bill' and RefID=@BillID;
            delete from GE where TransType='Payment' and RefID=@BillID;
            delete from Bills where BillID=@BillID;", "@BillID", SqlDbType.Int, Common.ToInt(value.BillID));

            return JsonConvert.SerializeObject("true");
        }
        [Route("api/Bills/SavePayment")]
        [HttpPost]
        public string SavePayment([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.MakePayment, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser.UserType != 2)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            JObject objJObject = value;
            Bills objBills = objJObject.ToObject<Bills>();

            GECommon.GEEntryPayment(objBills, objLoggedUser);
            //if (Common.ToInt(objBills.DrPayGEID) <= 0)
            //{
            //GE objGE = GECommon.GEntry(Common.ToInt(objBills.PaidToGLID),
            //                           Common.ToDecimal(objBills.PaidAmount), 0,
            //                           Common.ToInt(objBills.BillID),
            //                           Common.ToString(objBills.BillID), objBills.Remarks, Common.ToDate(objBills.PaidDate),
            //                           objLoggedUser.SocID,
            //                           0, "Bill");
            //drID = objGE.GEID.Value;
            //crID = GECommon.OrgGEntry(objGE.GEGroupID.Value, Common.ToInt(objBills.RoomID), 0, Common.ToDecimal(objBills.PaidAmount),
            //                              Common.ToInt(objBills.BillID),
            //                              Common.ToString(objBills.BillID), objBills.Remarks, Common.ToDate(objBills.PaidDate),
            //                              objLoggedUser.SocID,
            //                              0, "Bill").GEID.Value;
            //}
            //else
            //{
            //drID = Common.ToInt(objBills.DrPayGEID);
            //crID = Common.ToInt(objBills.CrPayGEID);
            //GECommon.UpdateGEEntry(Common.ToInt(objBills.DrPayGEID),
            //                       Common.ToDecimal(objBills.PaidAmount), 0,
            //                       Common.ToInt(objBills.BillID), Common.ToString(objBills.BillID));
            //GECommon.UpdateGEEntry(Common.ToInt(objBills.CrPayGEID), 0,
            //                       Common.ToDecimal(objBills.PaidAmount),
            //                       Common.ToInt(objBills.BillID), Common.ToString(objBills.BillID));
            //}
            Common.ExecuteNonQuery(@"Update Bills set PaidAmount=@PaidAmount, Remarks=@Remarks,
PaidDate=@PaidDate ,PaidToGLID=@PaidToGLID where BillID=@BillID",
                             "@PaidAmount", SqlDbType.Decimal, Common.ToDecimal(objBills.PaidAmount),
                             "@Remarks", SqlDbType.VarChar, Common.ToString(objBills.Remarks),
                             "@PaidDate", SqlDbType.DateTime, Common.ToDate(objBills.PaidDate),
                             "@PaidToGLID", SqlDbType.Int, objBills.PaidToGLID,
                             "@BillID", SqlDbType.Int, Common.ToInt(objBills.BillID));
            return JsonConvert.SerializeObject(objBills);
        }
        [Route("api/Bills/GetPendingBills")]
        [HttpPost]
        public string GetPendingBills([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.GenerateBills, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            //if (objLoggedUser.UserType != 2)
            //    throw new HttpResponseException(HttpStatusCode.Unauthorized);
            if (objLoggedUser.WPID <= 0)
            {
                return "{\"Error\":\"Working Period not defined, Please define a Working Period\"}";
            }

            DateTime billMonth = DateTime.Now;
            if (billMonth >= objLoggedUser.StartDate && billMonth <= objLoggedUser.EndDate)
            {
                billMonth = billMonth.AddMinutes(330);
                DataTable dt = Common.GetDBResultParameterized(@"select * from Get_PendingBills3(@Month,@Year,@SocID)",
                    "@Month", SqlDbType.Int, billMonth.Month,
                    "@Year", SqlDbType.Int, billMonth.Year,
                    "@SocID", SqlDbType.Int, objLoggedUser.SocID);
                return JsonConvert.SerializeObject(dt, Formatting.Indented);
            }
            else
            {
                return "{\"Error\":\"Working Period not defined for selected Month, Please define a Working Period\"}";
            }
        }
        [Route("api/Bills/GetOutstandingBills")]
        [HttpPost]
        public AngularGridData GetOutstandingBills([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.MakePayment, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            //if (objLoggedUser.UserType != 2)
            //    throw new HttpResponseException(HttpStatusCode.Unauthorized);

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = @"select B.RoomID,B.TotalBillAmount as Amount
,B.BillType,B.BillID,B.Remarks,B.BillGEGroupID,B.PaidGEGroupID,B.PaidToGLID,
W.WingName+' '+R.RoomNo as RoomNo,
Usr.PersonName,B.BillTitle,
DateName(M,B.BillDate)+'-'+DateName(YYYY,B.BillDate) as BillingMonth
,ISNULL(B.TotalBillAmount,0)-ISNULL(PAY.BPAmount,0) as Outstanding
,ISNULL(PAY.BPAmount,0) as PaidAmount,
ISNULL(BPR.ReqID,0) as ReqID from Bills B
inner join Rooms R ON B.RoomID=R.RoomID
inner join Wings W ON W.WingID=R.WingID
inner join Soc S ON R.SocID=S.SocID
outer apply
(
select top 1 U.FirstName+ISNULL(' '+U.LastName,'') as PersonName,U.UserID
from UserRooms UR
inner join Users U ON UR.UserID=U.UserID and UR.SocID=R.SocID
where UR.RoomID=R.RoomID
 order by U.MemberType
) as Usr
outer apply
(
select top 1 ReqID
from BillPaymentReq BPR
where BPR.BillID=B.BillID
) as BPR
outer apply
(
select SUM(BPAmount) as BPAmount
from BillPayments BP
where BP.BillID=B.BillID
) as PAY
where S.SocID=@SocID 
and ISNULL(B.TotalBillAmount,0)-ISNULL(PAY.BPAmount,0)>0 and B.PaymentReqDate IS NULL
and B.IsNewBill=1
and (Usr.PersonName like '%'+@Name+'%' or W.WingName+' '+R.RoomNo like '%'+@Name+'%')";
            objAngularDataBinder.ValueField = "BillID";
            Hashtable ht = new Hashtable();
            ht["@SocID"] = objLoggedUser.SocID;
            ht["@Name"] = Common.ToString(value.SearchText);
            objAngularDataBinder.Parameters = ht;
            return objAngularDataBinder.GetData();
        }
        [Route("api/Bills/Defaulters")]
        [HttpPost]
        public AngularGridData GetDefaulters([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.Defaulters, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            //if (objLoggedUser.UserType != 2)
            //    throw new HttpResponseException(HttpStatusCode.Unauthorized);

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();
            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);

            StringBuilder query = new StringBuilder(Common.GetDefaulterQuery(0));
            Hashtable ht = new Hashtable();
            if (!String.IsNullOrEmpty(objAngularGrid.SearchText))
            {
                query.Append(" and (Usr.PersonName like '%'+@Text+'%' OR W.WingName like '%'+@Text+'%' OR R.RoomNo like '%'+@Text+'%')");
                ht["@Text"] = objAngularGrid.SearchText;
            }
            objAngularDataBinder.Query = query.ToString();

            objAngularDataBinder.ValueField = "D.RoomID";
            objAngularDataBinder.OrderBy = "Outstanding";
            objAngularDataBinder.OrderDir = "Desc";
            ht["@SocID"] = objLoggedUser.SocID;
            objAngularDataBinder.Parameters = ht;
            return objAngularDataBinder.GetData();
        }
        [Route("api/Bills/Defaulters2")]
        [HttpPost]
        public string GetDefaulters2([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.Defaulters, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            StringBuilder query = new StringBuilder(Common.GetDefaulterQuery(0));
            DataTable dt = Common.GetDBResultParameterized(query.ToString(),
                "@SocID", SqlDbType.Int, objLoggedUser.SocID);
            return JsonConvert.SerializeObject(dt, Formatting.Indented);
        }
        [Route("api/Bills/BillRegister")]
        [HttpPost]
        public AngularGridData BillRegister([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.BillRegister, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            //if (objLoggedUser.UserType != 2)
            //    throw new HttpResponseException(HttpStatusCode.Unauthorized);
            DateTime date = Common.ToDate(value.OtherFilter.Date);
            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();
            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);

            objAngularDataBinder.Query = Common.GetBillRegisterQuery();
            objAngularDataBinder.ValueField = "B.BillID";
            objAngularDataBinder.OrderBy = "BillDate";
            objAngularDataBinder.OrderDir = "Desc";
            Hashtable ht = new Hashtable();
            ht["@SocID"] = objLoggedUser.SocID;
            ht["@Month"] = date.Month;
            ht["@Year"] = date.Year;
            ht["@Name"] = Common.ToString(value.SearchText);
            objAngularDataBinder.Parameters = ht;
            return objAngularDataBinder.GetData();
        }
        [Route("api/Bills/GetPaidBills")]
        [HttpPost]
        public AngularGridData GetPaidBills([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.BillRegister, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            //if (objLoggedUser.UserType != 2)
            //    throw new HttpResponseException(HttpStatusCode.Unauthorized);

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = @"select B.RoomID,B.TotalBillAmount
,B.BillType,B.BillID,B.Remarks,B.PaidDate,
W.WingName+' '+R.RoomNo as RoomNo,
Usr.PersonName,
B.BillDate
,B.Outstanding,BP.BPAmount as PaidAmount,B.Amount,B.LF,P.PaymentID,
case when B.Adjusted=1 then 'Paid in Advance' else '' end as Adjusted from Bills B
inner join Rooms R ON B.RoomID=R.RoomID
inner join Wings W ON R.WingID=W.WingID
Outer apply
(
select top 1 U.FirstName+ISNULL(' '+U.LastName,'') as PersonName,U.UserID
from UserRooms UR
inner join Users U ON UR.UserID=U.UserID and UR.SocID=R.SocID
where UR.RoomID=R.RoomID
 order by U.MemberType
) as Usr
inner join Soc S ON R.SocID=S.SocID
left join BillPayments BP ON B.BillID=BP.BillID
left join Payments P ON BP.PaymentID=P.PaymentID
where S.SocID=@SocID and ISNULL(B.BSID,0)>0
and (Usr.PersonName like '%'+@Name+'%' or W.WingName+' '+R.RoomNo like '%'+@Name+'%')
and B.IsNewBill=@ShowOldBill";
            objAngularDataBinder.ValueField = "B.BillID";
            Hashtable ht = new Hashtable();
            ht["@SocID"] = objLoggedUser.SocID;
            ht["@Name"] = Common.ToString(value.SearchText);
            ht["@ShowOldBill"] = !Common.ToBool(value.OtherFilter.showOldBill);
            objAngularDataBinder.Parameters = ht;
            return objAngularDataBinder.GetData();
        }
        [Route("api/Bills/GetMiscBills")]
        [HttpPost]
        public AngularGridData GetMiscBills([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.MiscBills, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            //if (objLoggedUser.UserType != 2)
            //    throw new HttpResponseException(HttpStatusCode.Unauthorized);

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = @"select B.RoomID,B.TotalBillAmount
,B.BillType,B.BillID,B.Remarks,B.PaidDate,
W.WingName+' '+R.RoomNo as RoomNo,
Usr.PersonName,ISNULL(B.BillTitle,'') as BillTitle,
B.BillDate
,B.Outstanding,B.PaidAmount,B.Amount,B.LF,PY.PaymentID from Bills B
inner join Rooms R ON B.RoomID=R.RoomID
inner join Wings W ON R.WingID=W.WingID
outer apply
(
select top 1 U.FirstName+ISNULL(' '+U.LastName,'') as PersonName,U.UserID
from UserRooms UR
inner join Users U ON UR.UserID=U.UserID and UR.SocID=R.SocID
where UR.RoomID=R.RoomID
 order by U.MemberType
) as Usr
inner join Soc S ON R.SocID=S.SocID
 outer apply
(
select top 1 PaymentID
from payments P where P.BillID=B.BillID
) as PY
where S.SocID=@SocID and B.BSID=0
and (Usr.PersonName like '%'+@Name+'%' or W.WingName+' '+R.RoomNo like '%'+@Name+'%' OR B.BillTitle like '%'+@Name+'%')";
            objAngularDataBinder.ValueField = "BillID";
            Hashtable ht = new Hashtable();
            ht["@SocID"] = objLoggedUser.SocID;
            ht["@Name"] = Common.ToString(value.SearchText);
            objAngularDataBinder.Parameters = ht;
            return objAngularDataBinder.GetData();
        }
        [Route("api/Bills/CreateBills")]
        [HttpPost]
        public string CreateBills([FromBody]dynamic value)
        {
            List<string> errors = new List<string>();
            Common.IsValidForm(Constants.Forms.MiscBills, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            BSU objBSU = objJObject.ToObject<BSU>();

            if (objBSU.BillTo == null || objBSU.BillTo.Count == 0)
            {
                errors.Add("Please select Bill To");
            }
            DataTable dtRooms = Common.GetDBResult("Select RoomID,Area from Rooms where SocID=" + objLoggedUser.SocID
                + " " + Common.GetUnitTypeCondition(objBSU.BillTo));
            BillsBL objBillsBL = new BillsBL(Common.GetConString());

            foreach (DataRow drRoom in dtRooms.Rows)
            {
                Bills objBills = new Bills();
                objBills.BillDate = objBSU.BDate;
                objBills.BillID = 0;
                objBills.RoomID = Common.ToInt(drRoom["RoomID"]);
                objBills.SocID = objLoggedUser.SocID;
                objBills.BSID = 0;
                objBills.BChgList = new List<BChg>();
                objBills.WPID = objLoggedUser.WPID;
                objBills.Term = objBSU.Term;
                objBills.IsNewBill = true;
                objBills.BillTitle = objBSU.Name;
                objBills.GraceDays = 0;

                foreach (BSUChg objBSUChg in objBSU.BSUChgList)
                {
                    BChg objBChg = new BChg();
                    if (objBSUChg.Basis == "Fixed")
                        objBChg.Amt = objBSUChg.Amt;
                    else if (objBSUChg.Basis == "Per SQFT")
                        objBChg.Amt = objBSUChg.Amt * Common.ToDecimal(drRoom["Area"]);
                    else if (objBSUChg.Basis == "Per Unit Type")
                    {
                        var BSUChgUnitType = objBSU.BSUChgUnitTypeList.Find(Obj => Obj.ChgID == objBSUChg.ChgID && Obj.UnitType == Common.ToString(drRoom["UnitType"]));
                        if (BSUChgUnitType != null)
                            objBChg.Amt = BSUChgUnitType.Amount;
                    }
                    else if (objBSUChg.Basis == "Per Block/Wing")
                    {
                        var BSUChgWing = objBSU.BSUChgWingList.Find(Obj => Obj.ChgID == objBSUChg.ChgID && Obj.WingID == Common.ToInt(drRoom["WingID"]));
                        if (BSUChgWing != null)
                            objBChg.Amt = BSUChgWing.Amount;
                    }
                    objBChg.ChgID = objBSUChg.ChgID;

                    objBills.BChgList.Add(objBChg);
                }
                objBills.Amount = objBills.BChgList.Sum(Obj => Obj.Amt);
                objBills.TotalBillAmount = Common.ToDecimal(objBills.Amount) + Common.ToDecimal(objBills.LF) + Common.ToDecimal(objBills.Outstanding);
                objBillsBL.Data = objBills;
                objBillsBL.Update();
                GECommon.GEEntryBill(objBills, objLoggedUser);
                Common.SendBillNotification(objLoggedUser.SocID, objLoggedUser.SocName);
            }
            if (errors.Count > 0)
                return JsonConvert.SerializeObject(errors);
            else
                return JsonConvert.SerializeObject(objBSU);
        }
        [Route("api/Bills/GenerateBills")]
        [HttpPost]
        public string GenerateBills([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.GenerateBills, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            //if (objLoggedUser.UserType != 2)
            //    throw new HttpResponseException(HttpStatusCode.Unauthorized);

            DateTime billMonth = Common.ToDate(value.month);
            billMonth = billMonth.AddMinutes(330);
            DataTable dt = Common.GetDBResultParameterized(@"select * from Get_PendingBills(@Month,@Year,@SocID)",
                "@Month", SqlDbType.Int, billMonth.Month,
                "@Year", SqlDbType.Int, billMonth.Year,
                "@SocID", SqlDbType.Int, objLoggedUser.SocID);
            foreach (DataRow dr in dt.Rows)
            {
                BillsBL objBillsBL = new BillsBL(Common.GetConString());
                Bills objBills = new Bills();
                objBills.Amount = Common.ToDecimal(dr["Amount"]);
                objBills.BillDate = Common.ToDate(dr["BDate"]);
                objBills.BillID = 0;
                objBills.BillType = Common.ToString(dr["BillType"]);
                objBills.Discount = 0;
                objBills.OtherChargeHead = String.Empty;
                objBills.OtherCharges = 0;
                objBills.PaidAmount = 0;
                objBills.PaidDate = null;
                objBills.RoomID = Common.ToInt(dr["RoomID"]);
                objBills.SocID = objLoggedUser.SocID;
                objBills.TotalBillAmount = objBills.Amount + objBills.OtherCharges - objBills.Discount;

                objBillsBL.Data = objBills;
                objBillsBL.Update();

                //GE objGE = GECommon.OrgGEntry(Common.ToInt(objBills.RoomID), Common.ToDecimal(objBills.TotalBillAmount), 0,
                //                                 Common.ToInt(objBills.BillID),
                //                                 Common.ToString(objBills.BillID), String.Empty, Common.ToDate(objBills.BillDate), objLoggedUser.SocID,
                //                                  0, "Bill");
                //int drBillID = objGE.GEID.Value;
                //int crBillID = GECommon.GEntry(objGE.GEGroupID.Value, GLNo.Sales,
                //                            0, Common.ToDecimal(objBills.TotalBillAmount),
                //                           Common.ToInt(objBills.BillID),
                //                           Common.ToString(objBills.BillID), String.Empty, Common.ToDate(objBills.BillDate),
                //                           objLoggedUser.SocID,
                //                           0, 0, "Bill").GEID.Value;
                //objBills.CrBillGEID = crBillID;
                //objBills.DrPayGEID = drBillID;

                objBillsBL.Update();
            }
            return String.Empty;
        }

        [Route("api/Bills/GenerateBills2")]
        [HttpPost]
        public string GenerateBills2([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.GenerateBills, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            //if (objLoggedUser.UserType != 2)
            //    throw new HttpResponseException(HttpStatusCode.Unauthorized);
            DateTime billMonth = Common.ToDate(value.month);
            RMBSUBL objBSUBL = new RMBSUBL(Common.GetConString());
            BillsBL objBillsBL = new BillsBL(Common.GetConString());

            DataTable dtRooms = Common.GetDBResultParameterized(@"select * from Get_PendingBills2(@Month,@SocID)",
                  "@Month", SqlDbType.Int, billMonth.Month,
                  "@SocID", SqlDbType.Int, objLoggedUser.SocID);

            foreach (DataRow drRoom in dtRooms.Rows)
            {
                int RoomID = Common.ToInt(drRoom["RMID"]);
                DataTable dtBSU = Common.GetDBResultParameterized("Select * from RMBSU where RMID=@RoomID and Month(BDate)=Month(@Date) and Year(BDate)=Year(@Date)",
            "@RoomID", SqlDbType.Int, RoomID,
            "@Date", SqlDbType.DateTime, billMonth);
                DataRow drdtBSU = null;
                if (dtBSU.Rows.Count <= 0) continue;
                drdtBSU = dtBSU.Rows[0];

                objBSUBL.Load(Common.ToInt(drdtBSU["BSID"]));
                RMBSU objBSU = objBSUBL.Data;

                Bills objBills = new Bills();
                objBills.BillDate = Common.ToDate(drdtBSU["BDate"]);
                objBills.BillID = 0;
                objBills.RoomID = RoomID;
                objBills.SocID = objLoggedUser.SocID;
                objBills.BSID = Common.ToInt(Common.ToInt(drdtBSU["BSID"]));
                objBills.BChgList = new List<BChg>();
                objBills.WPID = objLoggedUser.WPID;
                objBills.Term = Common.ToInt(drdtBSU["Term"]);
                foreach (RMChg objBSUChg in objBSU.RMChgList)
                {
                    BChg objBChg = new BChg();
                    if (objBSUChg.IsFixed == true)
                        objBChg.Amt = objBSUChg.Amt;
                    else
                        objBChg.Amt = objBSUChg.RPS * Common.ToDecimal(drRoom["Area"]);
                    objBChg.ChgID = objBSUChg.ChgID;

                    objBills.BChgList.Add(objBChg);
                }
                objBills.TotalBillAmount = objBills.Amount = objBills.BChgList.Sum(Obj => Obj.Amt);
                objBillsBL.Data = objBills;
                objBillsBL.Update();
                ////GECommon.GEEntryBill(objBSU.RMChgList, objBills, objLoggedUser);
                //GE objGE = GECommon.OrgGEntry(Common.ToInt(objBills.RoomID), Common.ToDecimal(objBills.TotalBillAmount), 0,
                //                                Common.ToInt(objBills.BillID),
                //                                Common.ToString(objBills.BillID), String.Empty, Common.ToDate(objBills.BillDate), objLoggedUser.SocID,
                //                                 0, "Bill");
                //int drBillID = objGE.GEID.Value;
                //foreach (RMChg objBSUChg in objBSU.RMChgList)
                //{
                //    int crBillID = GECommon.ChgGEntry(objGE.GEGroupID.Value, Common.ToInt(objBSUChg.ChgID),
                //                                0, Common.ToDecimal(objBills.TotalBillAmount),
                //                               Common.ToInt(objBills.BillID),
                //                               Common.ToString(objBills.BillID), String.Empty, Common.ToDate(objBills.BillDate),
                //                               objLoggedUser.SocID,
                //                               0, "Bill").GEID.Value;
                //    objBSUChg.CRGEID = crBillID;
                //}
                //objBills.DrPayGEID = drBillID;

                objBillsBL.Update();
            }
            return String.Empty;
        }

        [Route("api/Bills/GenerateBills3")]
        [HttpPost]
        public string GenerateBills3([FromBody]dynamic value)
        {
            try
            {
                Common.IsValidForm(Constants.Forms.GenerateBills, Request);
                LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
                //if (objLoggedUser.UserType != 2)
                //    throw new HttpResponseException(HttpStatusCode.Unauthorized);

                //Get Pending PaymentReq
                int pendingPaymentReq = Common.ToInt(Common.GetDBScalar("Select COUNT(*) from PaymentReq where Status IS NULL and SocID=" + objLoggedUser.SocID));
                if (pendingPaymentReq > 0)
                {
                    return "There are " + pendingPaymentReq + " Pending Bank Reconcilation Transaction(s), please Approve/Reject before bill Generate";
                }
                DateTime billMonth = Common.ToDate(value.month);
                BSUBL objBSUBL = new BSUBL(Common.GetConString());
                BillsBL objBillsBL = new BillsBL(Common.GetConString());

                DataTable dtRooms = Common.GetDBResultParameterized(@"select P.*,V.TotalPayment,V.TotalLF,V.Outstanding,V.TotalAmount 
from Get_PendingBills3(@Month,@Year,@SocID) P 
inner join VW_RoomOutstanding V ON P.RoomID=V.RoomID",
                      "@Month", SqlDbType.Int, billMonth.Month,
                      "@Year", SqlDbType.Int, billMonth.Year,
                      "@SocID", SqlDbType.Int, objLoggedUser.SocID);

                foreach (DataRow drRoom in dtRooms.Rows)
                {
                    int RoomID = Common.ToInt(drRoom["RoomID"]);
                    objBSUBL.Load(Common.ToInt(drRoom["BSID"]), objLoggedUser.SocID);
                    BSU objBSU = objBSUBL.Data;
                    decimal openingBal = 0;
                    decimal outstanding = Common.ToDecimal(drRoom["Outstanding"]);
                    decimal TerraceCharges = Common.ToDecimal(drRoom["TerraceCharges"]);
                    bool hasTeants = Common.ToInt(Common.GetDBScalar("Select COUNT(*) from Users where UserID IN ( select UserID from UserRooms where RoomID=" + RoomID + ")and MemberType='Tenant'")) > 0;

                    #region If First Bill and if Having Opening Balance
                    //If First Bill and if Having Opening Balance
                    if (drRoom["TotalAmount"].GetType() == typeof(DBNull) && Common.ToDecimal(drRoom["DrAmount"]) != 0)
                    {
                        decimal previousPrinciple = Common.ToDecimal(drRoom["DrAmount"]);
                        decimal previousInt = Common.ToDecimal(drRoom["DrAmountInt"]);

                        //Generate a bill in backend for opening balance
                        Bills objBillsOpening = new Bills();
                        objBillsOpening.BillDate = Common.ToDate(drRoom["BillDate"]).AddMonths(-1);
                        objBillsOpening.BillID = 0;
                        objBillsOpening.RoomID = RoomID;
                        objBillsOpening.SocID = objLoggedUser.SocID;
                        objBillsOpening.BSID = Common.ToInt(Common.ToInt(drRoom["BSID"]));
                        objBillsOpening.BChgList = new List<BChg>();
                        objBillsOpening.WPID = objLoggedUser.WPID;
                        objBillsOpening.Term = Common.ToInt(drRoom["Term"]);
                        objBillsOpening.BillTitle = "Previous Outstansing";

                        if (objBSU.BSUChgList.Count > 0)
                        {
                            BSUChg objBSUChg = objBSU.BSUChgList.First();
                            BChg objBChg = new BChg();
                            objBChg.Amt = previousPrinciple + previousInt;
                            objBChg.ChgID = objBSUChg.ChgID;
                            objBillsOpening.BChgList.Add(objBChg);
                        }
                        openingBal = previousPrinciple + previousInt;
                        objBillsOpening.TotalBillAmount = previousPrinciple + previousInt;
                        objBillsOpening.Amount = previousPrinciple;
                        objBillsOpening.LF = previousInt;
                        objBillsBL.Data = objBillsOpening;
                        objBillsBL.Update();
                        GECommon.GEEntryBill(objBillsOpening, objLoggedUser);

                        //Update DrAmount as 0
                        Common.ExecuteNonQuery("Update Accounts set DrAmount=0,DrAmountInt=0 where OrgID=" + RoomID);
                    }
                    #endregion

                    #region Generate Bill
                    //Mark All Previous bills of the BSU as IsNewBill=false
                    Common.ExecuteNonQuery("Update Bills set IsNewBill=0 where RoomID=@RoomID and BSID=@BSID",
                        "@RoomID", SqlDbType.Int, RoomID,
                        "@BSID", SqlDbType.Int, objBSU.BSID);
                    //Get last latest bill of the room of the BSID
                    int LastBillID = Common.ToInt(Common.GetDBScalar("Select BillID from Bills where RoomID=" + RoomID + " and BSID>0 order by BillDate desc"));

                    //Generate Bill
                    Bills objBills = new Bills();
                    objBills.BillDate = Common.ToDate(drRoom["BillDate"]);
                    objBills.BillID = 0;
                    objBills.RoomID = RoomID;
                    objBills.SocID = objLoggedUser.SocID;
                    objBills.BSID = Common.ToInt(Common.ToInt(drRoom["BSID"]));
                    objBills.BChgList = new List<BChg>();
                    objBills.WPID = objLoggedUser.WPID;
                    objBills.Term = Common.ToInt(drRoom["Term"]);
                    objBills.IsNewBill = true;
                    objBills.BillTitle = objBSU.Name;
                    objBills.GraceDays = objBSU.GraceDays;

                    //Set Outstansding
                    if (openingBal != 0)
                        objBills.Outstanding = openingBal;
                    else if (outstanding > 0)
                        objBills.Outstanding = outstanding;
                    //Get Late Fees
                    if (LastBillID > 0)
                        objBills.LF = Common.ToDecimal(Common.GetDelayCharge(LastBillID, objBills.BillDate.Value));

                    foreach (BSUChg objBSUChg in objBSU.BSUChgList)
                    {
                        if (objBSUChg.AccountType == "Occupation" && hasTeants == false)
                        {
                            continue;
                        }
                        BChg objBChg = new BChg();
                        if (objBSUChg.Basis == "Fixed")
                            objBChg.Amt = objBSUChg.Amt;
                        else if (objBSUChg.Basis == "Per SQFT")
                            objBChg.Amt = objBSUChg.Amt * Common.ToDecimal(drRoom["Area"]);
                        else if (objBSUChg.Basis == "Per Unit Type")
                        {
                            var BSUChgUnitType = objBSU.BSUChgUnitTypeList.Find(Obj => Obj.ChgID == objBSUChg.ChgID && Obj.UnitType == Common.ToString(drRoom["UnitType"]));
                            if (BSUChgUnitType != null)
                                objBChg.Amt = BSUChgUnitType.Amount;
                        }
                        else if (objBSUChg.Basis == "Per Unit")
                        {
                            var BSUChgRoom = objBSU.BSUChgRoomList.Find(Obj => Obj.ChgID == objBSUChg.ChgID && Obj.RoomID == Common.ToInt(drRoom["RoomID"]));
                            if (BSUChgRoom != null)
                                objBChg.Amt = BSUChgRoom.Amount;
                        }
                        else if (objBSUChg.Basis == "Per Block/Wing")
                        {
                            var BSUChgWing = objBSU.BSUChgWingList.Find(Obj => Obj.ChgID == objBSUChg.ChgID && Obj.WingID == Common.ToInt(drRoom["WingID"]));
                            if (BSUChgWing != null)
                                objBChg.Amt = BSUChgWing.Amount;
                        }
                        else if (objBSUChg.Basis == "Per Floor Type")
                        {
                            var BSUChgFloor = objBSU.BSUChgFloorList.Find(Obj => Obj.ChgID == objBSUChg.ChgID && Obj.FloorNo == Common.ToInt(drRoom["FloorNo"]));
                            if (BSUChgFloor != null)
                                objBChg.Amt = BSUChgFloor.Amount;
                        }
                        objBChg.ChgID = objBSUChg.ChgID;

                        objBills.BChgList.Add(objBChg);
                    }

                    //Generate Parking Charges based on the Parking alloted
                    DataTable dtCP = Common.GetDBResult("select * from CP where RMID=" + RoomID);
                    if (dtCP.Rows.Count > 0)
                    {
                        //Get parking ChgID
                        int parkingChgID = Common.ToInt(Common.GetDBScalar("Select AccountID from Accounts where AccountType='Parking' and SocID=" + objBills.SocID));
                        decimal totalParking = 0;
                        foreach (DataRow drCP in dtCP.Rows)
                        {
                            totalParking += Common.ToDecimal(drCP["Charges"]);
                        }
                        BChg objBChg = new BChg();
                        objBChg.Amt = totalParking;
                        objBChg.ChgID = parkingChgID;
                        objBills.BChgList.Add(objBChg);
                    }

                    //Generate TerraceCharges if has
                    if (TerraceCharges > 0)
                    {
                        //Get TerraceCharges ChgID
                        int TerraceChargesChgID = Common.ToInt(Common.GetDBScalar("Select AccountID from Accounts where AccountType='Terrace' and SocID=" + objBills.SocID));
                        BChg objBChg = new BChg();
                        objBChg.Amt = TerraceCharges;
                        objBChg.ChgID = TerraceChargesChgID;
                        objBills.BChgList.Add(objBChg);
                    }
                   
                    objBills.Amount = objBills.BChgList.Sum(Obj => Obj.Amt);
                    objBills.TotalBillAmount = Common.ToDecimal(objBills.Amount) + Common.ToDecimal(objBills.LF) + Common.ToDecimal(objBills.Outstanding);
                    objBillsBL.Data = objBills;
                    objBillsBL.Update();
                    GECommon.GEEntryBill(objBills, objLoggedUser);
                    #endregion
                    objBillsBL.Update();

                    Common.PaymentFromAdvance(objBills, outstanding, objLoggedUser.SocName);
                }
                Common.SendBillNotification(objLoggedUser.SocID, objLoggedUser.SocName);
            }
            catch (Exception Ex)
            {
                Common.WriteErrorLog(Ex);
            }
            return String.Empty;
        }

        [Route("api/BillsList/")]
        [HttpPost]
        public AngularGridData GetBills([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = @"select B.BillTitle, B.RoomID,B.TotalBillAmount
,B.BillType,B.BillID,B.Remarks,ISNULL(PR.ReqID,0) as ReqID,B.PaidDate,
case when PR.ReqID IS NULL and B.PaidDate is NULL then 'Not Paid'
when PR.ReqID IS NOT NULL and B.PaidDate is NULL then case when PR.Status is NULL then 'Paid - Not Approved' else PR.Status end
when B.PaidDate is NOT NULL then 'Paid' end as Status,
W.WingName+' '+R.RoomNo as RoomNo,
Usr.PersonName,
B.BillDate
,B.Outstanding,B.PaidAmount,B.Amount,B.LF,PY.PaymentID from Bills B
inner join Rooms R ON B.RoomID=R.RoomID
inner join Wings W ON R.WingID=W.WingID
Outer apply
(
select top 1 U.FirstName+ISNULL(' '+U.LastName,'') as PersonName,U.UserID
from UserRooms UR
inner join Users U ON UR.UserID=U.UserID and UR.SocID=R.SocID
where UR.RoomID=R.RoomID
 order by U.MemberType
) as Usr
inner join Soc S ON R.SocID=S.SocID
 outer apply
(
select top 1 PaymentID
from payments P where P.BillID=B.BillID
) as PY
left join BillPaymentReq BPR ON B.BillID=BPR.BillID
left join PaymentReq PR ON PR.ReqID=BPR.ReqID
where S.SocID=@SocID 
and (Usr.PersonName like '%'+@Name+'%' or W.WingName+' '+R.RoomNo like '%'+@Name+'%' OR B.BillTitle like '%'+@Name+'%'
OR B.BillID like '%'+@Name+'%')";
            if (objLoggedUser.UserType == 1)
            {
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                foreach (var room in objLoggedUser.RoomID)
                {
                    sb.Append(",").Append(room);
                }
                if (sb.Length > 0)
                {
                    objAngularDataBinder.Query += " and B.RoomID in (" + sb.Remove(0, 1).ToString() + ")";
                }
            }
            objAngularDataBinder.ValueField = "B.BillID";
            objAngularDataBinder.OrderBy = "BillDate";
            objAngularDataBinder.OrderDir = "Desc";
            Hashtable ht = new Hashtable();
            ht["@SocID"] = objLoggedUser.SocID;
            ht["@Name"] = Common.ToString(value.SearchText);
            objAngularDataBinder.Parameters = ht;

            return objAngularDataBinder.GetData();
        }

        // GET api/Bills/Id
        [Route("api/Bills/{Id}")]
        public string GetBills(int Id)
        {
            BillsBL objBillsBL = new BillsBL(Common.GetConString());
            objBillsBL.Load(Id);
            objBillsBL.Data.Outstanding = Common.ToDecimal(objBillsBL.Data.Outstanding);
            objBillsBL.Data.LF = Common.ToDecimal(objBillsBL.Data.LF);

            return JsonConvert.SerializeObject(objBillsBL.Data);
        }

        // POST api/Bills/
        public string Post([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.GenerateBills, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            Bills objBills = objJObject.ToObject<Bills>();
            BillsBL objBillsBL = new BillsBL(Common.GetConString());
            objBillsBL.Data = objBills;

            BillsValidator validator = new BillsValidator();
            ValidationResult results = validator.Validate(objBills);
            bool isNew = objBillsBL.IsNew;
            if (results.IsValid)
            {
                objBillsBL.Update();
                if (isNew)
                {
                    //GE objGE = GECommon.OrgGEntry(Common.ToInt(objBills.RoomID), Common.ToDecimal(objBills.TotalBillAmount), 0,
                    //                             Common.ToInt(objBills.BillID),
                    //                             Common.ToString(objBills.BillID), String.Empty, Common.ToDate(objBills.BillDate), objLoggedUser.SocID,
                    //                              0, "Bill");
                    //int drBillID = objGE.GEID.Value;
                    //int crBillID = GECommon.GEntry(objGE.GEGroupID.Value, (int)GLNo.Sales,
                    //                            0, Common.ToDecimal(objBills.TotalBillAmount),
                    //                           Common.ToInt(objBills.BillID),
                    //                           Common.ToString(objBills.BillID), String.Empty, Common.ToDate(objBills.BillDate),
                    //                           objLoggedUser.SocID,
                    //                           0, "Bill").GEID.Value;
                    //objBills.CrBillGEID = crBillID;
                    //objBills.DrPayGEID = drBillID;

                    objBillsBL.Update();
                }
                else
                {
                    //GECommon.UpdateGEEntry(Common.ToInt(objBills.DrBillGEID),
                    //                       Common.ToDecimal(objBills.TotalBillAmount), 0,
                    //                       Common.ToInt(objBills.BillID), Common.ToString(objBills.BillID));
                    //GECommon.UpdateGEEntry(Common.ToInt(objBills.CrBillGEID), 0,
                    //                       Common.ToDecimal(objBills.TotalBillAmount),
                    //                       Common.ToInt(objBills.BillID), Common.ToString(objBills.BillID));
                }
                return JsonConvert.SerializeObject(objBillsBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        // DELETE api/Bills/5
        [Route("api/Bills/{Id}")]
        [HttpDelete]
        public bool Delete(int Id)
        {
            Common.IsValidForm(Constants.Forms.GenerateBills, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            BillsBL objBillsBL = new BillsBL(Common.GetConString());
            return objBillsBL.Delete(Id);
        }
    }
    public class BillsValidator : AbstractValidator<Bills>
    {
        public BillsValidator()
        {

            RuleFor(obj => obj.Amount).NotEmpty();
            RuleFor(obj => obj.BillDate).NotEmpty();
            RuleFor(obj => obj.BillType).NotEmpty();
            RuleFor(obj => obj.Discount).NotEmpty();
            RuleFor(obj => obj.OtherChargeHead).NotEmpty();
            RuleFor(obj => obj.OtherCharges).NotEmpty();
            RuleFor(obj => obj.PaidAmount).NotEmpty();
            RuleFor(obj => obj.PaidDate).NotEmpty();
            RuleFor(obj => obj.RoomID).NotEmpty();
            RuleFor(obj => obj.SocID).NotEmpty();
            RuleFor(obj => obj.TotalBillAmount).NotEmpty();
        }
    }
}

