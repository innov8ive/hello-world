using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
    public class BillsDL
    {
        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public BillsDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public Bills Load(int BillID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            Bills objBills = new Bills();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get Bills
                var resultBills = dc.ExecuteQuery<Bills>("exec Get_Bills {0}", BillID).ToList();
                if (resultBills.Count > 0)
                {
                    objBills = resultBills[0];
                }
                objBills.BChgList = dc.ExecuteQuery<BChg>("Select * from BChg where BillID={0}", BillID).ToList();
                dc.Dispose();
                return objBills;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllBills()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_Bills", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(Bills objBills)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update Bills
                UpdateBills(objBills, trn);
                if (objBills.BillID > 0)
                {
                    DeleteBChg(Convert.ToInt32(objBills.BillID), trn);
                    foreach (BChg objBChg in objBills.BChgList)
                    {
                        objBChg.BillID = objBills.BillID;
                        InsertUpdateBChg(objBChg, trn);
                    }
                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int BillID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete Bills
                DeleteBills(BillID, trn);
                DeleteBChg(BillID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateBills(Bills objBills, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_Bills", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@Amount", SqlDbType.Decimal).Value = objBills.Amount;
                cmd.Parameters.Add("@BillDate", SqlDbType.DateTime).Value = objBills.BillDate;
                cmd.Parameters.Add("@BillID", SqlDbType.Int).Value = objBills.BillID;
                cmd.Parameters["@BillID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@BillType", SqlDbType.VarChar, 50).Value = objBills.BillType;
                cmd.Parameters.Add("@Discount", SqlDbType.Decimal).Value = objBills.Discount;
                cmd.Parameters.Add("@OtherChargeHead", SqlDbType.VarChar, 50).Value = objBills.OtherChargeHead;
                cmd.Parameters.Add("@OtherCharges", SqlDbType.Decimal).Value = objBills.OtherCharges;
                cmd.Parameters.Add("@PaidAmount", SqlDbType.Decimal).Value = objBills.PaidAmount;
                cmd.Parameters.Add("@PaidDate", SqlDbType.DateTime).Value = objBills.PaidDate;
                cmd.Parameters.Add("@RoomID", SqlDbType.Int).Value = objBills.RoomID;
                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = objBills.SocID;
                cmd.Parameters.Add("@TotalBillAmount", SqlDbType.Decimal).Value = objBills.TotalBillAmount;
                cmd.Parameters.Add("@BSID", SqlDbType.Int).Value = objBills.BSID;
                cmd.Parameters.Add("@LF", SqlDbType.Decimal).Value = objBills.LF;
                cmd.Parameters.Add("@WPID", SqlDbType.Int).Value = objBills.WPID;
                cmd.Parameters.Add("@Term", SqlDbType.Int).Value = objBills.Term;
                cmd.Parameters.Add("@Outstanding", SqlDbType.Decimal).Value = objBills.Outstanding;
                cmd.Parameters.Add("@IsNewBill", SqlDbType.Bit).Value = objBills.IsNewBill;
                cmd.Parameters.Add("@BillTitle", SqlDbType.VarChar, 100).Value = objBills.BillTitle;
                cmd.Parameters.Add("@GraceDays", SqlDbType.Int).Value = objBills.GraceDays;

                cmd.ExecuteNonQuery();

                //after updating the Bills, update BillID
                objBills.BillID = Convert.ToInt32(cmd.Parameters["@BillID"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteBills(int BillID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from Bills where BillID=@BillID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@BillID", SqlDbType.Int).Value = BillID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        public bool DeleteBChg(int BillID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from BChg where BillID=@BillID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@BillID", SqlDbType.Int).Value = BillID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        public bool InsertUpdateBChg(BChg objBChg, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Into_BChg", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Transaction = trn;
                cmd.Parameters.Add("@Amt", SqlDbType.Decimal).Value = objBChg.Amt;
                cmd.Parameters.Add("@BillID", SqlDbType.Decimal).Value = objBChg.BillID;
                cmd.Parameters.Add("@ChgID", SqlDbType.Decimal).Value = objBChg.ChgID;
                cmd.Parameters.Add("@CRGEID", SqlDbType.Decimal).Value = objBChg.CRGEID;
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        #endregion
    }
}
