using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

[Serializable][Table(Name = "dbo.Chg")]public class Chg{
private System.Nullable<int> _ChgID;
private string _ChgName;
private System.Nullable<int> _SocID;
 
[Column(Storage = "_ChgID")]
public System.Nullable<int> ChgID{get {return _ChgID;}set { _ChgID=value;}}
[Column(Storage = "_ChgName")]
public string ChgName{get {return _ChgName;}set { _ChgName=value;}}
[Column(Storage = "_SocID")]
public System.Nullable<int> SocID{get {return _SocID;}set { _SocID=value;}}
}}
