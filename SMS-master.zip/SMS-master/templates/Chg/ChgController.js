var app = angular.module('myApp');

app.controller('ChgListCtrl', function ($scope, $http, $location, GridData) {

    $scope = readyAngularGrid($scope, $http, 'api/ChgList', 'ChgID', GridData, 'Chg');
    $scope.gridOptions.columnDefs = [
    { displayName: 'Charge Name', field: 'ChgName' },
    ];
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchChg = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };
    $scope.newChg = function () {
        saveGridData($scope, GridData, 'Chg');
        $location.path('/Chg/0');
    };
    $scope.editChg = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            saveGridData($scope, GridData, 'Chg');
            $location.path('/Chg/' + selected[0].ChgID);
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.deleteChg = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'DELETE',
                url: 'api/Chg/' + selected[0].ChgID
            }).success(function (result) {
                if (result == true)
                    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
            });
        }
        else {
            alert('Please select a record to edit.');
        }
    };
})

.controller('ChgCtrl', function ($scope, $http, $location, $routeParams) {
    var ChgID = $routeParams.ChgID;
    $scope.Chg = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.ChgSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.ChgSubmitted = true;
        if ($scope.formChg.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/Chg', $scope.Chg, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.Chg = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/ChgList');
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/Chg/' + ChgID
        }).success(function (Chg) {
            $scope.Chg = JSON.parse(Chg);
        });
    }, 100);
});
