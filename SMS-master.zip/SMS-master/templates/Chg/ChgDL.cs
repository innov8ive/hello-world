using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
public class ChgDL
{

#region Private Members
private string connectionString;
#endregion

#region Constructor
public ChgDL(string conString)
{
connectionString = conString;
}
#endregion

#region Main Methods
public Chg Load(int ChgID)
{
SqlConnection SqlCon = new SqlConnection(connectionString);
Chg objChg = new Chg();
var dc = new DataContext(SqlCon);
try
{
//Get Chg
var resultChg = dc.ExecuteQuery<Chg>("exec Get_Chg {0}", ChgID).ToList();
if (resultChg.Count > 0)
{
objChg = resultChg[0];
}
dc.Dispose();
return objChg;
}
catch (Exception ex)
{
throw new Exception(ex.Message);
}
finally
{
if (SqlCon.State == ConnectionState.Open)
{
SqlCon.Close();
}
SqlCon.Dispose();
}
}
public DataTable LoadAllChg()
{
DataTable dt = new DataTable();
SqlConnection con = new SqlConnection(connectionString);
SqlCommand cmd = new SqlCommand("exec Get_Chg",con);

con.Open();
dt.Load(cmd.ExecuteReader());
con.Close();

return dt;
}
public bool Update(Chg objChg)
{
SqlConnection con = new SqlConnection(connectionString);
con.Open();
SqlTransaction trn = con.BeginTransaction();
try
{
//update Chg
UpdateChg(objChg,trn);
if (objChg.ChgID > 0)
{

trn.Commit();
}
return true;
}
catch
{
trn.Rollback();
return false;
}
finally
{
con.Dispose();
}
}
public bool Delete(int ChgID)
{
SqlConnection con = new SqlConnection(connectionString);
con.Open();
SqlTransaction trn = con.BeginTransaction();
try
{
//Delete Chg
DeleteChg(ChgID,trn);
trn.Commit();
return true;
}
catch
{
trn.Rollback();
return false;
}
finally
{
con.Dispose();
}
}

public bool UpdateChg(Chg objChg,SqlTransaction trn){SqlCommand cmd=new SqlCommand("Insert_Update_Chg",trn.Connection);try{cmd.CommandType=CommandType.StoredProcedure; cmd.Transaction = trn;
cmd.Parameters.Add("@ChgID",SqlDbType.Int).Value=objChg.ChgID;
cmd.Parameters["@ChgID"].Direction=ParameterDirection.InputOutput;
cmd.Parameters.Add("@ChgName",SqlDbType.VarChar,100).Value=objChg.ChgName;
cmd.Parameters.Add("@SocID",SqlDbType.Int).Value=objChg.SocID;
cmd.ExecuteNonQuery();//after updating the Chg, update ChgIDobjChg.ChgID=Convert.ToInt32(cmd.Parameters["@ChgID"].Value);return true;}catch{ trn.Rollback();return false;}finally{cmd.Dispose();}}
public bool DeleteChg(int ChgID, SqlTransaction trn){try{SqlCommand cmd=new SqlCommand("Delete from Chg where ChgID=@ChgID", trn.Connection);cmd.Transaction = trn;cmd.Parameters.Add("@ChgID",SqlDbType.Int).Value=ChgID;cmd.ExecuteNonQuery();return true;}catch{trn.Rollback();return false;}}#endregion
}
}
