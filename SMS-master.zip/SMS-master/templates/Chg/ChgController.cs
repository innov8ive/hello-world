using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;

namespace SampleAngular.Api
{
    public class ChgController : ApiController
    {
        // GET api/Chg
        [Route("api/ChgList/")]
        [HttpPost]
        public AngularGridData GetChg([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.BillSetUp, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = "Select * from Chg where SocID=" + objLoggedUser.SocID;
            objAngularDataBinder.ValueField = "ChgID";
            return objAngularDataBinder.GetData();
        }

        // GET api/Chg/Id
        [Route("api/Chg/{Id}")]
        public string GetChg(int Id)
        {
            Common.IsValidForm(Constants.Forms.BillSetUp, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
          
            ChgBL objChgBL = new ChgBL(Common.GetConString());
            objChgBL.Load(Id);

            Chg objChg = objChgBL.Data;
            if (Common.ToInt(objChg.SocID) > 0 && objChg.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            return JsonConvert.SerializeObject(objChgBL.Data);
        }

        // POST api/Chg/
        public string Post([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.BillSetUp, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            Chg objChg = objJObject.ToObject<Chg>();
            ChgBL objChgBL = new ChgBL(Common.GetConString());
            objChgBL.Data = objChg;
            if (objChgBL.IsNew)
            {
                objChg.SocID = objLoggedUser.SocID;
            }
            ChgValidator validator = new ChgValidator();
            ValidationResult results = validator.Validate(objChg);

            if (results.IsValid)
            {
                objChgBL.Update();
                return JsonConvert.SerializeObject(objChgBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        // DELETE api/Chg/5
        [Route("api/Chg/{Id}")]
        [HttpDelete]
        public bool Delete(int Id)
        {
            Common.IsValidForm(Constants.Forms.BillSetUp, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            ChgBL objChgBL = new ChgBL(Common.GetConString());
            objChgBL.Load(Id);

            Chg objChg = objChgBL.Data;
            if (Common.ToInt(objChg.SocID) > 0 && objChg.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            return objChgBL.Delete(Id);
        }
    }
    public class ChgValidator : AbstractValidator<Chg>
    {
        public ChgValidator()
        {
            RuleFor(obj => obj.ChgName).NotEmpty();
        }
    }
}

