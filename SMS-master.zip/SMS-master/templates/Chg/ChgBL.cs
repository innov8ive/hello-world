using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;
using SampleAngular;

namespace SampleAngularBL
{
    [Serializable]
    public class ChgBL
    {

        #region Declaration
        private string connectionString;
        Chg _Chg;
        public Chg Data
        {
            get { return _Chg; }
            set { _Chg = value; }
        }
        public bool IsNew
        {
            get { return (_Chg.ChgID <= 0 || _Chg.ChgID == null); }
        }
        #endregion

        #region Constructor
        public ChgBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private ChgDL CreateDL()
        {
            return new ChgDL(connectionString);
        }
        public void New()
        {
            _Chg = new Chg();
        }
        public void Load(int ChgID)
        {
            var ChgObj = this.CreateDL();
            _Chg = ChgID <= 0 ? ChgObj.Load(-1) : ChgObj.Load(ChgID);
        }
        public DataTable LoadAllChg()
        {
            var ChgDLObj = CreateDL();
            return ChgDLObj.LoadAllChg();
        }
        public bool Update()
        {
            var ChgDLObj = CreateDL();
            bool result = ChgDLObj.Update(this.Data);
            if (result)
            {
                GLDL objGLDL = new GLDL(connectionString);
                GL objGL = objGLDL.LoadByChgID(Data.ChgID.Value);
                if (objGL != null && objGL.GLID > 0)
                {
                    objGL.GLName = Data.ChgName;
                    objGLDL.Update(objGL);
                }
                else
                {
                    objGL = new GL();
                    objGL.ChgID = Data.ChgID;
                    objGL.GLName = Data.ChgName;
                    objGL.GroupID = objGLDL.GetGroupID((int)GroupNo.DirectIncome, Data.SocID.Value);
                    objGL.CompanyID = Data.SocID;
                    objGLDL.Update(objGL);
                }
            }
            return result;
        }
        public bool Delete(int ChgID)
        {
            var ChgDLObj = CreateDL();
            return ChgDLObj.Delete(ChgID);
        }
        #endregion
    }
}
