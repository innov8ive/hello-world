using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
    public class ForumsDL
    {

        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public ForumsDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public Forums Load(int ForumID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            Forums objForums = new Forums();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get Forums
                var resultForums = dc.ExecuteQuery<Forums>("exec Get_Forums {0}", ForumID).ToList();
                if (resultForums.Count > 0)
                {
                    objForums = resultForums[0];
                }
                dc.Dispose();
                return objForums;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllForums()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_Forums", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(Forums objForums)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update Forums
                UpdateForums(objForums, trn);
                if (!String.IsNullOrEmpty(objForums.ForumID))
                {

                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(string ForumID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete Forums
                DeleteForums(ForumID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateForums(Forums objForums, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_Forums", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@CreatedBy", SqlDbType.Int).Value = objForums.CreatedBy;
                cmd.Parameters.Add("@CreatedDate", SqlDbType.DateTime).Value = objForums.CreatedDate;
                cmd.Parameters.Add("@Details", SqlDbType.VarChar, 2500).Value = objForums.Details;
                cmd.Parameters.Add("@ForumID", SqlDbType.VarChar, 36).Value = objForums.ForumID;
                cmd.Parameters["@ForumID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@LastUpdateDate", SqlDbType.DateTime).Value = objForums.LastUpdateDate;
                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = objForums.SocID;
                cmd.Parameters.Add("@Title", SqlDbType.VarChar, 150).Value = objForums.Title;
                cmd.Parameters.Add("@Type", SqlDbType.VarChar, 20).Value = objForums.Type;
                cmd.Parameters.Add("@Status", SqlDbType.VarChar, 20).Value = objForums.Status;
                cmd.Parameters.Add("@CTTypeID", SqlDbType.Int).Value = objForums.CTTypeID;
                cmd.Parameters.Add("@Priority", SqlDbType.VarChar, 20).Value = objForums.Priority;
                cmd.Parameters.Add("@RoomID", SqlDbType.Int).Value = objForums.RoomID;

                cmd.ExecuteNonQuery();

                //after updating the Forums, update ForumID
                objForums.ForumID = Convert.ToString(cmd.Parameters["@ForumID"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteForums(string ForumID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from Forums where ForumID=@ForumID;Delete from Likes where ForumID=@ForumID;Delete from Comments where ForumID=@ForumID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@ForumID", SqlDbType.VarChar).Value = ForumID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        #endregion
    }
}
