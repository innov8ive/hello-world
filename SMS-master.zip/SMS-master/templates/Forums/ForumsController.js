var app = angular.module('myApp');


app.controller('ForumsListCtrl', function ($scope, $http, $location, GridData, $routeParams, User) {
    $scope.showModal = false;
    var ForumType = $routeParams.ForumType;
    $scope.ForumType = ForumType;
    var dummyTime = (new Date()).toJSON();
    $scope.Forums = { CreatedDate: dummyTime, LastUpdateDate: dummyTime };
    if (ForumType == 'Forum') {
        $scope = readyAngularGrid($scope, $http, 'api/Forums/List1/', 'ForumID', GridData, 'Forums');
        $scope.gridOptions.columnDefs = [
  { displayName: 'Created By', field: 'CreatedByName' },
  { displayName: 'Title', field: 'Title' },
  { displayName: 'Last Update Date', field: 'LastUpdateDate', cellFilter: 'date:\'dd-MMM-yyyy hh:mm\'' },
  { displayName: 'Likes', field: 'LikeCount' },
  { displayName: 'Comments', field: 'CommentCount' }];
    }
    else {
        $scope = readyAngularGrid($scope, $http, 'api/Forums/List2/', 'ForumID', GridData, 'Complaint Box');
        $scope.gridOptions.columnDefs = [
  { displayName: 'Complaint No.', field: 'ID' },
  { displayName: 'Unit No.', field: 'RoomNo' },
  { displayName: 'Created By', field: 'CreatedByName' },
  { displayName: 'Status', field: 'Status' },
  { displayName: 'Type', field: 'CTName' },
  { displayName: 'Priority', field: 'Priority' },
  { displayName: 'Title', field: 'Title' },
  { displayName: 'Last Update Date', field: 'LastUpdateDate', cellFilter: 'date:\'dd-MMM-yyyy hh:mm\'' }, ];
    }


    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchForums = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
        //initMyBox();
    };

    $scope.editForums = function () {
        $scope.loading = true;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            saveGridData($scope, GridData, 'Forums');
            var ForumID = selected[0].ForumID;
            setTimeout(function () {
                $http({
                    method: 'GET',
                    url: 'api/Forums/' + ForumID
                }).success(function (Forums) {
                    $scope.showModal = true;
                    $scope.loading = false;
                    $scope.Forums = Forums;
                });
            }, 100);
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.deleteForums = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        $scope.loading = true;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'DELETE',
                url: 'api/Forums/' + selected[0].ForumID
            }).success(function (result) {
                $scope.loading = false;
                if (result.length == 0) {
                    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
                    swal({ title: "Record deleted successfully!", type: "success", timer: 1000, showConfirmButton: false });
                }
                else
                    alert(result);
            });
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.deleteComment = function (commentID) {
        if (confirm('Are you sure want to delete?') == false) return;
        $scope.loading = true;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'DELETE',
                url: 'api/Comments/' + commentID + '/' + selected[0].ForumID
            }).success(function (result) {
                $scope.loading = false;
                if (result == true) {
                    var index = -1;
                    var comArr = $scope.Forums.Comments;
                    for (var i = 0; i < comArr.length; i++) {
                        if (comArr[i].CommentID === commentID) {
                            index = i;
                            break;
                        }
                    }
                    if (index === -1) {
                        alert("Something gone wrong");
                    }
                    $scope.Forums.Comments.splice(index, 1);
                }
            });
        }
        else {
            alert('Please select a record to edit.');
        }
    };
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };

    $scope.closeComplaint = function (itm) {
        $scope.loading = true;
        $http({
            method: 'POST',
            url: 'api/Forums/CloseComplaint/',
            data: JSON.stringify(itm)
        }).success(function (result) {
            $scope.loading = false;
            itm.Status = 'Closed';
            $scope.showModal = false;
            $scope.searchForums();
        });
    };
    $scope.addComment = function (itm) {
        if (itm.CurrentRemarks == '') return;
        $scope.loading = true;
        $scope.commentBox = {};
        $scope.commentBox.ForumID = itm.ForumID;
        $scope.commentBox.Remarks = itm.CurrentRemarks;
        $http.post('api/Comments', $scope.commentBox, config)
        .success(function (data, status, headers, config) {
            $scope.loading = false;
            var result = data;
            if (result.ErrorCode == 1)
                $scope.ErrorMessages = result.data;
            else {
                $scope.ErrorMessages = [];
                itm.CurrentRemarks = '';
                var curDate = (new Date()).toJSON();
                itm.Comments.push({
                    Remarks: $scope.commentBox.Remarks,
                    CommentedByName: User.FirstName + ' ' + User.LastName,
                    CommentedByImageUrl: User.ImageUrl,
                    CommentDate: curDate
                });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.publicForums = function () {
        $location.path('/Forums/' + $scope.ForumType);
    };
});

app.controller('ForumsCtrl', function ($scope, $http, $location, $q, User, $routeParams) {
    $scope.PageSize = 5;
    $scope.CurrentPage = 1;
    $scope.TotalPages;
    $scope.UserType = User.UserType;
    $scope.ForumID = $routeParams.ForumID;
    var ForumType = $routeParams.ForumType;
    $scope.ForumType = ForumType;
    $scope.User = User;
    $scope.commentBox = { Remarks: '', ForumID: '' };
    $scope.loadForums = function () {
        if (ForumType != 'Forum' && ForumType != 'Complaint Box') {
            $location.path('/login');
            return;
        }
        $scope.loading = true;
        $http({
            method: 'POST',
            url: 'api/ForumsList',
            data: JSON.stringify({ PageSize: $scope.PageSize, CurrentPage: $scope.CurrentPage, SearchText: $scope.filterText, ForumType: ForumType })
        }).success(function (largeLoad) {
            $scope.TotalPages = largeLoad.TotalPages;
            $scope.data = largeLoad.DataJson;
            $scope.loading = false;
            initMyBox();
        });
    };
    $scope.loadForums();
    $scope.prevPage = function () {
        $scope.CurrentPage--;
        $scope.loadForums();
    }
    $scope.nextPage = function () {
        $scope.CurrentPage++;
        $scope.loadForums();
    }

    $scope.newForums = function () {
        $scope.showModal = true;
    };
    $scope.Forums = {};
    $scope.ForumsSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.ForumsSubmitted = true;
        if ($scope.formForums.$invalid == true) return;
        $scope.loading = true;
        $scope.Forums.Type = ForumType;
        if (ForumType == 'Complaint Box' && ($scope.Forums.CTTypeID == null || $scope.Forums.CTTypeID == 0)) {
            alert('Please select Type');
            return;
        }
        if (ForumType == 'Complaint Box' && ($scope.Forums.Priority == null || $scope.Forums.Priority == '')) {
            alert('Please select Priority');
            return;
        }
        $http.post('api/Forums', $scope.Forums, config)
        .success(function (data, status, headers, config) {
            $scope.loading = false;
            var result = data;
            if (result.ErrorCode == 1)
                $scope.ErrorMessages = result.data;
            else {
                $scope.ErrorMessages = [];
                $scope.Forums = result.data;
                swal({ title: "You have successfully started a discussion!", type: "success", timer: 1000, showConfirmButton: false });
                $scope.loadForums();
                $scope.showModal = false;
                $scope.Forums = {};
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.addComment = function (itm) {
        if (itm.CurrentRemarks == '') return;
        $scope.commentBox.ForumID = itm.ForumID;
        $scope.commentBox.Remarks = itm.CurrentRemarks;
        $scope.loading = true;
        $http.post('api/Comments', $scope.commentBox, config)
        .success(function (data, status, headers, config) {
            $scope.loading = false;
            var result = data;
            if (result.ErrorCode == 1)
                $scope.ErrorMessages = result.data;
            else {
                $scope.ErrorMessages = [];
                itm.CurrentRemarks = '';
                var curDate = (new Date()).toJSON();
                itm.Comments.push({
                    Remarks: $scope.commentBox.Remarks,
                    CommentedByName: User.FirstName + ' ' + User.LastName,
                    CommentedByImageUrl: User.ImageUrl,
                    CommentDate: curDate
                });
            }

        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };
    $scope.like = function (itm) {
        $scope.loading = true;
        $http({
            method: 'POST',
            url: 'api/Comments/Like/',
            data: JSON.stringify(itm.ForumID)
        }).success(function (result) {
            $scope.loading = false;
            itm.YouLiked = result;
            if (result == true)
                itm.Likes++;
            else
                itm.Likes--;
        });
    };

    $scope.typelist = [];
    $scope.prioritylist = [];
    $scope.bindCTType = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetCTTypeList', Data: null })
        }).success(function (data) {
            $scope.typelist = data;
            $scope.prioritylist = [];
            $scope.prioritylist.push({ Key: 'Low', Value: 'Low' });
            $scope.prioritylist.push({ Key: 'Medium', Value: 'Medium' });
            $scope.prioritylist.push({ Key: 'High', Value: 'High' });
        });
    }
    $scope.bindCTType();

    $scope.roomlist = [];
    $scope.bindRoom = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetRoomList', Data: null })
        }).success(function (data) {
            $scope.roomlist = data;
        });
    }
    $scope.bindRoom();

    $scope.backToList = function () {
        $location.path('/ForumsList/' + $scope.ForumType);
    };
})
