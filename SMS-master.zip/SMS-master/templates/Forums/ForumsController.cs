using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;
using System.Web.Http.Cors;

namespace SampleAngular.Api
{
    public class ForumsController : ApiController
    {
        [Route("api/Forums/List1/")]
        [HttpPost]
        public AngularGridData GetForumsList1([FromBody]dynamic value)
        {
            //Common.IsValidForm(Constants.Forms.ForumList, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser == null) throw new HttpResponseException(HttpStatusCode.Unauthorized);

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = @"Select W.WingName+' '+R.RoomNo as RoomNo,F.*,U.FirstName+ISNULL(' '+U.LastName,'') as CreatedByName
,U.ImageUrl,C.TotalComments
,L.TotalLikes from Forums F  
inner join Users U ON F.CreatedBy=U.UserID
left join Rooms R ON R.RoomID=F.RoomID
left join Wings W ON W.WingID=R.WingID
left join 
(
	select COUNT(*) as TotalComments,ForumID as FID from Comments group by ForumID
) AS C ON C.FID=F.ForumID
left join 
(
	select COUNT(*) as TotalLikes,ForumID as FID from Likes group by ForumID
) AS L ON L.FID=F.ForumID
 where F.Type='Forum' and F.SocID=" + objLoggedUser.SocID;
            objAngularDataBinder.ValueField = "ForumID";

            if (!String.IsNullOrEmpty(objAngularGrid.SearchText))
            {
                Hashtable ht = new Hashtable();
                objAngularDataBinder.Query += " and (F.Title like '%'+@SearchText+'%' OR F.Details like '%'+@SearchText+'%')";

                ht["@SearchText"] = Common.ToString(objAngularGrid.SearchText);
                objAngularDataBinder.Parameters = ht;
            }
            objAngularDataBinder.OrderBy = "LastUpdateDate";
            objAngularDataBinder.OrderDir = "Desc";
            DataTable dt = objAngularDataBinder.GetDataTable();

            List<ForumsDetails> list = new List<ForumsDetails>();
            foreach (DataRow dr in dt.Rows)
            {
                list.Add(new ForumsDetails()
                {
                    ID = Common.ToInt(dr["ID"]),
                    RoomNo = Common.ToString(dr["RoomNo"]),
                    Type = Common.ToString(dr["Type"]),
                    ForumID = Common.ToString(dr["ForumID"]),
                    CreatedByName = Common.ToString(dr["CreatedByName"]),
                    CreatedByImageUrl = Common.ToString(dr["ImageUrl"]),
                    Title = Common.ToString(dr["Title"]),
                    Details = Common.ToString(dr["Details"]),
                    CreatedDate = Common.ToDate(dr["CreatedDate"]),
                    LastUpdateDate = Common.ToDate(dr["LastUpdateDate"]),
                    CommentCount = Common.ToInt(dr["TotalComments"]),
                    LikeCount = Common.ToInt(dr["TotalLikes"])
                });
            }

            AngularGridData objAngularData = new AngularGridData();
            objAngularData.TotalRecords = objAngularDataBinder.TotalRecords;
            objAngularData.TotalPages = objAngularDataBinder.TotalPages;
            string json = JsonConvert.SerializeObject(list, Formatting.Indented);
            objAngularData.Data = json;

            return objAngularData;
        }

        [Route("api/Forums/List2/")]
        [HttpPost]
        public AngularGridData GetForumsList2([FromBody]dynamic value)
        {
            //Common.IsValidForm(Constants.Forms.ForumList, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser == null) throw new HttpResponseException(HttpStatusCode.Unauthorized);

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = @"Select W.WingName+' '+R.RoomNo as RoomNo,F.*,U.FirstName+ISNULL(' '+U.LastName,'') as CreatedByName
,U.ImageUrl,C.TotalComments
,L.TotalLikes,CT.CTName from Forums F  
inner join Users U ON F.CreatedBy=U.UserID
left join ComplainType CT ON CT.CTType=F.CTTypeID
left join Rooms R ON R.RoomID=F.RoomID
left join Wings W ON W.WingID=R.WingID
left join 
(
	select COUNT(*) as TotalComments,ForumID as FID from Comments group by ForumID
) AS C ON C.FID=F.ForumID
left join 
(
	select COUNT(*) as TotalLikes,ForumID as FID from Likes group by ForumID
) AS L ON L.FID=F.ForumID
 where F.Type='Complaint Box'";
            if (objLoggedUser.UserType == 2)//admin
            {
                objAngularDataBinder.Query += " and F.SocID=" + objLoggedUser.SocID;
            }
            else
            {
                objAngularDataBinder.Query += " and F.SocID=" + objLoggedUser.SocID + " and F.CreatedBy=" + objLoggedUser.UserID;
            }
            objAngularDataBinder.ValueField = "ForumID";

            if (!String.IsNullOrEmpty(objAngularGrid.SearchText))
            {
                Hashtable ht = new Hashtable();
                objAngularDataBinder.Query += " and (F.Title like '%'+@SearchText+'%' OR F.Details like '%'+@SearchText+'%')";
                ht["@SearchText"] = Common.ToString(objAngularGrid.SearchText);
                objAngularDataBinder.Parameters = ht;
            }
            objAngularDataBinder.OrderBy = "LastUpdateDate";
            objAngularDataBinder.OrderDir = "Desc";
            DataTable dt = objAngularDataBinder.GetDataTable();

            List<ForumsDetails> list = new List<ForumsDetails>();
            foreach (DataRow dr in dt.Rows)
            {
                list.Add(new ForumsDetails()
                {
                    ID = Common.ToInt(dr["ID"]),
                    RoomNo = Common.ToString(dr["RoomNo"]),
                    Type = Common.ToString(dr["Type"]),
                    ForumID = Common.ToString(dr["ForumID"]),
                    CreatedByName = Common.ToString(dr["CreatedByName"]),
                    CreatedByImageUrl = Common.ToString(dr["ImageUrl"]),
                    Title = Common.ToString(dr["Title"]),
                    Details = Common.ToString(dr["Details"]),
                    CreatedDate = Common.ToDate(dr["CreatedDate"]),
                    LastUpdateDate = Common.ToDate(dr["LastUpdateDate"]),
                    CommentCount = Common.ToInt(dr["TotalComments"]),
                    LikeCount = Common.ToInt(dr["TotalLikes"]),
                    Status = Common.ToString(dr["Status"]),
                    CTName = Common.ToString(dr["CTName"]),
                    Priority = Common.ToString(dr["Priority"])
                });
            }

            AngularGridData objAngularData = new AngularGridData();
            objAngularData.TotalRecords = objAngularDataBinder.TotalRecords;
            objAngularData.TotalPages = objAngularDataBinder.TotalPages;
            string json = JsonConvert.SerializeObject(list, Formatting.Indented);
            objAngularData.Data = json;

            return objAngularData;
        }

        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/ForumsList/")]
        [HttpPost]
        public AngularGridData GetForums([FromBody]dynamic value)
        {
            //Common.IsValidForm(Constants.Forms.Forum, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser == null) throw new HttpResponseException(HttpStatusCode.Unauthorized);
            string ForumType = value.ForumType.ToString();

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = @"Select CT.CTName, F.*,U.FirstName+ISNULL(' '+U.LastName,'') as CreatedByName,U.ImageUrl from Forums F  
inner join Users U ON F.CreatedBy=U.UserID left join ComplainType CT ON CT.CTType=F.CTTypeID where Type=@Type";
            if (objLoggedUser.UserType == 2)//admin
            {
                objAngularDataBinder.Query += " and F.SocID=" + objLoggedUser.SocID;
            }
            else
            {
                objAngularDataBinder.Query += " and F.SocID=" + objLoggedUser.SocID + " and F.CreatedBy=" + objLoggedUser.UserID;
            }
            objAngularDataBinder.OrderBy = "LastUpdateDate";
            objAngularDataBinder.OrderDir = "Desc";
            objAngularDataBinder.ValueField = "ForumID";
            Hashtable ht = new Hashtable();
            ht["@Type"] = ForumType;

            if (!String.IsNullOrEmpty(objAngularGrid.SearchText))
            {
                objAngularDataBinder.Query += " and (F.Title like '%'+@SearchText+'%' OR F.Details like '%'+@SearchText+'%')";
                ht["@SearchText"] = Common.ToString(objAngularGrid.SearchText);
            }

            objAngularDataBinder.Parameters = ht;
            DataTable dt = objAngularDataBinder.GetDataTable();

            List<ForumsDetails> list = new List<ForumsDetails>();
            CommentsBL objCommentsBL = new CommentsBL(Common.GetConString());
            foreach (DataRow dr in dt.Rows)
            {
                List<int> likes = objCommentsBL.LoadAllLikes(Common.ToString(dr["ForumID"]));
                list.Add(new ForumsDetails()
                {
                    ForumID = Common.ToString(dr["ForumID"]),
                    CreatedByName = Common.ToString(dr["CreatedByName"]),
                    CreatedByImageUrl = Common.ToString(dr["ImageUrl"]),
                    Title = Common.ToString(dr["Title"]),
                    Details = Common.ToString(dr["Details"]),
                    Status = Common.ToString(dr["Status"]),
                    CTName = Common.ToString(dr["CTName"]),
                    Priority = Common.ToString(dr["Priority"]),
                    Type = Common.ToString(dr["Type"]),
                    CreatedDate = Common.ToDate(dr["CreatedDate"]),
                    LastUpdateDate = Common.ToDate(dr["LastUpdateDate"]),
                    Comments = objCommentsBL.LoadAllComments(Common.ToString(dr["ForumID"])),
                    LikeCount = likes.Count,
                    YouLiked = likes.Exists(Obj => Obj == objLoggedUser.UserID)
                });
            }

            AngularGridData objAngularData = new AngularGridData();
            objAngularData.TotalRecords = objAngularDataBinder.TotalRecords;
            objAngularData.TotalPages = objAngularDataBinder.TotalPages;
            objAngularData.DataJson = list;

            return objAngularData;
        }

        // GET api/Forums/Id
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/Forums/{Id}")]
        public object GetForums(string Id)
        {
            //Common.IsValidForm(Constants.Forms.ForumList, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser == null) throw new HttpResponseException(HttpStatusCode.Unauthorized);

            DataTable dt = Common.GetDBResultParameterized(@"Select CT.CTName,
F.*,U.FirstName+ISNULL(' '+U.LastName,'') as CreatedByName,U.ImageUrl,W.WingName+' '+R.RoomNo as RoomNo from Forums F  
inner join Users U ON F.CreatedBy=U.UserID 
left join Rooms R ON R.RoomID=F.RoomID
left join Wings W ON W.WingID=R.WingID
left join ComplainType CT ON CT.CTType=F.CTTypeID 
where ForumID=@ForumID and F.SocID=" + objLoggedUser.SocID, "@ForumID", SqlDbType.VarChar, Id);
            if (dt.Rows.Count > 0)
            {
                DataRow dr = dt.Rows[0];
                CommentsBL objCommentsBL = new CommentsBL(Common.GetConString());
                List<int> likes = objCommentsBL.LoadAllLikes(Common.ToString(dr["ForumID"]));
                ForumsDetails objForumsDetails = new ForumsDetails()
                {
                    ForumID = Common.ToString(dr["ForumID"]),
                    CreatedByName = Common.ToString(dr["CreatedByName"]),
                    CreatedByImageUrl = Common.ToString(dr["ImageUrl"]),
                    Title = Common.ToString(dr["Title"]),
                    Details = Common.ToString(dr["Details"]),
                    Type = Common.ToString(dr["Type"]),
                    Status = Common.ToString(dr["Status"]),
                    CTName = Common.ToString(dr["CTName"]),
                    RoomNo = Common.ToString(dr["RoomNo"]),
                    Priority = Common.ToString(dr["Priority"]),
                    CreatedDate = Common.ToDate(dr["CreatedDate"]),
                    LastUpdateDate = Common.ToDate(dr["LastUpdateDate"]),
                    Comments = objCommentsBL.LoadAllComments(Common.ToString(dr["ForumID"])),
                    LikeCount = likes.Count,
                    YouLiked = likes.Exists(Obj => Obj == objLoggedUser.UserID)
                };
                return JsonConvert.DeserializeObject(JsonConvert.SerializeObject(objForumsDetails));
            }

            return JsonConvert.DeserializeObject(JsonConvert.SerializeObject(new ForumsDetails()));
        }

        // POST api/Forums/
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        public object Post([FromBody]dynamic value)
        {
            PostResponse objPostResponse = new PostResponse();
            //Common.IsValidForm(Constants.Forms.Forum, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser == null) throw new HttpResponseException(HttpStatusCode.Unauthorized);

            JObject objJObject = value;
            Forums objForums = objJObject.ToObject<Forums>();
            ForumsBL objForumsBL = new ForumsBL(Common.GetConString());
            objForumsBL.Data = objForums;
            bool sendNotificationToAdmin = false;
            if (objForumsBL.IsNew)
            {
                if (objForums.Type == "Complaint Box")
                {
                    objForums.Status = "Open";
                    if (objLoggedUser.UserType != 2)
                    {
                        sendNotificationToAdmin = true;
                    }
                }
            }
            ForumsValidator validator = new ForumsValidator();
            ValidationResult results = validator.Validate(objForums);

            if (results.IsValid)
            {
                objForums.CreatedBy = objLoggedUser.UserID;
                objForums.CreatedDate = objForums.LastUpdateDate = DateTime.Now;
                objForums.SocID = objLoggedUser.SocID;
                objForumsBL.Data = objForums;
                if (objForumsBL.Update())
                {
                    if (sendNotificationToAdmin)
                    {
                        //get soc admin email and mobile
                        DataTable dtAdmin = Common.GetDBResultParameterized(@"Select MobileNo,EmailID from Users
where UserID=(select UserID from Soc where SocID=@SocID)", "@SocID", SqlDbType.Int, objLoggedUser.SocID);
                        if (dtAdmin.Rows.Count > 0)
                        {
                            string mobileNo = Common.ToString(dtAdmin.Rows[0]["MobileNo"]);
                            string emailID = Common.ToString(dtAdmin.Rows[0]["EmailID"]);
                            Common.SendSMS(mobileNo, "New Complaint Registered. " + objLoggedUser.SocName, 0);
                            Common.InsertIntoAlerts("New Complaint Registered. " + objLoggedUser.SocName, objLoggedUser.SocID, 0, "COMPLAINT");
                        }
                    }
                }
                objPostResponse.ErrorCode = 0;
                objPostResponse.data = JsonConvert.DeserializeObject(JsonConvert.SerializeObject(objForumsBL.Data));
                return objPostResponse;
            }
            objPostResponse.ErrorCode = 1;
            objPostResponse.data = JsonConvert.DeserializeObject(JsonConvert.SerializeObject(results.Errors));
            objPostResponse.ErrorMessage = Common.ErrorToString(results);
            return objPostResponse;
        }

        // DELETE api/Forums/5
        [Route("api/Forums/{Id}")]
        [HttpDelete]
        public string Delete(string Id)
        {
            Common.IsValidForm(Constants.Forms.Forum, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser == null) throw new HttpResponseException(HttpStatusCode.Unauthorized);

            ForumsBL objForumsBL = new ForumsBL(Common.GetConString());

            bool result = objForumsBL.Delete(Id);
            if (result)
                return String.Empty;
            else
                return "Forum/Complaint Box not deleted!";
        }
        [Route("api/Forums/CloseComplaint/")]
        [HttpPost]
        public bool CloseComplaint([FromBody]dynamic value)
        {
            //Common.IsValidForm(Constants.Forms.ForumList, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser == null) throw new HttpResponseException(HttpStatusCode.Unauthorized);

            JObject objJObject = value;
            Forums objForums = objJObject.ToObject<Forums>();
            Common.ExecuteNonQuery("Update Forums set Status=@Status where ForumID=@ForumID",
                "@ForumID", SqlDbType.VarChar, objForums.ForumID,
                "@Status", SqlDbType.VarChar, objForums.Status);
            CommentsBL objBL = new CommentsBL(Common.GetConString());
            Comments objComments = new Comments();
            objComments.CommentDate = DateTime.Now;
            objComments.CommentedBy = objLoggedUser.UserID;
            objComments.CommentID = 0;
            objComments.ForumID = objForums.ForumID;
            objComments.Remarks = "Complaint " + (objForums.Status == "Open" ? "Re-Opened" : objForums.Status) + "!";
            objBL.Data = objComments;
            objBL.Update();
            return true;
        }
    }
    public class ForumsValidator : AbstractValidator<Forums>
    {
        public ForumsValidator()
        {

            RuleFor(obj => obj.Details).NotEmpty();
            RuleFor(obj => obj.Title).NotEmpty();
        }
    }
}

