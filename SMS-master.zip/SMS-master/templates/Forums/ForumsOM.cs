using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{
    public class ForumsDetails
    {
        public string ForumID { get; set; }
        public string Title { get; set; }
        public string Details { get; set; }
        public string CreatedByName { get; set; }
        public string CreatedByImageUrl { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public List<CommentDetails> Comments { get; set; }
        public string CurrentRemarks { get; set; }
        public int LikeCount { get; set; }
        public int CommentCount { get; set; }
        public bool YouLiked { get; set; }
        public string Type { get; set; }
        public string Status { get; set; }
        public string Priority { get; set; }
        public string CTName { get; set; }
        public int ID { get; set; }
        public string RoomNo { get; set; }
    }
    public class CommentDetails
    {
        public int CommentID { get; set; }
        public string Remarks { get; set; }
        public string CommentedByName { get; set; }
        public string CommentedByImageUrl { get; set; }
        public DateTime CommentDate { get; set; }
    }
    [Serializable]
    [Table(Name = "dbo.Forums")]
    public class Forums
    {

        private System.Nullable<int> _CreatedBy;
        private System.Nullable<DateTime> _CreatedDate;
        private string _Details;
        private string _ForumID;
        private System.Nullable<DateTime> _LastUpdateDate;
        private System.Nullable<int> _SocID;
        private string _Title;
        private string _Type;
        private string _CreatedByName;
        private string _CreatedByImageUrl;
        private string _Status;
        private Nullable<int> _CTTypeID;
        private string _Priority;
        private Nullable<int> _RoomID;

        [Column(Storage = "_RoomID")]
        public Nullable<int> RoomID
        {
            get { return _RoomID; }
            set { _RoomID = value; }
        }

        [Column(Storage = "_Priority")]
        public string Priority
        {
            get { return _Priority; }
            set { _Priority = value; }
        }

        [Column(Storage = "_CTTypeID")]
        public Nullable<int> CTTypeID
        {
            get { return _CTTypeID; }
            set { _CTTypeID = value; }
        }

        [Column(Storage = "_Status")]
        public string Status
        {
            get { return _Status; }
            set { _Status = value; }
        }

        [Column(Storage = "_CreatedByImageUrl")]
        public string CreatedByImageUrl
        {
            get { return _CreatedByImageUrl; }
            set { _CreatedByImageUrl = value; }
        }

        [Column(Storage = "_CreatedByName")]
        public string CreatedByName
        {
            get { return _CreatedByName; }
            set { _CreatedByName = value; }
        }

        [Column(Storage = "_CreatedBy")]
        public System.Nullable<int> CreatedBy
        {
            get
            {
                return _CreatedBy;
            }
            set
            {
                _CreatedBy = value;
            }
        }

        [Column(Storage = "_CreatedDate")]
        public System.Nullable<DateTime> CreatedDate
        {
            get
            {
                return _CreatedDate;
            }
            set
            {
                _CreatedDate = value;
            }
        }

        [Column(Storage = "_Details")]
        public string Details
        {
            get
            {
                return _Details;
            }
            set
            {
                _Details = value;
            }
        }

        [Column(Storage = "_ForumID")]
        public string ForumID
        {
            get
            {
                return _ForumID;
            }
            set
            {
                _ForumID = value;
            }
        }

        [Column(Storage = "_LastUpdateDate")]
        public System.Nullable<DateTime> LastUpdateDate
        {
            get
            {
                return _LastUpdateDate;
            }
            set
            {
                _LastUpdateDate = value;
            }
        }

        [Column(Storage = "_SocID")]
        public System.Nullable<int> SocID
        {
            get
            {
                return _SocID;
            }
            set
            {
                _SocID = value;
            }
        }

        [Column(Storage = "_Title")]
        public string Title
        {
            get
            {
                return _Title;
            }
            set
            {
                _Title = value;
            }
        }

        [Column(Storage = "_Type")]
        public string Type
        {
            get
            {
                return _Type;
            }
            set
            {
                _Type = value;
            }
        }

        public List<Comments> Comments { get; set; }
    }
}
