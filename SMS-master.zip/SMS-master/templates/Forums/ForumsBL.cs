using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
    [Serializable]
    public class ForumsBL
    {

        #region Declaration
        private string connectionString;
        Forums _Forums;
        public Forums Data
        {
            get { return _Forums; }
            set { _Forums = value; }
        }
        public bool IsNew
        {
            get { return String.IsNullOrEmpty(_Forums.ForumID); }
        }
        #endregion

        #region Constructor
        public ForumsBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private ForumsDL CreateDL()
        {
            return new ForumsDL(connectionString);
        }
        public void New()
        {
            _Forums = new Forums();
        }
        public void Load(int ForumID)
        {
            var ForumsObj = this.CreateDL();
            _Forums = ForumID <= 0 ? ForumsObj.Load(-1) : ForumsObj.Load(ForumID);
        }
        public DataTable LoadAllForums()
        {
            var ForumsDLObj = CreateDL();
            return ForumsDLObj.LoadAllForums();
        }
        public bool Update()
        {
            var ForumsDLObj = CreateDL();
            return ForumsDLObj.Update(this.Data);
        }
        public bool Delete(string ForumID)
        {
            var ForumsDLObj = CreateDL();
            return ForumsDLObj.Delete(ForumID);
        }
        #endregion
    }
}
