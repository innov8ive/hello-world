using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;
using System.IO;

namespace SampleAngular.Api
{
    public class GLController : ApiController
    {
        [Route("api/GL/UploadGL/")]
        [HttpPost]
        public string UploadGL([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.ChartsofAccount, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            try
            {
                int GroupID = Common.ToInt(value.GroupID);
                JArray objJObject = value.Data;
                List<GLUpload> data = objJObject.ToObject<List<GLUpload>>();
                GLBL objGLBL = new GLBL(Common.GetConString());
                GL objGL = null;
                foreach (GLUpload objGLUpload in data)
                {
                    objGL = new GL();
                    objGL.CompanyID = objLoggedUser.SocID;
                    objGL.GLID = 0;
                    objGL.GLName = objGLUpload.GLName;
                    objGL.GroupID = GroupID;
                    objGL.IsSysDefined = false;
                    objGL.OnCredit = objGLUpload.Credit;
                    objGL.OnDebit = objGLUpload.Debit;

                    objGLBL.Data = objGL;
                    objGLBL.Update();
                }

                return "Data Uploaded Successfully!";
            }
            catch (Exception Ex)
            {
                return "Data Not Uploaded Successfully! " + Ex.Message;
            }
        }

        [Route("api/GLList/")]
        [HttpPost]
        public AngularGridData GetGL([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.ChartsofAccount, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            //GLBL objGLBL = new GLBL(Common.GetConString());
            //SocBL objSocBL = new SocBL(Common.GetConString());
            //objSocBL.CreateDefaultGL(Common.ToInt(objLoggedUser.SocID), objGLBL.LoadDefaultGLs());

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = @"select ISNULL(P.GroupName,G.GroupName ) as GroupName,
case when P.GroupName IS null then '' else G.GroupName end as SubGroupName,
GL.GLID,GL.GLNo,GL.GLName, GL.OnDebit,GL.OnCredit from GL left outer join Groups G ON G.GroupID=GL.GroupID
left outer join Groups P ON G.ParentGroupID=P.GroupID where GL.CompanyID=@CompanyID";
            Hashtable ht = new Hashtable();
            ht["@CompanyID"] = objLoggedUser.SocID;
            objAngularDataBinder.OrderBy = "GroupName";
            objAngularDataBinder.OrderDir = "Asc";
            objAngularDataBinder.Parameters = ht;
            objAngularDataBinder.ValueField = "GLID";
            return objAngularDataBinder.GetData();
        }

        // GET api/GL/Id
        [Route("api/GL/{Id}")]
        public string GetGL(int Id)
        {
            Common.IsValidForm(Constants.Forms.ChartsofAccount, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            GLBL objGLBL = new GLBL(Common.GetConString());
            objGLBL.Load(Id);
            return JsonConvert.SerializeObject(objGLBL.Data);
        }

        // POST api/GL/
        public string Post([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.ChartsofAccount, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            GL objGL = objJObject.ToObject<GL>();
            GLBL objGLBL = new GLBL(Common.GetConString());
            objGLBL.Data = objGL;

            GLValidator validator = new GLValidator();
            ValidationResult results = validator.Validate(objGL);
            if (objGLBL.IsNew)
            {
                objGL.CompanyID = objLoggedUser.SocID;
            }
            if (results.IsValid)
            {
                objGLBL.Update();
                return JsonConvert.SerializeObject(objGLBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        // DELETE api/GL/5
        [Route("api/GL/{Id}")]
        [HttpDelete]
        public bool Delete(int Id)
        {
            Common.IsValidForm(Constants.Forms.ChartsofAccount, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);


            GLBL objGLBL = new GLBL(Common.GetConString());
            return objGLBL.Delete(Id);
        }

        [Route("api/GL/RemovePhoto/")]
        [HttpPost]
        public string GLRemovePhoto([FromBody]dynamic param)
        {
            int ID = 0;
            string imageUrl;
            string data = param;
            if (data.Contains("."))
            {
                ID = Common.ToInt(data.Substring(0, data.IndexOf(".")));
                imageUrl = data.Substring(data.IndexOf(".") + 1);
                int count = Common.ExecuteNonQuery("Update GL Set ImageUrl='' where ID=@ID", "@ID", SqlDbType.Int, Common.ToInt(ID));
                if (count > 0)
                {
                    try
                    {
                        string filePath = HttpContext.Current.Server.MapPath("~/images/profile") + "/" + imageUrl;
                        File.Delete(filePath);
                    }
                    catch { }
                    return "true";
                }
                else
                {
                    return "false";
                }
            }
            return "false";
        }
        [Route("api/GL/AttachPhoto/")]
        [HttpPost]
        public string GLAttachPhoto([FromBody]dynamic param)
        {
            int ID = 0;
            string imageUrl;
            string data = param;
            if (data.Contains("."))
            {
                ID = Common.ToInt(data.Substring(0, data.IndexOf(".")));
                imageUrl = data.Substring(data.IndexOf(".") + 1);

                int count = Common.ExecuteNonQuery("Update GL Set ImageUrl=@ImageUrl where ID=@ID"
                    , "@ID", SqlDbType.Int, ID
                    , "@ImageUrl", SqlDbType.VarChar, imageUrl);
                if (count > 0)
                {
                    return imageUrl;
                }
                else
                {
                    return String.Empty;
                }
            }
            return String.Empty;
        }
    }
    public class GLValidator : AbstractValidator<GL>
    {
        public GLValidator()
        {
            RuleFor(obj => obj.GLName).NotEmpty();
        }
    }

    [Serializable]
    public class GLUpload
    {
        public string GLName { get; set; }
        public Nullable<int> GroupID { get; set; }
        public Nullable<decimal> Credit { get; set; }
        public Nullable<decimal> Debit { get; set; }
    }
}

