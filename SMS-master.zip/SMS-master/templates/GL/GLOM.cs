using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
namespace SampleAngularOM
{
    [Serializable]
    [Table(Name = "dbo.GL")]
    public class GL
    {
        private System.Nullable<int> _GLID;
        private string _GLName;
        private Nullable<int> _GLNo;
        private System.Nullable<int> _GroupID;
        private System.Nullable<bool> _IsSysDefined;
        private System.Nullable<int> _SrNo;
        private string _GroupName;
        private Nullable<decimal> _OnCredit;
        private Nullable<decimal> _OnDebit;
        private System.Nullable<int> _CompanyID;
        private int? _OrgID;
        private Nullable<int> _ChgID;

        [Column(Storage = "_ChgID")]
        public Nullable<int> ChgID
        {
            get { return _ChgID; }
            set { _ChgID = value; }
        }

        [Column(Storage = "_GLID")]
        public System.Nullable<int> GLID
        {
            get
            {
                return _GLID;
            }
            set
            {
                _GLID = value;
            }
        }
        [Column(Storage = "_GLName")]
        public string GLName
        {
            get
            {
                return _GLName;
            }
            set
            {
                _GLName = value;
            }
        }
        [Column(Storage = "_GLNo")]
        public Nullable<int> GLNo
        {
            get
            {
                return _GLNo;
            }
            set
            {
                _GLNo = value;
            }
        }
        [Column(Storage = "_GroupID")]
        public System.Nullable<int> GroupID
        {
            get
            {
                return _GroupID;
            }
            set
            {
                _GroupID = value;
            }
        }
        [Column(Storage = "_IsSysDefined")]
        public System.Nullable<bool> IsSysDefined
        {
            get
            {
                return _IsSysDefined;
            }
            set
            {
                _IsSysDefined = value;
            }
        }
        [Column(Storage = "_SrNo")]
        public System.Nullable<int> SrNo
        {
            get
            {
                return _SrNo;
            }
            set
            {
                _SrNo = value;
            }
        }
        [Column(Storage = "_GroupName")]
        public string GroupName
        {
            get
            {
                return _GroupName;
            }
            set
            {
                _GroupName = value;
            }
        }
        [Column(Storage = "_OnCredit")]
        public Nullable<decimal> OnCredit
        {
            get
            {
                return _OnCredit;
            }
            set
            {
                _OnCredit = value;
            }
        }
        [Column(Storage = "_OnDebit")]
        public Nullable<decimal> OnDebit
        {
            get
            {
                return _OnDebit;
            }
            set
            {
                _OnDebit = value;
            }
        }
        [Column(Storage = "_CompanyID")]
        public Nullable<int> CompanyID
        {
            get
            {
                return _CompanyID;
            }
            set
            {
                _CompanyID = value;
            }
        }
        [Column(Storage = "_OrgID")]
        public Nullable<int> OrgID
        {
            get
            {
                return _OrgID;
            }
            set
            {
                _OrgID = value;
            }
        }
    }
}
