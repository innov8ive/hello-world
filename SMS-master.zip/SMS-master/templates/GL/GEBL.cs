using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularDL;
using SampleAngularOM;

namespace SampleAngularBL
{
    [Serializable]
    public class GEBL
    {
        #region Declaration
        private string connectionString;
        GE _GE;
        public GE Data
        {
            get { return _GE; }
            set { _GE = value; }
        }
        #endregion
        #region Constructor
        public GEBL(string conString)
        {
            connectionString = conString;
        }
        #endregion
        #region Main Methods
        private GEDL CreateDL()
        {
            return new GEDL(connectionString);
        }
        public void New()
        {
            _GE = new GE();
        }
        public void Load(int GEID)
        {
            var GEObj = this.CreateDL();
            _GE = GEID <= 0 ? GEObj.Load(-1) : GEObj.Load(GEID);
        }
        public DataTable LoadAllGE()
        {
            var GEDLObj = CreateDL();
            return GEDLObj.LoadAllGE();
        }
        public bool Update()
        {
            var GEDLObj = CreateDL();
            return GEDLObj.Update(this.Data);
        }
        public bool Delete(int GEID)
        {
            var GEDLObj = CreateDL();
            return GEDLObj.Delete(GEID);
        }
        #endregion
    }
}
