using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
namespace SampleAngularOM
{
    [Serializable]
    [Table(Name = "dbo.GE")]
    public class GE
    {
        private string _Comment;
        private System.Nullable<int> _CompanyID;
        private System.Nullable<decimal> _Cr;
        private System.Nullable<decimal> _Dr;
        private System.Nullable<DateTime> _GEDate;
        private System.Nullable<int> _GLID;
        private System.Nullable<int> _RefID;
        private string _RefNo;
        private int? _LocationID;
        private DateTime? _EntryDate;
        private int? _GroupNo;
        private int? _GEGroupID;
        private string _TransType;

        [Column(Storage = "_TransType")]
        public string TransType
        {
            get { return _TransType; }
            set { _TransType = value; }
        }

        [Column(Storage = "_Comment")]
        public string Comment
        {
            get
            {
                return _Comment;
            }
            set
            {
                _Comment = value;
            }
        }
        [Column(Storage = "_CompanyID")]
        public System.Nullable<int> CompanyID
        {
            get
            {
                return _CompanyID;
            }
            set
            {
                _CompanyID = value;
            }
        }
        [Column(Storage = "_Cr")]
        public System.Nullable<decimal> Cr
        {
            get
            {
                return _Cr;
            }
            set
            {
                _Cr = value;
            }
        }
        [Column(Storage = "_Dr")]
        public System.Nullable<decimal> Dr
        {
            get
            {
                return _Dr;
            }
            set
            {
                _Dr = value;
            }
        }
        [Column(Storage = "_GEDate")]
        public System.Nullable<DateTime> GEDate
        {
            get
            {
                return _GEDate;
            }
            set
            {
                _GEDate = value;
            }
        }
        [Column(Storage = "_GLID")]
        public System.Nullable<int> GLID
        {
            get
            {
                return _GLID;
            }
            set
            {
                _GLID = value;
            }
        }
        [Column(Storage = "_RefID")]
        public System.Nullable<int> RefID
        {
            get
            {
                return _RefID;
            }
            set
            {
                _RefID = value;
            }
        }
        [Column(Storage = "_RefNo")]
        public string RefNo
        {
            get
            {
                return _RefNo;
            }
            set
            {
                _RefNo = value;
            }
        }
        [Column(Storage = "_LocationID")]
        public System.Nullable<int> LocationID
        {
            get
            {
                return _LocationID;
            }
            set
            {
                _LocationID = value;
            }
        }
        [Column(Storage = "_GroupNo")]
        public System.Nullable<int> GroupNo
        {
            get
            {
                return _GroupNo;
            }
            set
            {
                _GroupNo = value;
            }
        }
        [Column(Storage = "_EntryDate")]
        public System.Nullable<DateTime> EntryDate
        {
            get
            {
                return _EntryDate;
            }
            set
            {
                _EntryDate = value;
            }
        }
        [Column(Storage = "_GEGroupID")]
        public System.Nullable<int> GEGroupID
        {
            get
            {
                return _GEGroupID;
            }
            set
            {
                _GEGroupID = value;
            }
        }
    }
}
