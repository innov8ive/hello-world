using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularDL;
using SampleAngularOM;

namespace SampleAngularBL
{
    [Serializable]
    public class GLBL
    {
        #region Declaration
        private string connectionString;
        GL _GL;
        public GL Data
        {
            get { return _GL; }
            set { _GL = value; }
        }
        public bool IsNew
        {
            get { return (_GL.GLID <= 0 || _GL.GLID == null); }
        }
        #endregion

        #region Constructor
        public GLBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private GLDL CreateDL()
        {
            return new GLDL(connectionString);
        }
        public void New()
        {
            _GL = new GL();
        }
        public void Load(int GLID)
        {
            var GLObj = this.CreateDL();
            _GL = GLID <= 0 ? GLObj.Load(-1) : GLObj.Load(GLID);
        }
        public DataTable LoadAllGL()
        {
            var GLDLObj = CreateDL();
            return GLDLObj.LoadAllGL();
        }
        public bool Update()
        {
            var GLDLObj = CreateDL();
            return GLDLObj.Update(this.Data);
        }
        public bool Delete(int GLID)
        {
            var GLDLObj = CreateDL();
            return GLDLObj.Delete(GLID);
        }
        public int GetGroupID(int GLID)
        {
            var GLDLObj = CreateDL();
            return GLDLObj.GetGroupID(GLID);
        }
        public List<GL> LoadDefaultGLs()
        {
            var GLDLObj = CreateDL();
            return GLDLObj.LoadDefaultGLs();
        }
        #endregion
    }
}
