var app = angular.module('myApp');

app.controller('GLListCtrl', function ($scope, $http, $location, GridData) {

    $scope = readyAngularGrid($scope, $http, 'api/GLList', 'GLID', GridData, 'GL');
    $scope.gridOptions.columnDefs = [

    { displayName: 'Group Name', field: 'GroupName' },
    { displayName: 'Sub Group Name', field: 'SubGroupName' },
    { displayName: 'GL Name', field: 'GLName' },
    { displayName: 'Opening Cr. Balance', field: 'OnCredit' },
    { displayName: 'Opening Dr. Balance', field: 'OnDebit' },
    ];
    $scope.pagingOptions = {
        pageSizes: [10, 20, 30,100,200,500],
        pageSize: 500,
        currentPage: 1
    };
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchGL = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };
    $scope.newGL = function () {
        saveGridData($scope, GridData, 'GL');
        $location.path('/GL/0');
    };
    $scope.editGL = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            saveGridData($scope, GridData, 'GL');
            $location.path('/GL/' + selected[0].GLID);
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.deleteGL = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'DELETE',
                url: 'api/GL/' + selected[0].GLID
            }).success(function (result) {
                if (result == true)
                    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
            });
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.uploadGL = function () {
        $location.path('/CSVUpload');
    };
})

.controller('GLCtrl', function ($scope, $http, $location, $routeParams) {
    var ID = $routeParams.GLID;
    $scope.GL = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.GLSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.GLSubmitted = true;
        if ($scope.formGL.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/GL', $scope.GL, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.GL = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/GLList');
    }

    $scope.grouplist = [];
    $scope.bindGroup = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetGroupSubGroupList', Data: null })
        }).success(function (data) {
            $scope.grouplist = data;
        });
    }
    $scope.bindGroup();

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/GL/' + ID
        }).success(function (GL) {
            $scope.GL = JSON.parse(GL);
        });
    }, 100);
});
