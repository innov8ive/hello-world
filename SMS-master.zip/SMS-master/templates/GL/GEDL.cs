using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
    public class GEDL
    {
        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public GEDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public GE Load(int GEID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            GE objGE = new GE();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get GE
                var resultGE = dc.ExecuteQuery<GE>("exec Get_GE {0}", GEID).ToList();
                if (resultGE.Count > 0)
                {
                    objGE = resultGE[0];
                }
                dc.Dispose();
                return objGE;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllGE()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_GE", con);
            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();
            return dt;
        }
        public bool Update(GE objGE)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update GE
                UpdateGE(objGE, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int GEID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete GE
                DeleteGE(GEID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool UpdateGE(GE objGE, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_GE", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Transaction = trn;
                cmd.Parameters.Add("@Comment", SqlDbType.VarChar, 200).Value = objGE.Comment;
                cmd.Parameters.Add("@CompanyID", SqlDbType.Int).Value = objGE.CompanyID;
                cmd.Parameters.Add("@Cr", SqlDbType.Decimal).Value = objGE.Cr;
                cmd.Parameters.Add("@Dr", SqlDbType.Decimal).Value = objGE.Dr;
                cmd.Parameters.Add("@GEDate", SqlDbType.DateTime).Value = objGE.GEDate;
                cmd.Parameters.Add("@GLID", SqlDbType.Int).Value = objGE.GLID;
                cmd.Parameters.Add("@RefID", SqlDbType.Int).Value = objGE.RefID;
                cmd.Parameters.Add("@RefNo", SqlDbType.VarChar, 100).Value = objGE.RefNo;
                cmd.Parameters.Add("@LocationID", SqlDbType.Int).Value = objGE.LocationID;
                cmd.Parameters.Add("@GroupNo", SqlDbType.Int).Value = objGE.GroupNo;
                cmd.Parameters.Add("@EntryDate", SqlDbType.DateTime).Value = objGE.EntryDate;
                cmd.Parameters.Add("@GEGroupID", SqlDbType.Int).Value = objGE.GEGroupID;
                cmd.Parameters["@GEGroupID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@TransType", SqlDbType.VarChar, 20).Value = objGE.TransType;
                cmd.ExecuteNonQuery();
                //after updating the GE, update GEID
                objGE.GEGroupID = Convert.ToInt32(cmd.Parameters["@GEGroupID"].Value);
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteGE(int GEID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from GE where GEID=@GEID", trn.Connection);
                cmd.Transaction = trn;
                cmd.Parameters.Add("@GEID", SqlDbType.Int).Value = GEID;
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        #endregion
    }
}
