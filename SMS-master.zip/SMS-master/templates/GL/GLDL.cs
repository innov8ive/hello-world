using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
    public class GLDL
    {
        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public GLDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public GL Load(int GLID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            GL objGL = new GL();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get GL
                var resultGL = dc.ExecuteQuery<GL>("exec Get_GL {0}", GLID).ToList();
                if (resultGL.Count > 0)
                {
                    objGL = resultGL[0];
                }
                dc.Dispose();
                return objGL;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public GL LoadByOrgID(int orgID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            GL objGL = new GL();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get GL
                var resultGL = dc.ExecuteQuery<GL>("exec Get_GL_ByOrgID {0}", orgID).ToList();
                if (resultGL.Count > 0)
                {
                    objGL = resultGL[0];
                }
                dc.Dispose();
                return objGL;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public GL LoadByChgID(int chgID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            GL objGL = new GL();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get GL
                var resultGL = dc.ExecuteQuery<GL>("exec Get_GL_ByChgID {0}", chgID).ToList();
                if (resultGL.Count > 0)
                {
                    objGL = resultGL[0];
                }
                dc.Dispose();
                return objGL;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public List<GL> LoadDefaultGLs()
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            var dc = new DataContext(SqlCon);
            try
            {
                var resultGL = dc.ExecuteQuery<GL>("Select * from GL where CompanyID=0").ToList();

                dc.Dispose();
                return resultGL;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllGL()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_GL", con);
            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();
            return dt;
        }
        public bool Update(GL objGL)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update GL
                UpdateGL(objGL, trn);
                if (objGL.GLID > 0)
                {
                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int GLID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete GL
                DeleteGL(GLID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool UpdateGL(GL objGL, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_GL", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Transaction = trn;
                cmd.Parameters.Add("@GLID", SqlDbType.Int).Value = objGL.GLID;
                cmd.Parameters["@GLID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@GLName", SqlDbType.VarChar, 100).Value = objGL.GLName;
                cmd.Parameters.Add("@GLNo", SqlDbType.VarChar, 50).Value = objGL.GLNo;
                cmd.Parameters.Add("@GroupID", SqlDbType.Int).Value = objGL.GroupID;
                cmd.Parameters.Add("@IsSysDefined", SqlDbType.Bit).Value = objGL.IsSysDefined;
                cmd.Parameters.Add("@SrNo", SqlDbType.Int).Value = objGL.SrNo;
                cmd.Parameters.Add("@OnCredit", SqlDbType.Decimal).Value = objGL.OnCredit;
                cmd.Parameters.Add("@OnDebit", SqlDbType.Decimal).Value = objGL.OnDebit;
                cmd.Parameters.Add("@CompanyID", SqlDbType.Int).Value = objGL.CompanyID;
                cmd.Parameters.Add("@OrgID", SqlDbType.Int).Value = objGL.OrgID;
                cmd.Parameters.Add("@ChgID", SqlDbType.Int).Value = objGL.ChgID;
                cmd.ExecuteNonQuery();
                //after updating the GL, update GLID
                objGL.GLID = Convert.ToInt32(cmd.Parameters["@GLID"].Value);
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteGL(int GLID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from GL where GLID=@GLID", trn.Connection);
                cmd.Transaction = trn;
                cmd.Parameters.Add("@GLID", SqlDbType.Int).Value = GLID;
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        public int GetGroupID(int groupNo, int companyID)
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd =
                new SqlCommand("Select GroupID from Groups where GroupNo=" + groupNo + " and CompanyID=" + companyID,
                               con);
            con.Open();
            using (con)
            {
                dt.Load(cmd.ExecuteReader());
            }
            if (dt.Rows.Count > 0)
            {
                return Convert.ToInt32(dt.Rows[0]["GroupID"]);
            }
            else
            {
                return 0;
            }
        }
        public int GetGroupID(int GLID)
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd =
                new SqlCommand("Select GroupID from GL where GLID=" + GLID,
                               con);
            con.Open();
            using (con)
            {
                dt.Load(cmd.ExecuteReader());
            }
            if (dt.Rows.Count > 0)
            {
                return Convert.ToInt32(dt.Rows[0]["GroupID"]);
            }
            else
            {
                return 0;
            }
        }
        #endregion
    }
}
