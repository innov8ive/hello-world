using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
    public class CMDL
    {

        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public CMDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public CM Load(int CMID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            CM objCM = new CM();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get CM
                var resultCM = dc.ExecuteQuery<CM>("exec Get_CM {0}", CMID).ToList();
                if (resultCM.Count > 0)
                {
                    objCM = resultCM[0];
                }
                dc.Dispose();
                return objCM;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllCM()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_CM", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(CM objCM)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update CM
                UpdateCM(objCM, trn);
                if (objCM.CMID > 0)
                {

                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int CMID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete CM
                DeleteCM(CMID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateCM(CM objCM, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_CM", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@CMID", SqlDbType.Int).Value = objCM.CMID;
                cmd.Parameters["@CMID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@CMTypeID", SqlDbType.Int).Value = objCM.CMTypeID;
                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = objCM.SocID;
                cmd.Parameters.Add("@UserID", SqlDbType.Int).Value = objCM.UserID;
                cmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = objCM.FromDate;
                cmd.Parameters.Add("@ToDate", SqlDbType.DateTime).Value = objCM.ToDate;
                cmd.Parameters.Add("@CMTypeName", SqlDbType.VarChar, 100).Value = objCM.CMTypeName;

                cmd.ExecuteNonQuery();

                //after updating the CM, update CMID
                objCM.CMID = Convert.ToInt32(cmd.Parameters["@CMID"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteCM(int CMID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from CM where CMID=@CMID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@CMID", SqlDbType.Int).Value = CMID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        #endregion
    }
}
