var app = angular.module('myApp');

app.controller('CMListCtrl', function ($scope, $http, $location, GridData) {

    $scope = readyAngularGrid($scope, $http, 'api/CMList', 'CMID', GridData, 'CM');
    $scope.gridOptions.columnDefs = [

    { displayName: 'Member Type', field: 'CMTypeName' },
    { displayName: 'Member Name', field: 'UserName' },
    { displayName: 'Mobile', field: 'Mobile' },
    { displayName: 'From Date', field: 'FromDate', cellFilter: 'date:\'dd-MMM-yyyy\'' },
    { displayName: 'To Date', field: 'ToDate', cellFilter: 'date:\'dd-MMM-yyyy\'' }, ];
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchCM = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };
    $scope.newCM = function () {
        saveGridData($scope, GridData, 'CM');
        $location.path('/CM/0');
    };
    $scope.editCM = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            saveGridData($scope, GridData, 'CM');
            $location.path('/CM/' + selected[0].CMID);
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.deleteCM = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'DELETE',
                url: 'api/CM/' + selected[0].CMID
            }).success(function (result) {
                if (result == true)
                    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
            });
        }
        else {
            alert('Please select a record to edit.');
        }
    };
})

.controller('CMCtrl', function ($scope, $http, $location, $routeParams) {
    var CMID = $routeParams.CMID;
    $scope.CM = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.CMSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.CMSubmitted = true;
        if ($scope.formCM.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        if ($scope.CM.CMTypeID == 5 && ($scope.CM.CMTypeName == '' || $scope.CM.CMTypeName == null)) {
            swal({ title: "Please enter Other Member Type!", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        $http.post('api/CM', $scope.CM, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.CM = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/CMList');
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/CM/' + CMID
        }).success(function (CM) {
            $scope.CM = JSON.parse(CM);
        });
    }, 100);


    $scope.cmtypelist = [];
    $scope.bindCMType = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetCMTypeList', Data: null })
        }).success(function (data) {
            $scope.cmtypelist = data;
        });
    }
    $scope.bindCMType();

    $scope.userlist = [];
    $scope.bindUser = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetUserList', Data: null })
        }).success(function (data) {
            $scope.userlist = data;
        });
    }
    $scope.bindUser();
});
app.controller('CMListingCtrl', function ($scope, $http, $location, GridData) {

    $scope.cmlist = [];

    setTimeout(function () {
        $http({
            method: 'POST',
            url: 'api/CMListing/'
        }).success(function (data) {
            $scope.cmlist = data;
        });
    }, 100);
   
})