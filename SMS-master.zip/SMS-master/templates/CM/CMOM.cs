using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

    [Serializable]
    [Table(Name = "dbo.CM")]
    public class CM
    {

        private System.Nullable<int> _CMID;
        private System.Nullable<int> _CMTypeID;
        private System.Nullable<int> _SocID;
        private System.Nullable<int> _UserID;
        private Nullable<DateTime> _FromDate;
        private Nullable<DateTime> _ToDate;
        private string _CMTypeName;

        [Column(Storage = "_CMTypeName")]
        public string CMTypeName
        {
            get { return _CMTypeName; }
            set { _CMTypeName = value; }
        }

        [Column(Storage = "_ToDate")]
        public Nullable<DateTime> ToDate
        {
            get { return _ToDate; }
            set { _ToDate = value; }
        }

        [Column(Storage = "_FromDate")]
        public Nullable<DateTime> FromDate
        {
            get { return _FromDate; }
            set { _FromDate = value; }
        }


        [Column(Storage = "_CMID")]
        public System.Nullable<int> CMID
        {
            get
            {
                return _CMID;
            }
            set
            {
                _CMID = value;
            }
        }



        [Column(Storage = "_CMTypeID")]
        public System.Nullable<int> CMTypeID
        {
            get
            {
                return _CMTypeID;
            }
            set
            {
                _CMTypeID = value;
            }
        }



        [Column(Storage = "_SocID")]
        public System.Nullable<int> SocID
        {
            get
            {
                return _SocID;
            }
            set
            {
                _SocID = value;
            }
        }



        [Column(Storage = "_UserID")]
        public System.Nullable<int> UserID
        {
            get
            {
                return _UserID;
            }
            set
            {
                _UserID = value;
            }
        }

    }


}
