using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
[Serializable]
public class CMBL
{

#region Declaration
private string connectionString;
CM _CM;
public CM Data
{
get { return _CM; }
set { _CM = value; }
}
public bool IsNew
{
get { return (_CM.CMID <= 0 || _CM.CMID ==null); }
}
#endregion

#region Constructor
public CMBL(string conString)
{
connectionString = conString;
}
#endregion

#region Main Methods
private CMDL CreateDL()
{
return new CMDL(connectionString);
}
public void New()
{
_CM = new CM();
}
public void Load(int CMID)
{
var CMObj = this.CreateDL();
_CM = CMID <= 0 ? CMObj.Load(-1) : CMObj.Load(CMID);
}
public DataTable LoadAllCM()
{
var CMDLObj = CreateDL();
return CMDLObj.LoadAllCM();
}
public bool Update()
{
var CMDLObj = CreateDL();
return CMDLObj.Update(this.Data);
}
public bool Delete(int CMID)
{
var CMDLObj = CreateDL();
return CMDLObj.Delete(CMID);
}
#endregion
}
}
