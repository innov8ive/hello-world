using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;
using System.Web.Http.Cors;

namespace SampleAngular.Api
{
    public class CMController : ApiController
    {
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/CMListing/")]
        [HttpPost]
        public DataTable GetCMList([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.NormalUser, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            DataTable dt = Common.GetDBResult(@"Select CM.*,case when CM.CMTypeID=5 then CM.CMTypeName else CMT.CMTypeName end as CMTypeName2
,U.FirstName+ISNULL(' '+U.LastName,'') as UserName,U.MobileNo as Mobile,CM.FromDate,CM.ToDate,U.ImageUrl from CM 
left join CMType CMT ON CM.CMTypeID=CMT.CMTypeID 
inner join Users U ON CM.UserID =U.UserID
where CM.SocID=" + objLoggedUser.SocID + " order by CMT.SrNo");

            return dt;
        }

        [Route("api/CMList/")]
        [HttpPost]
        public AngularGridData GetCM([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.CommitteeMembers, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = @"Select CM.CMID,CM.CMTypeID,
CM.FromDate,CM.SocID,CM.ToDate,CM.UserID,case when CM.CMTypeID=5 then CM.CMTypeName else CMT.CMTypeName end as CMTypeName,U.FirstName+ISNULL(' '+U.LastName,'') as UserName,
U.MobileNo as Mobile from CM 
inner join CMType CMT ON CM.CMTypeID=CMT.CMTypeID 
inner join Users U ON CM.UserID =U.UserID
where CM.SocID=" + objLoggedUser.SocID;
            objAngularDataBinder.ValueField = "CMID";
            return objAngularDataBinder.GetData();
        }

        // GET api/CM/Id
        [Route("api/CM/{Id}")]
        public string GetCM(int Id)
        {
            Common.IsValidForm(Constants.Forms.CommitteeMembers, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            CMBL objCMBL = new CMBL(Common.GetConString());
            objCMBL.Load(Id);

            CM objCM = objCMBL.Data;
            if (Common.ToInt(objCM.SocID) > 0 && objCM.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            return JsonConvert.SerializeObject(objCMBL.Data);
        }

        // POST api/CM/
        public string Post([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.CommitteeMembers, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            CM objCM = objJObject.ToObject<CM>();
            CMBL objCMBL = new CMBL(Common.GetConString());
            objCMBL.Data = objCM;
            if (objCMBL.IsNew)
            {
                objCM.SocID = objLoggedUser.SocID;
            }

            CMValidator validator = new CMValidator();
            ValidationResult results = validator.Validate(objCM);

            if (!Common.IsUniqueInTable("CM", "UserID",
                Common.ToString(objCM.UserID),
                "CMID", Common.ToInt(objCM.CMID).ToString(), "SocID=" + Common.ToInt(objCM.SocID).ToString()))
            {
                results.Errors.Add(new ValidationFailure("UserID", "This User is already a Member of CM"));
            }

            if (results.IsValid)
            {
                if (objCM.CMTypeID != 5)//Others
                {
                    objCM.CMTypeName = String.Empty;
                }
                objCMBL.Update();
                return JsonConvert.SerializeObject(objCMBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        // DELETE api/CM/5
        [Route("api/CM/{Id}")]
        [HttpDelete]
        public bool Delete(int Id)
        {
            Common.IsValidForm(Constants.Forms.CommitteeMembers, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            CMBL objCMBL = new CMBL(Common.GetConString());
            objCMBL.Load(Id);

            CM objCM = objCMBL.Data;
            if (Common.ToInt(objCM.SocID) > 0 && objCM.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            return objCMBL.Delete(Id);
        }
    }
    public class CMValidator : AbstractValidator<CM>
    {
        public CMValidator()
        {
            RuleFor(obj => obj.CMTypeID).NotEmpty();
            RuleFor(obj => obj.UserID).NotEmpty();
        }
    }
}

