using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;
using System.IO;
using System.Web.Http.Cors;

namespace SampleAngular.Api
{
    public class ServicesController : ApiController
    {
        // GET api/Services
        [Route("api/ServicesList/")]
        [HttpPost]
        public AngularGridData GetServices([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.SystemAdmin, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser.SocID != 1)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = "Select * from Services";
            objAngularDataBinder.ValueField = "ServiceID";
            Hashtable ht = new Hashtable();
            ht["@SocID"] = objLoggedUser.SocID;
            objAngularDataBinder.Parameters = ht;
            return objAngularDataBinder.GetData();
        }

        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/GetAllServices/")]
        [HttpPost]
        public List<object> GetAllServices()
        {
            Common.IsValidForm(Constants.Forms.NormalUser, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            ServicesBL objServicesBL = new ServicesBL(Common.GetConString());
            List<object> objServicesList = new List<object>();
            DataTable dt = Common.GetDBResult("Select ServiceID from Services where Type='Active'");
            foreach (DataRow dr in dt.Rows)
            {
                objServicesBL.Load(Common.ToInt(dr["ServiceID"]), 1);
                objServicesList.Add(JsonConvert.DeserializeObject(JsonConvert.SerializeObject(objServicesBL.Data)));
            }
            return objServicesList;
        }

        // GET api/Services/Id
        [Route("api/Services/{Id}")]
        public string GetServices(int Id)
        {
            //Common.IsValidForm(Constants.Forms.Service, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            ServicesBL objServicesBL = new ServicesBL(Common.GetConString());
            objServicesBL.Load(Id, objLoggedUser.SocID);

            Services objServices = objServicesBL.Data;

            return JsonConvert.SerializeObject(objServicesBL.Data);
        }

        // POST api/Services/
        public string Post([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.SystemAdmin, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser.SocID != 1)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            JObject objJObject = value;
            Services objServices = objJObject.ToObject<Services>();
            ServicesBL objServicesBL = new ServicesBL(Common.GetConString());
            objServicesBL.Data = objServices;

            ServicesValidator validator = new ServicesValidator();
            ValidationResult results = validator.Validate(objServices);

            if (objLoggedUser.UserType != 2)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            if (results.IsValid)
            {
                objServices.SocID = objLoggedUser.SocID;
                objServicesBL.Update();
                return JsonConvert.SerializeObject(objServicesBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        // DELETE api/Services/5
        [Route("api/Services/{Id}")]
        [HttpDelete]
        public bool Delete(int Id)
        {
            Common.IsValidForm(Constants.Forms.SystemAdmin, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (Common.ToInt(Common.GetDBScalar("Select Count(*) from SubServices where ServiceID=" + Id)) > 0)
                return false;
            if (objLoggedUser.SocID != 1 || objLoggedUser.UserType != 2)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            ServicesBL objServicesBL = new ServicesBL(Common.GetConString());
            objServicesBL.Load(Id, objLoggedUser.SocID);
            Services objServices = objServicesBL.Data;
            if (Common.ToInt(objServices.SocID) > 0 && objServices.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            return objServicesBL.Delete(Id);
        }

        [Route("api/Services/RemovePhoto/")]
        [HttpPost]
        public string ServicesRemovePhoto([FromBody]dynamic param)
        {
            Common.IsValidForm(Constants.Forms.SystemAdmin, Request);
            int ServiceID = 0;
            string imageUrl;
            string data = param;
            if (data.Contains("."))
            {
                ServiceID = Common.ToInt(data.Substring(0, data.IndexOf(".")));
                imageUrl = data.Substring(data.IndexOf(".") + 1);
                int count = Common.ExecuteNonQuery("Update Services Set ImageUrl='' where ServiceID=@ServiceID", "@ServiceID", SqlDbType.Int, Common.ToInt(ServiceID));
                if (count > 0)
                {
                    try
                    {
                        string filePath = HttpContext.Current.Server.MapPath("~/images/profile") + "/" + imageUrl;
                        File.Delete(filePath);
                    }
                    catch { }
                    return "true";
                }
                else
                {
                    return "false";
                }
            }
            return "false";
        }
        [Route("api/Services/AttachPhoto/")]
        [HttpPost]
        public string ServicesAttachPhoto([FromBody]dynamic param)
        {
            Common.IsValidForm(Constants.Forms.SystemAdmin, Request);
            int ServiceID = 0;
            string imageUrl;
            string data = param;
            if (data.Contains("."))
            {
                ServiceID = Common.ToInt(data.Substring(0, data.IndexOf(".")));
                imageUrl = data.Substring(data.IndexOf(".") + 1);

                int count = Common.ExecuteNonQuery("Update Services Set ImageUrl=@ImageUrl where ServiceID=@ServiceID"
                    , "@ServiceID", SqlDbType.Int, ServiceID
                    , "@ImageUrl", SqlDbType.VarChar, imageUrl);
                if (count > 0)
                {
                    return imageUrl;
                }
                else
                {
                    return String.Empty;
                }
            }
            return String.Empty;
        }

        [Route("api/Services/DeleteSub/")]
        [HttpPost]
        public bool DeleteSub([FromBody]dynamic param)
        {
            Common.IsValidForm(Constants.Forms.SystemAdmin, Request);
            int subID = Common.ToInt(param);
            if (Common.ToInt(Common.GetDBScalar("Select Count(*) from SPSub where SubID=" + subID)) > 0)
                return false;

            Common.ExecuteNonQuery("delete from SubServices where SubID=" + subID);
            return true;
        }
    }
    public class ServicesValidator : AbstractValidator<Services>
    {
        public ServicesValidator()
        {
            RuleFor(obj => obj.ServiceName).NotEmpty();
        }
    }
}

