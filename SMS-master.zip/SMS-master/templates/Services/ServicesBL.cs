using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
    [Serializable]
    public class ServicesBL
    {

        #region Declaration
        private string connectionString;
        Services _Services;
        public Services Data
        {
            get { return _Services; }
            set { _Services = value; }
        }
        public bool IsNew
        {
            get { return (_Services.ServiceID <= 0 || _Services.ServiceID == null); }
        }
        #endregion

        #region Constructor
        public ServicesBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private ServicesDL CreateDL()
        {
            return new ServicesDL(connectionString);
        }
        public void New()
        {
            _Services = new Services();
        }
        public void Load(int ServiceID, int SocID)
        {
            var ServicesObj = this.CreateDL();
            _Services = ServiceID <= 0 ? ServicesObj.Load(-1, SocID) : ServicesObj.Load(ServiceID, SocID);
        }
        public DataTable LoadAllServices()
        {
            var ServicesDLObj = CreateDL();
            return ServicesDLObj.LoadAllServices();
        }
        public bool Update()
        {
            var ServicesDLObj = CreateDL();
            return ServicesDLObj.Update(this.Data);
        }
        public bool Delete(int ServiceID)
        {
            var ServicesDLObj = CreateDL();
            return ServicesDLObj.Delete(ServiceID);
        }
        #endregion
    }
}
