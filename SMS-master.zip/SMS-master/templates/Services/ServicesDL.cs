using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
    public class ServicesDL
    {

        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public ServicesDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public Services Load(int ServiceID, int SocID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            Services objServices = new Services();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get Services
                var resultServices = dc.ExecuteQuery<Services>("exec Get_Services {0}", ServiceID).ToList();
                if (resultServices.Count > 0)
                {
                    objServices = resultServices[0];
                    objServices.ServiceID = ServiceID;
                }
                //Get ServiceProviders
                var resultServiceProviders = dc.ExecuteQuery<ServiceProviders>("exec Get_ServiceProviders {0},{1}", ServiceID, SocID).ToList();
                objServices.ServiceProvidersList = resultServiceProviders;
                objServices.Types = new System.Collections.Hashtable();
                objServices.Types["ServiceProvidersList"] = new ServiceProviders();
                dc.Dispose();
                return objServices;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllServices()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_Services", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(Services objServices)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update Services
                UpdateServices(objServices, trn);
                if (objServices.ServiceID > 0)
                {
                    foreach (ServiceProviders objServiceProviders in objServices.ServiceProvidersList)
                    {
                        objServiceProviders.ServiceID = objServices.ServiceID;
                        InsertIntoServiceProviders(objServiceProviders, trn);
                    }
                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int ServiceID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete ServiceProviders
                DeleteServiceProviders(ServiceID, trn);
                //Delete Services
                DeleteServices(ServiceID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateServices(Services objServices, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_Services", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@ServiceID", SqlDbType.Int).Value = objServices.ServiceID;
                cmd.Parameters["@ServiceID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@ServiceName", SqlDbType.VarChar, 50).Value = objServices.ServiceName;
                cmd.Parameters.Add("@Icon", SqlDbType.VarChar, 20).Value = objServices.Icon;
                cmd.Parameters.Add("@ImageUrl", SqlDbType.VarChar, 50).Value = objServices.ImageUrl;
                cmd.Parameters.Add("@Type", SqlDbType.VarChar, 50).Value = objServices.Type;
                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = objServices.SocID;

                cmd.ExecuteNonQuery();

                //after updating the Services, update ServiceID
                objServices.ServiceID = Convert.ToInt32(cmd.Parameters["@ServiceID"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteServices(int ServiceID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from Services where ServiceID=@ServiceID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@ServiceID", SqlDbType.Int).Value = ServiceID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        public bool DeleteServiceProviders(int ServiceID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from ServiceProviders where ServiceID=@ServiceID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@ServiceID", SqlDbType.Int).Value = ServiceID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        public bool InsertIntoServiceProviders(ServiceProviders objServiceProviders, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Into_ServiceProviders", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Transaction = trn;


                cmd.Parameters.Add("@ServiceID", SqlDbType.Int).Value = objServiceProviders.ServiceID;
                cmd.Parameters.Add("@ServiceProviderName", SqlDbType.VarChar, 150).Value = objServiceProviders.ServiceProviderName;
                cmd.Parameters.Add("@ContactNo", SqlDbType.VarChar, 50).Value = objServiceProviders.ContactNo;
                cmd.Parameters.Add("@ZipCode", SqlDbType.VarChar, 8).Value = objServiceProviders.ZipCode;
                cmd.Parameters.Add("@City", SqlDbType.VarChar, 100).Value = objServiceProviders.City;
                cmd.Parameters.Add("@Address", SqlDbType.VarChar, 500).Value = objServiceProviders.Address;
                cmd.Parameters.Add("@SPID", SqlDbType.Int).Value = objServiceProviders.SPID;
                cmd.Parameters["@SPID"].Direction = ParameterDirection.InputOutput;

                cmd.ExecuteNonQuery();

                objServiceProviders.SPID = Convert.ToInt32(cmd.Parameters["@SPID"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        #endregion
    }
   
}

namespace BusinessLogic
{
    public interface IPerson
    {
        string Name { get; set; }
        decimal Salary { get; set; }
    }
    public class GradeCalculatorBL
    {
        public string CalculateGrade(IPerson objPerson)
        {
            if (objPerson.Salary > 1000)
            {
                return "A";
            }
            else
            {
                return "B";
            }
        }
    }
}

namespace UI
{
    public class Person : BusinessLogic.IPerson
    {
        private string _Name;
        public string Name
        {
            get
            {
                return _Name;
            }
            set
            {
                _Name = value;
            }
        }

        private decimal _Salary;
        public decimal Salary
        {
            get
            {
                return _Salary;
            }
            set
            {
                _Salary = value;
            }
        }
    }

    public class GradeCaculateUI
    {
        public void PrintGrade()
        {
            BusinessLogic.GradeCalculatorBL objGradeCalculator = new BusinessLogic.GradeCalculatorBL();
            Person objPerson1 = new Person();
            objPerson1.Name = "XYZ";
            objPerson1.Salary = 1200;
            objGradeCalculator.CalculateGrade(objPerson1);

            Person objPerson2 = new Person();
            objPerson2.Name = "XYZ";
            objPerson2.Salary = 1200;

            objGradeCalculator.CalculateGrade(objPerson2);
        }
    }
}
