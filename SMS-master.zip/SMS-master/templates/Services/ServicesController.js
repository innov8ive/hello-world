var app = angular.module('myApp');

app.controller('ServicesListCtrl', function ($scope, $http, $location, GridData) {

    $scope = readyAngularGrid($scope, $http, 'api/ServicesList', 'ServiceID', GridData, 'Services');
    $scope.gridOptions.columnDefs = [
    { displayName: 'Service Name', field: 'ServiceName' },
    { displayName: 'Type', field: 'Type' }, ];

    $scope.searchServices = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };
    $scope.newServices = function () {
        saveGridData($scope, GridData, 'Services');
        $location.path('/Services/0');
    };
    $scope.editServices = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            saveGridData($scope, GridData, 'Services');
            $location.path('/Services/' + selected[0].ServiceID);
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.deleteServices = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'DELETE',
                url: 'api/Services/' + selected[0].ServiceID
            }).success(function (result) {
                if (result == true)
                    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
                else
                    alert('You cannot delete this Service, because some transaction(s) related to this Service.')
            });
        }
        else {
            alert('Please select a record to edit.');
        }
    };
})

.controller('ServicesCtrl', function ($scope, $http, $location, $routeParams) {
    var ServiceID = $routeParams.ServiceID;
    $scope.Services = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.ServicesSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.ServicesSubmitted = true;
        if ($scope.formServices.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/Services', $scope.Services, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.Services = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/ServicesList');
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/Services/' + ServiceID
        }).success(function (Services) {
            $scope.Services = JSON.parse(Services);
        });
    }, 100);
    $scope.ServiceProviders = {};
    $scope.ServiceProvidersSubmitted = false;
    var ServiceProviders = [];
    $scope.editServiceProviders = function (indx) {
        $scope.EditMode = true;
        $scope.ServiceProviders = $scope.Services.ServiceProvidersList[indx];
        ServiceProviders = angular.copy($scope.Services.ServiceProvidersList);
    };
    $scope.deleteServiceProviders = function (indx) {
        var ServiceProviders = $scope.Services.ServiceProvidersList[indx];
        if (confirm('Are you sure want to delete?') == true) {
            $http({
                method: 'POST',
                url: 'api/Services/DeleteSub/',
                data: ServiceProviders.SubID
            }).success(function (result) {
                if (result == true)
                    $scope.Services.ServiceProvidersList.splice(indx, 1);
                else
                    alert('You cannot delete this Sub-Service, because some transaction(s) related to this Sub-Service.')
            });

        }
    };
    $scope.newServiceProviders = function () {
        $scope.EditMode = true;
        $scope.ServiceProvidersSubmitted = false;
        ServiceProviders = angular.copy($scope.Services.ServiceProvidersList);
        $scope.ServiceProviders = {};
        $scope.Services.ServiceProvidersList.push($scope.ServiceProviders);
    };
    $scope.cancelServiceProviders = function () {
        $scope.EditMode = false;
        $scope.ServiceProviders = {};
        angular.copy(ServiceProviders, $scope.Services.ServiceProvidersList);
    };
    $scope.updateServiceProviders = function (indx) {
        $scope.ServiceProvidersSubmitted = true;
        if ($scope.formServiceProviders.$invalid == true) return;
        $scope.EditMode = false;
        $scope.ServiceProviders = {};
    };

    $scope.removePhoto = function () {
        if (confirm('Are you sure, want to remove photo?')) {
            $http({
                method: 'POST',
                url: 'api/Services/RemovePhoto/',
                data: JSON.stringify($scope.Services.ServiceID + '.' + $scope.Services.ImageUrl)
            }).success(function (result) {
                if (result == 'true')
                    $scope.Services.ImageUrl = '';
            });
        }
    };
    $scope.uploadPhoto = function () {
        AttachImage($scope.photoUploaded, { width: 300, height: 240 });
    };
    $scope.photoUploaded = function (fileGUIDName, fileName, fileID) {
        $scope.Services.ImageUrl = fileGUIDName;
        $http({
            method: 'POST',
            url: 'api/Services/AttachPhoto/',
            data: JSON.stringify($scope.Services.ServiceID + '.' + $scope.Services.ImageUrl)
        }).success(function (result) {

        });
    };
})

app.controller('ServicesListingCtrl', function ($scope, $http, $location) {
    $scope.Services = [];
    $scope.showWin = false;
    $scope.winTitle = '';
    var randomColor = ['teal', 'green', 'orange', 'yellow', 'fuchsia', 'purple', 'maroon', 'olive', 'light-blue', 'red', 'blue' ];
    setTimeout(function () {
        $http({
            method: 'POST',
            url: 'api/GetAllServices'
        }).success(function (Services) {
            $scope.Services = Services;
        });
    }, 100);
    
    $scope.getRandomCss = function (indx) {
        return 'bg-' + randomColor[indx % 10];
    };
    $scope.showDetails = function (itm) {
        $scope.winTitle = itm.ServiceName;
        $scope.ServiceProvidersList = itm.ServiceProvidersList;
        $scope.showWin = true;
    };
});
app.directive('serviceprovider', function () {
    return {
        restrict: 'E',
        replace: true,
        templateUrl: 'templates/Services/ServiceProviders.html'
    }
});