using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

    [Serializable]
    [Table(Name = "dbo.Services")]
    public class Services
    {

        private System.Nullable<int> _ServiceID;
        private string _ServiceName;
        private string _Icon;
        private string _ImageUrl;
        private string _Type;
        private Nullable<int> _SocID;

        [Column(Storage = "_SocID")]
        public Nullable<int> SocID
        {
            get { return _SocID; }
            set { _SocID = value; }
        }

        [Column(Storage = "_Type")]
        public string Type
        {
            get { return _Type; }
            set { _Type = value; }
        }

        [Column(Storage = "_ServiceID")]
        public System.Nullable<int> ServiceID
        {
            get
            {
                return _ServiceID;
            }
            set
            {
                _ServiceID = value;
            }
        }

        [Column(Storage = "_ServiceName")]
        public string ServiceName
        {
            get
            {
                return _ServiceName;
            }
            set
            {
                _ServiceName = value;
            }
        }

        [Column(Storage = "_Icon")]
        public string Icon
        {
            get
            {
                return _Icon;
            }
            set
            {
                _Icon = value;
            }
        }

        [Column(Storage = "_ImageUrl")]
        public string ImageUrl
        {
            get
            {
                return _ImageUrl;
            }
            set
            {
                _ImageUrl = value;
            }
        }


        public System.Collections.Generic.List<ServiceProviders> ServiceProvidersList { get; set; }
        public Hashtable Types { get; set; }
    }


    [Serializable]
    [Table(Name = "dbo.ServiceProviders")]
    public class ServiceProviders
    {
        private System.Nullable<int> _ServiceID;
        private string _ServiceProviderName;
        private System.Nullable<int> _SPID;
        private string _ContactNo;
        private string _ZipCode;

        [Column(Storage = "_ZipCode")]
        public string ZipCode
        {
            get { return _ZipCode; }
            set { _ZipCode = value; }
        }
        private string _City;

        [Column(Storage = "_City")]
        public string City
        {
            get { return _City; }
            set { _City = value; }
        }
        private string _Address;

        [Column(Storage = "_Address")]
        public string Address
        {
            get { return _Address; }
            set { _Address = value; }
        }

        [Column(Storage = "_ContactNo")]
        public string ContactNo
        {
            get { return _ContactNo; }
            set { _ContactNo = value; }
        }

        [Column(Storage = "_ServiceID")]
        public System.Nullable<int> ServiceID
        {
            get
            {
                return _ServiceID;
            }
            set
            {
                _ServiceID = value;
            }
        }

        [Column(Storage = "_ServiceProviderName")]
        public string ServiceProviderName
        {
            get
            {
                return _ServiceProviderName;
            }
            set
            {
                _ServiceProviderName = value;
            }
        }

        [Column(Storage = "_SPID")]
        public System.Nullable<int> SPID
        {
            get
            {
                return _SPID;
            }
            set
            {
                _SPID = value;
            }
        }
    }
}
