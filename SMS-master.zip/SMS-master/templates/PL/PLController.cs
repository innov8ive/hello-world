using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;
using System.Web.Http.Cors;

namespace SampleAngular.Api
{
    public class PLController : ApiController
    {
        // GET api/PL
        [Route("api/PLList/")]
        [HttpPost]
        public AngularGridData GetPL([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.Polls, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = "Select * from PL where SocID = " + objLoggedUser.SocID;
            objAngularDataBinder.ValueField = "PLID";
            return objAngularDataBinder.GetData();
        }

        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/PL/GetAllPLs/")]
        [HttpPost]
        public List<object> GetAllPLs()
        {
            //Common.IsValidForm(Constants.Forms.Forum, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            PLBL objPLBL = new PLBL(Common.GetConString());
            List<object> objPLList = new List<object>();
            DataTable dt = Common.GetDBResult("Select PLID from PL where IsActive=1 and ShowTill>=GetDate() and SocID=" + objLoggedUser.SocID);
            foreach (DataRow dr in dt.Rows)
            {
                int casted = Common.ToInt(Common.GetDBScalar("select COUNT(*) from PLCast where UserID=@UserID and PLID=@PLID",
                    "@UserID", SqlDbType.Int, objLoggedUser.UserID,
                    "@PLID", SqlDbType.Int, Common.ToInt(dr["PLID"])));
                objPLBL.Load(Common.ToInt(dr["PLID"]));
                objPLBL.Data.Casted = casted > 0;
                objPLList.Add(JsonConvert.DeserializeObject(JsonConvert.SerializeObject(objPLBL.Data)));
            }
            return objPLList;
        }

        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/PL/SubmitCast/")]
        [HttpPost]
        public void SubmitCast([FromBody]dynamic value)
        {
            //Common.IsValidForm(Constants.Forms.Forum, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            PL objPL = objJObject.ToObject<PL>();

            if (Common.ToInt(objPL.SocID) > 0 && objPL.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            PLBL objPLBL = new PLBL(Common.GetConString());
            objPLBL.SubmitCast(objPL, objLoggedUser.UserID);
        }

        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/PL/GetPLResult/")]
        [HttpPost]
        public DataTable GetPLResult([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            int PLID = Common.ToInt(value.PLID);
            PLBL objPLBL = new PLBL(Common.GetConString());
            objPLBL.Load(PLID);

            if (objPLBL.IsNew)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            if (Common.ToInt(objPLBL.Data.SocID) > 0 && objPLBL.Data.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            DataTable dt = objPLBL.GetPLResult(PLID);
            return dt;
        }
        // GET api/PL/Id
        [Route("api/PL/{Id}")]
        public string GetPL(int Id)
        {
            Common.IsValidForm(Constants.Forms.Polls, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            PLBL objPLBL = new PLBL(Common.GetConString());
            objPLBL.Load(Id);

            PL objPL = objPLBL.Data;
            if (Common.ToInt(objPL.SocID) > 0 && objPL.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            return JsonConvert.SerializeObject(objPLBL.Data);
        }

        // POST api/PL/
        public string Post([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.Polls, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            PL objPL = objJObject.ToObject<PL>();
            PLBL objPLBL = new PLBL(Common.GetConString());
            objPLBL.Data = objPL;

            PLValidator validator = new PLValidator();
            ValidationResult results = validator.Validate(objPL);

            if (Common.ToInt(objPL.SocID) > 0 && objPL.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            if (objLoggedUser.UserType != 2)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            if (results.IsValid)
            {
                if (objPLBL.IsNew)
                {
                    objPL.SocID = objLoggedUser.SocID;
                    objPL.PLDate = DateTime.UtcNow;
                }
                objPL.IsActive = true;
                objPLBL.Update();
                return JsonConvert.SerializeObject(objPLBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        // DELETE api/PL/5
        [Route("api/PL/{Id}")]
        [HttpDelete]
        public bool Delete(int Id)
        {
            Common.IsValidForm(Constants.Forms.Polls, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            PLBL objPLBL = new PLBL(Common.GetConString());
            objPLBL.Load(Id);
            PL objPL = objPLBL.Data;
            if (Common.ToInt(objPL.SocID) > 0 && objPL.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            if (objLoggedUser.UserType != 2)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            return objPLBL.Delete(Id);
        }
    }
    public class PLValidator : AbstractValidator<PL>
    {
        public PLValidator()
        {
            RuleFor(obj => obj.PLDetails).NotEmpty();
            RuleFor(obj => obj.PLTitle).NotEmpty();
            RuleFor(obj => obj.ShowTill).NotEmpty();
        }
    }
}

