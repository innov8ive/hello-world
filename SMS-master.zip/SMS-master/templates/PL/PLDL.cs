using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;
using System.Text;

namespace SampleAngularDL
{
    public class PLDL
    {
        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public PLDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public PL Load(int PLID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            PL objPL = new PL();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get PL
                var resultPL = dc.ExecuteQuery<PL>("exec Get_PL {0}", PLID).ToList();
                if (resultPL.Count > 0)
                {
                    objPL = resultPL[0];
                }
                //Get PLOption
                var resultPLOption = dc.ExecuteQuery<PLOption>("exec Get_PLOption {0}", PLID).ToList();
                objPL.PLOptionList = resultPLOption;
                objPL.Types = new System.Collections.Hashtable();
                objPL.Types["PLOptionList"] = new PLOption();
                dc.Dispose();
                return objPL;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllPL()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_PL", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public List<PL> LoadForListing(int SocID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            var dc = new DataContext(SqlCon);
            try
            {
                //Get PL
                var resultPL = dc.ExecuteQuery<PL>("Select * from PL where IsActive=1 and ShowTill>=GetDate() and SocID={0}", SocID).ToList();

                dc.Dispose();
                return resultPL;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public bool Update(PL objPL)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update PL
                UpdatePL(objPL, trn);
                if (objPL.PLID > 0)
                {

                    //Update PLOption
                    DeletePLOption(Convert.ToInt32(objPL.PLID), trn);
                    int srNo = 1;
                    foreach (PLOption objPLOption in objPL.PLOptionList)
                    {
                        objPLOption.PLID = objPL.PLID;
                        objPLOption.SrNo = srNo;
                        InsertIntoPLOption(objPLOption, trn);
                        srNo++;
                    }
                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int PLID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete PLOption
                DeletePLOption(PLID, trn);
                //Delete PL
                DeletePL(PLID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public void SubmitCast(PL objPL, int UserID)
        {
            StringBuilder query = new StringBuilder("Delete from PLCast where UserID=@UserID and PLID=@PLID;");
            if (objPL.MultiOptions == true)
            {
                foreach (int opt in objPL.SelectedOptions)
                    query.AppendFormat("Insert into PLCast(PLID,PLSrNo,UserID,CastDate) values (@PLID,{0},@UserID,@CastDate);", opt);
            }
            else
            {
                query.AppendFormat("Insert into PLCast(PLID,PLSrNo,UserID,CastDate) values (@PLID,{0},@UserID,@CastDate);", objPL.SelectedOption);
            }
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand(query.ToString(), con);
            cmd.Parameters.Add("@UserID", SqlDbType.Int).Value = UserID;
            cmd.Parameters.Add("@PLID", SqlDbType.Int).Value = objPL.PLID;
            cmd.Parameters.Add("@CastDate", SqlDbType.DateTime, 20).Value = DateTime.UtcNow;

            try
            {
                con.Open();
                using (con)
                {
                    cmd.ExecuteNonQuery();
                }
            }
            catch { }
        }
        public DataTable GetPLResult(int PLID)
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand(@"
select PL.*,PLO.OptionText,PLO.SrNo,ISNULL(PL_CAST.TotalCast,0) as TotalCast,ISNULL(PL_TOTAL_CAST.PLTotalCast,0) as PLTotalCast,
case when ISNULL(PL_TOTAL_CAST.PLTotalCast,0)>0 then ISNULL(PL_CAST.TotalCast,0)*100/ISNULL(PL_TOTAL_CAST.PLTotalCast,0)
end AS CastPerc from PL
inner join PLOption PLO ON PL.PLID=PLO.PLID
left join 
(
	select PLID,PLSrNo,COUNT(*) TotalCast from PLCast
	group by PLID,PLSrNo
) as PL_CAST ON PL_CAST.PLID=PLO.PLID and PL_CAST.PLSrNo=PLO.SrNo
left join 
(
	select PLID,COUNT(*) PLTotalCast from 
		(
	select distinct PLID,UserID TotalCast from PLCast
	group by PLID,UserID
	) as T
	group by PLID
) as PL_TOTAL_CAST ON PL_TOTAL_CAST.PLID=PL.PLID
where PL.PLID=" + PLID, con);
            try
            {
                con.Open();
                dt.Load(cmd.ExecuteReader());
                con.Close();
            }
            catch { }
            return dt;
        }
        public bool UpdatePL(PL objPL, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_PL", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@IsActive", SqlDbType.Bit).Value = objPL.IsActive;
                cmd.Parameters.Add("@MultiOptions", SqlDbType.Bit).Value = objPL.MultiOptions;
                cmd.Parameters.Add("@PLDate", SqlDbType.DateTime).Value = objPL.PLDate;
                cmd.Parameters.Add("@PLDetails", SqlDbType.VarChar, 2500).Value = objPL.PLDetails;
                cmd.Parameters.Add("@PLID", SqlDbType.Int).Value = objPL.PLID;
                cmd.Parameters["@PLID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@PLTitle", SqlDbType.VarChar, 250).Value = objPL.PLTitle;
                cmd.Parameters.Add("@ShowTill", SqlDbType.DateTime).Value = objPL.ShowTill;
                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = objPL.SocID;

                cmd.ExecuteNonQuery();

                //after updating the PL, update PLID
                objPL.PLID = Convert.ToInt32(cmd.Parameters["@PLID"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeletePL(int PLID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from PL where PLID=@PLID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@PLID", SqlDbType.Int).Value = PLID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        public bool DeletePLOption(int PLID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from PLOption where PLID=@PLID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@PLID", SqlDbType.Int).Value = PLID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        public bool InsertIntoPLOption(PLOption objPLOption, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Into_PLOption", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Transaction = trn;


                cmd.Parameters.Add("@OptionText", SqlDbType.VarChar, 500).Value = objPLOption.OptionText;
                cmd.Parameters.Add("@PLID", SqlDbType.Int).Value = objPLOption.PLID;
                cmd.Parameters.Add("@SrNo", SqlDbType.Int).Value = objPLOption.SrNo;

                cmd.ExecuteNonQuery();

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        #endregion
    }
}
