using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{
    [Serializable]
    [Table(Name = "dbo.PL")]
    public class PL
    {
        private System.Nullable<bool> _IsActive;
        private System.Nullable<bool> _MultiOptions;
        private System.Nullable<DateTime> _PLDate;
        private string _PLDetails;
        private System.Nullable<int> _PLID;
        private string _PLTitle;
        private System.Nullable<DateTime> _ShowTill;
        private System.Nullable<int> _SocID;
        public List<int> SelectedOptions { get; set; }
        public Nullable<bool> Casted { get; set; }
        public System.Nullable<int> SelectedOption { get; set; }

        [Column(Storage = "_IsActive")]
        public System.Nullable<bool> IsActive
        {
            get
            {
                return _IsActive;
            }
            set
            {
                _IsActive = value;
            }
        }

        [Column(Storage = "_MultiOptions")]
        public System.Nullable<bool> MultiOptions
        {
            get
            {
                return _MultiOptions;
            }
            set
            {
                _MultiOptions = value;
            }
        }

        [Column(Storage = "_PLDate")]
        public System.Nullable<DateTime> PLDate
        {
            get
            {
                return _PLDate;
            }
            set
            {
                _PLDate = value;
            }
        }

        [Column(Storage = "_PLDetails")]
        public string PLDetails
        {
            get
            {
                return _PLDetails;
            }
            set
            {
                _PLDetails = value;
            }
        }

        [Column(Storage = "_PLID")]
        public System.Nullable<int> PLID
        {
            get
            {
                return _PLID;
            }
            set
            {
                _PLID = value;
            }
        }

        [Column(Storage = "_PLTitle")]
        public string PLTitle
        {
            get
            {
                return _PLTitle;
            }
            set
            {
                _PLTitle = value;
            }
        }

        [Column(Storage = "_ShowTill")]
        public System.Nullable<DateTime> ShowTill
        {
            get
            {
                return _ShowTill;
            }
            set
            {
                _ShowTill = value;
            }
        }

        [Column(Storage = "_SocID")]
        public System.Nullable<int> SocID
        {
            get
            {
                return _SocID;
            }
            set
            {
                _SocID = value;
            }
        }

        public System.Collections.Generic.List<PLOption> PLOptionList { get; set; }
        public Hashtable Types { get; set; }
    }


    [Serializable]
    [Table(Name = "dbo.PLOption")]
    public class PLOption
    {
        private string _OptionText;
        private System.Nullable<int> _PLID;
        private System.Nullable<int> _SrNo;

        [Column(Storage = "_OptionText")]
        public string OptionText
        {
            get
            {
                return _OptionText;
            }
            set
            {
                _OptionText = value;
            }
        }

        [Column(Storage = "_PLID")]
        public System.Nullable<int> PLID
        {
            get
            {
                return _PLID;
            }
            set
            {
                _PLID = value;
            }
        }

        [Column(Storage = "_SrNo")]
        public System.Nullable<int> SrNo
        {
            get
            {
                return _SrNo;
            }
            set
            {
                _SrNo = value;
            }
        }
    }
}
