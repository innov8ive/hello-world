using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
    [Serializable]
    public class PLBL
    {

        #region Declaration
        private string connectionString;
        PL _PL;
        public PL Data
        {
            get { return _PL; }
            set { _PL = value; }
        }
        public bool IsNew
        {
            get { return (_PL.PLID <= 0 || _PL.PLID == null); }
        }
        #endregion

        #region Constructor
        public PLBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private PLDL CreateDL()
        {
            return new PLDL(connectionString);
        }
        public void New()
        {
            _PL = new PL();
        }
        public void Load(int PLID)
        {
            var PLObj = this.CreateDL();
            _PL = PLID <= 0 ? PLObj.Load(-1) : PLObj.Load(PLID);
        }
        public List<PL> LoadForListing(int SocID)
        {
            var PLDLObj = CreateDL();
            return PLDLObj.LoadForListing(SocID);
        }
        public DataTable LoadAllPL()
        {
            var PLDLObj = CreateDL();
            return PLDLObj.LoadAllPL();
        }
        public bool Update()
        {
            var PLDLObj = CreateDL();
            return PLDLObj.Update(this.Data);
        }
        public bool Delete(int PLID)
        {
            var PLDLObj = CreateDL();
            return PLDLObj.Delete(PLID);
        }
        public void SubmitCast(PL objPL, int UserID)
        {
            var PLDLObj = CreateDL();
            PLDLObj.SubmitCast(objPL, UserID);
        }
        public DataTable GetPLResult(int PLID)
        {
            var PLDLObj = CreateDL();
            return PLDLObj.GetPLResult(PLID);
        }
        #endregion
    }
}
