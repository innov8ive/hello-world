using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
    [Serializable]
    public class VEBL
    {
        #region Declaration
        private string connectionString;
        VE _VE;
        public VE Data
        {
            get { return _VE; }
            set { _VE = value; }
        }
        public bool IsNew
        {
            get { return (_VE.VEID <= 0 || _VE.VEID == null); }
        }
        #endregion

        #region Constructor
        public VEBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private VEDL CreateDL()
        {
            return new VEDL(connectionString);
        }
        public void New()
        {
            _VE = new VE();
        }
        public void Load(int VEID)
        {
            var VEObj = this.CreateDL();
            _VE = VEID <= 0 ? VEObj.Load(-1) : VEObj.Load(VEID);
        }
        public DataTable LoadAllVE()
        {
            var VEDLObj = CreateDL();
            return VEDLObj.LoadAllVE();
        }
        public bool Update()
        {
            var VEDLObj = CreateDL();
            return VEDLObj.Update(this.Data);
        }
        public bool Delete(int VEID)
        {
            var VEDLObj = CreateDL();
            return VEDLObj.Delete(VEID);
        }
        #endregion
    }
}
