using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

    [Serializable]
    [Table(Name = "dbo.VE")]
    public class VE
    {
        private string _Remarks;
        private System.Nullable<int> _SocID;
        private System.Nullable<DateTime> _VEDate;
        private System.Nullable<int> _VEID;
        private System.Nullable<int> _VENo;
        private System.Nullable<int> _VTypeID;
        private System.Nullable<int> _GEGroupID;
        private System.Nullable<int> _WPID;

        [Column(Storage = "_WPID")]
        public System.Nullable<int> WPID
        {
            get { return _WPID; }
            set { _WPID = value; }
        }

        [Column(Storage = "_GEGroupID")]
        public System.Nullable<int> GEGroupID
        {
            get { return _GEGroupID; }
            set { _GEGroupID = value; }
        }

        [Column(Storage = "_Remarks")]
        public string Remarks
        {
            get
            {
                return _Remarks;
            }
            set
            {
                _Remarks = value;
            }
        }

        [Column(Storage = "_SocID")]
        public System.Nullable<int> SocID
        {
            get
            {
                return _SocID;
            }
            set
            {
                _SocID = value;
            }
        }

        [Column(Storage = "_VEDate")]
        public System.Nullable<DateTime> VEDate
        {
            get
            {
                return _VEDate;
            }
            set
            {
                _VEDate = value;
            }
        }

        [Column(Storage = "_VEID")]
        public System.Nullable<int> VEID
        {
            get
            {
                return _VEID;
            }
            set
            {
                _VEID = value;
            }
        }

        [Column(Storage = "_VENo")]
        public System.Nullable<int> VENo
        {
            get
            {
                return _VENo;
            }
            set
            {
                _VENo = value;
            }
        }

        [Column(Storage = "_VTypeID")]
        public System.Nullable<int> VTypeID
        {
            get
            {
                return _VTypeID;
            }
            set
            {
                _VTypeID = value;
            }
        }

        public List<VEDetails> VEDetailsList { get; set; }
    }
    [Serializable]
    [Table(Name = "dbo.VEDetails")]
    public class VEDetails
    {
        private System.Nullable<decimal> _Cr;
        private System.Nullable<int> _CrID;
        private System.Nullable<decimal> _Dr;
        private System.Nullable<int> _DrID;
        private System.Nullable<int> _SrNo;
        private System.Nullable<int> _VEID;

        [Column(Storage = "_Cr")]
        public System.Nullable<decimal> Cr
        {
            get
            {
                return _Cr;
            }
            set
            {
                _Cr = value;
            }
        }

        [Column(Storage = "_CrID")]
        public System.Nullable<int> CrID
        {
            get
            {
                return _CrID;
            }
            set
            {
                _CrID = value;
            }
        }

        [Column(Storage = "_Dr")]
        public System.Nullable<decimal> Dr
        {
            get
            {
                return _Dr;
            }
            set
            {
                _Dr = value;
            }
        }

        [Column(Storage = "_DrID")]
        public System.Nullable<int> DrID
        {
            get
            {
                return _DrID;
            }
            set
            {
                _DrID = value;
            }
        }

        [Column(Storage = "_SrNo")]
        public System.Nullable<int> SrNo
        {
            get
            {
                return _SrNo;
            }
            set
            {
                _SrNo = value;
            }
        }

        [Column(Storage = "_VEID")]
        public System.Nullable<int> VEID
        {
            get
            {
                return _VEID;
            }
            set
            {
                _VEID = value;
            }
        }
    }
}
