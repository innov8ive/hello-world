using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
    public class VEDL
    {

        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public VEDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public VE Load(int VEID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            VE objVE = new VE();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get VE
                var resultVE = dc.ExecuteQuery<VE>("exec Get_VE {0}", VEID).ToList();
                if (resultVE.Count > 0)
                {
                    objVE = resultVE[0];
                }
                objVE.VEDetailsList = dc.ExecuteQuery<VEDetails>("Select * from VEDetails where VEID={0}", VEID).ToList();
                dc.Dispose();
                return objVE;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllVE()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_VE", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(VE objVE)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update VE
                UpdateVE(objVE, trn);
                if (objVE.VEID > 0)
                {
                    DeleteVEDetails(Convert.ToInt32(objVE.VEID), trn);
                    int srNo = 1;
                    foreach (VEDetails objVEDetails in objVE.VEDetailsList)
                    {
                        objVEDetails.VEID = objVE.VEID;
                        objVEDetails.SrNo = srNo;
                        InsertIntoVEDetails(objVEDetails, trn);
                        srNo++;
                    }
                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int VEID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete VE
                DeleteVEDetails(VEID, trn);
                DeleteVE(VEID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateVE(VE objVE, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_VE", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = objVE.Remarks;
                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = objVE.SocID;
                cmd.Parameters.Add("@VEDate", SqlDbType.DateTime).Value = objVE.VEDate;
                cmd.Parameters.Add("@VEID", SqlDbType.Int).Value = objVE.VEID;
                cmd.Parameters["@VEID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@VENo", SqlDbType.Int).Value = objVE.VENo;
                cmd.Parameters["@VENo"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@VTypeID", SqlDbType.Int).Value = objVE.VTypeID;
                cmd.Parameters.Add("@GEGroupID", SqlDbType.Int).Value = objVE.GEGroupID;
                cmd.Parameters.Add("@WPID", SqlDbType.Int).Value = objVE.WPID;

                cmd.ExecuteNonQuery();

                //after updating the VE, update VEID
                objVE.VEID = Convert.ToInt32(cmd.Parameters["@VEID"].Value);
                objVE.VENo = Convert.ToInt32(cmd.Parameters["@VENo"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }

        public bool InsertIntoVEDetails(VEDetails objVEDetails, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Into_VEDetails", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Transaction = trn;
                cmd.Parameters.Add("@Cr", SqlDbType.Decimal).Value = objVEDetails.Cr;
                cmd.Parameters.Add("@CrID", SqlDbType.Int).Value = objVEDetails.CrID;
                cmd.Parameters.Add("@Dr", SqlDbType.Decimal).Value = objVEDetails.Dr;
                cmd.Parameters.Add("@DrID", SqlDbType.Int).Value = objVEDetails.DrID;
                cmd.Parameters.Add("@SrNo", SqlDbType.Int).Value = objVEDetails.SrNo;
                cmd.Parameters.Add("@VEID", SqlDbType.Int).Value = objVEDetails.VEID;

                cmd.ExecuteNonQuery();

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }

        public bool DeleteVEDetails(int VEID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from VEDetails where VEID=@VEID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@VEID", SqlDbType.Int).Value = VEID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        public bool DeleteVE(int VEID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from VE where VEID=@VEID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@VEID", SqlDbType.Int).Value = VEID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        #endregion
    }
}
