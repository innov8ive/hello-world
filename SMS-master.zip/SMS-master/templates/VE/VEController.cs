using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;

namespace SampleAngular.Api
{
    public class VEController : ApiController
    {
        // GET api/VE
        [Route("api/VEList/")]
        [HttpPost]
        public AngularGridData GetVE([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.JournalEntryVoucherEntry, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = @"Select VE.*,VT.VoucherTypeName from VE left join 
VoucherType VT ON VE.VTypeID=VT.VoucherTypeID and VE.SocID=VT.SocID where VE.SocID=" +objLoggedUser.SocID;
            objAngularDataBinder.ValueField = "VEID";
            return objAngularDataBinder.GetData();
        }

        // GET api/VE/Id
        [Route("api/VE/{Id}")]
        public string GetVE(int Id)
        {
            Common.IsValidForm(Constants.Forms.JournalEntryVoucherEntry, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            VEBL objVEBL = new VEBL(Common.GetConString());
            objVEBL.Load(Id);
            if (objVEBL.IsNew)
            {
                objVEBL.Data.WPID = objLoggedUser.WPID;
            }
            VE objVE = objVEBL.Data;
            if (Common.ToInt(objVE.SocID) > 0 && objVE.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            if(objVEBL.IsNew)
            {
                objVE.VEDate = DateTime.Now.Date;
                objVE.VTypeID = 1;
                objVE.VEDetailsList = new List<VEDetails>();
                objVE.VEDetailsList.Add(new VEDetails() { DrID = null, Dr = 0, CrID = -1 });
                objVE.VEDetailsList.Add(new VEDetails() { DrID = -1, Cr = 0, CrID = null });
            }
            return JsonConvert.SerializeObject(objVEBL.Data);
        }

        // POST api/VE/
        public string Post([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.JournalEntryVoucherEntry, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            VE objVE = objJObject.ToObject<VE>();
            VEBL objVEBL = new VEBL(Common.GetConString());
            objVEBL.Data = objVE;

            if (Common.ToInt(objVE.SocID) > 0 && objVE.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            
            bool isNew = false;
            if (objVEBL.IsNew)
            {
                isNew = true;
                objVE.SocID = objLoggedUser.SocID;
            }

            VEValidator validator = new VEValidator();
            ValidationResult results = validator.Validate(objVE);
            if (objLoggedUser.WPID <= 0 || objVE.WPID <= 0)
            {
                results.Errors.Add(new ValidationFailure("WPID", "Working Period Not Selected"));
            }
            if (objVE.VEDate > objLoggedUser.EndDate || objVE.VEDate < objLoggedUser.StartDate)
            {
                results.Errors.Add(new ValidationFailure("RefDate", "Date is not in Working Period Range"));
            }
            if (results.IsValid)
            {
                objVEBL.Update();
                GECommon.GEEntry(objVE);
                return JsonConvert.SerializeObject(objVEBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        // DELETE api/VE/5
        [Route("api/VE/{Id}")]
        [HttpDelete]
        public bool Delete(int Id)
        {
            VEBL objVEBL = new VEBL(Common.GetConString());
            return objVEBL.Delete(Id);
        }
    }
    public class VEValidator : AbstractValidator<VE>
    {
        public VEValidator()
        {
            RuleFor(obj => obj.Remarks).NotEmpty();
            RuleFor(obj => obj.VEDate).NotEmpty();
            RuleFor(obj => obj.VTypeID).NotEmpty();
        }
    }
}

