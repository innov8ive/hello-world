var app = angular.module('myApp');

app.controller('VEListCtrl', function ($scope, $http, $location, GridData) {

    $scope = readyAngularGrid($scope, $http, 'api/VEList', 'VEID', GridData, 'VE');
    $scope.gridOptions.columnDefs = [
    { displayName: 'VE No.', field: 'VENo' },
    { displayName: 'VE Date', field: 'VEDate', cellFilter: 'date:\'dd-MMM-yyyy\'' },
    { displayName: 'Remarks', field: 'Remarks' },
    { displayName: 'Voucher Type', field: 'VoucherTypeName' }, ];
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchVE = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };
    $scope.newVE = function () {
        saveGridData($scope, GridData, 'VE');
        $location.path('/VE/0');
    };
    $scope.editVE = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            saveGridData($scope, GridData, 'VE');
            $location.path('/VE/' + selected[0].VEID);
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.deleteVE = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'DELETE',
                url: 'api/VE/' + selected[0].VEID
            }).success(function (result) {
                if (result == true)
                    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
            });
        }
        else {
            alert('Please select a record to edit.');
        }
    };
})

.controller('VECtrl', function ($scope, $http, $location, $routeParams) {
    var VEID = $routeParams.VEID;
    $scope.VE = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.VESubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.VESubmitted = true;
        if ($scope.formVE.$invalid == true) return;
        if ($scope.VE.VEDetailsList != null) {
            var list = $scope.VE.VEDetailsList;
            for (var j = 0; j < list.length; j++) {
                if (
                    (list[j].DrID != -1 && (list[j].DrID == null || list[j].Dr <= 0)) ||
                    (list[j].CrID != -1 && (list[j].CrID == null || list[j].Cr <= 0))
                ) {
                    alert('Credit Side and Debit Side totals should be same!'); return;
                }
            }
        }
        if ($scope.TotalCr() != $scope.TotalDr()) { alert('Total Debit and Total Credit should be same!'); return; }

        $http.post('api/VE', $scope.VE, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.VE = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/VEList');
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/VE/' + VEID
        }).success(function (VE) {
            $scope.VE = JSON.parse(VE);
            $scope.bindYear();
        });
    }, 100);

    $scope.vtypelist = [];
    var drLoaded = false;
    var crLoaded = false;
    var clearDrCr = false;
    $scope.bindVType = function () {
        drLoaded = false;
        crLoaded = false;
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetVTypeList', Data: null })
        }).success(function (data) {
            $scope.vtypelist = data;
            $scope.bindDrList(true);
            $scope.bindCrList(true);

        });
    }
    window.setTimeout(function () {
        $scope.bindVType();
    }, 500);


    $scope.onVTypeSelected = function ($item, $select) {
        $scope.bindDrList(true);
        $scope.bindCrList(true);
        clearDrCr = true;
    }
    $scope.drlist = [];
    $scope.crlist = [];
    $scope.bindDrList = function (clear) {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetDrList', Data: null, query: $scope.VE.VTypeID })
        }).success(function (data) {
            $scope.drlist = data;
            drLoaded = true;
            drcrLoaded();
        });
    };
    $scope.bindCrList = function (clear) {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetCrList', Data: null, query: $scope.VE.VTypeID })
        }).success(function (data) {
            $scope.crlist = data;
            crLoaded = true;
            drcrLoaded();
        });
    };
    $scope.getText = function (model, array) {
        for (var j = 0; j < array.length; j++) {
            if (model == array[j].Key) {
                return array[j].Value;
            }
        }
        return '';
    }
    var drcrLoaded = function () {
        if (drLoaded == true && crLoaded == true && clearDrCr == true) {
            if ($scope.VE.VEDetailsList != null) {
                var list = $scope.VE.VEDetailsList;
                for (var j = 0; j < list.length; j++) {
                    if (list[j].DrID > -1)
                        list[j].DrID = null;
                    if (list[j].CrID > -1)
                        list[j].CrID = null;
                }
                $scope.VE.VEDetailsList = list;
            }
        }
    };
    $scope.TotalDr = function () {
        var total = 0;
        if ($scope.VE.VEDetailsList != null) {
            var list = $scope.VE.VEDetailsList;
            for (var j = 0; j < list.length; j++) {
                total += list[j].Dr;
            }
        }
        return total;
    }
    $scope.TotalCr = function () {
        var total = 0;
        if ($scope.VE.VEDetailsList != null) {
            var list = $scope.VE.VEDetailsList;
            for (var j = 0; j < list.length; j++) {
                total += list[j].Cr;
            }
        }
        return total;
    };
    $scope.addDrRow = function () {
        $scope.VE.VEDetailsList.push({ DrID: null, Dr: 0, CrID: -1, Cr: 0 });
    };
    $scope.addCrRow = function () {
        $scope.VE.VEDetailsList.push({ CrID: -1, Cr: 0, CrID: null, Dr: 0 });
    };
    $scope.deleteRow = function (indx) {
        $scope.VE.VEDetailsList.splice(indx, 1);
    };
    $scope.yearlist = [];
    $scope.bindYear = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetYearList', Data: null })
        }).success(function (data) {
            $scope.yearlist = data;
        });
    };
});
