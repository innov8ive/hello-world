using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;
using System.Text;
using System.Web.Http.Cors;

namespace SampleAngular.Api
{
    public class RoomsController : ApiController
    {
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/Rooms/TotalOutstanding")]
        [HttpPost]
        public decimal TotalOutstanding([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            decimal total = Common.ToDecimal(Common.GetDBScalar(@"select 
ISNULL(SUM(B.Amount),0)+ISNULL(SUM(B.LF),0)
-ISNULL(SUM(TotalPaid),0)-ISNULL(SUM(Discount),0) as Outstanding from Bills B
left join VW_BillPayments BP ON B.BillID=BP.BillID
where B.RoomID=@RoomID",
                "@RoomID", SqlDbType.Int, Common.ToInt(value.RoomID)));
            return total;
        }

        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/Rooms/GetStatement/")]
        [HttpPost]
        public AngularGridData GetStatement([FromBody]dynamic value)
        {
            //Common.IsValidForm(Constants.Forms.UnitStatement, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            //if (objLoggedUser.UserType != 2)
            //    throw new HttpResponseException(HttpStatusCode.Unauthorized);

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();
            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = @"select * from 
(
select BillDate,BillID,'Bill#'+CONVERT(varchar,BillID) as BillNo,
TotalBillAmount as Dr,0 as Cr,'Bill' as Type from Bills where RoomID=@RoomID
union all
select P.PaymentDate,BP.PaymentID,'Reciept#'+CONVERT(varchar,P.PaymentID) as BillNo,
0 as Dr,BP.BPAmount as Cr,'Reciept' as Type from BillPayments BP
inner join Payments P ON BP.PaymentID=P.PaymentID where P.RoomID=@RoomID
union all
select BillDate,BillID,'Reciept#'+CONVERT(varchar,BillID) as BillNo,
0 as Dr,TotalBillAmount as Cr,'Reciept' as Type from Bills where RoomID=@RoomID and Adjusted=1
) as T";
            objAngularDataBinder.ValueField = "BillID";
            objAngularDataBinder.OrderBy = "BillDate";
            objAngularDataBinder.OrderDir = "Desc";
            Hashtable ht = new Hashtable();
            ht["@RoomID"] = Common.ToString(value.OtherFilter.RoomID);
            objAngularDataBinder.Parameters = ht;
            return objAngularDataBinder.GetData();


            //            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            //            if (objLoggedUser == null) throw new HttpResponseException(HttpStatusCode.Unauthorized);

            //            DataTable dt = Common.GetDBResultParameterized(@"select * from 
            //(
            //select BillDate,BillID,'Invoice#'+CONVERT(varchar,BillID) as BillNo,
            //TotalBillAmount as Dr,0 as Cr,'Bill' as Type from Bills where RoomID=@RoomID
            //union all
            //select PaymentDate,PaymentID,'Reciept#'+CONVERT(varchar,PaymentID) as BillNo,
            //0 as Dr,Amount as Cr,'Reciept' as Type from Payments where RoomID=@RoomID
            //) as T order by T.BillDate desc", "@RoomID",SqlDbType.Int,Common.ToInt(value.RoomID));

            //            return JsonConvert.SerializeObject(dt,Formatting.Indented);
        }

        [Route("api/Rooms/UploadRooms/")]
        [HttpPost]
        public string UploadRooms([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser == null) throw new HttpResponseException(HttpStatusCode.Unauthorized);

            JArray objJObject = value;
            DataTable objData = objJObject.ToObject<DataTable>();


            MemmberUpoader objMemmberUpoader = new MemmberUpoader(objLoggedUser.SocID);
            string errorMessage = String.Empty;

            objMemmberUpoader.IsDataValid(ref errorMessage, objData);

            if (errorMessage.Length <= 0)
            {
                //DataTable existingUsers = Common.GetDBResult("Select EmailID,MobileNo from Users where CreatedBy=" + objLoggedUser.UserID);
                DataTable existingRooms = Common.GetDBResult("Select W.WingName,R.RoomNo from Rooms R inner join Wings W ON R.WingID=W.WIngID where R.SocID=" + objLoggedUser.SocID);

                int rowNumber = 0;
                foreach (DataRow dr in objData.Rows)
                {
                    rowNumber++;
                    string email = Common.ToString(dr["EmailID"]);
                    string mobileNo = Common.ToString(dr["MobileNo"]);
                    string roomNo = Common.ToString(dr["UnitNo"]);
                    string wingID = Common.ToString(dr["BlockWing"]);
                    //if (existingUsers.Select("EmailID='" + email + "'").Length > 0)
                    //{
                    //    errorMessage += ",\n EmailID  duplicate [" + email + "] at row " + rowNumber;
                    //}
                    //if (existingUsers.Select("MobileNo='" + mobileNo + "'").Length > 0)
                    //{
                    //    errorMessage += ",\n MobileNo  duplicate [" + mobileNo + "] at row " + rowNumber;
                    //}
                    if (existingRooms.Select("WingName='" + wingID + "' and RoomNo='" + roomNo + "'").Length > 0)
                    {
                        errorMessage += ",\n RoomNo  duplicate [" + roomNo + "] at row " + rowNumber;
                    }
                    if (Common.ToDecimal(dr["OpeningBalanceInterest"]) > 0 && Common.ToDecimal(dr["OpeningBalance"]) <= 0)
                    {
                        errorMessage += ",\n Invalid Opening Balance Interest at row " + rowNumber;
                    }
                }
            }

            if (errorMessage.Length == 0)
            {
                try
                {
                    foreach (DataRow dr in objMemmberUpoader.Data.Rows)
                    {
                        RoomsBL objRoomsBL = new RoomsBL(Common.GetConString());
                        UsersBL objUsersBL = new UsersBL(Common.GetConString());

                        Rooms objRooms = new Rooms();
                        objRooms.Area = Common.ToInt(dr["Area"]);
                        objRooms.FloorNo = Common.ToInt(dr["FloorNo"]);
                        objRooms.Intercom = Common.ToString(dr["Intercom"]);
                        objRooms.NoOfBal = Common.ToInt(dr["NoOfBalconies"]);
                        objRooms.NoOfBeds = Common.ToInt(dr["NoOfBeds"]);
                        objRooms.RoomNo = Common.ToString(dr["UnitNo"]);
                        objRooms.UnitType = Common.ToString(dr["UnitType"]);
                        objRooms.WingID = Common.ToInt(dr["BlockWing"]);
                        objRooms.OpeningBalance = Common.ToDecimal(dr["OpeningBalance"]);
                        objRooms.OpeningBalanceInt = Common.ToDecimal(dr["OpeningBalanceInterest"]);
                        objRooms.RoomID = 0;
                        objRooms.SocID = objLoggedUser.SocID;
                        objRooms.RMBSUList = new List<RMBSU>();
                        objRooms.RoomBSList = new List<RoomBS>();

                        objRoomsBL.Data = objRooms;
                        if (objRoomsBL.Update())
                        {
                            DataTable dtExisting = Common.GetDBResultParameterized(@"Select UserID from Users where (MobileNo=@MobileNo) and CreatedBy=@CreatedBy"
               , "@MobileNo", SqlDbType.VarChar, Common.ToString(dr["MobileNo"])
               , "@CreatedBy", SqlDbType.Int, Common.ToInt(objLoggedUser.UserID));

                            if (dtExisting.Rows.Count > 0)
                            {
                                Common.ExecuteNonQuery("Insert Into UserRooms(UserID,RoomID,SocID)values(@UserID,@RoomID,@SocID)",
                                    "@UserID", SqlDbType.Int, Common.ToInt(dtExisting.Rows[0]["UserID"]),
                                    "@RoomID", SqlDbType.Int, objRooms.RoomID,
                                    "@SocID", SqlDbType.Int, objLoggedUser.SocID);
                            }
                            else
                            {
                                Users objUsers = new Users();
                                objUsers.CreatedBy = objLoggedUser.UserID;
                                objUsers.EmailID = Common.ToString(dr["EmailID"]);
                                objUsers.FirstName = Common.ToString(dr["FirstName"]);
                                objUsers.IsActive = true;
                                objUsers.LastName = Common.ToString(dr["LastName"]);
                                objUsers.MemberType = Common.ToString(dr["MemberType"]);
                                objUsers.MobileNo = Common.ToString(dr["MobileNo"]);
                                string password = Guid.NewGuid().ToString().Substring(0, 6);
                                objUsers.Password = Common.MD5Encrypt(password);
                                objUsers.SocID = objLoggedUser.SocID;
                                objUsers.SendNotification = true;
                                objUsers.UserID = 0;
                                objUsers.UserType = 1;
                                objUsers.Verified = true;
                                objUsers.Rooms = new List<string>();
                                objUsers.Rooms.Add(objRooms.RoomID.ToString());

                                objUsersBL.Data = objUsers;
                                if (objUsersBL.Update())
                                {
                                    if (!String.IsNullOrEmpty(objUsers.MobileNo))
                                    {
                                        Common.SendSMS(Common.ToString(objUsers.MobileNo), "Dear Member, Your account created on app.societyInn.com. Username is " + objUsers.MobileNo + " Password is " + password + ". Download SocietyInn App https://goo.gl/ye3bjk from Play Store." + objLoggedUser.SocName, 0);
                                        //Common.SendSMS(Common.ToString(objUsers.MobileNo), "Your account created on SocietyInn.com. Password is " + password, 0);
                                    }
                                    else
                                    {
                                        Common.SendEmailSendGrid(Common.ToString(objUsers.EmailID), "Your account created on SocietyInn.com. Password is " + password, "Your account created on SocietyInn.com");
                                    }
                                }
                            }
                        }
                    }
                }
                catch (Exception Ex)
                {
                    errorMessage = Ex.Message;
                }
            }

            return JsonConvert.SerializeObject(errorMessage.Split(','));
        }

        // GET api/Rooms
        [Route("api/RoomsList/")]
        [HttpPost]
        public AngularGridData GetRooms([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser == null) throw new HttpResponseException(HttpStatusCode.Unauthorized);

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            StringBuilder query = new StringBuilder(@"Select R.*,S.SocName,W.WingName,VR.Users from Rooms R inner join SOC S ON R.SocID=S.SocID 
left join WIngs W ON R.WingID=W.WingID 
left join VW_Rooms VR ON R.RoomID=VR.RoomID where R.SocID=" + objLoggedUser.SocID);
            Hashtable ht = new Hashtable();
            if (!String.IsNullOrEmpty(objAngularGrid.SearchText))
            {
                query.Append(" and (VR.Users like '%'+@Text+'%' OR W.WingName like '%'+@Text+'%' OR R.RoomNo like '%'+@Text+'%')");

                ht["@Text"] = objAngularGrid.SearchText;
                objAngularDataBinder.Parameters = ht;
            }
            objAngularDataBinder.Query = query.ToString();
            objAngularDataBinder.ValueField = "R.RoomID";
            ht["@UserID"] = objLoggedUser.UserID;
            return objAngularDataBinder.GetData();
        }

        // GET api/Rooms/Id
        [Route("api/Rooms/{Id}")]
        public string GetRooms(int Id)
        {
            //Common.IsValidForm(Constants.Forms.Unit, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            RoomsBL objRoomsBL = new RoomsBL(Common.GetConString());
            objRoomsBL.Load(Id);
            Rooms objRooms = objRoomsBL.Data;
            if (Common.ToInt(objRooms.SocID) > 0 && objRooms.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            return JsonConvert.SerializeObject(objRoomsBL.Data);
        }

        // POST api/Rooms/
        public string Post([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.Unit, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            Rooms objRooms = objJObject.ToObject<Rooms>();
            RoomsBL objRoomsBL = new RoomsBL(Common.GetConString());
            objRoomsBL.Data = objRooms;
            if (objRoomsBL.IsNew)
            {
                objRooms.SocID = objLoggedUser.SocID;
            }
            RoomsValidator validator = new RoomsValidator();
            ValidationResult results = validator.Validate(objRooms);
            if (Common.ToInt(objRoomsBL.Data.SocID) > 0 && objRoomsBL.Data.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            if (!Common.IsUniqueInTable("Rooms", "RoomNo",
               Common.ToString(objRooms.RoomNo),
               "RoomID", Common.ToInt(objRooms.RoomID).ToString(), "WingID=" + Common.ToInt(objRooms.WingID)
               + " and SocID=" + Common.ToInt(objRooms.SocID).ToString()))
            {
                results.Errors.Add(new ValidationFailure("RoomNo", "This Unit No. is already added in  Block/Wing"));
            }
            if (objRooms.OpeningBalanceInt > 0 && objRooms.OpeningBalance <= 0)
            {
                results.Errors.Add(new ValidationFailure("RoomNo", "Invalid Opening Balance Interest"));
            }
            if (results.IsValid)
            {
                objRoomsBL.Update();
                return JsonConvert.SerializeObject(objRoomsBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        // DELETE api/Rooms/5
        [Route("api/Rooms/{Id}")]
        [HttpDelete]
        public string Delete(int Id)
        {
            Common.IsValidForm(Constants.Forms.Unit, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            RoomsBL objRoomsBL = new RoomsBL(Common.GetConString());
            objRoomsBL.Load(Id);

            Rooms objRooms = objRoomsBL.Data;
            if (Common.ToInt(objRooms.SocID) > 0 && objRooms.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            int count = Common.ToInt(Common.GetDBScalar("Select COUNT(*) from Bills where RoomID=" + Id));
            if (count > 0)
            {
                return "You cannot delete this Unit, some transaction(s) already made!";
            }

            bool result = objRoomsBL.Delete(Id);
            if (result)
                return String.Empty;
            else
                return "Unit not deleted!";
        }
    }
    public class RoomsValidator : AbstractValidator<Rooms>
    {
        public RoomsValidator()
        {
            RuleFor(obj => obj.FloorNo).NotEmpty();
            RuleFor(obj => obj.RoomNo).NotEmpty();
            RuleFor(obj => obj.SocID).NotEmpty();
            RuleFor(obj => obj.WingID).NotEmpty();
        }
    }
}

