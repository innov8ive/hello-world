using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
    public class RoomsDL
    {
        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public RoomsDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public Rooms Load(int RoomID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            Rooms objRooms = new Rooms();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get Rooms
                var resultRooms = dc.ExecuteQuery<Rooms>("exec Get_Rooms {0}", RoomID).ToList();
                if (resultRooms.Count > 0)
                {
                    objRooms = resultRooms[0];
                }
                var resultRoomBS = dc.ExecuteQuery<RoomBS>("exec Get_RoomBS {0}", RoomID).ToList();
                
                objRooms.RoomBSList = resultRoomBS;
                
                objRooms.RMBSUList = dc.ExecuteQuery<RMBSU>("Select * from RMBSU where RMID={0}", RoomID).ToList();

                objRooms.CPList = dc.ExecuteQuery<CP>("Select * from CP where RMID={0}", RoomID).ToList();
                dc.Dispose();
                return objRooms;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllRooms()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_Rooms", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(Rooms objRooms)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update Rooms
                UpdateRooms(objRooms, trn);
                if (objRooms.RoomID > 0)
                {
                    //Update RoomBS
                    int srNo = 1;
                    DeleteRoomBS(Convert.ToInt32(objRooms.RoomID), trn);
                    foreach (RoomBS objRoomBS in objRooms.RoomBSList)
                    {
                        objRoomBS.RoomID = objRooms.RoomID;
                        objRoomBS.SrNo = srNo;
                        InsertIntoRoomBS(objRoomBS, trn);
                        srNo++;
                    }
                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int RoomID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete Rooms
                DeleteRoomBS(RoomID, trn);
                DeleteRooms(RoomID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateRooms(Rooms objRooms, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_Rooms", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@BuildingNo", SqlDbType.VarChar, 10).Value = objRooms.BuildingNo;
                cmd.Parameters.Add("@FloorNo", SqlDbType.Int).Value = objRooms.FloorNo;
                cmd.Parameters.Add("@RoomID", SqlDbType.Int).Value = objRooms.RoomID;
                cmd.Parameters["@RoomID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@RoomNo", SqlDbType.VarChar, 10).Value = objRooms.RoomNo;
                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = objRooms.SocID;
                cmd.Parameters.Add("@Wing", SqlDbType.VarChar, 10).Value = objRooms.Wing;
                cmd.Parameters.Add("@UserID", SqlDbType.Int).Value = objRooms.UserID;
                cmd.Parameters.Add("@Area", SqlDbType.Int).Value = objRooms.Area;
                cmd.Parameters.Add("@UnitType", SqlDbType.VarChar, 50).Value = objRooms.UnitType;
                cmd.Parameters.Add("@Block", SqlDbType.VarChar, 10).Value = objRooms.Block;
                cmd.Parameters.Add("@WingID", SqlDbType.Int).Value = objRooms.WingID;
                cmd.Parameters.Add("@NoOfBeds", SqlDbType.Int).Value = objRooms.NoOfBeds;
                cmd.Parameters.Add("@NoOfBal", SqlDbType.Int).Value = objRooms.NoOfBal;
                cmd.Parameters.Add("@Intercom", SqlDbType.VarChar, 10).Value = objRooms.Intercom;
                cmd.Parameters.Add("@TerraceCharges", SqlDbType.Decimal).Value = objRooms.TerraceCharges;
                cmd.Parameters.Add("@OccupationCharges", SqlDbType.Decimal).Value = objRooms.OccupationCharges;
                cmd.ExecuteNonQuery();

                //after updating the Rooms, update RoomID
                objRooms.RoomID = Convert.ToInt32(cmd.Parameters["@RoomID"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteRooms(int RoomID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand(@"Delete from Rooms where RoomID=@RoomID;", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@RoomID", SqlDbType.Int).Value = RoomID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        public bool DeleteRoomBS(int RoomID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from RoomBS where RoomID=@RoomID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@RoomID", SqlDbType.Int).Value = RoomID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        public bool InsertIntoRoomBS(RoomBS objRoomBS, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Into_RoomBS", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Transaction = trn;


                cmd.Parameters.Add("@Amount", SqlDbType.Decimal).Value = objRoomBS.Amount;
                cmd.Parameters.Add("@BillMonth", SqlDbType.Int).Value = objRoomBS.BillMonth;
                cmd.Parameters.Add("@BillType", SqlDbType.VarChar, 50).Value = objRoomBS.BillType;
                cmd.Parameters.Add("@RoomID", SqlDbType.Int).Value = objRoomBS.RoomID;
                cmd.Parameters.Add("@SrNo", SqlDbType.Int).Value = objRoomBS.SrNo;

                cmd.ExecuteNonQuery();

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        #endregion
    }
}
