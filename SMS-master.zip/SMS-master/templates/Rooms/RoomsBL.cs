using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;
using SampleAngular;

namespace SampleAngularBL
{
    [Serializable]
    public class RoomsBL
    {

        #region Declaration
        private string connectionString;
        Rooms _Rooms;
        public Rooms Data
        {
            get { return _Rooms; }
            set { _Rooms = value; }
        }
        public bool IsNew
        {
            get { return (_Rooms.RoomID <= 0 || _Rooms.RoomID == null); }
        }
        #endregion

        #region Constructor
        public RoomsBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private RoomsDL CreateDL()
        {
            return new RoomsDL(connectionString);
        }
        public void New()
        {
            _Rooms = new Rooms();
        }
        public void Load(int RoomID)
        {
            var RoomsObj = this.CreateDL();
            _Rooms = RoomID <= 0 ? RoomsObj.Load(-1) : RoomsObj.Load(RoomID);
        }
        public DataTable LoadAllRooms()
        {
            var RoomsDLObj = CreateDL();
            return RoomsDLObj.LoadAllRooms();
        }
        public bool Update()
        {
            var RoomsDLObj = CreateDL();
            bool isNew = IsNew;
            bool result = RoomsDLObj.Update(this.Data);
            if (isNew)
            {
                SMSCreditBL objSMSCreditBL = new SMSCreditBL(connectionString);
                SMSCredit objSMSCredit = new SMSCredit();
                objSMSCredit.Credit = 12;
                objSMSCredit.CreditDate = DateTime.Today;
                objSMSCredit.ID = 0;
                objSMSCredit.Remarks = "First Time SMS Credit of Room";
                objSMSCredit.SocID = _Rooms.SocID;
                objSMSCreditBL.Data = objSMSCredit;
                objSMSCreditBL.Update();
            }
            if (result)
            {
                AccountsDL objGLDL = new AccountsDL(connectionString);
                Accounts objGL = objGLDL.LoadByOrgID(Data.RoomID.Value);
                if (objGL != null && objGL.AccountID > 0)
                {
                    string wingName = Common.ToString(Common.GetDBScalar("Select WingName from Wings where WingID=" + Data.WingID));
                    objGL.AccountName = wingName + " " + Data.RoomNo;
                    objGLDL.Update(objGL);
                }
                else
                {
                    objGL = new Accounts();
                    objGL.OrgID = Data.RoomID;
                    string wingName = Common.ToString(Common.GetDBScalar("Select WingName from Wings where WingID=" + Data.WingID));
                    objGL.AccountName = wingName + " " + Data.RoomNo;
                    objGL.ScheduleID = (int)GroupNo.Debtors;
                    objGL.SocID = Data.SocID;
                    objGL.DrAmount = Common.ToDecimal(Data.OpeningBalance);
                    objGL.DrAmountInt = Common.ToDecimal(Data.OpeningBalanceInt);
                    objGLDL.Update(objGL);
                }
            }
            return result;
        }
        public bool Delete(int RoomID)
        {
            var RoomsDLObj = CreateDL();
            return RoomsDLObj.Delete(RoomID);
        }
        #endregion
    }
}
