using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

    [Serializable]
    [Table(Name = "dbo.Rooms")]
    public class Rooms
    {
        private string _BuildingNo;
        private System.Nullable<int> _FloorNo;
        private System.Nullable<int> _RoomID;
        private string _RoomNo;
        private System.Nullable<int> _SocID;
        private string _Wing;
        private System.Nullable<int> _UserID;
        private Nullable<int> _Area;
        private string _UnitType;
        private string _Block;
        private Nullable<int> _WingID;
        private Nullable<int> _NoOfBeds;
        private Nullable<int> _NoOfBal;
        private string _Intercom;
        private Nullable<decimal> _OpeningBalance;
        private Nullable<decimal> _TerraceCharges;
        private Nullable<decimal> _OpeningBalanceInt;
        private Nullable<decimal> _OccupationCharges;

        [Column(Storage = "_OccupationCharges")]
        public Nullable<decimal> OccupationCharges
        {
            get { return _OccupationCharges; }
            set { _OccupationCharges = value; }
        }

        [Column(Storage = "_OpeningBalanceInt")]
        public Nullable<decimal> OpeningBalanceInt
        {
            get { return _OpeningBalanceInt; }
            set { _OpeningBalanceInt = value; }
        }

        [Column(Storage = "_TerraceCharges")]
        public Nullable<decimal> TerraceCharges
        {
            get { return _TerraceCharges; }
            set { _TerraceCharges = value; }
        }

        [Column(Storage = "_OpeningBalance")]
        public Nullable<decimal> OpeningBalance
        {
            get { return _OpeningBalance; }
            set { _OpeningBalance = value; }
        }

        [Column(Storage = "_Intercom")]
        public string Intercom
        {
            get { return _Intercom; }
            set { _Intercom = value; }
        }

        [Column(Storage = "_NoOfBal")]
        public Nullable<int> NoOfBal
        {
            get { return _NoOfBal; }
            set { _NoOfBal = value; }
        }

        [Column(Storage = "_NoOfBeds")]
        public Nullable<int> NoOfBeds
        {
            get { return _NoOfBeds; }
            set { _NoOfBeds = value; }
        }

        [Column(Storage = "_WingID")]
        public Nullable<int> WingID
        {
            get { return _WingID; }
            set { _WingID = value; }
        }

        [Column(Storage = "_Block")]
        public string Block
        {
            get { return _Block; }
            set { _Block = value; }
        }

        [Column(Storage = "_UnitType")]
        public string UnitType
        {
            get { return _UnitType; }
            set { _UnitType = value; }
        }

        [Column(Storage = "_Area")]
        public Nullable<int> Area
        {
            get { return _Area; }
            set { _Area = value; }
        }

        [Column(Storage = "_UserID")]
        public System.Nullable<int> UserID
        {
            get
            {
                return _UserID;
            }
            set
            {
                _UserID = value;
            }
        }

        [Column(Storage = "_BuildingNo")]
        public string BuildingNo
        {
            get
            {
                return _BuildingNo;
            }
            set
            {
                _BuildingNo = value;
            }
        }

        [Column(Storage = "_FloorNo")]
        public System.Nullable<int> FloorNo
        {
            get
            {
                return _FloorNo;
            }
            set
            {
                _FloorNo = value;
            }
        }

        [Column(Storage = "_RoomID")]
        public System.Nullable<int> RoomID
        {
            get
            {
                return _RoomID;
            }
            set
            {
                _RoomID = value;
            }
        }

        [Column(Storage = "_RoomNo")]
        public string RoomNo
        {
            get
            {
                return _RoomNo;
            }
            set
            {
                _RoomNo = value;
            }
        }

        [Column(Storage = "_SocID")]
        public System.Nullable<int> SocID
        {
            get
            {
                return _SocID;
            }
            set
            {
                _SocID = value;
            }
        }

        [Column(Storage = "_Wing")]
        public string Wing
        {
            get
            {
                return _Wing;
            }
            set
            {
                _Wing = value;
            }
        }
        public System.Collections.Generic.List<RoomBS> RoomBSList { get; set; }
        public System.Collections.Generic.List<RMBSU> RMBSUList { get; set; }
        public System.Collections.Generic.List<CP> CPList { get; set; }
    }


    [Serializable]
    [Table(Name = "dbo.RoomBS")]
    public class RoomBS
    {
        private System.Nullable<decimal> _Amount;
        private System.Nullable<int> _BillMonth;
        private string _BillType;
        private System.Nullable<int> _RoomID;
        private System.Nullable<int> _SrNo;

        [Column(Storage = "_Amount")]
        public System.Nullable<decimal> Amount
        {
            get
            {
                return _Amount;
            }
            set
            {
                _Amount = value;
            }
        }

        [Column(Storage = "_BillMonth")]
        public System.Nullable<int> BillMonth
        {
            get
            {
                return _BillMonth;
            }
            set
            {
                _BillMonth = value;
            }
        }

        [Column(Storage = "_BillType")]
        public string BillType
        {
            get
            {
                return _BillType;
            }
            set
            {
                _BillType = value;
            }
        }

        [Column(Storage = "_RoomID")]
        public System.Nullable<int> RoomID
        {
            get
            {
                return _RoomID;
            }
            set
            {
                _RoomID = value;
            }
        }

        [Column(Storage = "_SrNo")]
        public System.Nullable<int> SrNo
        {
            get
            {
                return _SrNo;
            }
            set
            {
                _SrNo = value;
            }
        }
    }

}
