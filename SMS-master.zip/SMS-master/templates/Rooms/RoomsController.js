var app = angular.module('myApp');

app.controller('RoomsListCtrl', function ($scope, $http, $location, GridData) {

    $scope = readyAngularGrid($scope, $http, 'api/RoomsList', 'RoomID', GridData, 'Rooms');
    $scope.gridOptions.columnDefs = [
    { displayName: 'Block/Wing', field: 'WingName' },
    { displayName: 'Unit No.', field: 'RoomNo' },
    { displayName: 'Unit Type', field: 'UnitType' },
    { displayName: 'Intercom', field: 'Intercom' },
    { displayName: 'Tenant/Owner', field: 'Users' },
    ];
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchRooms = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };
    $scope.newRooms = function () {
        saveGridData($scope, GridData, 'Rooms');
        $location.path('/Rooms/0');
    };
    $scope.uploadRooms = function () {
        $location.path('/MemberUpload');
    };
    $scope.editRooms = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            saveGridData($scope, GridData, 'Rooms');
            $location.path('/Rooms/' + selected[0].RoomID);
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.deleteRooms = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'DELETE',
                url: 'api/Rooms/' + selected[0].RoomID
            }).success(function (result) {
                if (result.length == 0) {
                    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
                    swal({ title: "Record deleted successfully!", type: "success", timer: 1000, showConfirmButton: false });
                }
                else
                    alert(result);
            });
        }
        else {
            alert('Please select a record to edit.');
        }
    };
    $scope.exportRooms = function () {
        window.open('api/AccountReport/DownloadMembers');
    };
})

.controller('RoomsCtrl', function ($scope, $http, $location, $routeParams) {
    var RoomID = $routeParams.RoomID;
    $scope.Rooms = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.RoomsSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.RoomsSubmitted = true;
        if ($scope.formRooms.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/Rooms', $scope.Rooms, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.Rooms = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/RoomsList');
    };

    $scope.wingList = [];
    $scope.bindWing = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetWingList', Data: null })
        }).success(function (data) {
            $scope.wingList = data;
        });
    }
    $scope.bindWing();

    //$scope.userlist = [];
    //$scope.bindUser = function () {
    //    $http({
    //        method: 'POST',
    //        url: 'api/Common/',
    //        data: JSON.stringify({ MethodName: 'GetUserList', Data: null })
    //    }).success(function (data) {
    //        $scope.userlist = data;
    //    });
    //}
    //$scope.bindUser();

    $scope.data = { floors: [], buildings: [], wings: [] };
    $scope.bindFloorBuildings = function () {
        for (var j = 0; j <= 30; j++) {
            $scope.data.floors.push({ Key: j, Value: j });
        }

        for (var j = 1; j <= 5; j++) {
            $scope.data.buildings.push({ Key: j, Value: j });
        }
        $scope.data.wings.push({ Key: 'A', Value: 'A' });
        $scope.data.wings.push({ Key: 'B', Value: 'B' });
        $scope.data.wings.push({ Key: 'C', Value: 'C' });
        $scope.data.wings.push({ Key: 'D', Value: 'D' });
        $scope.data.wings.push({ Key: 'E', Value: 'E' });
    };
    $scope.bindFloorBuildings();

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/Rooms/' + RoomID
        }).success(function (Rooms) {
            $scope.Rooms = JSON.parse(Rooms);
        });
    }, 100);

    $scope.RoomBS = {};
    $scope.RoomBSSubmitted = false;
    var RoomBS = [];
    $scope.editRoomBS = function (indx) {
        $scope.EditMode = true;
        $scope.RoomBS = $scope.Rooms.RoomBSList[indx];
        RoomBS = angular.copy($scope.Rooms.RoomBSList);
    };
    $scope.deleteRoomBS = function (indx) {
        if (confirm('Are you sure want to delete?') == true) {
            $scope.Rooms.RoomBSList.splice(indx, 1);
        }
    };
    $scope.newRoomBS = function () {
        $scope.EditMode = true;
        $scope.RoomBSSubmitted = false;
        RoomBS = angular.copy($scope.Rooms.RoomBSList);
        $scope.RoomBS = {};
        $scope.RoomBS.BillType = 'Maintainance';
        $scope.RoomBS.BillMonth = '1';
        $scope.Rooms.RoomBSList.push($scope.RoomBS);
    };
    $scope.cancelRoomBS = function () {
        $scope.EditMode = false;
        $scope.RoomBS = {};
        angular.copy(RoomBS, $scope.Rooms.RoomBSList);
    };
    $scope.updateRoomBS = function (indx) {
        $scope.RoomBSSubmitted = true;
        if ($scope.formRoomBS.$invalid == true) return;
        $scope.EditMode = false;
        $scope.RoomBS = {};
    };
    $scope.getMonthName = function (monthID) {
        if (monthID != null && monthID > 0) {
            var monthArr = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
            return monthArr[parseInt(monthID) - 1];
        }
    };
    $scope.editRMBSU = function (indx) {
        var BSID = $scope.Rooms.RMBSUList[indx].BSID;
        $location.path('/RMBSU/' + BSID + '/' + RoomID);
    };
    $scope.newRMBSU = function (indx) {
        $location.path('/RMBSU/0' + '/' + RoomID);
    };
    $scope.deleteRMBSU = function (indx) {
        if (confirm('Are you sure want to delete?') == true) {
            $http({
                method: 'DELETE',
                url: 'api/RMBSU/' + $scope.Rooms.RMBSUList[indx].BSID
            }).success(function (result) {
                if (result == true)
                    $scope.Rooms.RMBSUList.splice(indx, 1);
            });

        }
    };
    $scope.unittypes = [{ Key: '1RK', Value: '1RK' },
        { Key: '1BHK', Value: '1BHK' },
        { Key: '1.5BHK', Value: '1.5BHK' },
        { Key: '2BHK', Value: '2BHK' },
        { Key: '2.5BHK', Value: '2.5BHK' },
        { Key: '3BHK', Value: '3BHK' },
        { Key: '3.5BHK', Value: '3.5BHK' },
        { Key: '4BHK', Value: '4BHK' },
        { Key: '4.5BHK', Value: '4.5BHK' },
        { Key: '5BHK', Value: '5BHK' },
        { Key: 'Shop', Value: 'Shop' },
        { Key: 'Office', Value: 'Office' }];
});
app.controller('UnitStatementCtrl', function ($scope, $http, $location, $routeParams, User, GridData) {
    var RoomID = $routeParams.RoomID;
    $scope.Filter = { RoomID: null };
    $scope.rmlist = [];
    $scope.Statement = [];
    $scope.Outstanding = 0.00;
    $scope.printUrl = 'blankPage.html';
    $scope.bindRM = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetRoomList', Data: null, query: User.SocID })
        }).success(function (data) {
            $scope.rmlist = data;
        });
    };
    $scope.bindRM();

    $scope = readyAngularGrid($scope, $http, 'api/Rooms/GetStatement', 'BillID', GridData, 'Roomstatement');
    $scope.gridOptions.columnDefs = [
    { displayName: 'Date', field: 'BillDate', cellFilter: 'date:\'dd-MMM-yyyy\'' },
    { displayName: 'Reference No.', field: 'BillNo', cellTemplate: '<div class="ngCellText" ng-class="col.colIndex()"><a ng-click="printBillRec(row)">{{row.getProperty(col.field)}}</a></div>' },
    { displayName: 'Debit (Rs)', field: 'Dr' },
    { displayName: 'Credit (Rs)', field: 'Cr' }];
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchRooms = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };

    $scope.viewStatement = function () {
        $scope.searchRooms();

        $http({
            method: 'POST',
            url: 'api/Rooms/TotalOutstanding',
            data: JSON.stringify({ RoomID: $scope.Filter.RoomID })
        }).success(function (data) {
            $scope.Outstanding = parseFloat(data);
        });
    };

    $scope.$watch('Filter', function (newVal, oldVal) {
        if (newVal.RoomID != oldVal.RoomID)
            $scope.viewStatement();
    }, true);
    $scope.getText = function (model, array) {
        for (var j = 0; j < array.length; j++) {
            if (model == array[j].Key) {
                return ' - ' + array[j].Value;
            }
        }
        return '';
    };
    $scope.printBillRec = function (row) {
        $scope.printUrl = 'blankPage.html';
        var BillID = row.getProperty('BillID');
        var Type = row.getProperty('Type');
        var url = '';
        if (Type == 'Reciept')
            url = 'PrintReciept.aspx?BillID=' + BillID;
        else if (Type == 'Bill')
            url = 'PrintBill.aspx?BillID=' + BillID;
        $scope.printUrl = url;
        $scope.showModal = true;
        //window.open('PrintReciept.aspx?BillID=' + BillID, '', 'height=600,width=900');
    };
    $scope.$watch('showModal', function (newVal, oldVal) {
        if (newVal == false)
            $scope.printUrl = 'blankPage.html';
    }, true);
    $scope.showModal = false;
});
app.controller('RoomListingCtrl', function ($scope, $http) {
    $http({
        method: 'POST',
        url: 'api/Home/RoomList/'
    }).success(function (result) {
        $scope.RoomList = result;
    });
});
app.directive('roombs', function () {
    return {
        restrict: 'E',
        replace: true,
        templateUrl: 'templates/Rooms/RoomBS.html'
    }
});
app.directive('roomcp', function () {
    return {
        restrict: 'E',
        replace: true,
        templateUrl: 'templates/Rooms/RoomCP.html'
    }
});