var app = angular.module('myApp');

app.controller('PenaltyListCtrl', function ($scope, $http, $location, GridData) {

    $scope = readyAngularGrid($scope, $http, 'api/PenaltyList', 'PNID', GridData, 'Penalty');
    $scope.gridOptions.columnDefs = [

    { displayName: 'Method Name', field: 'PNName' },
    { displayName: 'Apply On', field: 'ApplyOn' },
    { displayName: 'Calculate Basis', field: 'FixedOrInt' },
    { displayName: 'Amount', field: 'PNAmount' },
    { displayName: 'Interest Method', field: 'IntMethod' },
    { displayName: 'Recalculate After (Days)', field: 'RecalAfter' }];
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchPenalty = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };
    $scope.newPenalty = function () {
        saveGridData($scope, GridData, 'Penalty');
        $location.path('/Penalty/0');
    };
    $scope.editPenalty = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            saveGridData($scope, GridData, 'Penalty');
            $location.path('/Penalty/' + selected[0].PNID);
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.deletePenalty = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'DELETE',
                url: 'api/Penalty/' + selected[0].PNID
            }).success(function (result) {
                if (result == "Success") {
                    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
                }
                else {
                    alert(result);
                }
            });
        }
        else {
            alert('Please select a record to edit.');
        }
    };
})

.controller('PenaltyCtrl', function ($scope, $http, $location, $routeParams) {
    var PNID = $routeParams.PNID;
    $scope.Penalty = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.PenaltySubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.PenaltySubmitted = true;
        if ($scope.formPenalty.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/Penalty', $scope.Penalty, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.Penalty = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/PenaltyList');
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/Penalty/' + PNID
        }).success(function (Penalty) {
            $scope.Penalty = JSON.parse(Penalty);
        });
    }, 100);
    $scope.recallist = [];
    $scope.bindRecalList = function () {
        $scope.recallist = [];
        $scope.recallist.push({ Key: '1', Value: 'Daily' });
        $scope.recallist.push({ Key: '7', Value: 'Weekly' });
        $scope.recallist.push({ Key: '15', Value: '15 Days' });
        $scope.recallist.push({ Key: '20', Value: '20 Days' });
        $scope.recallist.push({ Key: '30', Value: 'Monthly' });
        $scope.recallist.push({ Key: '45', Value: '45 Days' });
        $scope.recallist.push({ Key: '120', Value: 'Quarterly' });
        $scope.recallist.push({ Key: '180', Value: 'Half Yearly' });
    }
    $scope.bindRecalList();
});
