using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;

namespace SampleAngular.Api
{
    public class PenaltyController : ApiController
    {
        // GET api/Penalty
        [Route("api/PenaltyList/")]
        [HttpPost]
        public AngularGridData GetPenalty([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.PenaltyMethod, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = "Select * from Penalty where SocID="+objLoggedUser.SocID;
            objAngularDataBinder.ValueField = "PNID";
            return objAngularDataBinder.GetData();
        }

        // GET api/Penalty/Id
        [Route("api/Penalty/{Id}")]
        public string GetPenalty(int Id)
        {
            Common.IsValidForm(Constants.Forms.PenaltyMethod, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            PenaltyBL objPenaltyBL = new PenaltyBL(Common.GetConString());
            objPenaltyBL.Load(Id);
            Penalty objPenalty = objPenaltyBL.Data;
            if (Common.ToInt(objPenalty.SocID) > 0 && objPenalty.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            if (objPenaltyBL.IsNew)
            {
                objPenalty.IntMethod = "Normal";
            }
            return JsonConvert.SerializeObject(objPenaltyBL.Data);
        }

        // POST api/Penalty/
        public string Post([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.PenaltyMethod, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            Penalty objPenalty = objJObject.ToObject<Penalty>();
            PenaltyBL objPenaltyBL = new PenaltyBL(Common.GetConString());
            objPenaltyBL.Data = objPenalty;
            if (objPenaltyBL.IsNew)
            {
                objPenalty.SocID = objLoggedUser.SocID;
            }
            PenaltyValidator validator = new PenaltyValidator();
            ValidationResult results = validator.Validate(objPenalty);

            if (results.IsValid)
            {
                objPenaltyBL.Update();
                return JsonConvert.SerializeObject(objPenaltyBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        // DELETE api/Penalty/5
        [Route("api/Penalty/{Id}")]
        [HttpDelete]
        public string Delete(int Id)
        {
            Common.IsValidForm(Constants.Forms.PenaltyMethod, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            PenaltyBL objPenaltyBL = new PenaltyBL(Common.GetConString());
            objPenaltyBL.Load(Id);
            Penalty objPenalty = objPenaltyBL.Data;
            if (Common.ToInt(objPenalty.SocID) > 0 && objPenalty.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            int count = Common.ToInt(Common.GetDBScalar("Select COUNT(*) from BSU where PNID=" + Id));
            if (count > 0)
            {
                return "You cannot delete this Penalty Method because some transactions depends on it!";
            }
            if (objPenaltyBL.Delete(Id))
            {
                return "Success";
            }
            else
            {
                return "Failed";
            }
        }
    }
    public class PenaltyValidator : AbstractValidator<Penalty>
    {
        public PenaltyValidator()
        {
            RuleFor(obj => obj.FixedOrInt).NotEmpty();
            RuleFor(obj => obj.PNAmount).NotEmpty();
            RuleFor(obj => obj.PNName).NotEmpty();
            RuleFor(obj => obj.RecalAfter).NotEmpty();
            RuleFor(obj => obj.SocID).NotEmpty();
        }
    }
}

