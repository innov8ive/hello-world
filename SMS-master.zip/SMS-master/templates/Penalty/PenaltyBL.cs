using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
[Serializable]
public class PenaltyBL
{

#region Declaration
private string connectionString;
Penalty _Penalty;
public Penalty Data
{
get { return _Penalty; }
set { _Penalty = value; }
}
public bool IsNew
{
get { return (_Penalty.PNID <= 0 || _Penalty.PNID ==null); }
}
#endregion

#region Constructor
public PenaltyBL(string conString)
{
connectionString = conString;
}
#endregion

#region Main Methods
private PenaltyDL CreateDL()
{
return new PenaltyDL(connectionString);
}
public void New()
{
_Penalty = new Penalty();
}
public void Load(int PNID)
{
var PenaltyObj = this.CreateDL();
_Penalty = PNID <= 0 ? PenaltyObj.Load(-1) : PenaltyObj.Load(PNID);
}
public DataTable LoadAllPenalty()
{
var PenaltyDLObj = CreateDL();
return PenaltyDLObj.LoadAllPenalty();
}
public bool Update()
{
var PenaltyDLObj = CreateDL();
return PenaltyDLObj.Update(this.Data);
}
public bool Delete(int PNID)
{
var PenaltyDLObj = CreateDL();
return PenaltyDLObj.Delete(PNID);
}
#endregion
}
}
