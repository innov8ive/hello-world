using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

    [Serializable]
    [Table(Name = "dbo.Penalty")]
    public class Penalty
    {

        private string _ApplyOn;
        private string _FixedOrInt;
        private string _IntMethod;
        private System.Nullable<decimal> _PNAmount;
        private System.Nullable<int> _PNID;
        private string _PNName;
        private System.Nullable<int> _RecalAfter;
        private System.Nullable<int> _SocID;

        [Column(Storage = "_ApplyOn")]
        public string ApplyOn
        {
            get
            {
                return _ApplyOn;
            }
            set
            {
                _ApplyOn = value;
            }
        }



        [Column(Storage = "_FixedOrInt")]
        public string FixedOrInt
        {
            get
            {
                return _FixedOrInt;
            }
            set
            {
                _FixedOrInt = value;
            }
        }



        [Column(Storage = "_IntMethod")]
        public string IntMethod
        {
            get
            {
                return _IntMethod;
            }
            set
            {
                _IntMethod = value;
            }
        }



        [Column(Storage = "_PNAmount")]
        public System.Nullable<decimal> PNAmount
        {
            get
            {
                return _PNAmount;
            }
            set
            {
                _PNAmount = value;
            }
        }



        [Column(Storage = "_PNID")]
        public System.Nullable<int> PNID
        {
            get
            {
                return _PNID;
            }
            set
            {
                _PNID = value;
            }
        }



        [Column(Storage = "_PNName")]
        public string PNName
        {
            get
            {
                return _PNName;
            }
            set
            {
                _PNName = value;
            }
        }



        [Column(Storage = "_RecalAfter")]
        public System.Nullable<int> RecalAfter
        {
            get
            {
                return _RecalAfter;
            }
            set
            {
                _RecalAfter = value;
            }
        }



        [Column(Storage = "_SocID")]
        public System.Nullable<int> SocID
        {
            get
            {
                return _SocID;
            }
            set
            {
                _SocID = value;
            }
        }

    }


}
