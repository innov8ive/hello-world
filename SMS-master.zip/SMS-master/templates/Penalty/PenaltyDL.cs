using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
public class PenaltyDL
{

#region Private Members
private string connectionString;
#endregion

#region Constructor
public PenaltyDL(string conString)
{
connectionString = conString;
}
#endregion

#region Main Methods
public Penalty Load(int PNID)
{
SqlConnection SqlCon = new SqlConnection(connectionString);
Penalty objPenalty = new Penalty();
var dc = new DataContext(SqlCon);
try
{
//Get Penalty
var resultPenalty = dc.ExecuteQuery<Penalty>("exec Get_Penalty {0}", PNID).ToList();
if (resultPenalty.Count > 0)
{
objPenalty = resultPenalty[0];
}
dc.Dispose();
return objPenalty;
}
catch (Exception ex)
{
throw new Exception(ex.Message);
}
finally
{
if (SqlCon.State == ConnectionState.Open)
{
SqlCon.Close();
}
SqlCon.Dispose();
}
}
public DataTable LoadAllPenalty()
{
DataTable dt = new DataTable();
SqlConnection con = new SqlConnection(connectionString);
SqlCommand cmd = new SqlCommand("exec Get_Penalty",con);

con.Open();
dt.Load(cmd.ExecuteReader());
con.Close();

return dt;
}
public bool Update(Penalty objPenalty)
{
SqlConnection con = new SqlConnection(connectionString);
con.Open();
SqlTransaction trn = con.BeginTransaction();
try
{
//update Penalty
UpdatePenalty(objPenalty,trn);
if (objPenalty.PNID > 0)
{

trn.Commit();
}
return true;
}
catch
{
trn.Rollback();
return false;
}
finally
{
con.Dispose();
}
}
public bool Delete(int PNID)
{
SqlConnection con = new SqlConnection(connectionString);
con.Open();
SqlTransaction trn = con.BeginTransaction();
try
{
//Delete Penalty
DeletePenalty(PNID,trn);
trn.Commit();
return true;
}
catch
{
trn.Rollback();
return false;
}
finally
{
con.Dispose();
}
}

public bool UpdatePenalty(Penalty objPenalty,SqlTransaction trn){SqlCommand cmd=new SqlCommand("Insert_Update_Penalty",trn.Connection);try{cmd.CommandType=CommandType.StoredProcedure; cmd.Transaction = trn;
cmd.Parameters.Add("@ApplyOn",SqlDbType.VarChar,50).Value=objPenalty.ApplyOn;
cmd.Parameters.Add("@FixedOrInt",SqlDbType.VarChar,50).Value=objPenalty.FixedOrInt;
cmd.Parameters.Add("@IntMethod",SqlDbType.VarChar,50).Value=objPenalty.IntMethod;
cmd.Parameters.Add("@PNAmount",SqlDbType.Decimal).Value=objPenalty.PNAmount;
cmd.Parameters.Add("@PNID",SqlDbType.Int).Value=objPenalty.PNID;
cmd.Parameters["@PNID"].Direction=ParameterDirection.InputOutput;
cmd.Parameters.Add("@PNName",SqlDbType.VarChar,50).Value=objPenalty.PNName;
cmd.Parameters.Add("@RecalAfter",SqlDbType.Int).Value=objPenalty.RecalAfter;
cmd.Parameters.Add("@SocID",SqlDbType.Int).Value=objPenalty.SocID;
cmd.ExecuteNonQuery();//after updating the Penalty, update PNIDobjPenalty.PNID=Convert.ToInt32(cmd.Parameters["@PNID"].Value);return true;}catch{ trn.Rollback();return false;}finally{cmd.Dispose();}}
public bool DeletePenalty(int PNID, SqlTransaction trn){try{SqlCommand cmd=new SqlCommand("Delete from Penalty where PNID=@PNID", trn.Connection);cmd.Transaction = trn;cmd.Parameters.Add("@PNID",SqlDbType.Int).Value=PNID;cmd.ExecuteNonQuery();return true;}catch{trn.Rollback();return false;}}#endregion
}
}
