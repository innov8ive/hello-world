var app = angular.module('myApp');

app.controller('ACReportGECtrl', function ($scope, $http, $location, $filter) {
    $scope.printUrl = '';
    $scope.Filter = { FromDate: null, ToDate: null };
    var date = new Date();
    $scope.Filter.ToDate = $filter('date')(date, 'dd-MMM-yyyy');
    date = date.setMonth(date.getMonth() - 1);
    $scope.Filter.FromDate = $filter('date')(date, 'dd-MMM-yyyy');;
    $scope.print = function () {
        $scope.printUrl = 'api/AccountReport/PrintGE/' + $scope.Filter.FromDate + '/' + $scope.Filter.ToDate;
    };
    $scope.print();
})

app.controller('ACReportBalanceSheetCtrl', function ($scope, $http, $location, $filter) {
    $scope.printUrl = '';
    $scope.Filter = { AsOnDate: null };
    var date = new Date();
    $scope.Filter.AsOnDate = $filter('date')(date, 'dd-MMM-yyyy');
    $scope.print = function () {
        $scope.printUrl = 'api/AccountReport/PrintBalanceSheet/' + $scope.Filter.AsOnDate;
    };
    $scope.print();
})

app.controller('ACReportPNLCtrl', function ($scope, $http, $location, $filter) {
    $scope.printUrl = '';
    $scope.Filter = { AsOnDate: null };
    var date = new Date();
    $scope.Filter.AsOnDate = $filter('date')(date, 'dd-MMM-yyyy');
    $scope.print = function () {
        $scope.printUrl = 'api/AccountReport/PrintPNL/' + $scope.Filter.AsOnDate;
    };
    $scope.print();
})

app.controller('ACReportTrialBalanceCtrl', function ($scope, $http, $location, $filter, GridData) {
    $scope.printUrl = '';
    $scope.showGrid = true;
    $scope.Filter = { AsOnDate: null };
    var date = new Date();
    $scope.Filter.AsOnDate = $filter('date')(date, 'dd-MMM-yyyy');
    $scope.printGLList = function () {
        $scope.showGrid = false;
        $scope.printUrl = 'api/AccountReport/PrintTrialBalance/' + $scope.Filter.AsOnDate;
    };
    $scope.showGLList = function () {
        $scope.showGrid = true;
        $scope.bindGLList();
    };

    $scope.bindGLList = function () {

        $scope = readyAngularGrid($scope, $http, 'api/AccountReport/GLList/', 'GLID', GridData, 'GLList');
        $scope.gridOptions.columnDefs = [

        { displayName: 'Account Name', field: 'Account_Name' },
        { displayName: 'Dr', field: 'Dr' },
        { displayName: 'Cr', field: 'Cr' },
        ];
        $scope.pagingOptions = {
            pageSizes: [10, 20, 30, 100, 500],
            pageSize: 500,
            currentPage: 1
        };
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');
    }
    $scope.showGLList();
});