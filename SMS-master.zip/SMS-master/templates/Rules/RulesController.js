var app = angular.module('myApp');

app.controller('RulesCtrl', function ($scope, $http, $location, $routeParams) {
    $scope.Rules = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.RulesSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.RulesSubmitted = true;
        if ($scope.formRules.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/Rules', $scope.Rules, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.Rules = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/RulesList');
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/Rules/1'
        }).success(function (Rules) {
            $scope.Rules = Rules;
        });
    }, 100);
});
app.controller('BillTermsCtrl', function ($scope, $http, $location, $routeParams) {
    $scope.Rules = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.RulesSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {

        $scope.RulesSubmitted = true;
        if ($scope.formRules.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/Rules', $scope.Rules, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.Rules = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/BSUList');
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/Rules/1'
        }).success(function (Rules) {
            $scope.Rules = Rules;
        });
    }, 100);
});
app.controller('SocRulesCtrl', function ($scope, $http, $location) {
    $scope.Rules = {};
    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/Rules/1'
        }).success(function (Rules) {
            $scope.Rules = Rules;
        });
    }, 100);
});
