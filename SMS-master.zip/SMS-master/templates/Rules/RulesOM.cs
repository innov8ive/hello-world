using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

    [Serializable]
    [Table(Name = "dbo.Rules")]
    public class Rules
    {
        private string _Details;
        private System.Nullable<int> _RuleID;
        private System.Nullable<int> _SocID;
        private System.Nullable<int> _SrNo;
        private string _BillTerms;

        [Column(Storage = "_BillTerms")]
        public string BillTerms
        {
            get { return _BillTerms; }
            set { _BillTerms = value; }
        }

        [Column(Storage = "_Details")]
        public string Details
        {
            get
            {
                return _Details;
            }
            set
            {
                _Details = value;
            }
        }

        [Column(Storage = "_RuleID")]
        public System.Nullable<int> RuleID
        {
            get
            {
                return _RuleID;
            }
            set
            {
                _RuleID = value;
            }
        }

        [Column(Storage = "_SocID")]
        public System.Nullable<int> SocID
        {
            get
            {
                return _SocID;
            }
            set
            {
                _SocID = value;
            }
        }

        [Column(Storage = "_SrNo")]
        public System.Nullable<int> SrNo
        {
            get
            {
                return _SrNo;
            }
            set
            {
                _SrNo = value;
            }
        }
    }
}
