using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
    [Serializable]
    public class RulesBL
    {

        #region Declaration
        private string connectionString;
        Rules _Rules;
        public Rules Data
        {
            get { return _Rules; }
            set { _Rules = value; }
        }
        public bool IsNew
        {
            get { return (_Rules.RuleID <= 0 || _Rules.RuleID == null); }
        }
        #endregion

        #region Constructor
        public RulesBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private RulesDL CreateDL()
        {
            return new RulesDL(connectionString);
        }
        public void New()
        {
            _Rules = new Rules();
        }
        public void Load(int RuleID)
        {
            var RulesObj = this.CreateDL();
            _Rules = RuleID <= 0 ? RulesObj.Load(-1) : RulesObj.Load(RuleID);
        }
        public DataTable LoadAllRules()
        {
            var RulesDLObj = CreateDL();
            return RulesDLObj.LoadAllRules();
        }
        public bool Update()
        {
            var RulesDLObj = CreateDL();
            return RulesDLObj.Update(this.Data);
        }
        public bool Delete(int RuleID)
        {
            var RulesDLObj = CreateDL();
            return RulesDLObj.Delete(RuleID);
        }
        #endregion
    }
}
