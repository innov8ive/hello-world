using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;
using System.Web.Http.Cors;

namespace SampleAngular.Api
{
    public class RulesController : ApiController
    {
        // GET api/Rules/Id
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [Route("api/Rules/{Id}")]
        public object GetRules(int Id)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            RulesBL objRulesBL = new RulesBL(Common.GetConString());
            objRulesBL.Load(objLoggedUser.SocID);

            return JsonConvert.DeserializeObject(JsonConvert.SerializeObject(objRulesBL.Data));
        }

        // POST api/Rules/
        public string Post([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.SocietyRules, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            Rules objRules = objJObject.ToObject<Rules>();
            RulesBL objRulesBL = new RulesBL(Common.GetConString());
            objRulesBL.Data = objRules;
            if (objRulesBL.IsNew)
            {
                objRules.SocID = objLoggedUser.SocID;
            }
            RulesValidator validator = new RulesValidator();
            ValidationResult results = validator.Validate(objRules);

            if (results.IsValid)
            {
                objRulesBL.Update();
                return JsonConvert.SerializeObject(objRulesBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }
       
        // DELETE api/Rules/5
        [Route("api/Rules/{Id}")]
        [HttpDelete]
        public bool Delete(int Id)
        {
            Common.IsValidForm(Constants.Forms.SocietyRules, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            
            RulesBL objRulesBL = new RulesBL(Common.GetConString());
            return objRulesBL.Delete(objLoggedUser.SocID);
        }
    }
    public class RulesValidator : AbstractValidator<Rules>
    {
    }
}

