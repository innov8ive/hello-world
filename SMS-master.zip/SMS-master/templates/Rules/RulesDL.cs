using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
    public class RulesDL
    {

        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public RulesDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public Rules Load(int RuleID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            Rules objRules = new Rules();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get Rules
                var resultRules = dc.ExecuteQuery<Rules>("exec Get_Rules {0}", RuleID).ToList();
                if (resultRules.Count > 0)
                {
                    objRules = resultRules[0];
                }
                dc.Dispose();
                return objRules;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllRules()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_Rules", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(Rules objRules)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update Rules
                UpdateRules(objRules, trn);
                if (objRules.RuleID > 0)
                {

                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int RuleID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete Rules
                DeleteRules(RuleID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateRules(Rules objRules, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_Rules", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@Details", SqlDbType.NText).Value = objRules.Details;
                cmd.Parameters.Add("@BillTerms", SqlDbType.NText).Value = objRules.BillTerms;
                cmd.Parameters.Add("@RuleID", SqlDbType.Int).Value = objRules.RuleID;
                cmd.Parameters["@RuleID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = objRules.SocID;
                cmd.Parameters.Add("@SrNo", SqlDbType.Int).Value = objRules.SrNo;

                cmd.ExecuteNonQuery();

                //after updating the Rules, update RuleID
                objRules.RuleID = Convert.ToInt32(cmd.Parameters["@RuleID"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteRules(int RuleID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from Rules where SocID=@RuleID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@RuleID", SqlDbType.Int).Value = RuleID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        #endregion
    }
}
