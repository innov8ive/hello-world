using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
    public class UsersDL
    {
        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public UsersDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public Users Load(int UserID, int SocID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            Users objUsers = new Users();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get Users
                var resultUsers = dc.ExecuteQuery<Users>("exec Get_Users {0}", UserID).ToList();
                if (resultUsers.Count > 0)
                {
                    objUsers = resultUsers[0];
                }
                objUsers.Rooms = dc.ExecuteQuery<string>("Select Convert(varchar,RoomID) as RoomID from UserRooms where UserID={0} and SocID={1}", UserID, SocID).ToList();
                dc.Dispose();
                return objUsers;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllUsers()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_Users", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(Users objUsers)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update Users
                UpdateUsers(objUsers, trn);
                if (objUsers.UserID > 0)
                {
                    DeleteUserRooms(objUsers.UserID.Value, Convert.ToInt32(objUsers.SocID), trn);
                    foreach (string roomID in objUsers.Rooms)
                    {
                        UserRooms objUserRooms = new UserRooms();
                        objUserRooms.UserID = objUsers.UserID;
                        objUserRooms.RoomID = Convert.ToInt16(roomID);
                        objUserRooms.SocID = objUsers.SocID;
                        InsertIntoUserRooms(objUserRooms, trn);
                    }
                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int UserID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete Users
                DeleteUserRooms(UserID,0, trn);
                DeleteUsers(UserID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateUsers(Users objUsers, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_Users", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@EmailID", SqlDbType.VarChar, 200).Value = objUsers.EmailID;
                cmd.Parameters.Add("@FirstName", SqlDbType.VarChar, 50).Value = objUsers.FirstName;
                cmd.Parameters.Add("@IsActive", SqlDbType.Bit).Value = objUsers.IsActive;
                cmd.Parameters.Add("@LastName", SqlDbType.VarChar, 50).Value = objUsers.LastName;
                cmd.Parameters.Add("@Password", SqlDbType.VarChar, 50).Value = objUsers.Password;
                cmd.Parameters.Add("@UserID", SqlDbType.Int).Value = objUsers.UserID;
                cmd.Parameters["@UserID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@UserName", SqlDbType.VarChar, 50).Value = objUsers.UserName;
                cmd.Parameters.Add("@UserType", SqlDbType.Int).Value = objUsers.UserType;
                cmd.Parameters.Add("@CreatedBy", SqlDbType.Int).Value = objUsers.CreatedBy;
                cmd.Parameters.Add("@CityID", SqlDbType.Int).Value = objUsers.CityID;
                cmd.Parameters.Add("@Verified", SqlDbType.Bit).Value = objUsers.Verified;
                cmd.Parameters.Add("@Code", SqlDbType.VarChar, 50).Value = objUsers.Code;
                cmd.Parameters.Add("@MobileNo", SqlDbType.VarChar, 20).Value = objUsers.MobileNo;
                cmd.Parameters.Add("@RoomID", SqlDbType.Int).Value = 0;
                cmd.Parameters.Add("@Residing", SqlDbType.Bit).Value = objUsers.Residing;
                cmd.Parameters.Add("@SendNotification", SqlDbType.Bit).Value = objUsers.SendNotification;
                cmd.Parameters.Add("@MemberType", SqlDbType.VarChar, 10).Value = objUsers.MemberType;
                cmd.Parameters.Add("@AssignedGate", SqlDbType.VarChar, 20).Value = objUsers.AssignedGate;
                cmd.Parameters.Add("@IDCard", SqlDbType.VarChar, 20).Value = objUsers.IDCard;
                cmd.Parameters.Add("@RoleID", SqlDbType.Int).Value = Convert.ToInt32(objUsers.RoleID);
                cmd.Parameters.Add("@CoApplicantName", SqlDbType.VarChar, 250).Value = objUsers.CoApplicantName;
                cmd.Parameters.Add("@AppointmentDate", SqlDbType.DateTime).Value = objUsers.AppointmentDate;

                cmd.ExecuteNonQuery();

                //after updating the Users, update UserID
                objUsers.UserID = Convert.ToInt32(cmd.Parameters["@UserID"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool UpdateProfile(Users objUsers)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("Update Users set EmailID=@EmailID,FirstName=@FirstName,LastName=@LastName,CityID=@CityID,MobileNo=@MobileNo where UserID=@UserID", con);
            try
            {
                cmd.Parameters.Add("@EmailID", SqlDbType.VarChar, 200).Value = objUsers.EmailID;
                cmd.Parameters.Add("@FirstName", SqlDbType.VarChar, 50).Value = objUsers.FirstName;
                cmd.Parameters.Add("@LastName", SqlDbType.VarChar, 50).Value = objUsers.LastName;
                cmd.Parameters.Add("@CityID", SqlDbType.Int).Value = Convert.ToInt32(objUsers.CityID);
                cmd.Parameters.Add("@MobileNo", SqlDbType.VarChar, 11).Value = objUsers.MobileNo;
                cmd.Parameters.Add("@UserID", SqlDbType.Int).Value = objUsers.UserID;
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool DeleteUsers(int UserID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from Users where UserID=@UserID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@UserID", SqlDbType.Int).Value = UserID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }

        public bool DeleteUserRooms(int UserID, int SocID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from UserRooms where UserID=@UserID and (@SocID=0 OR SocID=@SocID)", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@UserID", SqlDbType.Int).Value = UserID;
                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = SocID;
                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        public bool InsertIntoUserRooms(UserRooms objUserRooms, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Into_UserRooms", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Transaction = trn;
                cmd.Parameters.Add("@RoomID", SqlDbType.Int).Value = objUserRooms.RoomID;
                cmd.Parameters.Add("@UserID", SqlDbType.Int).Value = objUserRooms.UserID;
                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = objUserRooms.SocID;
                cmd.ExecuteNonQuery();

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        #endregion
    }
}
