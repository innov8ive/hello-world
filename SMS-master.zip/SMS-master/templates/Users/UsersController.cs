using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;
using System.IO;
using System.Text;

namespace SampleAngular.Api
{
    public class UsersController : ApiController
    {
        // GET api/Users
        [Route("api/UsersList/")]
        [HttpPost]
        public AngularGridData GetUsers([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.Members, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);

            StringBuilder query = new StringBuilder(@"Select * from VW_Users where UserType<>9");
            if (objLoggedUser.UserType == 3)//Sysadmin
                query.Append(" and UserType=4");//SP
            else if (objLoggedUser.UserType == 2)//Admin
                query.Append(" and (CreatedBy=" + objLoggedUser.UserID + " OR UserID=" + objLoggedUser.UserID + ")");//Member

            if (!String.IsNullOrEmpty(objAngularGrid.SearchText))
            {
                query.Append(" and (RoomNos like '%'+@Text+'%' OR FirstName like '%'+@Text+'%' OR LastName like '%'+@Text+'%' OR EmailID like '%'+@Text+'%')");
                Hashtable ht = new Hashtable();
                ht["@Text"] = objAngularGrid.SearchText;
                objAngularDataBinder.Parameters = ht;
            }

            objAngularDataBinder.Query = query.ToString();
            objAngularDataBinder.ValueField = "UserID";
            return objAngularDataBinder.GetData();
        }

        // GET api/Users/Id
        [Route("api/Users/{Id}")]
        public string GetUsers(int Id)
        {
            if (Id > 0)
                Common.IsValidForm(Constants.Forms.Members, Request);
            UsersBL objUsersBL = new UsersBL(Common.GetConString());
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser != null)
                objUsersBL.Load(Id, objLoggedUser.SocID);
            else
                objUsersBL.Load(Id, 0);
            objUsersBL.Data.Password = String.Empty;
            if (objUsersBL.IsNew)
                objUsersBL.Data.SendNotification = true;
            return JsonConvert.SerializeObject(objUsersBL.Data);
        }

        [Route("api/UsersProfile")]
        [HttpGet]
        public string UsersProfile()
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser == null) throw new HttpResponseException(HttpStatusCode.Unauthorized);
            UsersBL objUsersBL = new UsersBL(Common.GetConString());
            objUsersBL.Load(objLoggedUser.UserID, objLoggedUser.SocID);
            objUsersBL.Data.Password = String.Empty;
            return JsonConvert.SerializeObject(objUsersBL.Data);
        }

        [Route("api/Users/Available/")]
        [HttpPost]
        public string UserAvailable([FromBody]dynamic username)
        {
            DataTable dt = Common.GetDBResultParameterized("Select 1 from Users where (EmailID=@UserName OR MobileNo=@UserName)", "@UserName", SqlDbType.VarChar, username);
            if (dt.Rows.Count > 0)
            {
                return "false";
            }
            else
            {
                return "true";
            }
        }
        [Route("api/Users/RemovePhoto/")]
        [HttpPost]
        public string UserRemovePhoto([FromBody]dynamic param)
        {
            int userID = 0;
            string imageUrl;
            string data = param;
            if (data.Contains("."))
            {
                userID = Common.ToInt(data.Substring(0, data.IndexOf(".")));
                imageUrl = data.Substring(data.IndexOf(".") + 1);
                int count = Common.ExecuteNonQuery("Update Users Set ImageUrl='' where UserID=@UserID", "@UserID", SqlDbType.Int, Common.ToInt(userID));
                if (count > 0)
                {
                    try
                    {
                        string filePath = HttpContext.Current.Server.MapPath("~/images/profile") + "/" + imageUrl;
                        File.Delete(filePath);
                    }
                    catch { }
                    return "true";
                }
                else
                {
                    return "false";
                }
            }
            return "false";
        }
        [Route("api/Users/AttachPhoto/")]
        [HttpPost]
        public string UserAttachPhoto([FromBody]dynamic param)
        {
            int userID = 0;
            string imageUrl;
            string data = param;
            if (data.Contains("."))
            {
                userID = Common.ToInt(data.Substring(0, data.IndexOf(".")));
                imageUrl = data.Substring(data.IndexOf(".") + 1);

                int count = Common.ExecuteNonQuery("Update Users Set ImageUrl=@ImageUrl where UserID=@UserID"
                    , "@UserID", SqlDbType.Int, userID
                    , "@ImageUrl", SqlDbType.VarChar, imageUrl);
                if (count > 0)
                {
                    return imageUrl;
                }
                else
                {
                    return String.Empty;
                }
            }
            return String.Empty;
        }

        [Route("api/Users/UpdateProfile/")]
        [HttpPost]
        public string UpdateProfile([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser == null) throw new HttpResponseException(HttpStatusCode.Unauthorized);

            JObject objJObject = value;
            Users objUsers = objJObject.ToObject<Users>();
            objUsers.UserID = objLoggedUser.UserID;
            UsersValidator validator = new UsersValidator();
            ValidationResult results = validator.Validate(objUsers);
            if (objUsers.MobileNo.Length != 10)
            {
                results.Errors.Add(new ValidationFailure("MobileNo", "Mobile No. should be 10 digit only"));
            }
            if (Common.ToString(objUsers.MobileNo).Length > 0)
            {
                DataTable dt = Common.GetDBResultParameterized(@"Select UserID from Users where MobileNo=@MobileNo
and UserID<>@UserID"
                    , "@UserID", SqlDbType.Int, Common.ToInt(objLoggedUser.UserID)
                    , "@MobileNo", SqlDbType.VarChar, Common.ToString(objUsers.MobileNo));
                if (dt.Rows.Count > 0)
                {
                    ValidationFailure emailError = new ValidationFailure("MobileNo", "Mobile is already registered, please choose another Mobile");
                    results.Errors.Add(emailError);
                }
            }
            if (Common.ToString(objUsers.EmailID).Length > 0)
            {
                DataTable dt = Common.GetDBResultParameterized(@"Select 1 from Users where EmailID=@EmailID and UserID<>@UserID"
                    , "@UserID", SqlDbType.Int, Common.ToInt(objLoggedUser.UserID)
                    , "@EmailID", SqlDbType.VarChar, Common.ToString(objUsers.EmailID));
                if (dt.Rows.Count > 0)
                {
                    ValidationFailure emailError = new ValidationFailure("EmailID", "EmailID already registered, please choose another EmailID");
                    results.Errors.Add(emailError);
                }
            }
            if (results.IsValid)
            {
                UsersBL objUsersBL = new UsersBL(Common.GetConString());
                objUsersBL.UpdateProfile(objUsers);
                return JsonConvert.SerializeObject(objUsers);
            }
            else
            {
                return JsonConvert.SerializeObject(results.Errors);
            }
        }
        // POST api/Users/
        public string Post([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.Members, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            JObject objJObject = value;
            Users objUsers = objJObject.ToObject<Users>();
            UsersBL objUsersBL = new UsersBL(Common.GetConString());
            objUsersBL.Data = objUsers;

            if (Common.ToInt(objUsers.UserType) <= 0)
            {
                if (objLoggedUser.UserType == 3)//Sysadmin
                    objUsers.UserType = 2;//Admin
                else if (objLoggedUser.UserType == 2)//Admin
                    objUsers.UserType = 1;//Member
            }
            UsersValidator validator = new UsersValidator();
            ValidationResult results = validator.Validate(objUsers);
            if (String.IsNullOrEmpty(objUsers.EmailID) && String.IsNullOrEmpty(objUsers.MobileNo))
            {
                results.Errors.Add(new ValidationFailure("EmailID", "EmailID/Mobile Required"));
            }
            if (Common.ToString(objUsers.EmailID).Length > 0)
            {
                DataTable dt = Common.GetDBResultParameterized(@"Select 1 from Users where EmailID=@EmailID and UserID<>@UserID and CreatedBy=@CreatedBy"
                    , "@EmailID", SqlDbType.VarChar, Common.ToString(objUsers.EmailID)
                    , "@UserID", SqlDbType.Int, Common.ToInt(objUsers.UserID)
                    , "@CreatedBy", SqlDbType.Int, Common.ToInt(objLoggedUser.UserID));
                if (dt.Rows.Count > 0)
                {
                    ValidationFailure emailError = new ValidationFailure("EmailID", "EmailID is already registered, please choose another EmailID");
                    results.Errors.Add(emailError);
                }
            }
            if (Common.ToString(objUsers.MobileNo).Length > 0)
            {
                DataTable dt = Common.GetDBResultParameterized(@"Select 1 from Users where MobileNo=@MobileNo and UserID<>@UserID"
                    , "@MobileNo", SqlDbType.VarChar, Common.ToString(objUsers.MobileNo)
                    , "@UserID", SqlDbType.Int, Common.ToInt(objUsers.UserID));
                if (dt.Rows.Count > 0)
                {
                    ValidationFailure emailError = new ValidationFailure("MobileNo", "Mobile is already registered, please choose another Mobile");
                    results.Errors.Add(emailError);
                }
            }
            if (objUsers.MobileNo.Length != 10)
            {
                results.Errors.Add(new ValidationFailure("MobileNo", "Mobile No. should be 10 digit only"));
            }
            if (objUsers.MobileNo.Length > 0 && Common.ToDouble(objUsers.MobileNo) < 0)
            {
                results.Errors.Add(new ValidationFailure("MobileNo", "Mobile No. should be 10 digit only"));
            }
            if (!String.IsNullOrEmpty(objUsers.MobileNo) && objUsers.MobileNo.Length > 0 && Common.ToInt(objUsers.MobileNo.Substring(0, 1)) < 6)
            {
                results.Errors.Add(new ValidationFailure("MobileNo", "Invalid Mobile No."));
            }

            bool isNew = objUsersBL.IsNew;
            string password = String.Empty;
            if (results.IsValid)
            {
                objUsers.SocID = objLoggedUser.SocID;
                if (objUsersBL.IsNew)
                {
                    password = Guid.NewGuid().ToString().Substring(0, 6);
                    objUsers.Password = password;
                    objUsers.IsActive = true;
                    objUsers.Verified = true;
                }
                if (!String.IsNullOrEmpty(objUsers.Password))
                    objUsers.Password = Common.MD5Encrypt(objUsers.Password);
                if (Common.ToInt(objUsers.UserID) <= 0)
                    objUsers.CreatedBy = objLoggedUser.UserID;
                objUsersBL.Update();
                if (isNew)
                {
                    if (!String.IsNullOrEmpty(objUsers.MobileNo))
                    {
                        Common.SendSMS(Common.ToString(objUsers.MobileNo), "Dear Member, Your account created on app.societyInn.com. Username is " + objUsers.MobileNo + " Password is " + password + "." + objLoggedUser.SocName + ". Download SocietyInn App https://goo.gl/ye3bjk from Play Store.", 0);
                    }
                    else
                    {
                        Common.SendEmailSendGrid(Common.ToString(objUsers.EmailID), "Your account created on SocietyInn.com. Password is " + password, "Your account created on SocietyInn.com");
                    }
                }
                objUsersBL.Data.Password = String.Empty;
                return JsonConvert.SerializeObject(objUsersBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }
        [Route("api/User/Register/")]
        [HttpPost]
        public string UserRegister([FromBody]dynamic value)
        {
            JObject objJObject = value;
            Users objUsers = objJObject.ToObject<Users>();
            UsersBL objUsersBL = new UsersBL(Common.GetConString());
            objUsersBL.Data = objUsers;
            objUsers.UserType = 1;
            objUsers.UserName = objUsers.EmailID;
            UsersValidator validator = new UsersValidator();
            ValidationResult results = validator.Validate(objUsers);

            if (String.IsNullOrEmpty(objUsers.EmailID) && String.IsNullOrEmpty(objUsers.MobileNo))
            {
                results.Errors.Add(new ValidationFailure("EmailID", "EmailID/Mobile Required"));
            }
            DataTable dt = Common.GetDBResultParameterized(@"Select 1 from Users where (EmailID=@EmailID OR MobileNo=@MobileNo)"
               , "@EmailID", SqlDbType.VarChar, Common.ToString(objUsers.EmailID)
               , "@MobileNo", SqlDbType.VarChar, Common.ToString(objUsers.MobileNo));

            if (String.IsNullOrEmpty(objUsers.Password))
            {
                results.Errors.Add(new ValidationFailure("Password", "Password Required"));
            }
            if (objUsers.CityID == null || objUsers.CityID == 0)
            {
                results.Errors.Add(new ValidationFailure("CityID", "City Required"));
            }

            if (results.IsValid)
            {
                string verifyCode = Guid.NewGuid().ToString();
                objUsers.IsActive = true;
                objUsers.Verified = false;
                objUsers.UserName = objUsers.EmailID;
                objUsers.Code = verifyCode;
                objUsers.Password = Common.MD5Encrypt(objUsers.Password);
                objUsers.EmailID = objUsers.EmailID;
                objUsersBL.Data = objUsers;
                objUsersBL.Update();

                if (objUsersBL.Data.UserID > 0)
                {
                    //Send Email
                }
                return JsonConvert.SerializeObject(objUsersBL.Data);
            }

            return JsonConvert.SerializeObject(results.Errors);
        }

        // DELETE api/Users/5
        [Route("api/Users/{Id}")]
        [HttpDelete]
        public string Delete(int Id)
        {
            Common.IsValidForm(Constants.Forms.Members, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            if (objLoggedUser.UserID == Id)
            {
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            }

            UsersBL objUsersBL = new UsersBL(Common.GetConString());
            objUsersBL.Load(Id, objLoggedUser.SocID);

            Users objUsers = objUsersBL.Data;
            if (Common.ToInt(objUsers.SocID) > 0 && objUsers.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            int count = Common.ToInt(Common.GetDBScalar("Select COUNT(*) from UserRooms where UserID=" + Id));
            //count = Common.ToInt(Common.GetDBScalar("Select COUNT(*) from Forums where CreatedBy=" + Id));
            if (count > 0)
            {
                return "You cannot delete this User, Please un-assign User's room(s) first!";
            }
            bool result = objUsersBL.Delete(Id);
            if (result)
                return String.Empty;
            else
                return "User not deleted!";
        }

        [Route("api/Users/MakeAdmin/")]
        [HttpPost]
        public string MakeAdmin([FromBody]dynamic param)
        {
            int userID = Common.ToInt(param);
            Common.IsValidForm(Constants.Forms.Members, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (userID > 0)
            {
                Common.ExecuteNonQuery("Update Users set UserType=1 where UserID=" + objLoggedUser.UserID);
                Common.ExecuteNonQuery("Update Users set UserType=2 where UserID=" + userID);
                Common.ExecuteNonQuery("Update Soc set UserID=" + userID + " where SocID=" + objLoggedUser.SocID);
                Common.ExecuteNonQuery("Update Users set CreatedBy=" + userID + " where (CreatedBy=" + objLoggedUser.UserID + " OR UserID=" + objLoggedUser.UserID + ")");
                Common.ExecuteNonQuery("update Users set CreatedBy=NULL where UserID=" + userID);
                return "true";
            }
            return "false";
        }

    }
    public class UsersValidator : AbstractValidator<Users>
    {
        public UsersValidator()
        {
            RuleFor(obj => obj.FirstName).NotEmpty();
            RuleFor(obj => obj.LastName).NotEmpty();
            RuleFor(obj => obj.UserType).NotEmpty();
        }
    }
}

