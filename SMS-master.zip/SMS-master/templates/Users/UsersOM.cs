using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

    [Serializable]
    [Table(Name = "dbo.Users")]
    public class Users
    {

        private string _EmailID;
        private string _FirstName;
        private string _ImageUrl;
        private System.Nullable<bool> _IsActive;
        private string _LastName;
        private string _Password;
        private System.Nullable<int> _UserID;
        private string _UserName;
        private System.Nullable<int> _UserType;
        private Nullable<int> _CreatedBy;
        private Nullable<int> _CityID;
        private Nullable<bool> _Verified;
        private string _Code;
        private string _MobileNo;
        private Nullable<int> _SocID;
        private string _MemberType;
        private Nullable<bool> _Residing;
        private Nullable<bool> _SendNotification;
        private string _AssignedGate;
        private string _IDCard;
        private string _ConfirmPassword;
        private Nullable<int> _RoleID;
        private string _CoApplicantName;
        private Nullable<DateTime> _AppointmentDate;

        [Column(Storage = "_AppointmentDate")]
        public Nullable<DateTime> AppointmentDate
        {
            get { return _AppointmentDate; }
            set { _AppointmentDate = value; }
        }

        [Column(Storage = "_CoApplicantName")]
        public string CoApplicantName
        {
            get { return _CoApplicantName; }
            set { _CoApplicantName = value; }
        }

        [Column(Storage = "_RoleID")]
        public Nullable<int> RoleID
        {
            get { return _RoleID; }
            set { _RoleID = value; }
        }

        [Column(Storage = "_ConfirmPassword")]
        public string ConfirmPassword
        {
            get { return _ConfirmPassword; }
            set { _ConfirmPassword = value; }
        }

        [Column(Storage = "_IDCard")]
        public string IDCard
        {
            get { return _IDCard; }
            set { _IDCard = value; }
        }

        [Column(Storage = "_AssignedGate")]
        public string AssignedGate
        {
            get { return _AssignedGate; }
            set { _AssignedGate = value; }
        }

        [Column(Storage = "_SendNotification")]
        public Nullable<bool> SendNotification
        {
            get { return _SendNotification; }
            set { _SendNotification = value; }
        }

        [Column(Storage = "_Residing")]
        public Nullable<bool> Residing
        {
            get { return _Residing; }
            set { _Residing = value; }
        }

        [Column(Storage = "_MemberType")]
        public string MemberType
        {
            get { return _MemberType; }
            set { _MemberType = value; }
        }

        [Column(Storage = "_SocID")]
        public Nullable<int> SocID
        {
            get { return _SocID; }
            set { _SocID = value; }
        }

        [Column(Storage = "_MobileNo")]
        public string MobileNo
        {
            get { return _MobileNo; }
            set { _MobileNo = value; }
        }

        [Column(Storage = "_Code")]
        public string Code
        {
            get { return _Code; }
            set { _Code = value; }
        }

        [Column(Storage = "_Verified")]
        public Nullable<bool> Verified
        {
            get { return _Verified; }
            set { _Verified = value; }
        }

        [Column(Storage = "_CityID")]
        public Nullable<int> CityID
        {
            get { return _CityID; }
            set { _CityID = value; }
        }

        [Column(Storage = "_CreatedBy")]
        public Nullable<int> CreatedBy
        {
            get { return _CreatedBy; }
            set { _CreatedBy = value; }
        }

        [Column(Storage = "_EmailID")]
        public string EmailID
        {
            get
            {
                return _EmailID;
            }
            set
            {
                _EmailID = value;
            }
        }

        [Column(Storage = "_FirstName")]
        public string FirstName
        {
            get
            {
                return _FirstName;
            }
            set
            {
                _FirstName = value;
            }
        }

        [Column(Storage = "_ImageUrl")]
        public string ImageUrl
        {
            get
            {
                return _ImageUrl;
            }
            set
            {
                _ImageUrl = value;
            }
        }

        [Column(Storage = "_IsActive")]
        public System.Nullable<bool> IsActive
        {
            get
            {
                return _IsActive;
            }
            set
            {
                _IsActive = value;
            }
        }

        [Column(Storage = "_LastName")]
        public string LastName
        {
            get
            {
                return _LastName;
            }
            set
            {
                _LastName = value;
            }
        }

        [Column(Storage = "_Password")]
        public string Password
        {
            get
            {
                return _Password;
            }
            set
            {
                _Password = value;
            }
        }

        [Column(Storage = "_UserID")]
        public System.Nullable<int> UserID
        {
            get
            {
                return _UserID;
            }
            set
            {
                _UserID = value;
            }
        }

        [Column(Storage = "_UserName")]
        public string UserName
        {
            get
            {
                return _UserName;
            }
            set
            {
                _UserName = value;
            }
        }

        [Column(Storage = "_UserType")]
        public System.Nullable<int> UserType
        {
            get
            {
                return _UserType;
            }
            set
            {
                _UserType = value;
            }
        }

        public List<string> Rooms { get; set; }
    }

    [Serializable]
    [Table(Name = "dbo.UserRooms")]
    public class UserRooms
    {
        private System.Nullable<int> _RoomID;
        private System.Nullable<int> _UserID;
        private System.Nullable<int> _SocID;

        [Column(Storage = "_SocID")]
        public System.Nullable<int> SocID
        {
            get { return _SocID; }
            set { _SocID = value; }
        }

        [Column(Storage = "_RoomID")]
        public System.Nullable<int> RoomID
        {
            get
            {
                return _RoomID;
            }
            set
            {
                _RoomID = value;
            }
        }

        [Column(Storage = "_UserID")]
        public System.Nullable<int> UserID
        {
            get
            {
                return _UserID;
            }
            set
            {
                _UserID = value;
            }
        }
    }
}
