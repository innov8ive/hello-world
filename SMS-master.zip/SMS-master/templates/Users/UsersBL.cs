using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
    [Serializable]
    public class UsersBL
    {

        #region Declaration
        private string connectionString;
        Users _Users;
        public Users Data
        {
            get { return _Users; }
            set { _Users = value; }
        }
        public bool IsNew
        {
            get { return (_Users.UserID <= 0 || _Users.UserID == null); }
        }
        #endregion

        #region Constructor
        public UsersBL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        private UsersDL CreateDL()
        {
            return new UsersDL(connectionString);
        }
        public void New()
        {
            _Users = new Users();
        }
        public void Load(int UserID, int SocID)
        {
            var UsersObj = this.CreateDL();
            _Users = UserID <= 0 ? UsersObj.Load(-1, SocID) : UsersObj.Load(UserID, SocID);
        }
        public DataTable LoadAllUsers()
        {
            var UsersDLObj = CreateDL();
            return UsersDLObj.LoadAllUsers();
        }
        public bool Update()
        {
            var UsersDLObj = CreateDL();
            return UsersDLObj.Update(this.Data);
        }
        public bool Delete(int UserID)
        {
            var UsersDLObj = CreateDL();
            return UsersDLObj.Delete(UserID);
        }
        public bool UpdateProfile(Users objUsers)
        {
            var UsersDLObj = CreateDL();
            return UsersDLObj.UpdateProfile(objUsers);
        }
        #endregion
    }
}
