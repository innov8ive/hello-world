using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using System.Collections;

namespace SampleAngularOM
{

    [Serializable]
    [Table(Name = "dbo.Directory")]
    public class Directory
    {

        private System.Nullable<int> _AddedBy;
        private string _EmailID;
        private System.Nullable<int> _ID;
        private string _MobileNo;
        private string _Name;
        private System.Nullable<int> _SocID;
        private string _ServiceName;
        private string _Address;

        [Column(Storage = "_Address")]
        public string Address
        {
            get { return _Address; }
            set { _Address = value; }
        }

        [Column(Storage = "_ServiceName")]
        public string ServiceName
        {
            get { return _ServiceName; }
            set { _ServiceName = value; }
        }



        [Column(Storage = "_AddedBy")]
        public System.Nullable<int> AddedBy
        {
            get
            {
                return _AddedBy;
            }
            set
            {
                _AddedBy = value;
            }
        }



        [Column(Storage = "_EmailID")]
        public string EmailID
        {
            get
            {
                return _EmailID;
            }
            set
            {
                _EmailID = value;
            }
        }



        [Column(Storage = "_ID")]
        public System.Nullable<int> ID
        {
            get
            {
                return _ID;
            }
            set
            {
                _ID = value;
            }
        }



        [Column(Storage = "_MobileNo")]
        public string MobileNo
        {
            get
            {
                return _MobileNo;
            }
            set
            {
                _MobileNo = value;
            }
        }



        [Column(Storage = "_Name")]
        public string Name
        {
            get
            {
                return _Name;
            }
            set
            {
                _Name = value;
            }
        }



        [Column(Storage = "_SocID")]
        public System.Nullable<int> SocID
        {
            get
            {
                return _SocID;
            }
            set
            {
                _SocID = value;
            }
        }

    }


}
