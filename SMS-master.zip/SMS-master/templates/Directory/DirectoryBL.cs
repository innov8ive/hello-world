using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using SampleAngularOM;
using SampleAngularDL;

namespace SampleAngularBL
{
[Serializable]
public class DirectoryBL
{

#region Declaration
private string connectionString;
Directory _Directory;
public Directory Data
{
get { return _Directory; }
set { _Directory = value; }
}
public bool IsNew
{
get { return (_Directory.ID <= 0 || _Directory.ID ==null); }
}
#endregion

#region Constructor
public DirectoryBL(string conString)
{
connectionString = conString;
}
#endregion

#region Main Methods
private DirectoryDL CreateDL()
{
return new DirectoryDL(connectionString);
}
public void New()
{
_Directory = new Directory();
}
public void Load(int ID)
{
var DirectoryObj = this.CreateDL();
_Directory = ID <= 0 ? DirectoryObj.Load(-1) : DirectoryObj.Load(ID);
}
public DataTable LoadAllDirectory()
{
var DirectoryDLObj = CreateDL();
return DirectoryDLObj.LoadAllDirectory();
}
public bool Update()
{
var DirectoryDLObj = CreateDL();
return DirectoryDLObj.Update(this.Data);
}
public bool Delete(int ID)
{
var DirectoryDLObj = CreateDL();
return DirectoryDLObj.Delete(ID);
}
#endregion
}
}
