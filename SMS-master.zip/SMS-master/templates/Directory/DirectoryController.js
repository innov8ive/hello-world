var app = angular.module('myApp');

app.controller('DirectoryListCtrl', function ($scope, $http, $location, GridData, User) {
    $scope.filter = { filterText: '' };
    $scope.DirectoryList = [];
    $scope.User = User;
    $scope.searchDirectory = function () {
        $http({
            method: 'POST',
            url: 'api/DirectoryList/',
            data: JSON.stringify({ searchText: $scope.filter.filterText })
        }).success(function (Directory) {
            $scope.DirectoryList = Directory;
        });
    };
    $scope.newDirectory = function () {
        $location.path('/Directory/0');
    };
    $scope.editDirectory = function (id) {
        $location.path('/Directory/' + id);
    };

    $scope.deleteDirectory = function (id) {
        if (confirm('Are you sure want to delete?') == false) return;

        $http({
            method: 'POST',
            url: 'api/DirectoryDelete/' + id
        }).success(function (result) {
            if (result == true)
                $scope.searchDirectory();
        });
    };

    window.setTimeout(function () { $scope.searchDirectory() }, 200);
})

.controller('DirectoryCtrl', function ($scope, $http, $location, $routeParams) {
    var ID = $routeParams.ID;
    $scope.Directory = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.DirectorySubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.DirectorySubmitted = true;
        if ($scope.formDirectory.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/Directory', $scope.Directory, config)
        .success(function (data, status, headers, config) {
            var result = data;
            if (result.ErrorCode == 1)
                $scope.ErrorMessages = result.data;
            else {
                $scope.ErrorMessages = [];
                $scope.Directory = result.data;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/DirectoryList');
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/Directory/' + ID
        }).success(function (Directory) {
            $scope.Directory = Directory;
        });
    }, 100);
});
