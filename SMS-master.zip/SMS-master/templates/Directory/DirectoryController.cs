using FluentValidation;
using FluentValidation.Results;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleAngularOM;
using SampleAngularBL;
using System.Web;
using System.Web.Http.Cors;

namespace SampleAngular.Api
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class DirectoryController : ApiController
    {
        // GET api/Directory
        [Route("api/DirectoryList/")]
        [HttpPost]
        public DataTable GetDirectory([FromBody]dynamic value)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            string searchText = Common.ToString(value.searchText);

            DataTable dt = Common.GetDBResultParameterized(@"Select D.*,U.Name+ISNULL(' ('+U.RoomNos+')','') as CreatedByName
from Directory D inner join VW_Users U ON D.AddedBy=U.UserID
where (D.Name like '%'+@Text+'%' OR D.EmailID like '%'+@Text+'%' OR D.MobileNo like '%'+@Text+'%' OR D.ServiceName like '%'+@Text+'%') 
and D.SocID=@SocID", "@Text", SqlDbType.VarChar, searchText,
                     "@SocID", SqlDbType.Int, objLoggedUser.SocID);


            return dt;
        }

       [Route("api/DirectoryList2/")]
        [HttpPost]
        public AngularGridData DirectoryList2([FromBody]dynamic value)
        {
            string searchText = Common.ToString(value.SearchText);
            Common.IsValidForm(Constants.Forms.Directory, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            JObject objJObject = value;
            AngularGrid objAngularGrid = objJObject.ToObject<AngularGrid>();

            AngularDataBinder objAngularDataBinder = new AngularDataBinder(objAngularGrid);
            objAngularDataBinder.Query = @"Select D.*,U.Name+ISNULL(' ('+U.RoomNos+')','') as CreatedByName from Directory D inner join VW_Users U ON D.AddedBy=U.UserID
where (D.Name like '%'+@Text+'%' OR D.EmailID like '%'+@Text+'%' OR D.MobileNo like '%'+@Text+'%' OR D.ServiceName like '%'+@Text+'%' ) 
and D.SocID=@SocID";
            Hashtable ht = new Hashtable();
            ht["@Text"] = searchText;
            ht["@SocID"] = objLoggedUser.SocID;
            objAngularDataBinder.Parameters = ht;
            objAngularDataBinder.ValueField = "ID";
            return objAngularDataBinder.GetData();
        }

        // GET api/Directory/Id
        [Route("api/Directory/{Id}")]
        public object GetDirectory(int Id)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            DirectoryBL objDirectoryBL = new DirectoryBL(Common.GetConString());
            objDirectoryBL.Load(Id);

            Directory objDirectory = objDirectoryBL.Data;
            if (Common.ToInt(objDirectory.SocID) > 0 && objDirectory.SocID != objLoggedUser.SocID)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);

            return JsonConvert.DeserializeObject(JsonConvert.SerializeObject(objDirectoryBL.Data));
        }

        // POST api/Directory/
        public object Post([FromBody]dynamic value)
        {
            PostResponse objPostResponse = new PostResponse();
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            JObject objJObject = value;
            Directory objDirectory = objJObject.ToObject<Directory>();
            DirectoryBL objDirectoryBL = new DirectoryBL(Common.GetConString());
            objDirectoryBL.Data = objDirectory;

            if (Common.ToInt(objDirectory.AddedBy) > 0 && objDirectory.AddedBy != objLoggedUser.UserID && objLoggedUser.UserType != 2)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            if (objDirectoryBL.IsNew)
            {
                objDirectory.SocID = objLoggedUser.SocID;
                objDirectory.AddedBy = objLoggedUser.UserID;
            }

            DirectoryValidator validator = new DirectoryValidator();
            ValidationResult results = validator.Validate(objDirectory);
            if (objDirectory.MobileNo.Length != 10)
            {
                results.Errors.Add(new ValidationFailure("MobileNo", "Mobile No. should be 10 digit only"));
            }
            if (objDirectory.MobileNo.Length > 0 && Common.ToDouble(objDirectory.MobileNo) < 0)
            {
                results.Errors.Add(new ValidationFailure("MobileNo", "Mobile No. should be 10 digit only"));
            }
            if (results.IsValid)
            {
                objDirectoryBL.Update();
                objPostResponse.ErrorCode = 0;
                objPostResponse.data = JsonConvert.DeserializeObject(JsonConvert.SerializeObject(objDirectoryBL.Data));
                return objPostResponse;
            }
            objPostResponse.ErrorCode = 1;
            objPostResponse.data = JsonConvert.DeserializeObject(JsonConvert.SerializeObject(results.Errors));
            objPostResponse.ErrorMessage = Common.ErrorToString(results);
            return objPostResponse;
        }

        // DELETE api/Directory/5
        [Route("api/Directory/{Id}")]
        [HttpDelete]
        public bool Delete(int Id)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);

            DirectoryBL objDirectoryBL = new DirectoryBL(Common.GetConString());
            objDirectoryBL.Load(Id);

            Directory objDirectory = objDirectoryBL.Data;
            if (Common.ToInt(objDirectory.AddedBy) > 0 && objDirectory.AddedBy != objLoggedUser.UserID && objLoggedUser.UserType != 2)
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
            return objDirectoryBL.Delete(Id);
        }

        [Route("api/DirectoryDelete/{Id}")]
        [HttpPost]
        public bool DirectoryDelete(int Id)
        {
            return Delete(Id);
        }
    }
    public class DirectoryValidator : AbstractValidator<Directory>
    {
        public DirectoryValidator()
        {
            RuleFor(obj => obj.MobileNo).NotEmpty();
            RuleFor(obj => obj.Name).NotEmpty();
        }
    }
}

