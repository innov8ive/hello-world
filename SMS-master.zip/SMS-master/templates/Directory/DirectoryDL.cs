using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data;
using System.Data.Linq.Mapping;
using SampleAngularOM;

namespace SampleAngularDL
{
    public class DirectoryDL
    {

        #region Private Members
        private string connectionString;
        #endregion

        #region Constructor
        public DirectoryDL(string conString)
        {
            connectionString = conString;
        }
        #endregion

        #region Main Methods
        public Directory Load(int ID)
        {
            SqlConnection SqlCon = new SqlConnection(connectionString);
            Directory objDirectory = new Directory();
            var dc = new DataContext(SqlCon);
            try
            {
                //Get Directory
                var resultDirectory = dc.ExecuteQuery<Directory>("exec Get_Directory {0}", ID).ToList();
                if (resultDirectory.Count > 0)
                {
                    objDirectory = resultDirectory[0];
                }
                dc.Dispose();
                return objDirectory;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (SqlCon.State == ConnectionState.Open)
                {
                    SqlCon.Close();
                }
                SqlCon.Dispose();
            }
        }
        public DataTable LoadAllDirectory()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("exec Get_Directory", con);

            con.Open();
            dt.Load(cmd.ExecuteReader());
            con.Close();

            return dt;
        }
        public bool Update(Directory objDirectory)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //update Directory
                UpdateDirectory(objDirectory, trn);
                if (objDirectory.ID > 0)
                {

                    trn.Commit();
                }
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }
        public bool Delete(int ID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();
            try
            {
                //Delete Directory
                DeleteDirectory(ID, trn);
                trn.Commit();
                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                con.Dispose();
            }
        }

        public bool UpdateDirectory(Directory objDirectory, SqlTransaction trn)
        {
            SqlCommand cmd = new SqlCommand("Insert_Update_Directory", trn.Connection);
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Transaction = trn;


                cmd.Parameters.Add("@AddedBy", SqlDbType.Int).Value = objDirectory.AddedBy;
                cmd.Parameters.Add("@EmailID", SqlDbType.VarChar, 200).Value = objDirectory.EmailID;
                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = objDirectory.ID;
                cmd.Parameters["@ID"].Direction = ParameterDirection.InputOutput;
                cmd.Parameters.Add("@MobileNo", SqlDbType.VarChar, 10).Value = objDirectory.MobileNo;
                cmd.Parameters.Add("@Name", SqlDbType.VarChar, 100).Value = objDirectory.Name;
                cmd.Parameters.Add("@SocID", SqlDbType.Int).Value = objDirectory.SocID;
                cmd.Parameters.Add("@ServiceName", SqlDbType.VarChar, 100).Value = objDirectory.ServiceName;
                cmd.Parameters.Add("@Address", SqlDbType.VarChar, 500).Value = objDirectory.Address;

                cmd.ExecuteNonQuery();

                //after updating the Directory, update ID
                objDirectory.ID = Convert.ToInt32(cmd.Parameters["@ID"].Value);

                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }
        public bool DeleteDirectory(int ID, SqlTransaction trn)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("Delete from Directory where ID=@ID", trn.Connection);
                cmd.Transaction = trn;

                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = ID;

                cmd.ExecuteNonQuery();


                return true;
            }
            catch
            {
                trn.Rollback();
                return false;
            }
        }
        #endregion
    }
}
