﻿<%@ WebHandler Language="C#" CodeBehind="ShowImage.ashx.cs" Class="SampleAngular.ShowImage" %>
