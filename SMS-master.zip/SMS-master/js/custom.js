$(window).on('load',function(){
  $("#loading-loader").fadeOut();
})


$(document).ready( function() {

 $(function(){
  
  
  var $container = $('#container');
  
  $container.isotope({
    itemSelector: '.item-awesome-layout',
    masonry: {
      columnWidth: 60
    }
  })
  
  $('.item-awesome-layout').mouseover(function(){
    var $this = $(this),
        tileStyle = $this.hasClass('big-awesome') ? { width: 200, height: 200} : { width: 200, height: 200};
    $this.toggleClass('big-awesome');
    
    $this.find('.item-awesome-content').stop().animate( tileStyle );

    $container.isotope( 'reLayout' )
    
  });

});

});








$(document).ready(function  () {
  init();  

});


// isotope()

function init(){
  // peace();
  // loading ();
  // sequenceSlider();
  // swiper();
  // wow();
  // FlipClock();
  owlCarousel();

  nav();

  formvalidate();
  navbutton();
	


}






function staller() {
	$(window).stellar({
    responsive:true
  });
	// body...
}



function navbutton(){

	$('#nav-toggle').on('click', function(e){
		// alert(e)
		e.preventDefault();
		if($(this).hasClass('active')) {
			$(this).removeClass('active');
		} else {
			$(this).addClass('active');

		}
	});

}


function formvalidate(){
	$('#myForm').validator()
}







function nav(){
  $('#nav').onePageNav({
    currentClass: 'active',
    changeHash: false,
    scrollSpeed: 1500,
    scrollThreshold: 0.5,
    filter: '',
    // easing: 'swing',
    begin: function() {
        //I get fired when the animation is starting
    },
    end: function() {
        //I get fired when the animation is ending
    },
    scrollChange: function($currentListItem) {
        //I get fired when you enter a section and I pass the list item of the section
    }
});
}



function seqslider(){

	var sequenceElement = document.getElementById("slides");
	var options = {
	    autoPlayInterval: 200,
	    // Place your Sequence options here to override defaults
	    // See: http://sequencejs.com/documentation/#options
	    keyNavigation: true,
	    fadeStepWhenSkipped: false,
	    nextButton: false,
	    prevButton: false,
	    pagination: true,
	    animateStartingFrameIn: false,
	    autoPlay: true,
	    preloader: false,
  }


}

function stackslider () {
// $( '#st-stack' ).stackslider();
	// body...
}



function fitvid(){
    $("#thing-with-videos").fitVids();
}




// switcher
function switcher(){
  $('.sw-clr').click(function(){
    ths = $(this);
    fileName = 'css/' + ths.data('target') + '.css';
    // alert("hello");

    // alert(fileName)
    $('#styles').prop('href', fileName);
});
}


function mixitup () {
	$("#protfolio-box").mixItUp({
		animation: {
			duration: 580,
			effects: 'fade stagger(34ms) translateZ(560px)',
			easing: 'cubic-bezier(0.39, 0.575, 0.565, 1)'
		}
	});
}





//wow js function
function wow(){
	new WOW().init()
}






function owlCarousel(){
	$("#owltest1").owlCarousel({
		items: 1,
    itemsDesktop : [1199, 1],
    itemsDesktopSmall : [979, 1],
    itemsTablet : [768, 1],
    itemsMobile : [479, 1],


		autoPlay: false,
		responsive: true,
		responsiveRefreshRate:100,
		responsiveBaseWidth: document,
		autoHeight: false,
		pagination:false,
		navigation : true,

		navigationText : ['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],

	});
}

function owltest(){
	$("#owltest").owlCarousel({
		items: 1,
    itemsDesktop : [1199, 1],
    itemsDesktopSmall : [979, 1],
    itemsTablet : [768, 1],
    itemsMobile : [479, 1],


		autoPlay: false,
		responsive: true,
		responsiveRefreshRate:100,
		responsiveBaseWidth: document,
		autoHeight: false,
		pagination:false,
		navigation : true,

		navigationText : ['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],

	});
	$("#owltest3").owlCarousel({
		items: 1,
    itemsDesktop : [1199, 1],
    itemsDesktopSmall : [979, 1],
    itemsTablet : [768, 1],
    itemsMobile : [479, 1],


		autoPlay: false,
		responsive: true,
		responsiveRefreshRate:100,
		responsiveBaseWidth: document,
		autoHeight: false,
		pagination:false,
		navigation : true,

		navigationText : ['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],

	});
	$("#owl").owlCarousel({
		items: 4,
    itemsDesktopSmall : [979, 3],
    itemsTablet : [768, 2],
    itemsMobile : [479, 1],

		autoPlay: true,
		responsive: true,
		responsiveRefreshRate:100,
		responsiveBaseWidth: document,
		autoHeight: false,

	});






}



function wow(){
	new WOW().init();
}

// functions






// swiper function




$('car-slider').carousel();
$('a[data-slide="prev"]').click(function () {
    $('#car-slider').carousel('prev');
});

$('a[data-slide="next"]').click(function () {
    $('#car-slider').carousel('next');
});








// ********************************************
// 
// 
//  carouesl slider customuzation  
// 
// 
// ********************************************






$(document).ready( function () {
    $('#car-slider').owlCarousel({
        // Other options go here
        // ...,
        
        items: 1,

      itemsDesktop : [1199, 1],
      itemsDesktopSmall : [979, 1],
      itemsTablet : [768, 1],
      itemsMobile : [479, 1],
    navigationText : ['<i class="fa fa-angle-left" style="font-size:20px;line-height:45px"></i>','<i class="fa fa-angle-right" style="font-size:20px;line-height:45px"></i>'],
    autoPlay: true,
    responsive: true,
    responsiveRefreshRate:100,
    responsiveBaseWidth: window,
    autoHeight: false,
    pagination:true,
    navigation : true,
    slideSpeed: 600,
    // transitionStyle : true,
    transitionStyle : "fade",
    beforeInit: function(){
          var wow = new WOW(
        {
          boxClass:     'slider-wow',      // animated element css class (default is wow)
          animateClass: 'animated', // animation css class (default is animated)
          offset:       0,          // distance to the element when triggering the animation (default is 0)
          mobile:       true,       // trigger animations on mobile devices (default is true)
          live:         true,       // act on asynchronously loaded content (default is true)
          callback:     function(box) {
            // the callback is fired every time an animation is started
            // the argument that is passed in is the DOM node being animated
          },
          scrollContainer: null // optional scroll container selector, otherwise use window
        }
      );
      wow.init();

    },

        onInitialized: function() {
            if ($('#car-slider').children().length == 1) {
                 $('#car-slider').trigger('autoplay.stop.owl');
            }

       
        },

        addClassActive: true,
      afterMove: function(){
          var wow = new WOW(
        {
          boxClass:     'slider-wow',      // animated element css class (default is wow)
          animateClass: 'animated', // animation css class (default is animated)
          offset:       0,          // distance to the element when triggering the animation (default is 0)
          mobile:       true,       // trigger animations on mobile devices (default is true)
          live:         true,       // act on asynchronously loaded content (default is true)
          callback:     function(box) {
            // the callback is fired every time an animation is started
            // the argument that is passed in is the DOM node being animated
          },
          scrollContainer: null // optional scroll container selector, otherwise use window
        }
      );
      wow.init();
      }

    });
});








$(document).ready( function () {
    $('#charity-slider').owlCarousel({
        // Other options go here
        // ...,
        
        items: 1,

      itemsDesktop : [1199, 1],
      itemsDesktopSmall : [979, 1],
      itemsTablet : [768, 1],
      itemsMobile : [479, 1],
    navigationText : ['<i class="fa fa-angle-left" style="font-size:60px;line-height:45px"></i>','<i class="fa fa-angle-right" style="font-size:60px;line-height:45px"></i>'],
    autoPlay: true,
    responsive: true,
    responsiveRefreshRate:100,
    responsiveBaseWidth: window,
    autoHeight: false,
    pagination:true,
    navigation : true,

    slideSpeed: 600,
    // transitionStyle : true,
    transitionStyle : "fadeOut",
    beforeInit: function(){
          var wow = new WOW(
        {
          boxClass:     'slider-wow',      // animated element css class (default is wow)
          animateClass: 'animated', // animation css class (default is animated)
          offset:       0,          // distance to the element when triggering the animation (default is 0)
          mobile:       true,       // trigger animations on mobile devices (default is true)
          live:         true,       // act on asynchronously loaded content (default is true)
          callback:     function(box) {
            // the callback is fired every time an animation is started
            // the argument that is passed in is the DOM node being animated
          },
          scrollContainer: null // optional scroll container selector, otherwise use window
        }
      );
      wow.init();

    },

        onInitialized: function() {
            if ($('#charity-slider').children().length == 1) {
                 $('#charity-slider').trigger('autoplay.stop.owl');
            }

       
        },

        addClassActive: true,
      afterMove: function(){
          var wow = new WOW(
        {
          boxClass:     'slider-wow',      // animated element css class (default is wow)
          animateClass: 'animated', // animation css class (default is animated)
          offset:       0,          // distance to the element when triggering the animation (default is 0)
          mobile:       true,       // trigger animations on mobile devices (default is true)
          live:         true,       // act on asynchronously loaded content (default is true)
          callback:     function(box) {
            // the callback is fired every time an animation is started
            // the argument that is passed in is the DOM node being animated
          },
          scrollContainer: null // optional scroll container selector, otherwise use window
        }
      );
      wow.init();
      }

    });
});




$(document).ready( function () {
    $('#transport-slider').owlCarousel({
        // Other options go here
        // ...,
        
        items: 1,

      itemsDesktop : [1199, 1],
      itemsDesktopSmall : [979, 1],
      itemsTablet : [768, 1],
      itemsMobile : [479, 1],
    navigationText : ['<i class="fa fa-angle-left" style="font-size:60px;line-height:45px"></i>','<i class="fa fa-angle-right" style="font-size:60px;line-height:45px"></i>'],
    autoPlay: true,
    responsive: true,
    responsiveRefreshRate:100,
    responsiveBaseWidth: window,
    autoHeight: false,
    pagination:true,
    navigation : true,

    slideSpeed: 600,
    // transitionStyle : true,
    transitionStyle : "fadeOut",
    beforeInit: function(){
          var wow = new WOW(
        {
          boxClass:     'slider-wow',      // animated element css class (default is wow)
          animateClass: 'animated', // animation css class (default is animated)
          offset:       0,          // distance to the element when triggering the animation (default is 0)
          mobile:       true,       // trigger animations on mobile devices (default is true)
          live:         true,       // act on asynchronously loaded content (default is true)
          callback:     function(box) {
            // the callback is fired every time an animation is started
            // the argument that is passed in is the DOM node being animated
          },
          scrollContainer: null // optional scroll container selector, otherwise use window
        }
      );
      wow.init();

    },

        onInitialized: function() {
            if ($('#transport-slider').children().length == 1) {
                 $('#transport-slider').trigger('autoplay.stop.owl');
            }

       
        },

        addClassActive: true,
      afterMove: function(){
          var wow = new WOW(
        {
          boxClass:     'slider-wow',      // animated element css class (default is wow)
          animateClass: 'animated', // animation css class (default is animated)
          offset:       0,          // distance to the element when triggering the animation (default is 0)
          mobile:       true,       // trigger animations on mobile devices (default is true)
          live:         true,       // act on asynchronously loaded content (default is true)
          callback:     function(box) {
            // the callback is fired every time an animation is started
            // the argument that is passed in is the DOM node being animated
          },
          scrollContainer: null // optional scroll container selector, otherwise use window
        }
      );
      wow.init();
      }

    });
});








// ********************************************
// 
// 
//  carouesl slider customuzation  
// 
// 
// ********************************************





// function submenu(){

// $('[data-submenu]').submenupicker();



// }





$(document).ready(function  () {

  var a = audiojs;

    a.events.ready(function() {
        var a1 = a.createAll();
    });
    
  
});





function fullpage(){
    $('#fullpage').fullpage({
        //Navigation
        menu: '#menu',
        lockAnchors: true,
        anchors:['firstPage', 'secondPage'],
        navigation: true,
        navigationPosition: 'right',
        showActiveTooltip: false,
        slidesNavigation: true,
        slidesNavPosition: 'bottom',

        //Scrolling
        css3: true,
        scrollingSpeed: 1000,
        autoScrolling: true,
        fitToSection: true,
        fitToSectionDelay: 1000,
        scrollBar: true,
        easing: 'easeInOutCubic',
        easingcss3: 'ease',
        loopBottom: false,
        loopTop: true,
        loopHorizontal: true,
        continuousVertical: true,
        normalScrollElements: '#element1, .element2',
        scrollOverflow: false,
        touchSensitivity: 15,
        normalScrollElementTouchThreshold: 5,

        //Accessibility
        keyboardScrolling: true,
        animateAnchor: true,
        recordHistory: false,

        //Design
        controlArrows: true,
        verticalCentered: true,
        resize : false,
        sectionsColor : ['#ccc', '#fff'],
        paddingTop: '3em',
        paddingBottom: '10px',
        fixedElements: '#header, .footer',
        responsiveWidth: 0,
        responsiveHeight: 0,

        //Custom selectors
        sectionSelector: '.section',
        slideSelector: '.slide',

        //events
        onLeave: function(index, nextIndex, direction){},
        afterLoad: function(anchorLink, index){},
        afterRender: function(){},
        afterResize: function(){},
        afterSlideLoad: function(anchorLink, index, slideAnchor, slideIndex){},
        onSlideLeave: function(anchorLink, index, slideIndex, direction, nextSlideIndex){}
    });
}



// function mockups() {
//   // body...

//   $('.phonemockup').deviceMock({
//    type        : 'laptop',   // browser , phone , tablet , desktop , laptop
//    size        : '2x',        // null(1x) , 2x , 3x , 4x , 5x
//    theme       : 'black' ,    // black , white (if phone or tablet)
//    orientation : 'portrait' , // landscape , portrait (if phone or tablet)
//    // address     : '' // show on URL BAR,
//    imgPath     : 'frameworks/jquery.devicemock/img/',
// });
// }





$(document).ready(function(){
  $('#nav-icon1,#nav-icon2,#nav-icon3,#nav-icon4').click(function(){
    $(this).toggleClass('open');
  });
});


$(document).ready(function(){
  $('#nav-icon1-single-pager').click(function(){
    $(this).toggleClass('open');
  });
});

$(document).ready(function() {
  setInterval(function (){
    var width = $(document).width();
    if (width > 768) {
      $(".navbar li a").click(function (e) {
        // e.stopImmediatePropagation();
      });
    }
  },50);
});












// $(document).ready(function() {

// $(".click-toggle-nav").click(function(e) {
//         if($(window ).width() <= "900") {
//               $(this).find('.navbar-navbar').slideDown();
//               // $(this).find('.navbar-navbar').slideUp();
      
//         }
//     });
// });


function function_name(argument) {
  $('#tg-category-slider li a').on('click', function () {
        var svg1 = new Walkway({
            selector: '#ps1',
            duration: 3500
        }).draw();

        var svg2 = new Walkway({
            selector: '#ps2',
            duration: 3500
        }).draw();

        var svg3 = new Walkway({
            selector: '#ps3',
            duration: 3500
        }).draw();

        var svg4 = new Walkway({
            selector: '#ps4',
            duration: 3500
        }).draw();

        var svg5 = new Walkway({
            selector: '#ps5',
            duration: 3500
        }).draw();

        var svg6 = new Walkway({
            selector: '#ps6',
            duration: 3500
        }).draw();
    });
  // body...
}


function travel_icons() {

  $(window).on('load',function(){
  var svg1 = new Walkway({
            selector: '#ps1',
            duration: 4500
        }).draw();

        var svg2 = new Walkway({
            selector: '#ps2',
            duration: 3500
        }).draw();

        var svg3 = new Walkway({
            selector: '#ps3',
            duration: 3500
        }).draw();

        var svg4 = new Walkway({
            selector: '#ps4',
            duration: 3500
        }).draw();

        var svg5 = new Walkway({
            selector: '#ps5',
            duration: 3500
        }).draw();
})

  // body...
}