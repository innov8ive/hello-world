﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Default.aspx.cs" Inherits="SampleAngular.Default" %>

<!DOCTYPE html>
<html lang="en" ng-app="myApp" class="js">
<head>
    <link rel='shortcut icon' type='image/x-icon' href='/images/Inn.ico' />
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link href="Content/bootstrap.min.css" rel="stylesheet" />
    <link href="Content/ng-grid.min.css" rel="stylesheet" />
    <link href="Content/jquery.Jcrop.min.css" rel="scontenttylesheet" />
    <link href="Content/font-awesome.min.css" rel="stylesheet" />
    <link href="Content/themes/base/all.css" rel="stylesheet" />
    <link href="Content/AdminLTE.min.css" rel="stylesheet" />
    <link href="Content/all-skins.min.css" rel="stylesheet" />
    <link href="Content/select.min.css" rel="stylesheet" />
    <link href="Content/selectize.default.css" rel="stylesheet" />
    <link href="Content/index.css" rel="stylesheet" />
    <link href="Content/sweetalert.css" rel="stylesheet" />
    <link href="Content/bootstrap-treeview.min.css" rel="stylesheet" />
    <link href="Content/ngGallery.css" rel="stylesheet" />
    <script>
        var build = '<%=Application["builddate"] %>';
    </script>
    <script src="Scripts/jquery-1.9.1.min.js"></script>
    <script src="Scripts/jquery-ui-1.11.4.min.js"></script>
    <script src="Scripts/bootstrap.min.js"></script>
    <script src="Scripts/adminlte.min.js"></script>
    <script src="Scripts/jquery.slimscroll.min.js"></script>
    <script src="Scripts/jquery.Jcrop.min.js"></script>
    <script src="Scripts/sweetalert.min.js"></script>

    <script src="Scripts/dropzone.js"></script>
    <script src="Scripts/jquery.csv.min.js"></script>
    <script src="Scripts/bootstrap-treeview.min.js"></script>
    <script src="Scripts/Chart.min.js"></script>
    <script src="Scripts/jquery.timeago.js"></script>

    <script src="Scripts/angular.min.js"></script>
    <script src="Scripts/angular-sanitize.min.js"></script>
    <script src="Scripts/ng-grid.min.js"></script>
    <script src="Scripts/angular-route.min.js"></script>
    <script src="Scripts/angular-timeago.js"></script>
    <script src="Scripts/checklist-model.js"></script>
    <script src="Scripts/select.min.js"></script>
    <script src="Scripts/ngGallery.js"></script>

    <script src="Scripts/jquery.signalR-2.2.2.min.js"></script>
    <script src="signalr/hubs"></script>

    <script src="Scripts/app.site.js?buid=<%=Application["builddate"] %>"></script>
    <script src="Scripts/common.js?buid=<%=Application["builddate"] %>"></script>

    <script src="templates/Users/UsersController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/Soc/SocController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/Rooms/RoomsController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/Forums/ForumsController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/Carousel/CarouselController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/MailSettings/MailSettingsController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/Language/LanguageController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/GL/GLController.js?buid=<%=Application["builddate"] %>"></script>

    <script src="templates/ACReport/ACReportController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/Services/ServicesController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/NB/NBController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/PL/PLController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/Bills/BillsController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/DashBoard/AdminHomeController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/Folder/FolderController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/CM/CMController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/AL/ALController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/CP/CPController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/Chg/ChgController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/BSU/BSUController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/BSU/RMBSUController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/Schedule/ScheduleController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/Schedule/AccountsController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/VT/VoucherTypeController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/VE/VEController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/Wings/WingsController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/Msg/MsgController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/VM/VMController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/FC/FCController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/BS/BookingsController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/Rules/RulesController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/GK/GKController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/WP/WPController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/Penalty/PenaltyController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/MT/MTController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/Directory/DirectoryController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/FM/FMController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/Payments/PaymentsController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/SMSCredit/SMSCreditController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/PaymentReq/PaymentReqController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/Chat/ChatController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/Vendors/VendorsController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/Exp/ExpController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/Income/IncomeController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/Contra/ContraController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/Roles/RolesController.js?buid=<%=Application["builddate"] %>"></script>
    <script src="templates/PayTM/PayTMController.js?buid=<%=Application["builddate"] %>"></script>


    <!-- Put your controllers here -->
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style type="text/css">
        .pageContent
        {
            position: relative;
        }

        .content
        {
            padding: 0px;
        }

        .pageContentAction
        {
            position: absolute;
            bottom: 0px;
            right: 0px;
            display: none;
        }

        .pageContent:hover
        {
            border: solid 1px silver;
        }

            .pageContent:hover .pageContentAction
            {
                background-color: white;
                border: 1px solid gray;
                display: block !important;
                padding: 10px;
            }

        .skin-blue .main-header .logo
        {
            background-color: white;
        }

        .timeago
        {
            color: gray;
            font-size: 11px;
            font-style: italic;
        }
    </style>

    <style type="text/css">
        #ulUsers .list-group-item
        {
            cursor: pointer;
        }

        #chatBody li.list-group-item
        {
            border: medium none;
            background-color: #E6E6E6;
            margin: 7px;
            margin-right: 50px;
            border-radius: 0 5px 5px 15px;
        }

        #chatBody li.text-right
        {
            background-color: lightblue;
            margin-left: 50px;
            margin-right: 7px;
            border-radius: 5px 0 15px 5px;
            text-align: left !important;
        }

        .list-group-item.text-center
        {
            background-color: lightgray !important;
            border-radius: 0 !important;
            cursor: pointer;
            margin-left: 150px !important;
            margin-right: 150px !important;
        }

        time
        {
            font-size: 12px;
            color: gray;
            font-style: italic;
            margin: 0px;
        }

            time:before
            {
                content: '\A';
                white-space: pre;
            }

        .emoticon
        {
            font-size: 50px;
        }

        .emoticon-small
        {
            font-size: 25px;
        }

        .emot:hover
        {
            border: solid 1px gray;
            border-radius: 30%;
        }

        .fa
        {
            cursor: pointer;
        }

        .fa-check
        {
            margin-left: 10px;
        }

        .read
        {
            color: green;
        }

        .list-group-item img.profile
        {
            border: 1px solid silver;
            border-radius: 50%;
            height: 40px;
            left: -50px;
            position: absolute;
            top: 0;
        }

        table.pCheck
        {
            width: 100%;
        }

        .user-group
        {
            color: brown;
            font-weight: bold;
        }
    </style>
</head>
<body class="hold-transition skin-purple sidebar-mini">
    <form id="form1" runat="server"></form>
    <div class="wrapper">
        <div ng-controller="MenuController">
            <header class="main-header" ng-show="User.UserID > 0">
                <a href="#/adminHome" class="logo" style="background-color: white;">
                    <!-- mini logo for sidebar mini 50x50 pixels -->
                    <span class="logo-mini"><b>Society</b>Inn</span>
                    <!-- logo for regular state and mobile devices -->
                    <span class="logo-lg">
                        <img src="images/logo.png" height="40" />
                    </span>
                </a>
                <!-- Header Navbar -->
                <nav class="navbar navbar-static-top" role="navigation">
                    <!-- Sidebar toggle button-->
                    <a class="sidebar-toggle" data-toggle="push-menu" role="button" onclick="sizeChanged()">
                        <span class="sr-only">Toggle navigation</span>
                    </a>
                    <span class="pull-left" style="font-size: 12px; color: white; line-height: 50px;">{{User.SocName}}
                        <span ng-show="User.SocList.length>1" style="cursor: pointer; color: orange; font-size: 12px;" ng-click="showSocChange();">Change</span>
                        <span ng-show="User.RMList.length>0" style="cursor: pointer; color: orange; font-size: 12px;" ng-click="switchToRMView();">Unit View</span>
                        <span ng-show="User.ForcedRMLogin==true" style="cursor: pointer; color: orange; font-size: 12px;" ng-click="switchToAdminView();">Admin View</span>
                    </span>

                    <div class="navbar-custom-menu">

                        <ul class="nav navbar-nav">
                            <li class="dropdown notifications-menu" id="alertLI">
                                <a class="dropdown-toggle" data-toggle="dropdown" ng-click="markReadAlert()">
                                    <i class="fa fa-bell-o"></i>
                                    <span class="label label-warning">{{Total}}</span>
                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <!-- inner menu: contains the actual data -->
                                        <ul class="menu">
                                            <li ng-repeat="itm in AlertList">
                                                <a>{{itm.Msg}}
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                            <li class="dropdown user user-menu">
                                <!-- Menu Toggle Button -->
                                <a class="dropdown-toggle" data-toggle="dropdown">
                                    <!-- The user image in the navbar-->
                                    <img src="Download.aspx?filepath=images/profile/{{User.ImageUrl}}&type=profile" class="user-image" alt="User Image">
                                    <!-- hidden-xs hides the username on small devices so only the image appears. -->
                                    <span class="hidden-xs">{{User.FirstName+' '+User.LastName}}</span>
                                </a>
                                <ul class="dropdown-menu">
                                    <!-- The user image in the menu -->
                                    <li class="user-header">
                                        <img src="Download.aspx?filepath=images/profile/{{User.ImageUrl}}&type=profile" height="160" width="160" class="img-circle" alt="User Image">
                                        <p>
                                            {{User.FirstName+' '+User.LastName}}
                                            <small>
                                                <span style="font-size: 14px; color: orange; float: left; position: relative; top: 14px;">{{User.WPName}}
  <span style="color: white; cursor: pointer" ng-click="showWPChange();">Change</span>
                                                </span>
                                            </small>
                                        </p>
                                    </li>
                                    <li class="user-body">
                                        <div class="row">
                                            <div class="col-xs-12 text-center">
                                                <a href="#/changepassword">Change Password</a>
                                            </div>
                                        </div>
                                        <!-- /.row -->
                                    </li>
                                    <!-- Menu Footer-->
                                    <li class="user-footer">
                                        <div class="pull-left">
                                            <a href="#/Profile" class="btn btn-default btn-flat">Profile</a>
                                        </div>
                                        <div class="pull-right">
                                            <a href="#/logout" class="btn btn-default btn-flat">Sign out</a>
                                        </div>
                                    </li>
                                </ul>
                            </li>
                            <li ng-hide="User.UserID > 0">
                                <a href="#/login"><i class="fa fa-user"></i></a>
                            </li>
                        </ul>
                    </div>
                </nav>
            </header>
            <!-- Left side column. contains the logo and sidebar -->
            <aside class="main-sidebar" ng-show="User.UserID > 0">
                <section class="sidebar">
                    <ul class="sidebar-menu tree" data-widget="tree">
                        <li ng-repeat="menuItem in User.MenuItems" ng-include="'templates/menu-item.html'"
                            ng-class="menuItem.Children!=null && menuItem.Children.length>0?'treeview': ''"></li>
                    </ul>
                </section>
                <!-- /.sidebar -->
            </aside>

            <modal title="'Change Financial Year'" visible="showModal">
            <div class="form-group">
                <div class="col-md-12">
                     <ui-select name="yearTextBox" ng-model="WP.WPID" theme="selectize" required>
                                <ui-select-match placeholder="Select or search in the list...">{{$select.selected.Value}}</ui-select-match>
                                <ui-select-choices repeat="itm.Key as itm in yearlist | filter: $select.search">
                                    <span ng-bind-html="itm.Value | highlight: $select.search"></span>
                                </ui-select-choices>
                            </ui-select>
                                    
                </div>
            </div>
            <div class="modal-footer">               
                <button class="btn btn-primary" type="button" ng-click="changeWP()">Change</button>
            </div>
        </modal>

            <modal title="'Change Society'" visible="showModalSoc">
            <div class="form-group">
                <div class="col-md-12">
                     <ui-select name="socTextBox" ng-model="WP.SocID" theme="selectize" required>
                                <ui-select-match placeholder="Select or search in the list...">{{$select.selected.Value}}</ui-select-match>
                                <ui-select-choices repeat="itm.Key as itm in soclist | filter: $select.search">
                                    <span ng-bind-html="itm.Value | highlight: $select.search"></span>
                                </ui-select-choices>
                            </ui-select>
                                    
                </div>
            </div>
            <div class="modal-footer">               
                <button class="btn btn-primary" type="button" ng-click="changeSoc()">Change</button>
            </div>
        </modal>
        </div>
        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <div ng-view></div>
            <div style="padding: 0px 10px; bottom: 0px; position: fixed; right: 0px; background-color: white;">
                Copyright &copy; 2016-2017 <a target="_blank" href="https://societyinn.com">SocietyInn.com</a>. All rights reserved.
            </div>
        </div>

        <div class="modal fade" id="modalDropFile" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title">Drag and Drop Files</h4>
                    </div>
                    <div class="modal-body">
                        <div class="row" style="padding: 20px;">
                            <div class="col-md-12">
                                <div id="divDropFiles" style="height: 300px; text-align: center; vertical-align: middle; border: medium dashed;">
                                    Drop files here or click to upload.
                                </div>
                                <h3 id="fileUploadedMessage"></h3>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">
                            <span aria-hidden="true" class="fa fa-close"></span>&nbsp;Close
                        </button>
                    </div>
                </div>
            </div>
        </div>

       
    </div>

    <script type="text/javascript">
        $(document).ready(function () {
            var groupHub = $.connection.chatHub;
            groupHub.client.notify = function (groupName) {
                if (window.location.toString().indexOf('ChatList') == -1) {
                    addChatBadge();
                }
                else {
                    angular.element('#divChatList').scope().othersMessageRecieved(groupName);
                    angular.element('#divChatList').scope().$apply()
                }
            };
            groupHub.client.notifyUserComesOnline = function (userID, userName) {
                $("#notification").fadeIn("slow").find('.notification-text').html(userName + ' is online');
                $(".dismiss").on('click', function () {
                    $("#notification").fadeOut("slow");
                });
                if (angular.element('#divChatList').scope() != null) {
                    angular.element('#divChatList').scope().othersComesOnline(userID);
                    angular.element('#divChatList').scope().$apply();
                }
            };
            groupHub.client.notifyUserGoesOffline = function (userID) {
                if (angular.element('#divChatList').scope() != null) {
                    angular.element('#divChatList').scope().othersGoesOffline(userID);
                    angular.element('#divChatList').scope().$apply();
                }
            };

            groupHub.client.messageSent = function (Msg, fromUser, toUser, uniqueID, groupName, sentBy) {

                var $scope = angular.element('#divChatList').scope();
                $scope.messageSent(Msg, fromUser, toUser, uniqueID, groupName, sentBy);
                $scope.$apply();
            };

            groupHub.client.messageDeleted = function (uniqueID, fromUser, toUser) {
                $("[UniqueID='" + uniqueID + "']").html('<span class="remarkLog">This message has been removed.</span>');
            };
            groupHub.client.messageRead = function (fromUserID, toUserID) {
                if (User.UserID == toUserID && ToUserID == fromUserID)
                    $('.fa-check').addClass('read');
            };
            groupHub.client.messageOpened = function (fromUserID, toUserID) {
                if (User.UserID == fromUserID && ToUserID == toUserID)
                    $('.fa-check').addClass('read');
            };

            var url = '<%=ResolveUrl("~/")%>';
            //$.ajax({
            //    type: "POST",
            //    url: url + "api/Chat/HasUnReadChat",
            //    contentType: "application/json; charset=utf-8",
            //    dataType: "json",
            //    success: function (result) {
            //        if (result > 0)
            //            addChatBadge();
            //    }
            //});

        });

        function addChatBadge() {

            $("#liChat").find('a').find('.delete-me').remove();
            $("#liChat").find('a').append('<span class="label pull-right delete-me"><i class="fa fa-circle" style="color:green;"></i></span>');
        }
    </script>
</body>
</html>
