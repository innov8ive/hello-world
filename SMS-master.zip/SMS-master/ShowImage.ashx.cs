﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;

namespace SampleAngular
{
    /// <summary>
    /// Summary description for ShowImage
    /// </summary>
    public class ShowImage : IHttpHandler
    {
        int thumbWidth, thumbHeight; String _path;
        public void ProcessRequest(HttpContext context)
        {
            // by default
            if (context.Request["Width"] != null)
                thumbWidth = Int32.Parse(context.Request["Width"]);
            else
            {
                thumbWidth = 50;
            }
            if (context.Request["Height"] != null)
                thumbHeight = Int32.Parse(context.Request["Height"]);
            else
            {
                thumbHeight = 40;
            }
            // get path of 'no thumbnail' image
            const String NoThumbFile = "images/profile/profile.png";
            String sNoThumbPath = context.Request.MapPath(context.Request.ApplicationPath.TrimEnd('/') + "/" + NoThumbFile);
            // map requested path
            if (context.Request["ImageName"] != null)
            {
                if (context.Request["ImageName"].Contains("."))
                    _path = context.Request.MapPath("~/images/profile/" + context.Request["ImageName"]);
                else
                    _path = context.Request.MapPath("~/images/profile/" + context.Request["ImageName"] + ".png");
            }
            else
                _path = sNoThumbPath;
            //====================================== 
            System.Drawing.Image image;
            try
            {
                image = System.Drawing.Image.FromFile(_path);
            }
            catch
            {
                image = System.Drawing.Image.FromFile(sNoThumbPath);
            }
            int srcWidth = image.Width;
            int srcHeight = image.Height;
            System.Drawing.Bitmap bitmap = new System.Drawing.Bitmap(thumbWidth, (int)thumbHeight);
            //- Create a System.Drawing.Graphics object from the Bitmap which we will use to draw the high quality scaled image
            System.Drawing.Graphics gr = System.Drawing.Graphics.FromImage(bitmap);
            using (gr)
            {
                //- Set the System.Drawing.Graphics object property SmoothingMode to HighQuality
                gr.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
                //- Set the System.Drawing.Graphics object property CompositingQuality to HighQuality
                gr.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighQuality;
                //- Set the System.Drawing.Graphics object property InterpolationMode to High
                gr.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.High;
                //- Draw the original image into the target Graphics object scaling to the desired width and height
                System.Drawing.Rectangle rectDestination = new System.Drawing.Rectangle(0, 0, thumbWidth, (int)thumbHeight);
                //Set Image codec of JPEG type, the index of JPEG codec is "1"
                System.Drawing.Imaging.ImageCodecInfo codec = System.Drawing.Imaging.ImageCodecInfo.GetImageEncoders()[1];
                //Set the parameters for defining the quality of the thumbnail... here it is set to 100%
                System.Drawing.Imaging.EncoderParameters eParams = new System.Drawing.Imaging.EncoderParameters(1);
                eParams.Param[0] = new System.Drawing.Imaging.EncoderParameter(System.Drawing.Imaging.Encoder.Quality, 100L);
                gr.DrawImage(image, rectDestination, 0, 0, srcWidth, srcHeight, System.Drawing.GraphicsUnit.Pixel);
                gr.Dispose();
                context.Response.ContentType = MimeTypeHelper.GetMimeType(_path);
                bitmap.Save(context.Response.OutputStream, System.Drawing.Imaging.ImageFormat.Png);
                bitmap.Dispose();
            }
        }
        public static byte[] ImageToByte(Image img)
        {
            ImageConverter converter = new ImageConverter();
            return (byte[])converter.ConvertTo(img, typeof(byte[]));
        }
        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}