﻿using SampleAngularBL;
using SampleAngularOM;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
////using BitlyDotNET.Implementations;
////using BitlyDotNET.Interfaces;
using System.Web.Configuration;
using System.Drawing.Imaging;
using System.Drawing;
using System.Web.SessionState;

namespace SampleAngular
{
    /// <summary>
    /// Summary description for FileUploadHandler
    /// </summary>
    public class FileUploadHandler : IHttpHandler, IReadOnlySessionState
    {

        public void ProcessRequest(HttpContext context)
        {
            try
            {

                context.Response.AddHeader("Access-Control-Allow-Origin", "*");
                context.Response.AddHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
                context.Response.AddHeader("Access-Control-Allow-Headers", "Content-Type, Accept");

                if (context.Request["type"] == "RawImageFile")
                {
                    string data = Common.ToString(context.Request["data"]);
                    int width = Common.ToInt(context.Request["width"]);
                    byte[] bytes = Convert.FromBase64String(data);
                    Bitmap bitmap;
                    using (var ms = new MemoryStream(bytes))
                    {
                        bitmap = new Bitmap(ms);
                    }
                    ImageCompress imgCompress = new ImageCompress();
                    setRepectiveHeight(imgCompress, bitmap, width);
                    string fileGUIDName = Guid.NewGuid().ToString() + ".png";
                    imgCompress.Save(fileGUIDName, context.Server.MapPath("~/"));

                    bytes = File.ReadAllBytes(context.Server.MapPath("~/") + fileGUIDName);
                    string base64String = Convert.ToBase64String(bytes);
                    File.Delete(context.Server.MapPath("~/") + fileGUIDName);

                    context.Response.Write("data:" + Common.ToString(context.Request["contentType"]) + ";base64," + base64String);
                }
                else if (context.Request["type"] == "ImageFile")
                {
                    string[] data = Common.ToString(context.Request["data"]).Split(',');
                    string imageData = data.Length > 1 ? data[1] : data[0];
                    byte[] bytes = Convert.FromBase64String(imageData);
                    string fileGUIDName = Guid.NewGuid().ToString() + ".png";
                    string fileReadableName = DateTime.UtcNow.ToString("dd-MMM-yyyy-HH-mm-ss");
                    string fname = context.Server.MapPath("~/images/profile/" + fileGUIDName);

                    //Save the file in file system
                    File.WriteAllBytes(fname, bytes);

                    //Attach Image
                    int DataID = Common.ToInt(context.Request["DataID"]);
                    string DataType = Common.ToString(context.Request["DataType"]);
                    if (DataID > 0 && DataType.Length > 0)
                    {
                        if (DataType == "User")
                            Common.ExecuteNonQuery("Update Users set ImageUrl='" + fileGUIDName + "' where UserID=" + DataID);
                        else if (DataType == "FM")
                            Common.ExecuteNonQuery("Update FM set ImageUrl='" + fileGUIDName + "' where FMID=" + DataID);
                    }

                    context.Response.Write(fileGUIDName + "|" + fileReadableName + "|001");
                }
                else if (context.Request.Files.Count > 0)
                {
                    context.Response.ContentType = "text/plain";
                    try
                    {
                        LoggedUser objLoggedUser = HttpContext.Current.Session["LoggedUser"] as LoggedUser;
                        HttpFileCollection files = context.Request.Files;
                        HttpPostedFile file = files[0];
                        string extension = Path.GetExtension(file.FileName).ToLower();
                        string[] allowedExt;
                        if (context.Request.QueryString["ALID"] != null)
                        {
                            allowedExt = ".png,.jpg,.jpeg,.gif,.bmp".Split(',');
                        }
                        else
                        {
                            allowedExt = ".doc,.docx,.pdf,.xls,.xlsx,.png,.jpg,.jpeg,.gif,.bmp,.ttf,.ppt,.pptx,.txt,.eml,.emlx,.msg,.vdsx,.vsd".Split(',');
                        }
                        if (!allowedExt.Contains(extension))
                        {
                            context.Response.Write("Invalid extension");
                            return;
                        }

                        string newFileName = Guid.NewGuid().ToString() + extension;
                        string fname = context.Server.MapPath("~/AttachedFiles/" + newFileName);

                        //Save the file in file system
                        file.SaveAs(fname);
                        string fileName = GetFileName(file);
                        int fileID = 0;
                        if (context.Request.QueryString["FolderID"] != null)
                        {

                            int? folderID = Common.ToInt(context.Request.QueryString["FolderID"], null);

                            if (folderID <= 0) folderID = null;

                            //save the file reference in database
                            FilesBL objFilesBL = new FilesBL(Common.GetConString());
                            Files objFiles = new Files();
                            objFiles.FileGUID = newFileName;
                            objFiles.FileName = fileName;
                            objFiles.FolderID = folderID;
                            objFiles.SocID = objLoggedUser.SocID;
                            objFilesBL.Data = objFiles;
                            objFilesBL.Update();
                            fileID = Common.ToInt(objFiles.FileID);
                        }
                        else if (context.Request.QueryString["ALID"] != null)
                        {
                            ImgBL objImgBL = new ImgBL(Common.GetConString());
                            Img objImg = new Img();
                            objImg.ALID = Common.ToInt(context.Request.QueryString["ALID"]);
                            objImg.ImgID = 0;
                            objImg.SocID = objLoggedUser.SocID;
                            objImg.ImageUrl = newFileName;
                            objImgBL.Data = objImg;
                            objImgBL.Update();
                            fileID = Common.ToInt(objImg.ImgID);
                        }
                        else if (context.Request.QueryString["MTID"] != null)
                        {
                            //save the file reference in database
                            FilesBL objFilesBL = new FilesBL(Common.GetConString());
                            Files objFiles = new Files();
                            objFiles.FileGUID = newFileName;
                            objFiles.FileName = fileName;
                            objFiles.SocID = objLoggedUser.SocID;
                            objFilesBL.Data = objFiles;
                            objFilesBL.Update();
                            fileID = Common.ToInt(objFiles.FileID);

                            string SiteUrl = WebConfigurationManager.AppSettings["SiteUrl"];
                            string fileUrl = SiteUrl + "/Download.aspx?fileID=" + newFileName;
                            Common.ExecuteNonQuery("Update MT set MOMFileID=" + fileID + " where MTID=" + Common.ToInt(context.Request.QueryString["MTID"]));

                            ////IBitlyService s = new BitlyService("sanjayg311", "R_11431f9fd84c4dcfb8dcace137858ffa");
                            ////string shortened;
                            ////if (s.Shorten(fileUrl, out shortened) == StatusCode.OK)
                            ////{
                            ////    Common.ExecuteNonQuery("Update MT set MOMFileUrl='" + shortened + "' where MTID=" + Common.ToInt(context.Request.QueryString["MTID"]));
                            ////}
                        }

                        context.Response.Write(newFileName + "|" + fileName + "|" + fileID);
                    }
                    catch (Exception Ex)
                    {
                        context.Response.Write(Ex.Message);
                    }
                }
            }
            catch (Exception Ex)
            {
                context.Response.Write(Ex.Message);
            }
        }
        private string GetFileName(HttpPostedFile postedFile)
        {
            string filename = postedFile.FileName;
            if (filename.IndexOf('\\') > -1)
            {
                filename = filename.Substring(filename.LastIndexOf('\\') + 1);
            }
            else if (filename.IndexOf('/') > -1)
            {
                filename = filename.Substring(filename.LastIndexOf('/') + 1);
            }
            return filename;
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
        private void setRepectiveHeight(ImageCompress imgCompress, Bitmap ImageBMP, int ThumbnailWidth)
        {
            decimal iwidth_Opt = ImageBMP.Width;
            decimal iheight_Opt = ImageBMP.Height;
            decimal lengthRatio = iheight_Opt / iwidth_Opt;
            int ThumbnailNewWidth = 0;
            int ThumbnailNewHeight = 0;
            if (ThumbnailWidth > 0)
            {
                ThumbnailNewWidth = ThumbnailWidth;
                decimal lengthTemp = ThumbnailNewWidth * lengthRatio;
                ThumbnailNewHeight = (int)lengthTemp;
            }
            else
            {
                ThumbnailNewWidth = ImageBMP.Width;
                ThumbnailNewHeight = ImageBMP.Height;
            }
            imgCompress.GetImage = ImageBMP;
            imgCompress.Width = ThumbnailNewWidth;
            imgCompress.Height = ThumbnailNewHeight;
        }
        private Bitmap CreateThumbnail(Bitmap ImageBMP, int ThumbnailWidth, int ThumbnailHeight)
        {
            System.Drawing.Bitmap Thumbnail = null;
            try
            {
                decimal iwidth_Opt = ImageBMP.Width;
                decimal iheight_Opt = ImageBMP.Height;
                decimal lengthRatio = iheight_Opt / iwidth_Opt;
                ImageFormat loFormat = ImageBMP.RawFormat;

                int ThumbnailNewWidth = 0;
                int ThumbnailNewHeight = 0;

                // If the uploaded image is smaller than a thumbnail size the just return it
                if (ImageBMP.Width <= ThumbnailWidth && ImageBMP.Height <= ThumbnailHeight)
                    return ImageBMP;

                if (ThumbnailWidth > 0)
                {
                    ThumbnailNewWidth = ThumbnailWidth;
                    decimal lengthTemp = ThumbnailNewWidth * lengthRatio;
                    ThumbnailNewHeight = (int)lengthTemp;
                }
                else
                {
                    ThumbnailNewWidth = ImageBMP.Width;
                    ThumbnailNewHeight = ImageBMP.Height;
                }

                Thumbnail = new Bitmap(ThumbnailNewWidth, ThumbnailNewHeight);
                Graphics g = Graphics.FromImage(Thumbnail);
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                g.FillRectangle(Brushes.White, 0, 0, ThumbnailNewWidth, ThumbnailNewHeight);
                g.DrawImage(ImageBMP, 0, 0, ThumbnailNewWidth, ThumbnailNewHeight);

                ImageBMP.Dispose();
            }
            catch
            {
                return null;
            }

            return Thumbnail;
        }
    }

    public class ImageCompress
    {
        #region[PrivateData]
        private static volatile ImageCompress imageCompress;
        private Bitmap bitmap;
        private int width;
        private int height;
        private System.Drawing.Image img;
        #endregion[Privatedata]

        #region[Constructor]
        /// <summary>
        /// It is used to restrict to create the instance of the      ImageCompress
        /// </summary>
        public ImageCompress()
        {
        }
        #endregion[Constructor]

        #region[Poperties]
        /// <summary>
        /// Gets ImageCompress object
        /// </summary>
        public ImageCompress GetImageCompressObject
        {
            get
            {
                if (imageCompress == null)
                {
                    imageCompress = new ImageCompress();
                }
                return imageCompress;
            }
        }

        /// <summary>
        /// Gets or sets Width
        /// </summary>
        public int Height
        {
            get { return height; }
            set { height = value; }
        }

        /// <summary>
        /// Gets or sets Width
        /// </summary>
        public int Width
        {
            get { return width; }
            set { width = value; }
        }

        /// <summary>
        /// Gets or sets Image
        /// </summary>
        public Bitmap GetImage
        {
            get { return bitmap; }
            set { bitmap = value; }
        }
        #endregion[Poperties]

        #region[PublicFunction]
        /// <summary>
        /// This function is used to save the image
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="path"></param>
        public void Save(string fileName, string path)
        {
            if (ISValidFileType(fileName))
            {
                string pathaname = path + @"\" + fileName;
                save(pathaname, 60);
            }
        }
        public void Save(MemoryStream stream)
        {
            save(stream, 60);
        }
        #endregion[PublicFunction]

        #region[PrivateData]
        /// <summary>
        /// This function is use to compress the image to
        /// predefine size
        /// </summary>
        /// <returns>return bitmap in compress size</returns>
        private System.Drawing.Image CompressImage()
        {
            if (GetImage != null)
            {
                Width = (Width == 0) ? GetImage.Width : Width;
                Height = (Height == 0) ? GetImage.Height : Height;
                Bitmap newBitmap = new Bitmap(Width, Height, PixelFormat.Format24bppRgb);
                newBitmap = bitmap;
                newBitmap.SetResolution(80, 80);
                return newBitmap.GetThumbnailImage(Width, Height, null, IntPtr.Zero);
            }
            else
            {
                throw new Exception("Please provide bitmap");
            }
        }

        /// <summary>
        /// This function is used to check the file Type
        /// </summary>
        /// <param name="fileName">String data type:contain the file name</param>
        /// <returns>true or false on the file extention</returns>
        private bool ISValidFileType(string fileName)
        {
            bool isValidExt = false;
            string fileExt = Path.GetExtension(fileName);
            switch (fileExt.ToLower())
            {
                case CommonConstant.JPEG:
                case CommonConstant.BTM:
                case CommonConstant.JPG:
                case CommonConstant.PNG:
                    isValidExt = true;
                    break;
            }
            return isValidExt;
        }

        /// <summary>
        /// This function is used to get the imageCode info
        /// on the basis of mimeType
        /// </summary>
        /// <param name="mimeType">string data type</param>
        /// <returns>ImageCodecInfo data type</returns>
        private ImageCodecInfo GetImageCoeInfo(string mimeType)
        {
            ImageCodecInfo[] codes = ImageCodecInfo.GetImageEncoders();
            for (int i = 0; i < codes.Length; i++)
            {
                if (codes[i].MimeType == mimeType)
                {
                    return codes[i];
                }
            }
            return null;
        }

        /// <summary>
        /// this function is used to save the image into a
        /// given path
        /// </summary>
        /// <param name="path">string data type</param>
        /// <param name="quality">int data type</param>
        private void save(string path, int quality)
        {
            img = CompressImage();
            ////Setting the quality of the picture
            EncoderParameter qualityParam =
                new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, quality);
            ////Seting the format to save
            ImageCodecInfo imageCodec = GetImageCoeInfo("image/jpeg");
            ////Used to contain the poarameters of the quality
            EncoderParameters parameters = new EncoderParameters(1);
            parameters.Param[0] = qualityParam;
            ////Used to save the image to a  given path
            img.Save(path, imageCodec, parameters);
        }
        private void save(MemoryStream stream, int quality)
        {
            img = CompressImage();
            ////Setting the quality of the picture
            EncoderParameter qualityParam =
                new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, quality);
            ////Seting the format to save
            ImageCodecInfo imageCodec = GetImageCoeInfo("image/jpeg");
            ////Used to contain the poarameters of the quality
            EncoderParameters parameters = new EncoderParameters(1);
            parameters.Param[0] = qualityParam;
            ////Used to save the image to a  given path
            img.Save(stream, imageCodec, parameters);
        }
        #endregion[PrivateData]
    }
    public class CommonConstant
    {
        public const string JPEG = ".jpeg";
        public const string PNG = ".png";
        public const string JPG = ".jpg";
        public const string BTM = ".btm";
    }
}