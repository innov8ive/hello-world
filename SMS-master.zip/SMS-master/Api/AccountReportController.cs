﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Text;
using System.Net.Http.Formatting;

namespace SampleAngular.Api
{
    public class AccountReportController : ApiController
    {
        [Route("api/AccountReport/DownloadPaymentFormat/")]
        [HttpGet]
        public HttpResponseMessage DownloadPaymentFormat()
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser == null) return null;

            HttpResponseMessage response = new HttpResponseMessage();
            DataTable dt = Common.GetDBResultParameterized(@"select B.BillID,
W.WingName+' '+R.RoomNo as RoomNo
,ISNULL(B.TotalBillAmount,0) as Outstanding,
0 as Amount,null as PaymentDate,'Cash' as PaymentMode,'' as PaymentRefNo,
'' as PaymentRefDate
 from Bills B
inner join Rooms R ON B.RoomID=R.RoomID
inner join Wings W ON W.WingID=R.WingID
where B.SocID=@SocID and PaidDate IS NULL
and B.IsNewBill=1", "@SocID", SqlDbType.Int, objLoggedUser.SocID);
            return ExportDataTable(dt);
        }
        [Route("api/AccountReport/DownloadMemberFormat/")]
        [HttpGet]
        public HttpResponseMessage DownloadMemberFormat()
        {
            HttpResponseMessage response = new HttpResponseMessage();

            StringBuilder sb = new StringBuilder();
            string columns = "BlockWing,UnitNo,FloorNo,Area,UnitType,NoOfBeds,NoOfBalconies,Intercom,EmailID,MobileNo,FirstName,LastName,MemberType,OpeningBalance,OpeningBalanceInterest";
            foreach (string dc in columns.Split(','))
            {
                sb.Append(dc + ",");
            }
            sb.Append("\n");

            byte[] pdfBytes = Encoding.ASCII.GetBytes(sb.ToString());
            response.Content = new ByteArrayContent(pdfBytes);
            response.Content.Headers.ContentType = new MediaTypeHeaderValue("text/csv");
            response.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment")
            {
                FileName = "MemberFormat.csv"
            };
            return response;
        }

        [Route("api/AccountReport/DownloadMembers/")]
        [HttpGet]
        public HttpResponseMessage DownloadMembers()
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser == null) return null;
            DataTable dt = Common.GetDBResult(@"Select S.SocName,W.WingName,R.RoomNo
,U.Users as Members,R.UnitType,R.Area
from Rooms R inner join SOC S ON R.SocID=S.SocID 
left join VW_Rooms U ON R.RoomID=U.RoomID
left join WIngs W ON R.WingID=W.WingID where R.SocID=" + objLoggedUser.SocID + " Order By U.Users");
            return ExportDataTable(dt);
        }

        [Route("api/AccountReport/DownloadBillRegister/")]
        [HttpGet]
        public HttpResponseMessage DownloadBillRegister()
        {
            string dateString = Request.GetQueryString("date");
            string name = Common.ToString(Request.GetQueryString("name"));
            DateTime date = Common.ToDate(dateString);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser == null) return null;
            DataTable dt = Common.GetDBResultParameterized(Common.GetBillRegisterQuery(),
                "@SocID", SqlDbType.Int, objLoggedUser.SocID,
                "@Month", SqlDbType.Int, date.Month,
                "@Year", SqlDbType.Int, date.Year,
                "@Name", SqlDbType.VarChar, name);
            return ExportDataTable(dt);
        }
        [Route("api/AccountReport/DownloadBillRegisterPdf/")]
        [HttpGet]
        public HttpResponseMessage DownloadBillRegisterPdf()
        {
            string dateString = Request.GetQueryString("date");
            string name = Common.ToString(Request.GetQueryString("name"));
            DateTime date = Common.ToDate(dateString);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser == null) return null;
            DataTable dt = Common.GetDBResultParameterized(Common.GetBillRegisterQuery(),
                "@SocID", SqlDbType.Int, objLoggedUser.SocID,
                "@Month", SqlDbType.Int, date.Month,
                "@Year", SqlDbType.Int, date.Year,
                "@Name", SqlDbType.VarChar, name);
            //return ExportDataTable(dt);
            DataTableToPDF obj = new DataTableToPDF();
            obj.Header = "Bill Register Month - " + date.ToString("MMM-yyyy");
            return obj.DataTableToPdf(dt, new float[] { 10f, 10f, 10f, 10f, 10f, 10f, 10f, 10f, 10f, 10f, 10f, 10f, 10f });
        }

        [Route("api/AccountReport/DownloadExpenseRegister/")]
        [HttpGet]
        public HttpResponseMessage DownloadExpenseRegister()
        {
            string dateString = Request.GetQueryString("date");
            string name = Common.ToString(Request.GetQueryString("name"));
            DateTime date = Common.ToDate(dateString);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser == null) return null;
            DataTable dt = Common.GetDBResultParameterized(Common.GetExpListQuery(),
                "@SocID", SqlDbType.Int, objLoggedUser.SocID,
                "@FGL", SqlDbType.Int, 0,
                "@Month", SqlDbType.Int, date.Month,
                "@Year", SqlDbType.Int, date.Year,
                "@Name", SqlDbType.VarChar, name);
            return ExportDataTable(dt);
        }
        [Route("api/AccountReport/DownloadExpenseRegisterPdf/")]
        [HttpGet]
        public HttpResponseMessage DownloadExpenseRegisterPdf()
        {
            string dateString = Request.GetQueryString("date");
            string name = Common.ToString(Request.GetQueryString("name"));
            DateTime date = Common.ToDate(dateString);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser == null) return null;
            DataTable dt = Common.GetDBResultParameterized(Common.GetExpListQuery(),
                "@SocID", SqlDbType.Int, objLoggedUser.SocID,
                "@FGL", SqlDbType.Int, 0,
                "@Month", SqlDbType.Int, date.Month,
                "@Year", SqlDbType.Int, date.Year,
                "@Name", SqlDbType.VarChar, name);
            DataTableToPDF obj = new DataTableToPDF();
            obj.Header = "Expense Register Month - " + date.ToString("MMM-yyyy");
            return obj.DataTableToPdf(dt, new float[] { 10f, 10f, 10f, 10f, 10f, 10f, 10f, 10f, 10f });
        }

        private static HttpResponseMessage ExportDataTable(DataTable dt)
        {
            HttpResponseMessage response = new HttpResponseMessage();

            StringBuilder sb = new StringBuilder();

            foreach (DataColumn dc in dt.Columns)
            {
                sb.Append(dc.ColumnName + ",");
            }
            sb.Append("\n");

            foreach (DataRow dr in dt.Rows)
            {
                foreach (DataColumn dc in dt.Columns)
                {
                    sb.Append('"' + Common.ToString(dr[dc.ColumnName]) + '"' + ",");
                }
                sb.Append("\n");
            }

            byte[] pdfBytes = Encoding.ASCII.GetBytes(sb.ToString());
            response.Content = new ByteArrayContent(pdfBytes);
            response.Content.Headers.ContentType = new MediaTypeHeaderValue("text/csv");
            response.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment")
   {
       FileName = DateTime.Now.ToString("dd_MM_yyyy_hh_ss") + ".csv"
   };
            return response;
        }
        [Route("api/AccountReport/PrintGE/{FromDate}/{ToDate}")]
        [HttpGet]
        public HttpResponseMessage PrintGE(string FromDate, string ToDate)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser == null) return null;
            DateTime fromDate = Common.ToDate(FromDate);
            DateTime toDate = Common.ToDate(ToDate);
            return GECommon.PrintGE(fromDate, toDate, objLoggedUser);
        }

        [Route("api/AccountReport/PrintTrialBalance/{AsOnDate}")]
        [HttpGet]
        public HttpResponseMessage PrintGE(string AsOnDate)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser == null) return null;
            DateTime asOnDate = Common.ToDate(AsOnDate);
            return GECommon.PrintTrialBalance(asOnDate, objLoggedUser);
        }

        [Route("api/AccountReport/GLList/")]
        [HttpPost]
        public AngularGridData GLList([FromBody]dynamic value)
        {
            Common.IsValidForm(Constants.Forms.ChartsofAccount, Request);
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            DataTable dt = GECommon.GetTrialBalance(Common.ToDate(value.OtherFilter.AsOnDate), objLoggedUser);
            dt.Columns["Account Name"].ColumnName = "Account_Name";
            dt.AcceptChanges();
            string json = JsonConvert.SerializeObject(dt, Formatting.Indented);
            AngularGridData objAngularData = new AngularGridData();
            objAngularData.TotalRecords = dt.Rows.Count;
            objAngularData.TotalPages = 1;
            objAngularData.Data = json;
            return objAngularData;
        }

        [Route("api/AccountReport/PrintBalanceSheet/{AsOnDate}")]
        [HttpGet]
        public HttpResponseMessage PrintBalanceSheet(string AsOnDate)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser == null) return null;
            DateTime asOnDate = Common.ToDate(AsOnDate);
            return GECommon.PrintBalanceSheet(asOnDate, objLoggedUser);
        }

        [Route("api/AccountReport/PrintPNL/{AsOnDate}")]
        [HttpGet]
        public HttpResponseMessage PrintPNL(string AsOnDate)
        {
            LoggedUser objLoggedUser = Common.GetUserFromSession(Request);
            if (objLoggedUser == null) return null;
            DateTime asOnDate = Common.ToDate(AsOnDate);

            return GECommon.PrintIncomeExpense(asOnDate, false, objLoggedUser) as HttpResponseMessage;
        }
    }

    public static class Ext
    {
        public static string GetQueryString(this HttpRequestMessage request, string key)
        {
            // IEnumerable<KeyValuePair<string,string>> - right!
            var queryStrings = request.GetQueryNameValuePairs();
            if (queryStrings == null)
                return null;

            var match = queryStrings.FirstOrDefault(kv => string.Compare(kv.Key, key, true) == 0);
            if (string.IsNullOrEmpty(match.Value))
                return null;

            return match.Value;
        }
    }
}
