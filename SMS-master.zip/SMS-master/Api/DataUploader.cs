﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;

namespace SampleAngular
{
    public class MemmberUpoader : DataUploader
    {
        List<UploadColumn> _Columns;
        public MemmberUpoader(int socID)
        {
            _Columns = new List<UploadColumn>();
            _Columns.Add(new UploadColumn()
            {
                ColumnName = "BlockWing",
                ColumnType = "System.String",
                DataColumnName = "BlockWing",
                IsManadatory = true,
                MaxLength = 10,
                RefList = GetFloors(socID)
            });
            _Columns.Add(new UploadColumn()
            {
                ColumnName = "UnitNo",
                ColumnType = "System.String",
                DataColumnName = "UnitNo",
                IsManadatory = true,
                MaxLength = 10
            });
            _Columns.Add(new UploadColumn()
            {
                ColumnName = "FloorNo",
                ColumnType = "System.Int32",
                DataColumnName = "FloorNo",
                IsManadatory = true,
                MaxLength = 2
            });
            _Columns.Add(new UploadColumn()
            {
                ColumnName = "Area",
                ColumnType = "System.Int32",
                DataColumnName = "Area",
                IsManadatory = true,
                MaxLength = 4
            });
            _Columns.Add(new UploadColumn()
            {
                ColumnName = "UnitType",
                ColumnType = "System.String",
                DataColumnName = "UnitType",
                IsManadatory = true,
                MaxLength = 10,
                RefList = new List<ReferenceColumn>()
                {
                    new ReferenceColumn(){Text="1RK",Value="1RK"},
                    new ReferenceColumn(){Text="1BHK",Value="1BHK"},
                    new ReferenceColumn(){Text="1.5BHK",Value="1.5BHK"},
                    new ReferenceColumn(){Text="2BHK",Value="2BHK"},
                    new ReferenceColumn(){Text="2.5BHK",Value="2.5BHK"},
                    new ReferenceColumn(){Text="3BHK",Value="3BHK"},
                    new ReferenceColumn(){Text="3.5BHK",Value="3.5BHK"},
                    new ReferenceColumn(){Text="4BHK",Value="4BHK"},
                    new ReferenceColumn(){Text="4.5BHK",Value="4.5BHK"},
                    new ReferenceColumn(){Text="Shop",Value="Shop"},
                    new ReferenceColumn(){Text="Office",Value="Office"}
                }
            });
            _Columns.Add(new UploadColumn()
            {
                ColumnName = "NoOfBeds",
                ColumnType = "System.Int32",
                DataColumnName = "NoOfBeds",
                IsManadatory = false,
                MaxLength = 2

            });
            _Columns.Add(new UploadColumn()
            {
                ColumnName = "NoOfBalconies",
                ColumnType = "System.String",
                DataColumnName = "NoOfBalconies",
                IsManadatory = false,
                MaxLength = 2
            });
            _Columns.Add(new UploadColumn()
            {
                ColumnName = "Intercom",
                ColumnType = "System.String",
                DataColumnName = "Intercom",
                IsManadatory = false,
                MaxLength = 10
            });
            _Columns.Add(new UploadColumn()
            {
                ColumnName = "EmailID",
                ColumnType = "System.String",
                DataColumnName = "EmailID",
                IsManadatory = false,
                MaxLength = 200
            });
            _Columns.Add(new UploadColumn()
            {
                ColumnName = "MobileNo",
                ColumnType = "System.Double",
                DataColumnName = "MobileNo",
                IsManadatory = true,
                MaxLength = 10,
                MatchExactLength = true
            });
            _Columns.Add(new UploadColumn()
            {
                ColumnName = "FirstName",
                ColumnType = "System.String",
                DataColumnName = "FirstName",
                IsManadatory = true,
                MaxLength = 50
            });
            _Columns.Add(new UploadColumn()
            {
                ColumnName = "LastName",
                ColumnType = "System.String",
                DataColumnName = "LastName",
                IsManadatory = true,
                MaxLength = 50
            });
            _Columns.Add(new UploadColumn()
            {
                ColumnName = "MemberType",
                ColumnType = "System.String",
                DataColumnName = "MemberType",
                IsManadatory = true,
                MaxLength = 20,
                RefList = new List<ReferenceColumn>()
                {
                    new ReferenceColumn(){Text="Owner",Value="Owner"},
                    new ReferenceColumn(){Text="Tenant",Value="Tenant"}
                }
            });
            _Columns.Add(new UploadColumn()
            {
                ColumnName = "OpeningBalance",
                ColumnType = "System.Double",
                DataColumnName = "OpeningBalance",
                IsManadatory = false,
                MaxLength = 5
            });
            _Columns.Add(new UploadColumn()
            {
                ColumnName = "OpeningBalanceInterest",
                ColumnType = "System.Double",
                DataColumnName = "OpeningBalanceInterest",
                IsManadatory = false,
                MaxLength = 5
            });
        }

        private List<ReferenceColumn> GetFloors(int socID)
        {
            List<ReferenceColumn> result = new List<ReferenceColumn>();
            DataTable dt = Common.GetDBResult("Select * from Wings where SocID=" + socID);
            foreach (DataRow dr in dt.Rows)
            {
                result.Add(new ReferenceColumn()
                {
                    Text = Common.ToString(dr["WingName"]),
                    Value = Common.ToString(dr["WingID"])
                });
            }
            return result;
        }

        public override List<UploadColumn> Columns
        {
            get
            {
                return _Columns;
            }
            set
            {
                _Columns = value;
            }
        }
    }
    #region Generic Data Uploader
    public class UploadColumn
    {
        public string ColumnName { get; set; }
        public string ColumnType { get; set; }
        public bool IsManadatory { get; set; }
        public string DataColumnName { get; set; }
        public int MaxLength { get; set; }
        public bool MatchExactLength { get; set; }
        public bool RestrictDuplicate { get; set; }
        public List<ReferenceColumn> RefList { get; set; }
    }
    public class ReferenceColumn
    {
        public string Value { get; set; }
        public string Text { get; set; }
    }
    public abstract class DataUploader
    {
        public DataUploader() { }
        protected string TableName;
        protected string IdentityColumn;
        protected string ConnectionString;
        private string fileData = String.Empty;
        public abstract List<UploadColumn> Columns { get; set; }
        private DataTable _Data;
        public DataTable Data { get { return _Data; } }
        public int TotalSuccessInsert;
        public int TotalFailedInsert;
        public bool IsDataValid(ref string message, DataTable dt)
        {
            bool isValid = true;
            int rowNumber = 0;
            int colNumber = 0;
            char colSep = ',';
            string colName = String.Empty;
            string colType = String.Empty;
            string dataColName = String.Empty;
            List<ReferenceColumn> refCols = null;
            ReferenceColumn refCol = null;
            DataRow dr = null;
            int tempInt;
            double tempDouble;
            DateTime tempDate;
            string colContent = String.Empty;

            if (Columns == null || Columns.Count <= 0)
            {
                message = "No Data Columns Specified";
                return false;
            }
            CreateDataTable();
            if (dt.Columns.Contains("$$hashkey"))
                dt.Columns.Remove("$$hashkey");
            dt.AcceptChanges();
            //Each row
            foreach (DataRow lineContent in dt.Rows)
            {
                rowNumber++;
                colNumber = 0;

                //Check Valid No of Columns
                if (dt.Columns.Count != Columns.Count)
                {
                    message = "No of Column mismatch at row " + (colNumber + 1).ToString();
                    return false;
                }
                //Match Column
                foreach (DataColumn col in dt.Columns)
                {
                    colName = Columns[colNumber].ColumnName;
                    if (colName.ToLower() != col.ColumnName.ToLower())
                    {
                        isValid = false;
                        message = "Column [" + Columns[colNumber].ColumnName + "] not found at " + (colNumber + 1).ToString() + " position.";
                        return false;
                    }
                    colNumber++;
                }
                colNumber = 0;
                dr = Data.NewRow();
                //Each column
                foreach (DataColumn objCol in dt.Columns)
                {
                    colName = Columns[colNumber].ColumnName;
                    colContent = Common.ToString(lineContent[objCol.ColumnName]);
                    dataColName = Columns[colNumber].DataColumnName;
                    colType = Columns[colNumber].ColumnType;
                    refCols = Columns[colNumber].RefList;
                    {
                        //Check Blank
                        if (colContent.Trim() == String.Empty && Columns[colNumber].IsManadatory == true)
                        {
                            message += ",\n " + colName + " is blank at row " + rowNumber;
                        }

                        //Check Max Length
                        if (Columns[colNumber].MaxLength > 0 && colContent.Trim().Length > Columns[colNumber].MaxLength)
                        {
                            message += ",\n " + colName + " length is greater than " + Columns[colNumber].MaxLength + " at row " + rowNumber;
                        }

                        //Check Exact Length
                        if (Columns[colNumber].MatchExactLength && Columns[colNumber].MaxLength != colContent.Trim().Length)
                        {
                            message += ",\n " + colName + " length should be " + Columns[colNumber].MaxLength + " at row " + rowNumber;
                        }

                        //Check Duplicate
                        if (Columns[colNumber].RestrictDuplicate && Data.Select(dataColName + "='" + Common.ToString(colContent.Trim()) + "'").Length > 0)
                        {
                            message += ",\n " + colName + " duplicate [" + colContent.Replace("\r", "") + "] at row " + rowNumber;
                        }

                        //Check DataType
                        if (!(Columns[colNumber].IsManadatory == false && colContent.Replace("\r", "").Length <= 0))
                            switch (colType.ToLower())
                            {
                                case "system.int32":
                                    tempInt = 0;
                                    if (!int.TryParse(colContent.Replace("\r", ""), out tempInt))
                                        message += ",\n " + colName + " value [" + colContent + "] is not Integer at row " + rowNumber;
                                    dr[dataColName] = tempInt;
                                    break;
                                case "system.double":
                                    tempDouble = 0;
                                    if (!double.TryParse(colContent.Replace("\r", ""), out tempDouble))
                                        message += ",\n " + colName + " value [" + colContent + "] is not Decimal at row " + rowNumber;
                                    dr[dataColName] = tempDouble;
                                    break;
                                case "system.datetime":
                                    tempDate = DateTime.Now;
                                    if (!DateTime.TryParse(colContent.Replace("\r", ""), out tempDate))
                                        message += ",\n " + colName + " value [" + colContent + "] is not DateTime at row " + rowNumber;
                                    dr[dataColName] = tempDate;
                                    break;
                                case "system.string":
                                    dr[dataColName] = colContent.Replace("\r", "").Replace("'", "''");

                                    if (refCols != null && refCols.Count > 0)
                                    {
                                        refCol = refCols.Find(Obj => Obj.Text == Common.ToString(dr[colName]));
                                        if (refCol != null)
                                            dr[dataColName] = refCol.Value;
                                        else
                                            dr[dataColName] = "0";
                                    }
                                    break;
                            }
                        else
                            dr[dataColName] = DBNull.Value;
                    }
                    colNumber++;
                }
                if (dr != null)
                    Data.Rows.Add(dr);
            }

            if (message.Length > 0 && message.StartsWith(","))
            {
                message = message.Substring(1);
                isValid = false;
            }
            return isValid;
        }
        /// <summary>
        /// Method to validate CSV data
        /// Sanjay Gupta.
        /// Rohit, Feb 10, 2014: Added CompanyID parameter.
        /// </summary>
        /// <param name="message"></param>
        /// <param name="fileName"></param>
        /// <param name="companyID"></param>
        /// <returns></returns>
        public bool IsDataValidForInsert(ref string message, DataTable dt, int companyID)
        {
            int totalSuccess = 0;
            int totalFailed = 0;
            bool isValid = true;
            int rowNumber = 0;
            int colNumber = 0;
            char colSep = ',';
            string colName = String.Empty;
            string colType = String.Empty;
            string dataColName = String.Empty;
            string colMessage = String.Empty;
            List<ReferenceColumn> refCols = null;
            ReferenceColumn refCol = null;
            DataRow dr = null;
            int tempInt;
            double tempDouble;
            DateTime tempDate;
            DataTable dtCurrentData = GetCurrentData(companyID);
            string colContent = String.Empty;

            if (Columns == null || Columns.Count <= 0)
            {
                message = "No Data Columns Specified";
                return false;
            }
            CreateDataTable();

            //Each row
            foreach (DataRow lineContent in dt.Rows)
            {
                rowNumber++;
                colNumber = 0;

                //Check Valid No of Columns
                if (dt.Columns.Count != Columns.Count)
                {
                    message = "No of Column mismatch at row " + (colNumber + 1).ToString();
                    return false;
                }
                //Match Column
                foreach (DataColumn col in dt.Columns)
                {
                    colName = Columns[colNumber].ColumnName;
                    if (colName.ToLower() != col.ColumnName.ToLower())
                    {
                        isValid = false;
                        message = "Column [" + Columns[colNumber].ColumnName + "] not found at " + (colNumber + 1).ToString() + " position.";
                        return false;
                    }
                    colNumber++;
                }
                colNumber = 0;
                dr = Data.NewRow();
                //Each column
                colMessage = String.Empty;
                foreach (DataColumn objCol in dt.Columns)
                {
                    colName = Columns[colNumber].ColumnName;
                    colContent = Common.ToString(lineContent[objCol.ColumnName]);
                    dataColName = Columns[colNumber].DataColumnName;
                    colType = Columns[colNumber].ColumnType;
                    refCols = Columns[colNumber].RefList;

                    //Check Blank
                    if (colContent.Trim() == String.Empty && Columns[colNumber].IsManadatory == true)
                    {
                        colMessage += ", " + colName + " is blank at row " + rowNumber;
                    }

                    //Check Max Length
                    if (Columns[colNumber].MaxLength > 0 && colContent.Trim().Length > Columns[colNumber].MaxLength)
                    {
                        colMessage += ", " + colName + " length is greater than " + Columns[colNumber].MaxLength + " at row " + rowNumber;
                    }

                    //Check Duplicate
                    if (Columns[colNumber].RestrictDuplicate && Data.Select(dataColName + "='" + Common.ToString(colContent.Trim().Replace("'", "''")) + "'").Length > 0)
                    {
                        colMessage += ", " + colName + " duplicate [" + colContent.Replace("\r", "") + "] at row " + rowNumber;
                    }

                    //Check DataType
                    if (!(Columns[colNumber].IsManadatory == false && colContent.Replace("\r", "").Length <= 0))
                        switch (colType.ToLower())
                        {
                            case "system.int32":
                                tempInt = 0;
                                if (!int.TryParse(colContent.Replace("\r", ""), out tempInt))
                                    colMessage += ",\n " + colName + " value [" + colContent + "] is not Integer at row " + rowNumber;
                                dr[dataColName] = tempInt;
                                break;
                            case "system.double":
                                tempDouble = 0;
                                if (!double.TryParse(colContent.Replace("\r", ""), out tempDouble))
                                    colMessage += ",\n " + colName + " value [" + colContent + "] is not Decimal at row " + rowNumber;
                                dr[dataColName] = tempDouble;
                                break;
                            case "system.datetime":
                                tempDate = DateTime.Now;
                                if (!DateTime.TryParse(colContent.Replace("\r", ""), out tempDate))
                                    colMessage += ",\n " + colName + " value [" + colContent + "] is not DateTime at row " + rowNumber;
                                dr[dataColName] = tempDate;
                                break;
                            case "system.string":
                                dr[dataColName] = colContent.Replace("\r", "").Trim();

                                if (refCols != null && refCols.Count > 0)
                                {
                                    refCol = refCols.Find(Obj => Obj.Text == Common.ToString(dr[colName]));
                                    if (refCol != null)
                                        dr[dataColName] = refCol.Value;
                                    else
                                        dr[dataColName] = "0";
                                }
                                break;
                        }
                    else
                        dr[dataColName] = DBNull.Value;

                    //Check Duplicate
                    if (Columns[colNumber].RestrictDuplicate && dtCurrentData.Select(dataColName + "='" + Common.ToString(colContent.Trim().Replace("'", "''")) + "'").Length > 0)
                    {
                        colMessage += ", " + colName + " duplicate [" + colContent.Replace("\r", "") + "] at row " + rowNumber;
                    }


                    colNumber++;
                }

                if (colMessage.Length > 0)
                {
                    message += ",<br/><span style='color:red'>Failed:" + colMessage.Substring(1) + "</span>";
                    totalFailed++;
                    continue;
                }
                else if (dr != null)
                {
                    Data.Rows.Add(dr);
                    message += ",<br/><span style='color:green'>Success: row number " + rowNumber.ToString() + "</span>";
                    totalSuccess++;
                }
            }

            if (message.Length > 0 && message.StartsWith(","))
            {
                message = message.Substring(1);
            }
            TotalSuccessInsert = totalSuccess;
            TotalFailedInsert = totalFailed;
            return isValid;
        }
        public bool ValidateAndInsert(ref string message, DataTable dt)
        {
            bool IsValid = IsDataValid(ref message, dt);
            if (IsValid)
            {
                InsertInDatabase(Data);
            }
            return IsValid;
        }
        private void CreateDataTable()
        {
            _Data = new DataTable();
            DataColumn dc;
            foreach (UploadColumn col in Columns)
            {
                dc = new DataColumn();
                dc.AllowDBNull = !col.IsManadatory;
                dc.Caption = col.DataColumnName;
                dc.ColumnName = col.DataColumnName;
                dc.ReadOnly = false;
                dc.DataType = Type.GetType(col.ColumnType);
                Data.Columns.Add(dc);
            }
        }
        public void InsertInDatabase(DataTable dt)
        {
            SqlConnection con = new SqlConnection(this.ConnectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();

            StringBuilder sb = new StringBuilder();
            string[] columnNames = dt.Columns.Cast<DataColumn>().
                                              Select(column => column.ColumnName).
                                              ToArray();
            sb.Append("insert into ").Append(this.TableName).Append(" (").Append(string.Join(",", columnNames));
            sb.Append(") ");
            int counter = 0;
            foreach (DataRow row in dt.Rows)
            {
                if (counter > 0)
                    sb.AppendLine(" UNION ALL ");
                string[] fields = row.ItemArray.Select(field => field.GetType() == typeof(DBNull) ? "null" : "'" + Common.ToString(field).Replace("'", "''") + "'").
                                                ToArray();
                sb.Append("SELECT ").Append(string.Join(",", fields));
                counter++;
            }

            SqlCommand cmd = new SqlCommand(sb.ToString(), con);
            cmd.Transaction = trn;
            try
            {
                cmd.ExecuteNonQuery();
                trn.Commit();
            }
            catch
            {
                trn.Rollback();
            }

        }
        public bool InsertInDatabaseRowByRow(DataTable dt)
        {
            SqlConnection con = new SqlConnection(this.ConnectionString);
            con.Open();
            SqlTransaction trn = con.BeginTransaction();

            StringBuilder sb = new StringBuilder();
            string[] columnNames = dt.Columns.Cast<DataColumn>().
                                              Select(column => column.ColumnName).
                                              ToArray();
            sb.Append("insert into ").Append(this.TableName).Append(" (").Append(string.Join(",", columnNames));
            sb.Append(") ");
            StringBuilder sbCommand;
            try
            {
                foreach (DataRow row in dt.Rows)
                {
                    //Fire "OnBeforeRowInsert" event if defined
                    if (this.OnBeforeRowInsert != null)
                    {
                        OnBeforeRowInsert(row);
                    }

                    sbCommand = new StringBuilder(sb.ToString());
                    string[] fields = row.ItemArray.Select(field => field.GetType() == typeof(DBNull) ? "null" : "'" + Common.ToString(field).Replace("'", "''") + "'").
                                                    ToArray();
                    sbCommand.Append("SELECT ").Append(string.Join(",", fields));

                    sbCommand.Append(";");
                    if (IdentityColumn.Length > 0)
                    {
                        sbCommand.Append("set @").Append(IdentityColumn).Append(" =@@IDENTITY");
                    }
                    SqlCommand cmd = new SqlCommand(sbCommand.ToString(), con);

                    if (IdentityColumn.Length > 0)
                    {
                        cmd.Parameters.Add("@" + IdentityColumn, SqlDbType.Int).Value = 0;
                        cmd.Parameters["@" + IdentityColumn].Direction = ParameterDirection.InputOutput;
                    }
                    cmd.Transaction = trn;

                    cmd.ExecuteNonQuery();
                    int lastID = 0;

                    if (IdentityColumn.Length > 0)
                    {
                        lastID = Common.ToInt(cmd.Parameters["@" + IdentityColumn].Value);
                    }

                    //Fire "OnAfterRowInsert" event if defined
                    if (this.OnAfterRowInsert != null)
                    {
                        OnAfterRowInsert(row, trn, lastID);
                    }
                }
                trn.Commit();
                return true;
            }
            catch (Exception Ex)
            {
                trn.Rollback();
                throw new Exception(Ex.Message);
            }
            finally
            {
                con.Dispose();
            }
        }
        private DataTable GetCurrentData()
        {
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("Select * from " + TableName, con);
            DataTable dt = new DataTable();
            try
            {
                con.Open();
                dt.Load(cmd.ExecuteReader());
            }
            finally
            {
                con.Dispose();
            }
            return dt;
        }
        /// <summary>
        /// Method to get data of Product Master table company wise.
        /// Rohit, Feb 10, 2014.
        /// </summary>
        /// <param name="companyID"></param>
        /// <returns></returns>
        private DataTable GetCurrentData(int companyID)
        {
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("Select * from " + TableName + " where CompanyID = " + companyID, con);
            DataTable dt = new DataTable();
            try
            {
                con.Open();
                dt.Load(cmd.ExecuteReader());
            }
            finally
            {
                con.Dispose();
            }
            return dt;
        }
        public delegate void BeforeRowInsert(DataRow dr);
        public delegate void AfterRowInsert(DataRow dr, SqlTransaction trn, int lastID);

        /// <summary>
        /// Fires just before Inserting the row in database
        /// </summary>
        public event BeforeRowInsert OnBeforeRowInsert;
        /// <summary>
        /// Fires after Inserting the row in database
        /// </summary>
        public event AfterRowInsert OnAfterRowInsert;
    }
    #endregion
}