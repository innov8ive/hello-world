﻿angular.module('myApp', ['ngRoute', 'ngSanitize', 'ui.select', 'yaru22.angular-timeago', 'ui.bootstrap', 'jkuri.gallery', 'pascalprecht.translate'])
.factory('RequestsErrorHandler', ['$q', function ($q) {
    return {
        // --- The user's API for claiming responsiblity for requests ---
        specificallyHandled: function (specificallyHandledBlock) {
            specificallyHandleInProgress = true;
            try {
                return specificallyHandledBlock();
            } finally {
                specificallyHandleInProgress = false;
            }
        },

        // --- Response interceptor for handling errors generically ---
        responseError: function (rejection) {
            if (rejection.status == 401) {
                window.location = '#/login';
            }
            return $q.reject(rejection);
        }
    };
}])
.config(['$routeProvider', '$httpProvider', function ($routeProvider, $httpProvider) {

    $routeProvider.when('/home', {
        templateUrl: 'templates/Site/home.html'
    });
    $routeProvider.when('/category/:CategoryID', {
        templateUrl: 'templates/Site/category.html'
    });
    $routeProvider.when('/search/:CategoryID/:SubID', {
        templateUrl: 'templates/Site/searchresult.html'
    });
    $routeProvider.when('/search/:CategoryID/:SubID/:SearchText', {
        templateUrl: 'templates/Site/searchresult.html'
    });
    $routeProvider.when('/SP/:SPID', {
        templateUrl: 'templates/Site/SPProfile.html'
    });
    $routeProvider.when('/login', {
        templateUrl: 'templates/Site/login.html'
    });
    $routeProvider.when('/RegisterSP', {
        templateUrl: 'templates/Site/SP.html'
    });
    $routeProvider.when('/RegisterUser', {
        templateUrl: 'templates/Site/User.html'
    });
    $routeProvider.when('/logout', {
        templateUrl: 'templates/Site/logout.html'
    });
    $routeProvider.when('/changepassword', {
        templateUrl: 'templates/Site/changepassword.html'
    });
    $routeProvider.when('/Profile', {
        templateUrl: 'templates/Site/Profile.html'
    });
    $routeProvider.when('/UserProfile/:UserID', {
        templateUrl: 'templates/Site/UserProfile.html'
    });
    $routeProvider.when('/EditSP', {
        templateUrl: 'templates/SP/SPEdit.html'
    });
    $routeProvider.when('/PendingSP', {
        templateUrl: 'templates/SP/SPPending.html'
    });
    $routeProvider.when('/Listing', {
        templateUrl: 'templates/SP/SPEditListing.html'
    });
    $routeProvider.when('/verifyaccount/:code', {
        templateUrl: 'templates/Site/verifyaccount.html'
    });
    $routeProvider.when('/Images', {
        templateUrl: 'templates/SP/SPImg.html'
    });
    $routeProvider.when('/Videos', {
        templateUrl: 'templates/SP/SPVideo.html'
    });
    $routeProvider.when('/Keywords', {
        templateUrl: 'templates/SP/SPKey.html'
    });

    $routeProvider.otherwise({ redirectTo: '/home' });
    $httpProvider.interceptors.push('RequestsErrorHandler');
}])
.config(['$translateProvider', function ($translateProvider, $translate) {
    //$translateProvider.useStaticFilesLoader({
    //    prefix: 'lang/',
    //    suffix: '.json'
    //});
    $translateProvider.useUrlLoader('api/FetchLanguage');
    $translateProvider.registerAvailableLanguageKeys(['EN', 'PT'], {
        'EN': 'EN',
        'PT': 'PT',
    });
    $translateProvider.preferredLanguage('EN');
}])
.factory('User', function () {
    var self = this;
    self.UserID = 0;
    self.UserType = 0;
    self.Token = '';
    self.UserName = '';
    self.FirstName = '';
    self.LastName = '';
    self.ImageUrl = '';
    self.MenuItems = [];
    self.Verified = false;
    self.CityID = 0;
    self.Lang = 'EN';
    return self;
})
.controller('MenuController', function ($scope, User, $http, $location, $translate) {
 
    $scope.User = User;
    $scope.IsLoggedIn = User.UserID > 0 ? true : false;

    $scope.changeLanguage = function (lang) {
        User.Lang = lang;
        $translate.use(lang);
        $location.path("/home");
    };
    angular.element(document).ready(function () {
        $http({
            method: 'POST',
            url: 'api/Common/LoadUserFromSession'
        }).success(function (result) {
            if (result != null) {
                User.Verified = result.Verified;
                if (User.Verified != null && User.Verified == false) {
                    alert('Your account is not Verified. Please verify your account by clicking on Verify link sent to your email.')
                    return;
                }
                User.CityID = result.CityID;
                User.UserID = result.UserID;
                User.UserType = result.UserType;
                User.Token = result.Token;
                User.UserName = result.UserName;
                User.FirstName = result.FirstName;
                User.LastName = result.LastName;
                User.ImageUrl = result.ImageUrl;
                User.MenuItems = result.MenuItems;
                $http.defaults.headers.post['Token'] = result.Token;
                $http.defaults.headers.post['UserID'] = result.UserID;
                $http.defaults.headers.get = { Token: result.Token, UserID: result.UserID };

                if ($scope.User.UserType == 3) {//Sysadmin
                   // $location.path("/logout");
                }
            }
        });
    });

})

.controller('LogoutController', function ($scope, User, $http) {
    $http({
        method: 'POST',
        url: 'api/Common/Logout'
    }).success(function (result) {
        User.UserID = User.UserType = 0;
        User.FirstName = User.LastName = User.Token = User.ImageUrl = '';
        User.MenuItems = [];
        $http.defaults.headers.post['Token'] = '';
        $http.defaults.headers.post['UserID'] = 0;
        $http.defaults.headers.get = { Token: '', UserID: 0 };
    });
})
.controller('CPController', function ($scope, User, $http) {
    $scope.CP = { OldPassword: '', NewPassword: '', ConfirmPassword: '', UserID: 0 };
    $scope.changePassword = function () {
        $scope.CPSubmitted = true;
        if ($scope.formCP.$invalid == true) return;
        if ($scope.CP.NewPassword != $scope.CP.ConfirmPassword) {
            swal({ title: "New Password and Confirmn Password must be same!", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        $scope.CP.UserID = User.UserID;
        $http({
            method: 'POST',
            url: 'api/Common/ChangePassword',
            data: JSON.stringify($scope.CP)
        }).success(function (result) {
            if (result == "Invalid") {
                swal({ title: "Invalid Old Password, Password not changed!", type: "error", timer: 1000, showConfirmButton: false });
            }
            else if (result == "Changed") {
                swal({ title: "Password changed successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        });
    };
})

.controller('LoginController', function ($scope, $http, $location, User) {
    $scope.LoginUser = { UserName: '', Password: '' };
    $scope.login = function () {
        $scope.LoginSubmitted = true;
        if ($scope.formLogin.$invalid == true) return;
        $http({
            method: 'POST',
            url: 'api/Common/LoginMember',
            data: JSON.stringify($scope.LoginUser)
        }).success(function (result) {
            if (result == null) {
                alert('Invalid Username or Password');
                $scope.LoginUser.Password = '';
                User.UserID = 0;
                User.Token = '';
                User.FirstName = User.LastName = User.UserName = User.ImageUrl = '';
                User.MenuItems = [];
            }
            else {
                User.Verified = result.Verified;
                if (User.Verified != null && User.Verified == false) {
                    alert('Your account is not Verified. Please verify your account by clicking on Verify link sent to your email.')
                    return;
                }
                User.CityID = result.CityID;
                User.UserID = result.UserID;
                User.UserType = result.UserType;
                User.Token = result.Token;
                User.UserName = result.UserName;
                User.FirstName = result.FirstName;
                User.LastName = result.LastName;
                User.ImageUrl = result.ImageUrl;
                User.MenuItems = result.MenuItems;
                $http.defaults.headers.post['Token'] = result.Token;
                $http.defaults.headers.post['UserID'] = result.UserID;
                $http.defaults.headers.get = { Token: result.Token, UserID: result.UserID };

                $location.path('/home');
            }
        });
    }
})
.directive('modal', function () {
    return {
        template: '<div class="modal fade">' +
            '<div class="modal-dialog">' +
              '<div class="modal-content">' +
                '<div class="modal-header">' +
                  '<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>' +
                  '<h4 class="modal-title"></h4>' +
                '</div>' +
                '<div class="modal-body" ng-transclude></div>' +
              '</div>' +
            '</div>' +
          '</div>',
        restrict: 'E',
        transclude: true,
        replace: true,
        scope: true,
        link: function postLink(scope, element, attrs) {
            scope.$watch(attrs.title, function (value) {
                $(element).find('.modal-title').html(value);
            });

            scope.$watch(attrs.visible, function (value) {
                if (value == true)
                    $(element).modal('show');
                else
                    $(element).modal('hide');
            });

            $(element).on('shown.bs.modal', function () {
                scope.$apply(function () {
                    scope.$parent[attrs.visible] = true;
                });
            });

            $(element).on('hidden.bs.modal', function () {
                scope.$apply(function () {
                    scope.$parent[attrs.visible] = false;
                });
            });
        }
    };
}).directive('imageuploader', function () {
    return {
        restrict: 'E',
        replace: true,
        templateUrl: 'templates/image-uploader.html'
    }
}).directive('loading', ['$http', function ($http) {
    return {
        restrict: 'A',
        link: function (scope, elm, attrs) {
            scope.isLoading = function () {
                return $http.pendingRequests.length > 0;
            };

            scope.$watch(scope.isLoading, function (v) {
                if (v) {
                    elm.show();
                } else {
                    elm.hide();
                }
            });
        }
    };

}]).filter('trustAsResourceUrl', ['$sce', function ($sce) {
    return function (val) {
        return $sce.trustAsHtml(val);
    };
}]).directive('starRating', function () {
    return {
        restrict: 'EA',
        template:
          '<ul class="star-rating" ng-class="{readonly: readonly}">' +
          '  <li ng-repeat="star in stars" class="star" ng-class="{filled: star.filled}" ng-click="toggle($index)">' +
          '    <i class="fa fa-star"></i>' + // or &#9733
          '  </li>' +
          '</ul>',
        scope: {
            ratingValue: '=ngModel',
            max: '=?', // optional (default is 5)
            onRatingSelect: '&?',
            readonly: '=?'
        },
        link: function (scope, element, attributes) {
            if (scope.max == undefined) {
                scope.max = 5;
            }
            function updateStars() {
                scope.stars = [];
                for (var i = 0; i < scope.max; i++) {
                    scope.stars.push({
                        filled: i < scope.ratingValue
                    });
                }
            };
            scope.toggle = function (index) {
                if (scope.readonly == undefined || scope.readonly === false) {
                    scope.ratingValue = index + 1;
                    scope.onRatingSelect({
                        rating: index + 1
                    });
                }
            };
            scope.$watch('ratingValue', function (oldValue, newValue) {
                if (newValue || oldValue) {
                    updateStars();
                }
            });
        }
    };
}).run(function ($rootScope, $templateCache) {
    $rootScope.$on('$viewContentLoaded', function () {
       // $templateCache.removeAll();
    });
});