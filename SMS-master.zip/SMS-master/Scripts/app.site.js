﻿angular.module('myApp', ['ngRoute', 'ngGrid', 'ngSanitize', 'ui.select', 'yaru22.angular-timeago', 'checklist-model', 'jkuri.gallery'])
.factory('RequestsErrorHandler', ['$q', function ($q) {
    return {
        // --- The user's API for claiming responsiblity for requests ---
        specificallyHandled: function (specificallyHandledBlock) {
            specificallyHandleInProgress = true;
            try {
                return specificallyHandledBlock();
            } finally {
                specificallyHandleInProgress = false;
            }
        },

        // --- Response interceptor for handling errors generically ---
        responseError: function (rejection) {
            if (rejection.status == 401) {
                window.location = '#/login';
            }
            return $q.reject(rejection);
        }
    };
}])
.config(['$routeProvider', '$httpProvider', function ($routeProvider, $httpProvider) {


    $routeProvider.when('/privacy', {
        templateUrl: 'templates/privacy.html?build=' + build
    });
    $routeProvider.when('/terms', {
        templateUrl: 'templates/terms.html?build=' + build
    });
    $routeProvider.when('/home', {
        templateUrl: 'templates/DashBoard/home.html?build=' + build
    });
    $routeProvider.when('/adminHome', {
        templateUrl: 'templates/DashBoard/adminHome.html?build=' + build
    });
    $routeProvider.when('/PayTMHome', {
        templateUrl: 'templates/PayTM/home.html?build=' + build
    });
    $routeProvider.when('/login', {
        templateUrl: 'templates/login.html?build=' + build,
        css: 'css/login.css'
    });
    $routeProvider.when('/logout', {
        templateUrl: 'templates/logout.html?build=' + build,
        css: 'Content/login.css'
    });
    $routeProvider.when('/changepassword', {
        templateUrl: 'templates/changepassword.html?build=' + build
    });
    $routeProvider.when('/verifyaccount/:code', {
        templateUrl: 'templates/Site/verifyaccount.html'
    });
    $routeProvider.when('/UsersList', {
        templateUrl: 'templates/Users/UsersList.html?build=' + build
    });
    $routeProvider.when('/Users/:UserID/:RoomID', {
        templateUrl: 'templates/Users/Users.html?build=' + build
    });
    $routeProvider.when('/Users/:UserID', {
        templateUrl: 'templates/Users/Users.html?build=' + build
    });
    $routeProvider.when('/Profile', {
        templateUrl: 'templates/Users/Profile.html?build=' + build
    });
    $routeProvider.when('/SocList', {
        templateUrl: 'templates/Soc/SocList.html?build=' + build
    });
    $routeProvider.when('/Soc/:SocID', {
        templateUrl: 'templates/Soc/Soc.html?build=' + build
    });
    $routeProvider.when('/RoomsList', {
        templateUrl: 'templates/Rooms/RoomsList.html?build=' + build
    });
    $routeProvider.when('/Rooms/:RoomID', {
        templateUrl: 'templates/Rooms/Rooms.html?build=' + build
    });
    $routeProvider.when('/Forums/:ForumType', {
        templateUrl: 'templates/Forums/Forums.html?build=' + build
    });
    $routeProvider.when('/Forums/:ForumType/:ForumID', {
        templateUrl: 'templates/Forums/Forums.html?build=' + build
    });
    $routeProvider.when('/ForumsList', {
        templateUrl: 'templates/Forums/ForumsList.html?build=' + build
    });
    $routeProvider.when('/ForumsList/:ForumType', {
        templateUrl: 'templates/Forums/ForumsList.html?build=' + build
    });

    $routeProvider.when('/CarouselList', {
        templateUrl: 'templates/Carousel/CarouselList.html?build=' + build
    });
    $routeProvider.when('/Carousel/:ID', {
        templateUrl: 'templates/Carousel/Carousel.html?build=' + build
    });
    $routeProvider.when('/MailSettings', {
        templateUrl: 'templates/MailSettings/MailSettings.html?build=' + build
    });
    $routeProvider.when('/LanguageList', {
        templateUrl: 'templates/Language/LanguageList.html?build=' + build
    });
    $routeProvider.when('/Language/:ID', {
        templateUrl: 'templates/Language/Language.html?build=' + build
    });
    $routeProvider.when('/GLList', {
        templateUrl: 'templates/GL/GLList.html?build=' + build
    });
    $routeProvider.when('/GL/:GLID', {
        templateUrl: 'templates/GL/GL.html?build=' + build
    });
    $routeProvider.when('/Register', {
        templateUrl: 'templates/Soc/Register.html?build=' + build
    });
    $routeProvider.when('/ExpList', {
        templateUrl: 'templates/Exp/ExpList.html?build=' + build
    });
    $routeProvider.when('/Exp/:ExpID', {
        templateUrl: 'templates/Exp/Exp.html?build=' + build
    });
    $routeProvider.when('/IncomeList', {
        templateUrl: 'templates/Income/IncomeList.html?build=' + build
    });
    $routeProvider.when('/Income/:IncomeID', {
        templateUrl: 'templates/Income/Income.html?build=' + build
    });
    $routeProvider.when('/ContraList', {
        templateUrl: 'templates/Contra/ContraList.html?build=' + build
    });
    $routeProvider.when('/Contra/:ContraID', {
        templateUrl: 'templates/Contra/Contra.html?build=' + build
    });
    $routeProvider.when('/GE', {
        templateUrl: 'templates/ACReport/GE.html?build=' + build
    });
    $routeProvider.when('/TrialBalance', {
        templateUrl: 'templates/ACReport/TrialBalance.html?build=' + build
    });
    $routeProvider.when('/BalanceSheet', {
        templateUrl: 'templates/ACReport/BalanceSheet.html?build=' + build
    });
    $routeProvider.when('/PNL', {
        templateUrl: 'templates/ACReport/PNL.html?build=' + build
    });
    $routeProvider.when('/ServicesList', {
        templateUrl: 'templates/Services/ServicesList.html?build=' + build
    });
    $routeProvider.when('/Services/:ServiceID', {
        templateUrl: 'templates/Services/Services.html?build=' + build
    });
    $routeProvider.when('/ServicesListing', {
        templateUrl: 'templates/Services/ServicesListing.html?build=' + build
    });
    $routeProvider.when('/NBList', {
        templateUrl: 'templates/NB/NBList.html?build=' + build
    });
    $routeProvider.when('/NB/:NBID', {
        templateUrl: 'templates/NB/NB.html?build=' + build
    });
    $routeProvider.when('/NBListing', {
        templateUrl: 'templates/NB/NBListing.html?build=' + build
    });
    $routeProvider.when('/PLList', {
        templateUrl: 'templates/PL/PLList.html?build=' + build
    });
    $routeProvider.when('/PL/:PLID', {
        templateUrl: 'templates/PL/PL.html?build=' + build
    });
    $routeProvider.when('/PLListing', {
        templateUrl: 'templates/PL/PLListing.html?build=' + build
    });
    $routeProvider.when('/PLResult/:PLID', {
        templateUrl: 'templates/PL/PLResult.html?build=' + build
    });
    $routeProvider.when('/PendingBills', {
        templateUrl: 'templates/Bills/PendingBills.html?build=' + build
    });
    $routeProvider.when('/OutstandingBills', {
        templateUrl: 'templates/Bills/OutstandingBills.html?build=' + build
    });
    $routeProvider.when('/PaidBills', {
        templateUrl: 'templates/Bills/PaidBills.html?build=' + build
    });
    $routeProvider.when('/MemberLogin/:UserID/:Password', {
        templateUrl: 'templates/MemberLogin.html?build=' + build
    });
    $routeProvider.when('/Folders', {
        templateUrl: 'templates/Folder/FolderList.html?build=' + build
    });
    $routeProvider.when('/CSVUpload', {
        templateUrl: 'templates/Folder/CSVUpload.html?build=' + build
    });
    $routeProvider.when('/MemberUpload', {
        templateUrl: 'templates/Folder/MemberUpload.html?build=' + build
    });
    $routeProvider.when('/CMList', {
        templateUrl: 'templates/CM/CMList.html?build=' + build
    });
    $routeProvider.when('/CM/:CMID', {
        templateUrl: 'templates/CM/CM.html?build=' + build
    });
    $routeProvider.when('/ALList', {
        templateUrl: 'templates/AL/ALList.html?build=' + build
    });
    $routeProvider.when('/AL/:ALID', {
        templateUrl: 'templates/AL/AL.html?build=' + build
    });
    $routeProvider.when('/CPList', {
        templateUrl: 'templates/CP/CPList.html?build=' + build
    });
    $routeProvider.when('/CP/:CPID', {
        templateUrl: 'templates/CP/CP.html?build=' + build
    });
    $routeProvider.when('/ChgList', {
        templateUrl: 'templates/Chg/ChgList.html?build=' + build
    });
    $routeProvider.when('/Chg/:ChgID', {
        templateUrl: 'templates/Chg/Chg.html?build=' + build
    });
    $routeProvider.when('/BSUList', {
        templateUrl: 'templates/BSU/BSUList.html?build=' + build
    });
    $routeProvider.when('/BSU/:BSID', {
        templateUrl: 'templates/BSU/BSU.html?build=' + build
    });
    $routeProvider.when('/RMBSU/:BSID/:RMID', {
        templateUrl: 'templates/BSU/RMBSU.html?build=' + build
    });
    $routeProvider.when('/ScheduleList', {
        templateUrl: 'templates/Schedule/ScheduleList.html?build=' + build
    });
    $routeProvider.when('/Schedule/:ID/:MasterID', {
        templateUrl: 'templates/Schedule/Schedule.html?build=' + build
    });
    $routeProvider.when('/Accounts/:ID/:ScheduleID', {
        templateUrl: 'templates/Schedule/Accounts.html?build=' + build
    });
    $routeProvider.when('/VoucherTypeList', {
        templateUrl: 'templates/VT/VoucherTypeList.html?build=' + build
    });
    $routeProvider.when('/VoucherType/:VTID', {
        templateUrl: 'templates/VT/VoucherType.html?build=' + build
    });
    $routeProvider.when('/VEList', {
        templateUrl: 'templates/VE/VEList.html?build=' + build
    });
    $routeProvider.when('/VE/:VEID', {
        templateUrl: 'templates/VE/VE.html?build=' + build
    });
    $routeProvider.when('/WingsList', {
        templateUrl: 'templates/Wings/WingsList.html?build=' + build
    });
    $routeProvider.when('/Wings/:WingID', {
        templateUrl: 'templates/Wings/Wings.html?build=' + build
    });
    $routeProvider.when('/MsgList', {
        templateUrl: 'templates/Msg/MsgList.html?build=' + build
    });
    $routeProvider.when('/SMSList', {
        templateUrl: 'templates/Msg/SMSList.html?build=' + build
    });

    $routeProvider.when('/VMList', {
        templateUrl: 'templates/VM/VMList.html?build=' + build
    });
    $routeProvider.when('/VMListing', {
        templateUrl: 'templates/VM/VMListing.html?build=' + build
    });
    $routeProvider.when('/VM/:VMID', {
        templateUrl: 'templates/VM/VM.html?build=' + build
    });
    $routeProvider.when('/FCList', {
        templateUrl: 'templates/FC/FCList.html?build=' + build
    });
    $routeProvider.when('/FC/:FCID', {
        templateUrl: 'templates/FC/FC.html?build=' + build
    });
    $routeProvider.when('/BookingsList', {
        templateUrl: 'templates/BS/BookingsList.html?build=' + build
    });
    $routeProvider.when('/BS/:BookingID', {
        templateUrl: 'templates/BS/Bookings.html?build=' + build
    });
    $routeProvider.when('/Rules', {
        templateUrl: 'templates/Rules/Rules.html?build=' + build
    });
    $routeProvider.when('/SocRules', {
        templateUrl: 'templates/Rules/SocRules.html?build=' + build
    });
    $routeProvider.when('/GKList', {
        templateUrl: 'templates/GK/GKList.html?build=' + build
    });
    $routeProvider.when('/GK/:GKID', {
        templateUrl: 'templates/GK/GK.html?build=' + build
    });
    $routeProvider.when('/WPList', {
        templateUrl: 'templates/WP/WPList.html?build=' + build
    });
    $routeProvider.when('/WP/:WPID', {
        templateUrl: 'templates/WP/WP.html?build=' + build
    });
    $routeProvider.when('/PenaltyList', {
        templateUrl: 'templates/Penalty/PenaltyList.html?build=' + build
    });
    $routeProvider.when('/Penalty/:PNID', {
        templateUrl: 'templates/Penalty/Penalty.html?build=' + build
    });
    $routeProvider.when('/MTList', {
        templateUrl: 'templates/MT/MTList.html?build=' + build
    });
    $routeProvider.when('/MT/:MTID', {
        templateUrl: 'templates/MT/MT.html?build=' + build
    });
    $routeProvider.when('/MOM/:MTID', {
        templateUrl: 'templates/MT/MOM.html?build=' + build
    });
    $routeProvider.when('/DirectoryList', {
        templateUrl: 'templates/Directory/DirectoryList.html?build=' + build
    });
    $routeProvider.when('/Directory/:ID', {
        templateUrl: 'templates/Directory/Directory.html?build=' + build
    });
    $routeProvider.when('/CMListing', {
        templateUrl: 'templates/CM/CMListing.html?build=' + build
    });
    $routeProvider.when('/FMList/:FMType', {
        templateUrl: 'templates/FM/FMList.html?build=' + build
    });
    $routeProvider.when('/FM/:FMID/:FMType', {
        templateUrl: 'templates/FM/FM.html?build=' + build
    });
    $routeProvider.when('/CPListing', {
        templateUrl: 'templates/CP/CPListing.html?build=' + build
    });
    $routeProvider.when('/PLListing', {
        templateUrl: 'templates/PL/PLListing.html?build=' + build
    });
    $routeProvider.when('/PaymentsList', {
        templateUrl: 'templates/Payments/PaymentsList.html?build=' + build
    });
    $routeProvider.when('/Payments/:PaymentID/:RoomID/:BillID/:ReqID', {
        templateUrl: 'templates/Payments/Payments.html?build=' + build
    });
    $routeProvider.when('/MiscBills', {
        templateUrl: 'templates/Bills/MiscBills.html?build=' + build
    });
    $routeProvider.when('/MiscBillDetails', {
        templateUrl: 'templates/Bills/BSUMisc.html?build=' + build
    });
    $routeProvider.when('/BillTerms', {
        templateUrl: 'templates/Rules/BillTerms.html?build=' + build
    });
    $routeProvider.when('/UnitStatement', {
        templateUrl: 'templates/Rooms/UnitStatement.html?build=' + build
    });
    $routeProvider.when('/PaymentUpload', {
        templateUrl: 'templates/Folder/PaymentUpload.html?build=' + build
    });
    $routeProvider.when('/SMSCreditList', {
        templateUrl: 'templates/SMSCredit/SMSCreditList.html?build=' + build
    });
    $routeProvider.when('/SMSCredit/:ID', {
        templateUrl: 'templates/SMSCredit/SMSCredit.html?build=' + build
    });
    $routeProvider.when('/Defaulters', {
        templateUrl: 'templates/Bills/Defaulters.html?build=' + build
    });
    $routeProvider.when('/BillRegister', {
        templateUrl: 'templates/Bills/BillRegister.html?build=' + build
    });
    $routeProvider.when('/UnitDetails', {
        templateUrl: 'templates/Rooms/UnitListing.html?build=' + build
    });
    $routeProvider.when('/PayAndDue', {
        templateUrl: 'templates/PaymentReq/PayAndDue.html?build=' + build
    });
    $routeProvider.when('/PaymentReqList', {
        templateUrl: 'templates/PaymentReq/PaymentReqList.html?build=' + build
    });
    $routeProvider.when('/PaymentHistory', {
        templateUrl: 'templates/PaymentReq/PaymentHistory.html?build=' + build
    });
    $routeProvider.when('/ChatList', {
        templateUrl: 'templates/Chat/ChatList.html?build=' + build
    });
    $routeProvider.when('/GKRoomList', {
        templateUrl: 'templates/GK/RoomsList.html?build=' + build
    });
    $routeProvider.when('/BookingsListing', {
        templateUrl: 'templates/BS/BookingsListing.html?build=' + build
    });
    $routeProvider.when('/VendorsList/:VendorType', {
        templateUrl: 'templates/Vendors/VendorsList.html?build=' + build
    });
    $routeProvider.when('/Vendors/:VendorID/:VendorType', {
        templateUrl: 'templates/Vendors/Vendors.html?build=' + build
    });
    $routeProvider.when('/RolesList', {
        templateUrl: 'templates/Roles/RolesList.html?build=' + build
    });
    $routeProvider.when('/Roles/:RoleID', {
        templateUrl: 'templates/Roles/Roles.html?build=' + build
    });
    $routeProvider.when('/PayTMAuthKey', {
        templateUrl: 'templates/PayTM/AuthKey.html?build=' + build
    });
    $routeProvider.when('/ExpReportList', {
        templateUrl: 'templates/Exp/ExpReportList.html?build=' + build
    });

    $routeProvider.otherwise({ redirectTo: '/login' });
    $httpProvider.interceptors.push('RequestsErrorHandler');
}]).
directive('jqdatepicker', function ($filter) {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, element, attrs, ngModelCtrl) {
            element.datepicker({
                dateFormat: 'dd-M-yy',
                changeYear: true,
                changeMonth: true,
                onSelect: function (date) {
                    //var ar = date.split("/");
                    //date = new Date(ar[2] + "-" + ar[1] + "-" + ar[0]);
                    ngModelCtrl.$setViewValue(date);
                    scope.$apply();
                }
            });
            ngModelCtrl.$formatters.unshift(function (v) {
                return $filter('date')(v, 'dd-MMM-yyyy');
            });

        }
    };
})
.factory('GridData', function () {
    var self = this;
    self.GridName = '';
    self.PageSize = 10;
    self.CurrentPage = 10;
    self.OrderBy = '';
    self.OrderDir = '';
    self.SearchText = '';

    return self;
})
.factory('User', function () {
    var self = this;
    self.UserID = 0;
    self.Token = '';
    self.UserName = '';
    self.FirstName = '';
    self.LastName = '';
    self.ImageUrl = '';
    self.MenuItems = [];
    self.SocName = '';
    self.WPID = 0;
    self.WPName = '';
    self.Verified = false;
    self.SocList = [];
    self.RMList = [];
    self.ForcedRMLogin = false;
    self.ShowAd = true;
    return self;
})
.controller('MenuController', function ($scope, User, $http, $location, $route, $rootScope) {
    $scope.User = User;

    $scope.showModal = false;
    $scope.showModalSoc = false;
    $scope.IsLoggedIn = User.UserID > 0 ? true : false;
    angular.element(document).ready(function () {
        $http({
            method: 'POST',
            url: 'api/Common/LoadUserFromSession'
        }).success(function (result) {
            if (result != null) {
                User.Verified = result.Verified;
                if (User.Verified != null && User.Verified == false) {
                    alert('Your account is not Verified. Please verify your account by clicking on Verify link sent to your email.')
                    $location.path("/logout");
                    return;
                }
                User.CityID = result.CityID;
                User.UserID = result.UserID;
                User.UserType = result.UserType;
                User.Token = result.Token;
                User.UserName = result.UserName;
                User.FirstName = result.FirstName;
                User.LastName = result.LastName;
                User.ImageUrl = result.ImageUrl;
                User.MenuItems = result.MenuItems;
                User.SocName = result.SocName;
                User.SocList = result.SocList;
                User.RMList = result.RMList;
                User.ForcedRMLogin = result.ForcedRMLogin;
                User.WPName = result.WPName;
                User.WPID = result.WPID;
                $http.defaults.headers.post['Token'] = result.Token;
                $http.defaults.headers.post['UserID'] = result.UserID;
                $http.defaults.headers.get = { Token: result.Token, UserID: result.UserID };
                $.connection.hub.start().done(function () {
                    $.connection.chatHub.server.joinChatNotification(User.UserID);
                });
                if (User.UserType == 2) {
                    //$location.path('/adminHome');
                    $('.logo').attr('href', '#/adminHome');
                }
                else if (User.UserType == 9) {
                    //$location.path('/VMList');
                    $('.logo').attr('href', '#/VMList');
                }
                else if (User.UserType == 8) {
                    //$location.path('/PayTMHome');
                    $('.logo').attr('href', '#/PayTMHome');
                }
                else {
                    //$location.path('/home');
                    $('.logo').attr('href', '#/home');
                }
                $scope.searchAlert();
            }
        });
    });

    $scope.WP = { WPID: null, SocID: null };
    $scope.showWPChange = function () {
        $scope.showModal = true;
        $scope.bindYear();
    };
    $scope.yearlist = [];
    $scope.bindYear = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetYearList', Data: null })
        }).success(function (data) {
            $scope.yearlist = data;
        });
    };
    $scope.changeWP = function () {
      
        if ($scope.WP.WPID == null || $scope.WP.WPID <= 0) {
            alert('Please select a Financial Year');
            return;
        }
       
        $http({
            method: 'POST',
            url: 'api/Common/ChangeWP',
            data: JSON.stringify($scope.WP.WPID)
        }).success(function (data) {
            $scope.showModal = false;
            User.WPID = data.WPID;
            User.WPName = data.WPName;
            
            $location.path("/adminHome");
        });
    };

    $scope.showSocChange = function () {
        $scope.showModalSoc = true;
        $scope.bindSoc();
    };
    $scope.soclist = [];
    $scope.bindSoc = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetMySocList', Data: null })
        }).success(function (data) {
            $scope.soclist = data;
        });
    };

    $scope.switchToRMView = function () {
        $http({
            method: 'POST',
            url: 'api/Common/SwitchToRMView'
        }).success(function (result) {
            User.CityID = result.CityID;
            User.UserID = result.UserID;
            User.UserType = result.UserType;
            User.Token = result.Token;
            User.UserName = result.UserName;
            User.FirstName = result.FirstName;
            User.LastName = result.LastName;
            User.ImageUrl = result.ImageUrl;
            User.MenuItems = result.MenuItems;
            User.SocName = result.SocName;
            User.SocList = result.SocList;
            User.RMList = result.RMList;
            User.ForcedRMLogin = result.ForcedRMLogin;
            User.WPName = result.WPName;
            User.WPID = result.WPID;
            $location.path('/home');
            $('.logo').attr('href', '#/home');
            $route.reload();
        });
    };
    $scope.switchToAdminView = function () {
        $http({
            method: 'POST',
            url: 'api/Common/SwitchToAdminView'
        }).success(function (result) {
            User.CityID = result.CityID;
            User.UserID = result.UserID;
            User.UserType = result.UserType;
            User.Token = result.Token;
            User.UserName = result.UserName;
            User.FirstName = result.FirstName;
            User.LastName = result.LastName;
            User.ImageUrl = result.ImageUrl;
            User.MenuItems = result.MenuItems;
            User.SocName = result.SocName;
            User.SocList = result.SocList;
            User.RMList = result.RMList;
            User.ForcedRMLogin = result.ForcedRMLogin;
            User.WPName = result.WPName;
            User.WPID = result.WPID;
            $location.path('/adminHome');
            $('.logo').attr('href', '#/adminHome');
            $route.reload();
        });
    };
    $scope.changeSoc = function () {
        if ($scope.WP.SocID == null || $scope.WP.SocID <= 0) {
            alert('Please select a Society');
            return;
        }
        $http({
            method: 'POST',
            url: 'api/Common/ChangeSoc',
            data: JSON.stringify($scope.WP.SocID)
        }).success(function (result) {
            $scope.showModalSoc = false;
            User.CityID = result.CityID;
            User.UserID = result.UserID;
            User.UserType = result.UserType;
            User.Token = result.Token;
            User.UserName = result.UserName;
            User.FirstName = result.FirstName;
            User.LastName = result.LastName;
            User.ImageUrl = result.ImageUrl;
            User.MenuItems = result.MenuItems;
            User.SocName = result.SocName;
            User.SocList = result.SocList;
            User.RMList = result.RMList;
            User.ForcedRMLogin = result.ForcedRMLogin;
            User.WPName = result.WPName;
            User.WPID = result.WPID;
            $route.reload();
        });
    };

    $rootScope.$on('$routeChangeStart', function (event, next, current) {
        $('body').removeClass('sidebar-open');
    });

    $scope.Total = 0;
    $scope.AlertList = [];
    $scope.searchAlert = function () {
        $http({
            method: 'POST',
            url: 'api/Alert/GetList/'
        }).success(function (ALs) {
            $scope.AlertList = ALs;
            $scope.Total = $scope.AlertList.length;
        });
    };
    $scope.markReadAlert = function () {
        $http({
            method: 'POST',
            url: 'api/Alert/MarkRead/'
        }).success(function (ALs) {
            $scope.Total = 0;
        });
    };
})
.controller('MemberLoginController', function ($scope, User, $http, $routeParams, $location) {
    var UserID = $routeParams.UserID;
    var Password = $routeParams.Password;
    $scope.login = function () {
        $http({
            method: 'POST',
            url: 'api/Common/LoginMember',
            data: JSON.stringify({ UserName: $routeParams.UserID, Password: $routeParams.Password })
        }).success(function (result) {
            if (result == null) {
                alert('Invalid Username or Password');
                $scope.LoginUser.Password = '';
                User.UserID = 0;
                User.Token = '';
                User.FirstName = User.LastName = User.UserName = User.ImageUrl = '';
                User.MenuItems = [];
            }
            else {
                User.Verified = result.Verified;
                if (User.Verified != null && User.Verified == false) {
                    alert('Your account is not Verified. Please verify your account by clicking on Verify link sent to your email.')
                    $location.path("/logout");
                    return;
                }
                User.UserID = result.UserID;
                User.Token = result.Token;
                User.UserName = result.UserName;
                User.UserType = result.UserType;
                User.FirstName = result.FirstName;
                User.LastName = result.LastName;
                User.ImageUrl = result.ImageUrl;
                User.SocName = result.SocName;
                User.WPName = result.WPName;
                User.SocList = result.SocList;
                User.RMList = result.RMList;
                User.ForcedRMLogin = result.ForcedRMLogin;
                User.WPID = result.WPID;
                User.ShowAd = true;
                User.MenuItems = result.MenuItems;
                $http.defaults.headers.post['Token'] = result.Token;
                $http.defaults.headers.post['UserID'] = result.UserID;
                $http.defaults.headers.get = { Token: result.Token, UserID: result.UserID };
                window.document.title = result.SocName;
                $.connection.hub.start().done(function () {
                    $.connection.chatHub.server.joinChatNotification(User.UserID);
                });
                if (User.UserType == 2) {
                    $location.path('/adminHome');
                    $('.logo').attr('href', '#/adminHome');
                }
                else if (User.UserType == 9) {
                    $location.path('/VMList');
                    $('.logo').attr('href', '#/VMList');
                }
                else if (User.UserType == 8) {
                    $location.path('/PayTMHome');
                    $('.logo').attr('href', '#/PayTMHome');
                }
                else {
                    $location.path('/home');
                    $('.logo').attr('href', '#/home');
                }
                angular.element('#alertLI').scope().searchAlert();
                angular.element('#alertLI').scope().$apply()
            }
        });
    };
    $scope.login();
})
.controller('LogoutController', function ($scope, User, $http) {
    $http({
        method: 'POST',
        url: 'api/Common/Logout'
    }).success(function (result) {
        User.UserID = 0;
        User.FirstName = User.LastName = User.Token = User.ImageUrl = '';
        User.WPName = '';
        User.WPID = 0;
        User.MenuItems = [];
        User.SocList = [];
        User.RMList = [];
        User.ForcedRMLogin = false;
        $http.defaults.headers.post['Token'] = '';
        $http.defaults.headers.post['UserID'] = 0;
        $http.defaults.headers.get = { Token: '', UserID: 0 };
    });
})
.controller('CPController', function ($scope, User, $http) {
    $scope.CP = { OldPassword: '', NewPassword: '', ConfirmPassword: '', UserID: 0 };
    $scope.changePassword = function () {
        $scope.CPSubmitted = true;
        if ($scope.formCP.$invalid == true) return;
        if ($scope.CP.NewPassword != $scope.CP.ConfirmPassword) {
            swal({ title: "New Password and Confirmn Password must be same!", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        $scope.CP.UserID = User.UserID;
        $http({
            method: 'POST',
            url: 'api/Common/ChangePassword',
            data: JSON.stringify($scope.CP)
        }).success(function (result) {
            if (result == "Invalid") {
                swal({ title: "Invalid Old Password, Password not changed!", type: "error", timer: 1000, showConfirmButton: false });
            }
            else if (result == "Changed") {
                swal({ title: "Password changed successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        });
    };
})

.controller('LoginController', function ($scope, $http, $location, User) {
    //$scope.LoginUser = { UserName: 'awadh@mailinator.com', Password: 'test' };
    $scope.LoginUser = { UserName: 'admin@gmail.com', Password: 'admin123' };
    //$scope.LoginUser = { UserName: '', Password: '' };
    $scope.FPShow = false;
    $scope.FP = { UserName: '' };
    $scope.register = function () {
        $location.path('/Register');
    };
    $scope.login = function () {
        $scope.LoginSubmitted = true;
        if ($scope.formLogin.$invalid == true) return;
        $http({
            method: 'POST',
            url: 'api/Common/Login',
            data: JSON.stringify($scope.LoginUser)
        }).success(function (result) {
            if (result == null) {
                alert('Invalid Username or Password');
                $scope.LoginUser.Password = '';
                User.UserID = 0;
                User.Token = '';
                User.FirstName = User.LastName = User.UserName = User.ImageUrl = '';
                User.MenuItems = [];
            }
            else {
                User.Verified = result.Verified;
                if (User.Verified != null && User.Verified == false) {
                    alert('Your account is not Verified. Please verify your account by clicking on Verify link sent to your email.')
                    $location.path("/logout");
                    return;
                }
                User.UserID = result.UserID;
                User.Token = result.Token;
                User.UserName = result.UserName;
                User.FirstName = result.FirstName;
                User.LastName = result.LastName;
                User.ImageUrl = result.ImageUrl;
                User.MenuItems = result.MenuItems;
                User.UserType = result.UserType;
                User.SocName = result.SocName;
                User.SocList = result.SocList;
                User.RMList = result.RMList;
                User.ForcedRMLogin = result.ForcedRMLogin;
                User.WPName = result.WPName;
                User.WPID = result.WPID;
                User.ShowAd = true;
                $http.defaults.headers.post['Token'] = result.Token;
                $http.defaults.headers.post['UserID'] = result.UserID;
                $http.defaults.headers.get = { Token: result.Token, UserID: result.UserID };
                window.document.title = result.SocName;

                $.connection.hub.start().done(function () {
                    $.connection.chatHub.server.joinChatNotification(User.UserID);
                });
                if (User.UserType == 2) {
                    $location.path('/adminHome');
                    $('.logo').attr('href', '#/adminHome');
                }
                else if (User.UserType == 8) {
                    $location.path('/PayTMHome');
                    $('.logo').attr('href', '#/PayTMHome');
                }
                else if (User.UserType == 9) {
                    $location.path('/VMList');
                    $('.logo').attr('href', '#/VMList');
                }
                else {
                    $location.path('/home');
                    $('.logo').attr('href', '#/home');
                }

                angular.element('#alertLI').scope().searchAlert();
                angular.element('#alertLI').scope().$apply()
            }
        })
    };
    $scope.forgotPassword = function () {
        $scope.FPShow = true;
        $scope.FP.UserName = '';
    };
    $scope.submitFP = function () {
        if ($scope.FP.UserName == '') {
            swal({ title: "Please enter Username!", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        $http({
            method: 'POST',
            url: 'api/Common/ForgotPassword',
            data: JSON.stringify({ UserName: $scope.FP.UserName })
        }).success(function (result) {
            if (result == "Success") {
                swal({ title: "New Password has been sent to your Registered Email/Mobile!", type: "success", timer: 5000, showConfirmButton: false });
            }
            else {
                swal({ title: result, type: "error", timer: 1000, showConfirmButton: false });
            }
            $scope.FPShow = false;
        });
    };
})
.directive('modal', function () {
    return {
        template: '<div class="modal fade">' +
            '<div class="modal-dialog">' +
              '<div class="modal-content">' +
                '<div class="modal-header">' +
                  '<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>' +
                  '<h4 class="modal-title"></h4>' +
                '</div>' +
                '<div class="modal-body" ng-transclude></div>' +
              '</div>' +
            '</div>' +
          '</div>',
        restrict: 'E',
        transclude: true,
        replace: true,
        scope: true,
        link: function postLink(scope, element, attrs) {
            scope.$watch(attrs.title, function (value) {
                $(element).find('.modal-title').html(value);
            });
            scope.$watch(attrs.type, function (value) {
                $(element).addClass(value);
            });
            scope.$watch(attrs.visible, function (value) {
                if (value == true)
                    $(element).modal('show');
                else
                    $(element).modal('hide');
            });

            $(element).on('shown.bs.modal', function () {
                scope.$apply(function () {
                    scope.$parent[attrs.visible] = true;
                });
            });

            $(element).on('hidden.bs.modal', function () {
                scope.$apply(function () {
                    scope.$parent[attrs.visible] = false;
                });
            });
        }
    };
}).directive('modalbig', function () {
    return {
        template: '<div class="modal modal-wide fade">' +
            '<div class="modal-dialog">' +
              '<div class="modal-content">' +
                '<div class="modal-header">' +
                  '<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>' +
                  '<h4 class="modal-title"></h4>' +
                '</div>' +
                '<div class="modal-body" ng-transclude></div>' +
              '</div>' +
            '</div>' +
          '</div>',
        restrict: 'E',
        transclude: true,
        replace: true,
        scope: true,
        link: function postLink(scope, element, attrs) {
            scope.$watch(attrs.title, function (value) {
                $(element).find('.modal-title').html(value);
            });
            scope.$watch(attrs.type, function (value) {
                $(element).addClass(value);
            });
            scope.$watch(attrs.visible, function (value) {
                if (value == true)
                    $(element).modal('show');
                else
                    $(element).modal('hide');
            });

            $(element).on('shown.bs.modal', function () {
                scope.$apply(function () {
                    scope.$parent[attrs.visible] = true;
                });
            });

            $(element).on('hidden.bs.modal', function () {
                scope.$apply(function () {
                    scope.$parent[attrs.visible] = false;
                });
            });
        }
    };
}).directive('modalwide', function () {
    return {
        template: '<div class="modal modal-morewide fade">' +
            '<div class="modal-dialog">' +
              '<div class="modal-content">' +
                '<div class="modal-header">' +
                  '<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>' +
                  '<h4 class="modal-title"></h4>' +
                '</div>' +
                '<div class="modal-body" ng-transclude></div>' +
              '</div>' +
            '</div>' +
          '</div>',
        restrict: 'E',
        transclude: true,
        replace: true,
        scope: true,
        link: function postLink(scope, element, attrs) {
            scope.$watch(attrs.title, function (value) {
                $(element).find('.modal-title').html(value);
            });
            scope.$watch(attrs.type, function (value) {
                $(element).addClass(value);
            });
            scope.$watch(attrs.visible, function (value) {
                if (value == true)
                    $(element).modal('show');
                else
                    $(element).modal('hide');
            });

            $(element).on('shown.bs.modal', function () {
                scope.$apply(function () {
                    scope.$parent[attrs.visible] = true;
                });
            });

            $(element).on('hidden.bs.modal', function () {
                scope.$apply(function () {
                    scope.$parent[attrs.visible] = false;
                });
            });
        }
    };
}).directive('head', ['$rootScope', '$compile',
    function ($rootScope, $compile) {
        return {
            restrict: 'E',
            link: function (scope, elem) {
                var html = '<link rel="stylesheet" ng-repeat="(routeCtrl, cssUrl) in routeStyles" ng-href="{{cssUrl}}" />';
                elem.append($compile(html)(scope));
                scope.routeStyles = {};
                $rootScope.$on('$routeChangeStart', function (e, next, current) {
                    if (current && current.$$route && current.$$route.css) {
                        if (!angular.isArray(current.$$route.css)) {
                            current.$$route.css = [current.$$route.css];
                        }
                        angular.forEach(current.$$route.css, function (sheet) {
                            delete scope.routeStyles[sheet];
                        });
                    }
                    if (next && next.$$route && next.$$route.css) {
                        if (!angular.isArray(next.$$route.css)) {
                            next.$$route.css = [next.$$route.css];
                        }
                        angular.forEach(next.$$route.css, function (sheet) {
                            scope.routeStyles[sheet] = sheet;
                        });
                    }
                });
            }
        };
    }
]).directive('imageuploader', function () {
    return {
        restrict: 'E',
        replace: true,
        templateUrl: 'templates/image-uploader.html'
    }
}).directive('loading', ['$http', function ($http) {
    return {
        restrict: 'A',
        link: function (scope, elm, attrs) {
            scope.isLoading = function () {
                return $http.pendingRequests.length > 0;
            };

            scope.$watch(scope.isLoading, function (v) {
                if (v) {
                    elm.show();
                } else {
                    elm.hide();
                }
            });
        }
    };

}]).filter('trustAsResourceUrl', ['$sce', function ($sce) {
    return function (val) {
        return $sce.trustAsHtml(val);
    };
}]).directive('myEnter', function () {
    return function (scope, element, attrs) {
        element.bind("keydown keypress", function (event) {

            if (event.which === 13) {
                scope.$apply(function () {
                    scope.$eval(attrs.myEnter);
                });

                event.preventDefault();
            }
        });
    };
})
.directive('fileModel', ['$parse', function ($parse) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;

            element.bind('change', function () {
                scope.$apply(function () {
                    modelSetter(scope, element[0].files[0]);
                });
            });
        }
    };
}]);

//**//
function goBack() {
    window.history.back();
}
window.addEventListener("message", receiveMessage, false);
//**//
function receiveMessage(event) {
    if (event.data == "Back") {
        goBack();
    }
}

