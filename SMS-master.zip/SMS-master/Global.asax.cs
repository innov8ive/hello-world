﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Routing;
using System.Web.Security;
using System.Web.SessionState;
using System.Web.Http;
using System.Data;

namespace SampleAngular
{
    public class Global : HttpApplication
    {
        void Application_Start(object sender, EventArgs e)
        {
            // Code that runs on application startup
            GlobalConfiguration.Configure(WebApiConfig.Register);

            System.Reflection.Assembly assembly = System.Reflection.Assembly.GetExecutingAssembly();
            System.IO.FileInfo fileInfo = new System.IO.FileInfo(assembly.Location);
            DateTime lastModified = fileInfo.LastWriteTime;

            Application["builddate"] = lastModified.ToString("ddMMyyyyhhMMss");
           
            //Common.CreateSchedule(16);
            //Common.CreateAccounts(16);
            //Common.GetDelayCharge(9, Common.ToDate("2017-08-15"));

            //Common.SendBillNotification(17, "SAI SHRUSHTI HEIGHTS");
        }

        protected void Application_PostAuthorizeRequest()
        {
                HttpContext.Current.SetSessionStateBehavior(SessionStateBehavior.Required);
        }
        
    }
}