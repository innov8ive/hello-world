﻿<%@ Page Language="C#" AutoEventWireup="True" CodeBehind="PrintBill.aspx.cs" Inherits="SampleAngular.PrintBill" EnableViewState="false" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title></title>
    <style type="text/css">
        table
        {
            font-size: 11px;
        }

            table.details td
            {
                border-bottom: solid 1px black;
                border-right: solid 1px black;
            }

            table.tblFooter td
            {
                padding-top: 15px;
            }

            table.noborder td
            {
                border-bottom: solid 0px black;
                border-right: solid 0px black;
            }
    </style>
</head>
<body style="font-family: Arial; font-size: 12px;">
    <form id="form1" runat="server">
        <div>
            <asp:Repeater ID="Repeater1" runat="server" OnItemDataBound="Repeater1_ItemDataBound">
                <ItemTemplate>
                    <table style="width: 100%; border-collapse: collapse; border-left: solid 1px black; border-top: solid 1px black;" cellpadding="3" class=" noborder" cellspacing="0">
                        <tr>
                            <td style="text-align: center;" width="100">
                                <asp:Image id="imgLogo"  runat="server" width="100"/>
                            </td>
                            <td style="text-align: center;">
                                <asp:HiddenField ID="hdnBillID" runat="server" Value='<%#Eval("BillID") %>' />
                                <table cellpadding="4" cellspacing="0" class="noborder" style="width: 100%; font-size: 10px;">
                                    <tr>
                                        <td style="font-size: 18px">
                                            <asp:Label ID="lbSocName" runat="server" Text='<%#Eval("SocName") %>'></asp:Label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <asp:Label ID="lbSocAddress" runat="server" Text='<%#Eval("SocAddress1") %>'></asp:Label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <asp:Label ID="lbSocAddress1" runat="server" Text='<%#Eval("SocAddress2") %>'></asp:Label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <asp:Label ID="lbSocAddress2" runat="server" Text='<%#Eval("City")+" - "+Eval("ZipCode")+", "+Eval("StateName") %>'></asp:Label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <asp:Label ID="lbContact" runat="server" Text='<%# "Contact No: "+ Eval("ContactNo")%>'></asp:Label>, <asp:Label ID="lbEmail" runat="server" Text='<%# "Email: "+ Eval("SocEmail")%>'></asp:Label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                           Registration No. <asp:Label ID="lbRegNo" runat="server" Font-Bold="true" Text='<%#Eval("RegNo")%>'></asp:Label>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                            <td width="150" style="vertical-align:top;border-right: solid 1px black;" >
                                <table cellpadding="4" cellspacing="0" class="noborder" style="width: 100%;">
                                    <tr>
                                        <td style="font-size: 15px" colspan="2">
                                            
                                                <asp:Label ID="lbBillName" runat="server" Text='<%#Eval("BillName") %>'></asp:Label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <b>Bill No:</b>
                                        </td>
                                        <td>
                                            <asp:Label ID="lbBillNo" runat="server" Text='<%#Eval("BillID") %>'></asp:Label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <b>Bill Date:
                                            </b>
                                        </td>
                                        <td>
                                            <asp:Label ID="lbBillDate" runat="server"
                                                Text='<%#DataBinder.Eval(Container.DataItem, "BillDate", "{0:dd-MMM-yyyy}")%>'>
                                            </asp:Label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <b>Due Date:
                                            </b>
                                        </td>
                                        <td>
                                            <asp:Label ID="lbDueDate" runat="server" Text='<%#DataBinder.Eval(Container.DataItem, "DueDate", "{0:dd-MMM-yyyy}") %>'></asp:Label>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="3" style="border-right: solid 1px black; border-top: solid 1px black;"">
                                <table style="width: 100%;" class="noborder" cellpadding="4">
                                    <tr>
                                        <td  style="text-align: right;">
                                           <b> Unit ID:</b>
                                        </td>
                                        <td>
                                            <asp:Label ID="Label1" runat="server" Text='<%#Eval("RoomID") %>'></asp:Label>
                                        </td>
                                        <td>
                                            <b>
                                                <asp:Label ID="lbName" runat="server" Text='<%#Eval("Name") %>'></asp:Label>
                                            </b>
                                        </td>
                                        <td style="text-align: right;">
                                            <b>Unit No:
                                            </b>
                                        </td>
                                        <td>
                                            <asp:Label ID="lbUnitNo" runat="server" Text='<%#Eval("RoomNo") %>'></asp:Label>
                                        </td>
                                        <td style="text-align: right;">
                                            <b>Area(SQFT):
                                            </b>
                                        </td>
                                        <td width="50">
                                            <asp:Label ID="lbSQFT" runat="server" Text='<%#Eval("Area") %>'></asp:Label>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                    <table style="width: 100%; border-collapse: collapse; border-left: solid 1px black; border-top: solid 1px black;" cellpadding="4" class="details">
                        <tr style="background-color: gray; color: white;">
                            <td style="border-right: solid 1px black;" width="10"><b>Sr. No.</b></td>
                            <td style="border-right: solid 1px black;"><b>Particulars</b></td>
                            <td style="border-right: solid 1px black;" width="20"><b>Amount</b></td>
                        </tr>
                        <asp:Repeater ID="rptDetails" runat="server">
                            <ItemTemplate>
                                <tr>
                                    <td><%#(((RepeaterItem)Container).ItemIndex+1).ToString()%></td>
                                    <td><%#Eval("AccountName") %></td>
                                    <td>
                                        <%#SampleAngular.Common.ToDecimal( Eval("Amt")).ToString("0.00") %>
                                    </td>
                                </tr>
                            </ItemTemplate>
                        </asp:Repeater>
                        <tr>
                            <td colspan="2" style="text-align: right;"><b>Total</b></td>
                            <td>
                                <b>
                                    <asp:Label runat="server" ID="lbAmount" Text='<%#SampleAngular.Common.ToDecimal( Eval("Amount")).ToString("0.00") %>'></asp:Label>
                                </b>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="text-align: right;"><b>Previous Due</b></td>
                            <td>
                                <b>
                                    <asp:Label runat="server" ID="lbOutstanding" Text='<%#SampleAngular.Common.ToDecimal( Eval("Outstanding")).ToString("0.00") %>'></asp:Label>
                                </b>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="text-align: right;"><b>Interest on Due</b></td>
                            <td>
                                <asp:Label runat="server" ID="lbLF" Text='<%#SampleAngular.Common.ToDecimal( Eval("LF")).ToString("0.00") %>'></asp:Label>
                            </td>
                        </tr>
                         <tr id="trAdjustment" runat="server">
                            <td colspan="2" style="text-align: right;"><b>Adjustment</b></td>
                            <td>
                                <asp:Label runat="server" ID="lbAdjustment" Text='<%#SampleAngular.Common.ToDecimal( Eval("Adjustment")).ToString("0.00") %>'></asp:Label>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="text-align: right;"><b>GRAND TOTAL</b></td>
                            <td>
                                <b>
                                    <asp:Label runat="server" ID="lbTotalBillAmount" Text='<%#SampleAngular.Common.ToDecimal( Eval("TotalBillAmount")).ToString("0.00") %>'></asp:Label>
                                </b>
                            </td>
                        </tr>
                    </table>
                    <table style="width: 100%; border-collapse: collapse; border-left: solid 1px black;" cellpadding="4" class="details">
                        <tr>
                            <td>
                                <b>Amount in Words: </b>
                                <asp:Label ID="lbTotalInWords" runat="server"></asp:Label>
                            </td>
                        </tr>
                        <tr>
                            <td style="font-size:11px;">
                                <asp:Label ID="lbTermsCond" runat="server" Text='<%#Eval("BillTerms") %>'></asp:Label>
                            </td>
                        </tr>
                        <tr>
                            <td style="text-align: right;">
                                <h4>For 
                                    <asp:Label ID="lbSocName2" runat="server" Text='<%#Eval("SocName") %>'></asp:Label>
                                </h4>
                                Chairman / Secretary / Treasure
                            </td>
                        </tr>
                        <tr>
                            <td style="font-size:11px;text-align:center;">
                                This is computer generated bill hence no signature required.
                            </td>
                        </tr>
                    </table>
                    <div id="divPageBreak" runat="server">&nbsp;</div>
                </ItemTemplate>
            </asp:Repeater>
        </div>
    </form>
</body>
</html>
