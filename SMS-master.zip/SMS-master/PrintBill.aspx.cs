﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.tool.xml;
using SampleAngularBL;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Text;
using SampleAngularOM;
using System.Web.Configuration;

namespace SampleAngular
{
    public partial class PrintBill : System.Web.UI.Page
    {
        BillsBL objBL;
        LoggedUser objLoggedUser;
        protected void Page_Load(object sender, EventArgs e)
        {
            objLoggedUser = HttpContext.Current.Session["LoggedUser"] as LoggedUser;
            if (!IsPostBack)
            {
                int BillID = Common.ToInt(Request.QueryString["BillID"]);
                if (Request.QueryString["BillGUID"] != null)
                {
                    try
                    {
                        BillID = Common.ToInt(Common.DeSerialize(Request.QueryString["BillGUID"]));
                    }
                    finally { }
                }
                string BillTitle = Common.ToString(Request.QueryString["BillTitle"]);
                StringBuilder query = new StringBuilder(@"select B.RoomID,B.TotalBillAmount,B.Discount
,B.BillType,B.BillID,B.Remarks,B.PaidDate,B.Discount,
W.WingName+' '+R.RoomNo as RoomNo,
Usr.PersonName as Name,
B.BillDate,Rules.BillTerms
,B.Outstanding,B.PaidAmount,B.Amount,B.LF,ISNULL(B.BillTitle,BSU.Name) as BillName
,S.SocName,S.RegNo,R.Area,DATEADD(dd,B.Term,B.BillDate) as DueDate,
S.SocAddress1, S.SocAddress2,S.City,S.ZipCode,S.ContactNo,S.SocEmail,ST.StateName,B.Adjusted,B.Adjustment,
S.ImageUrl as Logo from Bills B
inner join Rooms R ON B.RoomID=R.RoomID
inner join Wings W ON R.WingID=W.WingID
outer apply
(
select top 1 U.FirstName+ISNULL(' '+U.LastName,'')+ISNULL('/'+U.CoApplicantName,'') as PersonName,U.UserID
from UserRooms UR
inner join Users U ON UR.UserID=U.UserID and UR.SocID=R.SocID
where UR.RoomID=R.RoomID
 order by U.MemberType
) as Usr
inner join Soc S ON R.SocID=S.SocID
inner join State ST ON S.StateID=ST.StateID
left join BSU ON B.BSID=BSU.BSID
left join Rules ON Rules.SocID=R.SocID
where 1=1 ");
                if (BillID > 0)
                {
                    query.Append(" and B.BillID=").Append(BillID);
                }
                else if (BillTitle.Length > 0)
                {
                    query.Append(" and ISNULL(B.BillTitle,BSU.Name)='").Append(BillTitle.Replace("'", "''")).Append("'");
                }
                else
                {
                    query.Append(" and B.BSID>0 and B.IsNewBill=1");
                }
                if (objLoggedUser != null)
                {
                    query.Append(" and S.SocID=").Append(objLoggedUser.SocID);
                }
                DataTable dt = Common.GetDBResultParameterized(query.ToString());

                Repeater1.DataSource = dt;
                Repeater1.DataBind();
            }
        }
        protected override void Render(HtmlTextWriter writer)
        {
            //MemoryStream mem = new MemoryStream();
            //StreamWriter twr = new StreamWriter(mem);
            //HtmlTextWriter myWriter = new HtmlTextWriter(twr);
            //base.Render(myWriter);
            //myWriter.Flush();
            //myWriter.Dispose();
            //StreamReader strmRdr = new StreamReader(mem);
            //strmRdr.BaseStream.Position = 0;
            //string pageContent = strmRdr.ReadToEnd();
            //strmRdr.Dispose();
            //mem.Dispose();
            //writer.Write(pageContent);
            StringBuilder sb = new StringBuilder();
            StringWriter swriter = new StringWriter(sb);
            HtmlTextWriter htw = new HtmlTextWriter(swriter);
            base.Render(htw);
            string pageContent = sb.ToString();
            CreatePDFDocument(pageContent);
        }
        public void CreatePDFDocument(string strHtml)
        {
            MemoryStream objStream = new MemoryStream();
            HttpResponse response = HttpContext.Current.Response;
            //string strFileName = HttpContext.Current.Server.MapPath("test.pdf");
            // step 1: creation of a document-object
            Document document = new Document();
            // step 2:
            // we create a writer that listens to the document
            PdfWriter writer = PdfWriter.GetInstance(document, objStream);
            StringReader se = new StringReader(strHtml);
            document.Open();
            XMLWorkerHelper.GetInstance().ParseXHtml(writer, document, se);
            document.Close();

            byte[] pdfBytes = objStream.ToArray();
            objStream.Close();
            objStream.Dispose();

            response.Clear();
            response.ContentType = "application/pdf";
            response.Buffer = true;
            if (Request.QueryString["download"] != null)
                response.AddHeader("content-disposition", "attachment;filename=" + "Bill" + ".pdf");
            else
                response.AddHeader("content-disposition", "inline;filename=" + "Bill" + ".pdf");
            response.OutputStream.Write(pdfBytes, 0, pdfBytes.Length);
            response.End();
        }

        protected void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.SelectedItem
                || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                int BillID = Common.ToInt(((HiddenField)e.Item.FindControl("hdnBillID")).Value);
                DataTable dt = Common.GetDBResultParameterized(@"select BChg.*,A.AccountName from BChg
inner join Bills B ON BChg.BillID=B.BillID
inner join Accounts A ON BChg.ChgID=A.AccountID and A.SocID=B.SocID 
where BChg.BillID=@BillID", "@SocID", SqlDbType.Int, 1,
                              "@BillID", SqlDbType.Int, BillID);
                Repeater rptDetails = (Repeater)e.Item.FindControl("rptDetails");
                rptDetails.DataSource = dt;
                rptDetails.DataBind();

                string SiteUrl = WebConfigurationManager.AppSettings["SiteUrl"];

                string logo = Common.ToString(((DataRowView)e.Item.DataItem)["Logo"]);
                if (logo.Length > 0)
                {
                    System.Web.UI.WebControls.Image imgLogo = (System.Web.UI.WebControls.Image)e.Item.FindControl("imgLogo");
                    imgLogo.ImageUrl = SiteUrl + "/images/profile/" + logo;
                }


                decimal adjustment = Common.ToDecimal(((Label)e.Item.FindControl("lbAdjustment")).Text);
                decimal total = Common.ToDecimal(((Label)e.Item.FindControl("lbTotalBillAmount")).Text);
                if (adjustment > 0)
                {
                    total = total - adjustment;
                    ((System.Web.UI.HtmlControls.HtmlTableRow)e.Item.FindControl("trAdjustment")).Visible = true;
                    ((Label)e.Item.FindControl("lbTotalBillAmount")).Text = total.ToString("0.00");
                }
                else
                {
                    ((System.Web.UI.HtmlControls.HtmlTableRow)e.Item.FindControl("trAdjustment")).Visible = false;
                }

                StringBuilder totalInWords = new StringBuilder("Rs. ");

                int rupees = (int)Math.Truncate(total);
                int paise = (int)(total - Math.Truncate(total));
                totalInWords.Append(Common.NumberToWords(rupees));
                if (paise > 0)
                    totalInWords.Append(" and ").Append(Common.NumberToWords(paise));
                totalInWords.Append(" Only");
                ((Label)e.Item.FindControl("lbTotalInWords")).Text = totalInWords.ToString();

                if (e.Item.ItemIndex % 2 == 1)
                {
                    HtmlGenericControl divPageBreak = e.Item.FindControl("divPageBreak") as HtmlGenericControl;
                    divPageBreak.Attributes["style"] = "page-break-before:always";
                }
            }
        }

    }
}