var app = angular.module('starter');
app.controller('UsersListCtrl', function ($scope, $http, $location, $state) {
    $scope = readyAngularGrid($scope, $http, 'api/UsersList', 'UserID', 'Users');
    $scope.totalPages = 1;
    $scope.pagingOptions.pageSize = 5;
    $scope.searchUsers = function () {
        $scope.pagingOptions.currentPage = 1;
        $scope.totalPages = 1;
        $scope.allData = [];
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };

    window.setTimeout(function () { $scope.searchUsers(); }, 200);

    $scope.newUsers = function () {
        $state.go('app.UsersEdit', { 'UserID': 0 });
    };
    $scope.editUsers = function (UserID) {
        $state.go('app.UsersEdit', { 'UserID': UserID });
    };
    $scope.deleteUsers = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'DELETE',
                url: 'api/Users/' + selected[0].UserID
            }).success(function (result) {
                if (result == true)
                    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
            });
        }
        else {
            alert('Please select a record to edit.');
        }
    };
}).controller('UsersCtrl', function ($scope, $http, $location, $stateParams, $window) {
    $scope.baseUrl = baseUrl;
    var UserID = $stateParams.UserID;
    $scope.Users = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.UsersSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.UsersSubmitted = true;
        if ($scope.formUsers.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        if ($scope.Users.UserID <= 0 && $scope.UsernameAvailable == 'false') return;
        $http.post('api/Users', $scope.Users, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.Users = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        // $location.path('/UsersList');
        $window.history.back();
    };
    $scope.userAvailable = function () {
        $http({
            method: 'POST',
            url: 'api/Users/Available/',
            data: JSON.stringify($scope.Users.UserName)
        }).success(function (result) {
            $scope.UsernameAvailable = result;
        });
    };
    $scope.removePhoto = function () {
        if (confirm('Are you sure, want to remove photo?')) {
            $http({
                method: 'POST',
                url: 'api/Users/RemovePhoto/',
                data: JSON.stringify($scope.Users.UserID + '.' + $scope.Users.ImageUrl)
            }).success(function (result) {
                if (result == 'true')
                    $scope.Users.ImageUrl = '';
            });
        }
    };
    $scope.uploadPhoto = function () {
        AttachImage($scope.photoUploaded, { width: 200,height:200 });
    };
    $scope.photoUploaded = function (fileGUIDName, fileName, fileID) {
        $scope.Users.ImageUrl = fileGUIDName;
        $http({
            method: 'POST',
            url: 'api/Users/AttachPhoto/',
            data: JSON.stringify($scope.Users.UserID + '.' + $scope.Users.ImageUrl)
        }).success(function (result) {

        });
    };
    setTimeout(function () {

        $http({
            method: 'GET',
            url: 'api/Users/' + UserID
        }).success(function (Users) {
            $scope.Users = JSON.parse(Users);
            $scope.Users.IsActive = $scope.Users.IsActive == null ? true : $scope.Users.IsActive;
        });
    }, 100);

    $scope.roomlist = [];
    $scope.membertypelist = [];
    $scope.bindRoom = function () {
        $scope.membertypelist = [];
        $scope.membertypelist.push({ Key: 'Owner', Value: 'Owner' });
        $scope.membertypelist.push({ Key: 'Tenant', Value: 'Tenant' });

        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetRoomList', Data: null })
        }).success(function (data) {
            $scope.roomlist = data;
        });
    }
    $scope.bindRoom();
})
.controller('ProfileCtrl',['$scope', '$http', '$location', '$stateParams', '$window', 'User', function ($scope, $http, $location, $stateParams, $window, User) {
    $scope.Users = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.UsersSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.UsersSubmitted = true;
        if ($scope.formUsers.$invalid == true) return;
        $http.post('api/Users/UpdateProfile', $scope.Users, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.Users = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
                User.FirstName = $scope.Users.FirstName;
                User.LastName = $scope.Users.LastName;
                User.CityID = $scope.Users.CityID;
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        // $location.path('/UsersList');
        $window.history.back();
    };
    $scope.removePhoto = function () {
        if (confirm('Are you sure, want to remove photo?')) {
            $http({
                method: 'POST',
                url: 'api/Users/RemovePhoto/',
                data: JSON.stringify($scope.Users.UserID + '.' + $scope.Users.ImageUrl)
            }).success(function (result) {
                if (result == 'true') {
                    $scope.Users.ImageUrl = '';
                    User.ImageUrl = '';
                }
            });
        }
    };
    $scope.uploadPhoto = function () {
        AttachImage($scope.photoUploaded);
    };
    $scope.photoUploaded = function (fileGUIDName, fileName, fileID) {
        $scope.Users.ImageUrl = fileGUIDName;
        $http({
            method: 'POST',
            url: 'api/Users/AttachPhoto/',
            data: JSON.stringify($scope.Users.UserID + '.' + $scope.Users.ImageUrl)
        }).success(function (result) {
            User.ImageUrl = $scope.Users.ImageUrl;
        });
    };
    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/UsersProfile'
        }).success(function (Users) {
            $scope.Users = JSON.parse(Users);
        });
    }, 100);

    $scope.citylist = [];
    $scope.bindCity = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetAllCityList', Data: null })
        }).success(function (data) {
            $scope.citylist = data;
        });
    };
    $scope.bindCity();
}])
.controller('GKListCtrl',['$scope', '$http', '$location', 'GridData', function ($scope, $http, $location, GridData) {

    $scope = readyAngularGrid($scope, $http, 'api/GKList', 'UserID', GridData, 'Users');
    $scope.gridOptions.columnDefs = [
    { displayName: 'FirstName', field: 'FirstName' },
    { displayName: 'LastName', field: 'LastName' },
    { displayName: 'UserName', field: 'UserName' },
    { displayName: 'EmailID', field: 'EmailID' },
    ];
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchUsers = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };
    $scope.newUsers = function () {
        saveGridData($scope, GridData, 'Users');
        $location.path('/GK/0');
    };
    $scope.editUsers = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            saveGridData($scope, GridData, 'Users');
            $location.path('/GK/' + selected[0].UserID);
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.deleteUsers = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'DELETE',
                url: 'api/GKDelete/' + selected[0].UserID
            }).success(function (result) {
                if (result == true)
                    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
            });
        }
        else {
            alert('Please select a record to edit.');
        }
    };
}]);
