var app = angular.module('starter');

app.controller('CBoxListCtrl', function ($scope, $http, $location, $state, $ionicFilterBar, $ionicModal) {
    $scope.baseUrl = baseUrl;
    $scope = readyAngularGrid($scope, $http, 'api/Forums/List2/', 'ForumID', 'Forums');
    $scope.totalPages = 1;
    $scope.pagingOptions.pageSize = 5;
    $scope.searchForum = function () {
        $scope.pagingOptions.currentPage = 1;
        $scope.totalPages = 1;
        $scope.allData = [];
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };

    window.setTimeout(function () { $scope.searchForum(); }, 200);


    $scope.newForum = function () {
        $state.go('app.CBoxEdit', { 'ForumID': '' });
    };
    $scope.viewForum = function (FMID) {
        $state.go('app.CBoxView', { 'ForumID': FMID });
    };
    $scope.showFilterBar = function () {
        filterBarInstance = $ionicFilterBar.show({
            items: null,
            update: function (a, b) {
                if (b != null) {
                    $scope.filterOptions.filterText = b;
                    $scope.searchForum();
                }
            },
            delay: 500
        });
        window.setTimeout(function () { $('.filter-bar-search').val($scope.filterOptions.filterText); }, 200);
    };
    $scope.doRefresh = function () {
        //simulate async response
        $scope.searchForum();
    };
    $ionicModal.fromTemplateUrl('image-modal.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        $scope.modal = modal;
    });
    $scope.openModal = function (Obj, $event) {
        if (Obj != null && Obj != '') {
            $scope.imageSrc = baseUrl + 'Download.aspx?type=profile&filepath=images/profile/' + Obj;
            $scope.modal.show();
            $event.stopPropagation();
        }
    };

    $scope.closeModal = function () {
        $scope.modal.hide();
    };
    $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
        if ($scope.modal.isShown()) {
            event.preventDefault();
            $scope.closeModal();
        }
    });
});

app.controller('ForumsListCtrl', function ($scope, $http, $location, $state, $ionicFilterBar, $ionicModal) {
    $scope.baseUrl = baseUrl;
    $scope = readyAngularGrid($scope, $http, 'api/Forums/List1/', 'ForumID', 'Forums');
    $scope.totalPages = 1;
    $scope.pagingOptions.pageSize = 10;
    $scope.searchForum = function () {
        $scope.pagingOptions.currentPage = 1;
        $scope.totalPages = 1;
        $scope.allData = [];
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };

    window.setTimeout(function () { $scope.searchForum(); }, 200);


    $scope.newForum = function () {
        $state.go('app.ForumsEdit', { 'ForumID': '' });
    };
    $scope.viewForum = function (FMID) {
        $state.go('app.ForumsView', { 'ForumID': FMID });
    };
    $scope.showFilterBar = function () {
        filterBarInstance = $ionicFilterBar.show({
            items: null,
            update: function (a, b) {
                if (b != null) {
                    $scope.filterOptions.filterText = b;
                    $scope.searchForum();
                }
            },
            delay: 500
        });
        window.setTimeout(function () { $('.filter-bar-search').val($scope.filterOptions.filterText); }, 200);
       
    };
    $scope.doRefresh = function () {
        //simulate async response
        $scope.searchForum();
    };
    $ionicModal.fromTemplateUrl('image-modal.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        $scope.modal = modal;
    });
    $scope.openModal = function (Obj, $event) {
        if (Obj != null && Obj != '') {
            $scope.imageSrc = baseUrl + 'Download.aspx?type=profile&filepath=images/profile/' + Obj;
            $scope.modal.show();
            $event.stopPropagation();
        }
    };

    $scope.closeModal = function () {
        $scope.modal.hide();
    };
    $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
        if ($scope.modal.isShown()) {
            event.preventDefault();
            $scope.closeModal();
        }
    });
});
app.controller('ForumsViewCtrl', function ($scope, $http, $location, $q, $stateParams, Globals,
    $ionicScrollDelegate, $timeout, $ionicModal) {
    $scope.baseUrl = baseUrl;
    $scope.PageSize = 5;
    $scope.CurrentPage = 1;
    $scope.TotalPages;

    var ForumID = $stateParams.ForumID;
    $scope.commentBox = { Remarks: '', ForumID: '' };

    $scope.Forums = {};
    $scope.ForumsSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.closeComplaint = function () {
        $http({
            method: 'POST',
            url: 'api/Forums/CloseComplaint/',
            data: JSON.stringify($scope.Forums)
        }).success(function (result) {
            $scope.Forums.Status = 'Closed';
            swal({ title: "Complaint Closed!", type: "success", timer: 1000, showConfirmButton: false });
        });
    };
    $scope.deleteComment = function (commentID) {
        if (confirm('Are you sure want to delete?') == false) return;

        $http({
            method: 'DELETE',
            url: 'api/Comments/' + commentID + '/' + $scope.Forums.ForumID
        }).success(function (result) {

            if (result == true) {
                var index = -1;
                var comArr = $scope.Forums.Comments;
                for (var i = 0; i < comArr.length; i++) {
                    if (comArr[i].CommentID === commentID) {
                        index = i;
                        break;
                    }
                }
                if (index === -1) {
                    alert("Something gone wrong");
                }
                $scope.Forums.Comments.splice(index, 1);
            }
        });
    };
    $scope.addComment = function () {

        if ($scope.commentBox.CurrentRemarks == '') return;
        $scope.commentBox.ForumID = ForumID;
        $scope.commentBox.Remarks = $scope.commentBox.CurrentRemarks;
        $http.post('api/Comments', $scope.commentBox, config)
        .success(function (data, status, headers, config) {
            var result = data;
            if (result.ErrorCode == 1)
                $scope.ErrorMessages = result.data;
            else {
                $scope.ErrorMessages = [];
                $scope.commentBox.CurrentRemarks = '';
                var curDate = (new Date()).toJSON();
                $scope.Forums.Comments.push({
                    Remarks: $scope.commentBox.Remarks,
                    CommentedByName: Globals.Name,
                    CommentedByImageUrl: Globals.ImageUrl,
                    CommentDate: curDate
                });
                $timeout(function () {
                    $ionicScrollDelegate.scrollBottom();
                }, 50);
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };
    $scope.like = function () {
        $http({
            method: 'POST',
            url: 'api/Comments/Like/',
            data: JSON.stringify(ForumID)
        }).success(function (result) {
            $scope.Forums.YouLiked = result;
            if (result == true)
                $scope.Forums.LikeCount++;
            else
                $scope.Forums.LikeCount--;
        });
    };

    window.setTimeout(function () {
        $scope.getForum();
    }, 200);
    $ionicModal.fromTemplateUrl('image-modal.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        $scope.modal = modal;
    });
    $scope.openModal = function (Obj, $event) {
        if (Obj != null && Obj != '') {
            $scope.imageSrc = baseUrl + 'Download.aspx?type=profile&filepath=images/profile/' + Obj;
            $scope.modal.show();
            $event.stopPropagation();
        }
    };

    $scope.closeModal = function () {
        $scope.modal.hide();
    };
    $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
        if ($scope.modal.isShown()) {
            event.preventDefault();
            $scope.closeModal();
        }
    });
    $scope.getForum = function () {
        $http({
            method: 'GET',
            url: 'api/Forums/' + ForumID
        }).success(function (result) {
            $scope.Forums = result;
            $scope.$broadcast('scroll.refreshComplete');
        });
    };
    $scope.doRefresh = function () {
        //simulate async response
        $scope.getForum();
    };
})
app.controller('ForumsCtrl', function ($scope, $http, $location, $q, $stateParams, $state) {
    var ForumType = 'Forum';
    $scope.ForumType = ForumType;

    $scope.Forums = { RoomID: ' ' };
    $scope.ForumsSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.ForumsSubmitted = true;
        if ($scope.formForums.$invalid == true) return;
        if ($scope.Forums.RoomID == null || $scope.Forums.RoomID == '' || $scope.Forums.RoomID == ' ') {
            swal({ title: "Please select Unit.", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        $scope.Forums.Type = ForumType;
        $http.post('api/Forums', $scope.Forums, config)
        .success(function (data, status, headers, config) {
            var result = data;
            if (result.ErrorCode == 1)
                $scope.ErrorMessages = result.data;
            else {
                $scope.ErrorMessages = [];
                $scope.Forums = result.data;
                swal({ title: "You have successfully started a discussion!", type: "success", timer: 1000, showConfirmButton: false });
                $scope.Forums = {};
                $state.go('app.Forums');
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };
    $scope.roomlist = [];
    $scope.bindRoom = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetRoomList', Data: null })
        }).success(function (data) {
            $scope.roomlist = data;
        });
    }
    $scope.bindRoom();
})
app.controller('CBoxCtrl', function ($scope, $http, $location, $q, $stateParams, $state) {
    var ForumType = 'Complaint Box';
    $scope.ForumType = ForumType;

    $scope.Forums = { Priority: ' ', RoomID: ' ', CTTypeID: ' ' };
    $scope.ForumsSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.ForumsSubmitted = true;
        if ($scope.formForums.$invalid == true) return;
        if ($scope.Forums.CTTypeID == null || $scope.Forums.CTTypeID == '' || $scope.Forums.CTTypeID == ' ') {
            swal({ title: "Please select Type.", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        if ($scope.Forums.Priority == null || $scope.Forums.Priority == '' || $scope.Forums.Priority == ' ') {
            swal({ title: "Please select Priority.", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        if ($scope.Forums.RoomID == null || $scope.Forums.RoomID == '' || $scope.Forums.RoomID == ' ') {
            swal({ title: "Please select Unit.", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        $scope.Forums.Type = ForumType;
        $http.post('api/Forums', $scope.Forums, config)
        .success(function (data, status, headers, config) {
            var result = data;
            if (result.ErrorCode == 1)
                $scope.ErrorMessages = result.data;
            else {
                $scope.ErrorMessages = [];
                $scope.Forums = result.data;
                swal({ title: "You have successfully created the Complaint!", type: "success", timer: 1000, showConfirmButton: false });
                $scope.Forums = {};
                $state.go('app.CBox');
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };
    $scope.typelist = [];
    $scope.prioritylist = [];
    $scope.bindCTType = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetCTTypeList', Data: null })
        }).success(function (data) {
            $scope.typelist = data;
            $scope.prioritylist = [];
            $scope.prioritylist.push({ Key: 'Low', Value: 'Low' });
            $scope.prioritylist.push({ Key: 'Medium', Value: 'Medium' });
            $scope.prioritylist.push({ Key: 'High', Value: 'High' });
        });
    }
    $scope.bindCTType();

    $scope.roomlist = [];
    $scope.bindRoom = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetRoomList', Data: null })
        }).success(function (data) {
            $scope.roomlist = data;
        });
    }
    $scope.bindRoom();
})
