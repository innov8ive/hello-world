var app = angular.module('starter');

app.controller('SocRegisterCtrl', function ($scope, $http, $location, $state) {
    $scope.Soc = {};
    $scope.Users = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.SocSubmitted = false;
    $scope.UsersSubmitted = false;
    $scope.UsernameAvailable = null;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        },
        timeout: 12000
    };
    $scope.update = function () {
        $scope.SocSubmitted = $scope.UsersSubmitted = true;
        if ($scope.formSoc.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        if ($scope.UsernameAvailable == 'false' || $scope.UsernameAvailable == null) return;
        //if ($scope.Users.Password != $scope.Users.ConfirmPassword) {
        //    alert('Password and Confirm Password should be same');
        //    return;
        //}

        $http.post('api/SocRegister', { Soc: $scope.Soc, User: $scope.Users }, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.Soc = result;
                swal({ title: "Society Details saved successfully. Please check SMS and Email!", type: "success", showConfirmButton: true, timer: 3000 });
                $state.go('app.login');
            }
        }).error(function () {
            swal({ title: "Society Details saved successfully. Please check SMS and Email!", type: "success", showConfirmButton: true, timer: 3000 });
            $state.go('app.login');
        });

    };
    $scope.userAvailable = function () {
        if ($scope.formSoc.emailidTextBox.$invalid == true) return;
        $http({
            method: 'POST',
            url: 'api/Users/Available/',
            data: JSON.stringify($scope.Users.EmailID)
        }).success(function (result) {
            $scope.UsernameAvailable = result;
        });
    };
    $scope.cancel = function () {
        $location.path('/login');
    }

    $scope.statelist = [];
    $scope.bindState = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetStateList', Data: null })
        }).success(function (data) {
            $scope.statelist = data;
        });
    }
    $scope.bindState();

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/Soc/0'
        }).success(function (Soc) {
            $scope.Soc = JSON.parse(Soc);
        });
        $http({
            method: 'GET',
            url: 'api/Users/0'
        }).success(function (Users) {
            $scope.Users = JSON.parse(Users);
        });
    }, 100);
});