var app = angular.module('starter');

app.controller('FolderListCtrl', function ($scope, $http, $location) {

    $scope.path = [];
    $scope.modalTitle = '';
    $scope.filter = { filterText: '', FolderID: 0 };
    $scope.showModal = false;
    $scope.Folder = {};
    $scope.FolderSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.searchFolder = function () {
        $http({
            method: 'POST',
            url: 'api/FolderList/',
            data: JSON.stringify($scope.filter)
        }).success(function (Folder) {
            $scope.Folders = JSON.parse(Folder);
        });

        $http({
            method: 'POST',
            url: 'api/FileList/',
            data: JSON.stringify($scope.filter)
        }).success(function (Folder) {
            $scope.Files = JSON.parse(Folder);
        });
    };

    $scope.newFolder = function () {
        $scope.Folder = {};
        $scope.modalTitle = 'Create a New Folder';
        $('#modalF').modal('show');
    };
    $scope.renameFolder = function (itm) {
        $scope.Folder = itm;
        $scope.modalTitle = 'Rename Folder';
        $('#modalF').modal('show');
    };
    $scope.closeFolder = function () {
        $('#modalF').modal('hide');
    };
    $scope.deleteFolder = function (FolderID) {
        $http({
            method: 'POST',
            url: 'api/Folder/DeleteFolder/',
            data: JSON.stringify({ FolderID: FolderID })
        }).success(function (result) {
            if (result.indexOf('Error:') > -1) {
                swal({ title: result, type: "error", showConfirmButton: true });
            }
            else {
                swal({ title: "Folder Deleted successfully!", type: "success", timer: 1000, showConfirmButton: false });
                $scope.searchFolder();
            }
        });
    };

    $scope.deleteFile = function (FileID, FileGUID) {
        if (confirm('Are you sure want to delete this file?') == true) {
            $http({
                method: 'POST',
                url: 'api/Folder/DeleteFile/',
                data: JSON.stringify({ FileID: FileID, FileGUID: FileGUID })
            }).success(function (result) {
                swal({ title: "File Deleted successfully!", type: "success", timer: 1000, showConfirmButton: false });
                $scope.searchFolder();
            });
        }
    };
    $scope.saveFolder = function () {
        if ($scope.Folder.FolderName == null || $scope.Folder.FolderName == '') {
            alert('Please enter Folder Name');
            return;
        }
        $scope.Folder.ParentFolderID = $scope.filter.FolderID;
        $http.post('api/Folder', $scope.Folder, config)
       .success(function (data, status, headers, config) {
           var result = JSON.parse(data);
           if ($.isArray(result))
               $scope.ErrorMessages = result;
           else {
               $scope.ErrorMessages = [];
               swal({ title: "Folder Saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
               $('#modalF').modal('hide');
               $scope.searchFolder();
           }
       })
       .error(function (data, status, header, config) {
           alert('error');
       });
    };
    $scope.navigateFolder = function (itm) {
        $scope.filter.FolderID = itm.FolderID;
        $scope.path.push({ FolderID: itm.FolderID, FolderName: itm.FolderName, toString: function () { return this.FolderName; } });
        $scope.searchFolder();
    };
    $scope.backFolder = function () {
        $scope.path.pop();
        if ($scope.path.length > 0)
            $scope.filter.FolderID = $scope.path[$scope.path.length - 1].FolderID;
        else
            $scope.filter.FolderID = 0;
        $scope.searchFolder();
    };
    $scope.pathToShow = function () {
        return $scope.path.join('/');
    };
    $scope.addFiles = function () {
        openFileUploader($scope.fileUploaded, baseUrl + 'FileUploadHandler.ashx?FolderID=' + $scope.filter.FolderID);
    }
    $scope.fileUploaded = function (result) {
        $scope.searchFolder();
    }
    $scope.getFileCss = function (fileName) {
        var ext = fileName.substring(fileName.lastIndexOf('.') + 1).toLowerCase();
        switch (ext) {
            case 'png':
            case 'jpg':
            case 'jpeg':
            case 'gif':
            case 'bmp':
                return 'fa fa-file-image-o';
            case 'xls':
            case 'xlsx':
            case 'csv':
                return 'fa fa-file-excel-o';
            case 'doc':
            case 'docx':
                return 'fa fa-file-word-o';
            case 'txt':
                return 'fa fa-file-text-o';
            case 'pdf':
                return 'fa fa-file-pdf-o';
            case 'zip':
            case 'rar':
                return 'fa fa-file-zip-o';
        }
        return 'fa fa-file-o';
    };
    $scope.openFile = function (itm) {
        window.open('Download.aspx?fileID=' + itm.FileGUID);
    };
    $scope.searchFolder();
});
app.controller('CSVUploaderCtrl', function ($scope, $http, $location) {
    $scope.data = [];
    $scope.uploadFile = function () {
        var f = $scope.myFile;
        if (f) {
            if (f.name.toLowerCase().endsWith('.csv') == true) {
                var r = new FileReader();
                r.onload = function (e) {
                    var contents = e.target.result;
                    $scope.data = $.csv.toObjects(contents);
                }
                r.readAsText(f);
            } else {
                alert("Please select only .CSV file.");
            }
        } else {
            alert("Please select a csv file");
        }
    };

    $scope.grouplist = [];
    $scope.bindGroup = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetGroupSubGroupList', Data: null })
        }).success(function (data) {
            $scope.grouplist = data;
        });
    }
    $scope.bindGroup();

    $scope.GL = {};
    $scope.saveData = function () {
        if ($scope.GL.GroupID == null || $scope.GL.GroupID <= 0) {
            swal({ title: "Please select GL Group!", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        if ($scope.data.length <= 0) {
            swal({ title: "Please upload csv file!", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        if ($scope.data.length > 300) {
            swal({ title: "CSV file data has more than 300 rows!", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }

        var errorMessage = '';
        for (var j = 0; j < $scope.data.length; j++) {
            if ($scope.data[j].GLName == null || $scope.data[j].GLName.length > 100 || $scope.data[j].GLName.length == 0) {
                errorMessage += '\nGL Name is either blank or has more than 100 char at row ' + (j + 1);
            }
            if ($scope.data[j].Credit == null || $scope.data[j].Debit == null ||
                $scope.data[j].Credit < 0 || $scope.data[j].Debit < 0) {
                errorMessage += '\nGL Credit and Debit should not be blank or less than zero at row ' + (j + 1);
            }
        }
        if (errorMessage.length > 0) {
            alert(errorMessage);
            return;
        }

        $http({
            method: 'POST',
            url: 'api/GL/UploadGL/',
            data: JSON.stringify({ GroupID: $scope.GL.GroupID, Data: $scope.data })
        }).success(function (result) {
            $scope.data = [];
            alert(result);
        });
    };
});
app.controller('MemberUploaderCtrl', function ($scope, $http, $location) {
    $scope.data = [];
    $scope.floors = [];
    $scope.unitTypes = [];
    $scope.memberTypes = [];
    $scope.loadRefData = function () {
        $scope.floors = [];
        $scope.unitTypes = [];
        $scope.memberTypes = [];

        $scope.wingList = [];
        $scope.bindWing = function () {
            $http({
                method: 'POST',
                url: 'api/Common/',
                data: JSON.stringify({ MethodName: 'GetWingList', Data: null })
            }).success(function (data) {
                $scope.wingList = data;
            });
        }
        $scope.bindWing();

        for (var j = 0; j <= 30; j++) {
            $scope.floors.push(j);
        }

        $scope.memberTypes.push('Owner');
        $scope.memberTypes.push('Tenant');

        $scope.unitTypes.push({ text: '1RK', value: '1RK' });
        $scope.unitTypes.push({ text: '1BHK', value: '1BHK' });
        $scope.unitTypes.push({ text: '1.5BHK', value: '1.5BHK' });
        $scope.unitTypes.push({ text: '2BHK', value: '2BHK' });
        $scope.unitTypes.push({ text: '2.5BHK', value: '2.5BHK' });
        $scope.unitTypes.push({ text: '3BHK', value: '3BHK' });
        $scope.unitTypes.push({ text: '3.5BHK', value: '3.5BHK' });
        $scope.unitTypes.push({ text: '4BHK', value: '4BHK' });
        $scope.unitTypes.push({ text: '4.5BHK', value: '4.5BHK' });
        $scope.unitTypes.push({ text: 'Shop', value: 'Shop' });
        $scope.unitTypes.push({ text: 'Office', value: 'Office' });
    };

    $scope.uploadFile = function () {
        var f = $scope.myFile;
        if (f) {
            if (f.name.toLowerCase().endsWith('.csv') == true) {
                var r = new FileReader();
                r.onload = function (e) {
                    var contents = e.target.result;
                    $scope.data = $.csv.toObjects(contents);
                    window.setTimeout(function () { $scope.loadRefData(); }, 200);
                }
                r.readAsText(f);
            } else {
                alert("Please select only .CSV file.");
            }
        } else {
            alert("Please select a csv file");
        }
    };
    $scope.UploadResult = '';
    $scope.saveData = function () {
        if ($scope.data.length <= 0) {
            swal({ title: "Please upload csv file!", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        if ($scope.data.length > 300) {
            swal({ title: "CSV file data has more than 300 rows!", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }

        var errorMessage = '';
        //for (var j = 0; j < $scope.data.length; j++) {
        //    if ($scope.data[j].GLName == null || $scope.data[j].GLName.length > 100 || $scope.data[j].GLName.length == 0) {
        //        errorMessage += '\nGL Name is either blank or has more than 100 char at row ' + (j + 1);
        //    }
        //    if ($scope.data[j].Credit == null || $scope.data[j].Debit == null || 
        //        $scope.data[j].Credit < 0 || $scope.data[j].Debit < 0) {
        //        errorMessage += '\nGL Credit and Debit should not be blank or less than zero at row ' + (j + 1);
        //    }
        //}
        //if (errorMessage.length > 0) {
        //    alert(errorMessage);
        //    return;
        //}

        $http({
            method: 'POST',
            url: 'api/Rooms/UploadRooms/',
            data: JSON.stringify($scope.data)
        }).success(function (result) {
            $scope.UploadResult = JSON.parse(result);
            if ($scope.UploadResult.length == 1 && $scope.UploadResult[0] == '') {
                $scope.data = [];
                alert('Data Uploaded Successfully');
            }
        });

    };

    $scope.downloadFile = function () {
        window.open('api/AccountReport/DownloadMemberFormat');
    };
});
app.controller('PaymentUploaderCtrl', function ($scope, $http, $location) {
    $scope.credittolist = [];
    $scope.loadRefData = function () {
        $scope.credittolist = [];
        $scope.bindCreditTo = function () {
            $http({
                method: 'POST',
                url: 'api/Common/',
                data: JSON.stringify({ MethodName: 'GetContraGLList', Data: null })
            }).success(function (data) {
                $scope.credittolist = data;
            });
        };
        $scope.bindCreditTo();
    };

    $scope.uploadFile = function () {
        var f = $scope.myFile;
        if (f) {
            if (f.name.toLowerCase().endsWith('.csv') == true) {
                var r = new FileReader();
                r.onload = function (e) {
                    var contents = e.target.result;
                    $scope.data = $.csv.toObjects(contents);
                    window.setTimeout(function () { $scope.loadRefData(); }, 200);
                }
                r.readAsText(f);
            } else {
                alert("Please select only .CSV file.");
            }
        } else {
            alert("Please select a csv file");
        }
    };
    $scope.UploadResult = [];
    $scope.saveData = function () {
        if ($scope.data.length <= 0) {
            swal({ title: "Please upload csv file!", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        if ($scope.data.length > 300) {
            swal({ title: "CSV file data has more than 300 rows!", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }

        var errorMessage = '';
        $http({
            method: 'POST',
            url: 'api/Payments/UploadPayment/',
            data: JSON.stringify($scope.data)
        }).success(function (result) {

            $scope.UploadResult = JSON.parse(result);
            if ($scope.UploadResult.length == 1 && $scope.UploadResult[0] == '') {
                $scope.data = [];
                alert('Data Uploaded Successfully');
            }
        });

    };

    $scope.downloadFile = function () {
        window.open('api/AccountReport/DownloadPaymentFormat');
    };
});