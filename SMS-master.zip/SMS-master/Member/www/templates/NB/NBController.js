var app = angular.module('starter');

app.controller('NBListCtrl', function ($scope, $http, $location, $state) {
    $scope = readyAngularGrid($scope, $http, 'api/NBList', 'NBID', 'NB');
    $scope.totalPages = 1;
    $scope.pagingOptions.pageSize = 5;
    $scope.searchNB = function () {
        $scope.pagingOptions.currentPage = 1;
        $scope.totalPages = 1;
        $scope.allData = [];
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };

    window.setTimeout(function () { $scope.searchNB(); }, 200);

    $scope.newNB = function () {
        $state.go('app.NBEdit', { 'NBID': 0 });
    };
    $scope.editNB = function (NBID) {
        $state.go('app.NBEdit', { 'NBID': NBID });
    };
    $scope.deleteNB = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'DELETE',
                url: 'api/NB/' + selected[0].NBID
            }).success(function (result) {
                if (result == true)
                    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
            });
        }
        else {
            alert('Please select a record to edit.');
        }
    };
})
.controller('NBCtrl', function ($scope, $http, $location, $stateParams) {
    var NBID = $stateParams.NBID;
    $scope.NB = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.NBSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.NBSubmitted = true;
        if ($scope.formNB.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/NB', $scope.NB, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.NB = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/NBList');
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/NB/' + NBID
        }).success(function (NB) {
            $scope.NB = JSON.parse(NB);
        });
    }, 100);

    $scope.toMarkup = function (text) {
        return toMarkup(text);
    };
});
app.controller('NBListingCtrl', function ($scope, $http, $location, $state) {
    
    $scope.NBs = [];
    setTimeout(function () {
        $scope.searchNB();
    }, 100);
    $scope.searchNB = function () {
        $http({
            method: 'POST',
            url: 'api/NB/GetAllNBs'
        }).success(function (NBs) {
            $scope.NBs = NBs;
            for (var j = 0; j < $scope.NBs.length; j++) {
                $scope.NBs[j].DetailsShort = $scope.NBs[j].Details.length > 100
                    ? $scope.NBs[j].Details.substring(0, 100) + '...' : $scope.NBs[j].Details;
            }
            $scope.$broadcast('scroll.refreshComplete');
        });
    };
    $scope.toMarkup = function (text) {
        return toMarkup(text);
    };
    $scope.doRefresh = function () {
        //simulate async response
        $scope.searchNB();
    };
    $scope.viewNB = function (NBID) {
        $state.go('app.NBDetails', { 'NBID': NBID });
    };
});

app.controller('NBDetailsCtrl', function ($scope, $http, $location, $stateParams, $state) {
    var NBID = $stateParams.NBID;
    $scope.NB = {};

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/NB/' + NBID
        }).success(function (NB) {
            $scope.NB = JSON.parse(NB);
        });
    }, 100);

    $scope.toMarkup = function (text) {
        return toMarkup(text);
    };

});
