var app = angular.module('starter');
app.controller('RoomsViewCtrl', function ($scope, $http, $location, $state, $ionicFilterBar, $stateParams) {
    var RoomID = $stateParams.RoomID;
    $scope.Filter = { RoomID: RoomID };
    $scope = readyAngularGrid($scope, $http, 'api/Rooms/GetStatement', 'BillID', 'RoomStatement');
    $scope.totalPages = 1;
    $scope.pagingOptions.pageSize = 10;
    $scope.searchStatement = function () {
        $scope.pagingOptions.currentPage = 1;
        $scope.totalPages = 1;
        $scope.allData = [];
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };

    window.setTimeout(function () { $scope.searchStatement(); $scope.fetchOutstanding(); $scope.fetchRoomDetails(); }, 200);

    $scope.showFilterBar = function () {
        filterBarInstance = $ionicFilterBar.show({
            items: null,
            update: function (a, b) {
                if (b != null) {
                    $scope.filterOptions.filterText = b;
                    $scope.searchStatement();
                }
            },
            delay: 500
        });
        window.setTimeout(function () { $('.filter-bar-search').val($scope.filterOptions.filterText); }, 200);
    };
    $scope.doRefresh = function () {
        //simulate async response
        $scope.searchStatement();
        $scope.fetchOutstanding();
        $scope.fetchRoomDetails();
    };
    $scope.fetchOutstanding = function () {
        $http({
            method: 'POST',
            url: 'api/Rooms/TotalOutstanding',
            data: JSON.stringify({ RoomID: $scope.Filter.RoomID })
        }).success(function (data) {
            $scope.Outstanding = parseFloat(data);
        });
    };
    $scope.fetchRoomDetails = function () {
        $http({
            method: 'GET',
            url: 'api/Rooms/' + RoomID
        }).success(function (data) {
            $scope.Rooms = JSON.parse(data);
        });
    };
    $scope.printBill = function (billID, Type) {
        var url = '';
        if (Type == 'Reciept')
            url = 'PrintReciept.aspx?BillID=' + billID;
        else
            url = 'PrintBill.aspx?BillID=' + billID;
        var url = 'https://docs.google.com/gview?url=' + baseUrl + url + '&embedded=true';
        cordova.InAppBrowser.open(url, '_blank', 'location=no');
    };
});

app.controller('UnitDetailsCtrl', function ($scope, $http, $location, $state, $ionicFilterBar) {
    $scope.$on('$ionicView.beforeEnter', function (e, config) {
        config.enableBack = false;
    });
    $scope.filterOptions = { filterText: '' }
    $http({
        method: 'POST',
        url: 'api/Home/RoomList/'
    }).success(function (result) {
        $scope.RoomList = result;
    });

    $scope.CPList = [];

    $http({
        method: 'POST',
        url: 'api/CPListing/',
        data: JSON.stringify($scope.filter)
    }).success(function (result) {
        $scope.CPList = result;
    });


    $scope.update = function () {
        $http({
            method: 'POST',
            url: 'api/UpdateCPListing/',
            data: JSON.stringify($scope.CPList)
        }).success(function (result) {
            //$scope.CPList = result;
            swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
        });
    };

    $scope.searchVM = function () {
        $http({
            method: 'POST',
            url: 'api/VMListing/',
            data: JSON.stringify({ SearchText: $scope.filterOptions.filterText })
        }).success(function (result) {
            $scope.allData = result;
            //Stop the ion-refresher from spinning
            $scope.$broadcast('scroll.refreshComplete');
        });
    };

    window.setTimeout(function () { $scope.searchVM(); }, 200);
    $scope.showFilterBar = function () {
        filterBarInstance = $ionicFilterBar.show({
            items: null,
            update: function (a, b) {
                if (b != null) {
                    $scope.filterOptions.filterText = b;
                    $scope.searchVM();
                }
            },
            delay: 500
        });
    };

    $scope.doRefresh = function () {
        //simulate async response
        $scope.searchVM();
    };

    $scope.viewRooms = function (RMID) {
        $state.go('app.RoomsView', { 'RoomID': RMID });
    };
});
app.controller('FMListCtrl', function ($scope, $http, $location, $state, $stateParams, $ionicFilterBar, $ionicModal, $ionicTabsDelegate, $timeout) {
    $scope.$on('$ionicView.beforeEnter', function (e, config) {
        config.enableBack = false;
    });
    $scope.filterOptions = { filterText: '' };
    $scope.baseUrl = baseUrl;
    $scope.FMType = $stateParams.FMType;


    $scope.searchFM = function () {
        $http({
            method: 'POST',
            url: 'api/FMList/',
            data: JSON.stringify({ filterText: $scope.filterOptions.filterText, FMType: $scope.FMType })
        }).success(function (result) {
            $scope.allData = result;
            //Stop the ion-refresher from spinning
            $scope.$broadcast('scroll.refreshComplete');
        });
    };

    window.setTimeout(function () { $scope.searchFM(); }, 200);

    $scope.doRefresh = function () {
        //simulate async response
        $scope.searchFM();
    };
    $scope.newFM = function () {
        $state.go('app.FMEdit', { 'FMID': 0, 'FMType': $scope.FMType });
    };
    $scope.editFM = function (FMID) {
        $state.go('app.FMEdit', { 'FMID': FMID, 'FMType': $scope.FMType });
    };
    $scope.showFilterBar = function () {
        filterBarInstance = $ionicFilterBar.show({
            items: null,
            update: function (a, b) {
                if (b != null) {
                    $scope.filterOptions.filterText = b;
                    $scope.searchFM();
                }
            },
            delay: 500
        });
        window.setTimeout(function () { $('.filter-bar-search').val($scope.filterOptions.filterText); }, 200);
    };

    $scope.onFamilySelected = function () {
        $scope.FMType = 'FM';
        $scope.searchFM();
    };
    $scope.onStaffsSelected = function () {
        $scope.FMType = 'Staffs';
        $scope.searchFM();
    };
    $scope.onTenantsSelected = function () {
        $scope.FMType = 'Tenants';
        $scope.searchFM();
    };
    $ionicModal.fromTemplateUrl('image-modal.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        $scope.modal = modal;
    });

    $scope.openModal = function (Obj, $event) {
        if (Obj != null && Obj != '') {
            $scope.imageSrc = baseUrl + 'Download.aspx?type=profile&filepath=images/profile/' + Obj;
            $scope.modal.show();
            $event.stopPropagation();
        }
    };

    $scope.closeModal = function () {
        $scope.modal.hide();
    };
    $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
        if ($scope.modal.isShown()) {
            event.preventDefault();
            $scope.closeModal();
        }
    });
    $timeout(function () {
        if ($stateParams.FMType == 'FM')
            $ionicTabsDelegate.select(0, false);
        else if ($stateParams.FMType == 'Staffs')
            $ionicTabsDelegate.select(1, false);
        else if ($stateParams.FMType == 'Tenants')
            $ionicTabsDelegate.select(2, false);
    }, 400);
})

.controller('FMCtrl', function ($scope, $http, $location, $stateParams, $rootScope, $state, $cordovaCamera) {
    $scope.baseUrl = baseUrl;
    var FMID = $stateParams.FMID;
    $scope.FMType = $stateParams.FMType;
    $scope.FM = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.FMSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.FMSubmitted = true;
        if ($scope.formFM.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $scope.FM.FMType = $scope.FMType;
        $http.post('api/FM', $scope.FM, config)
        .success(function (data, status, headers, config) {
            var result = data;
            if (result.ErrorCode == 1)
                $scope.ErrorMessages = result.data;
            else {
                $scope.ErrorMessages = [];
                $scope.FM = result.data;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/FMList/' + $scope.FMType);
    }
    $scope.genderlist = [];
    $scope.idlist = [];
    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/FM/' + FMID
        }).success(function (FM) {
            $scope.genderlist.push({ Value: 'Male', Key: 'Male', Selected: false });
            $scope.genderlist.push({ Value: 'Female', Key: 'Female', Selected: false });

            $scope.idlist.push({ Value: 'PAN No.', Key: 'PAN No.', Selected: false });
            $scope.idlist.push({ Value: 'Aadhar No.', Key: 'Aadhar No.', Selected: false });
            $scope.FM = FM;
            $scope.FM.FMType = $scope.FMType;
        });
    }, 100);

    $scope.removePhoto = function () {
        if (confirm('Are you sure, want to remove photo?')) {
            $http({
                method: 'POST',
                url: 'api/FM/RemovePhoto/',
                data: JSON.stringify($scope.FM.FMID + '.' + $scope.FM.ImageUrl)
            }).success(function (result) {
                if (result == 'true')
                    $scope.FM.ImageUrl = '';
            });
        }
    };

    $scope.choosePhoto = function () {
        try {
            var options = {
                quality: 75,
                destinationType: Camera.DestinationType.DATA_URL,
                sourceType: Camera.PictureSourceType.PHOTOLIBRARY,
                allowEdit: true,
                encodingType: Camera.EncodingType.JPEG,
                targetWidth: 300,
                targetHeight: 300,
                popoverOptions: CameraPopoverOptions,
                saveToPhotoAlbum: false
            };

            $cordovaCamera.getPicture(options).then(function (imageData) {
                showLoading();
                $.post(baseUrl + 'FileUploadHandler.ashx', {
                    type: 'ImageFile', data: imageData
                    , contentType: 'image/jpeg', DataID: $scope.FM.FMID, DataType: 'FM'
                }, function (result, a, b, c) {
                    hideLoading();
                    fuResult = result.split('|');
                    if (fuResult.length == 3) {
                        var fileGUIDName = fuResult[0];
                        $scope.FM.ImageUrl = fileGUIDName;
                    }
                    else {
                        alert(result);
                    }
                });
            }, function (err) {
                hideLoading();
                alert(err);
            });
        } catch (e) { alert(e); }
    };
    $scope.deleteFM = function () {
        if (confirm('Are you sure want to delete?') == true) {
            $http({
                method: 'DELETE',
                url: 'api/FM/' + $scope.FM.FMID
            }).success(function (result) {
                if (result == true) {
                    $state.go('app.FM', { FMType: $scope.FMType });
                    swal({ title: "Data deleted successfully!", type: "success", timer: 1000, showConfirmButton: false });
                }
            });
        }
    };
});
app.controller('CMListingCtrl', function ($scope, $http, $location, $ionicModal) {
    $scope.baseUrl = baseUrl;
    $scope.cmlist = [];

    setTimeout(function () {
        $scope.searchCM();
    }, 100);
    $scope.searchCM = function () {
        $http({
            method: 'POST',
            url: 'api/CMListing/'
        }).success(function (data) {
            $scope.cmlist = data;
            $scope.$broadcast('scroll.refreshComplete');
        });
    };
    $ionicModal.fromTemplateUrl('image-modal.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        $scope.modal = modal;
    });

    $scope.openModal = function (Obj, $event) {
        if (Obj != null && Obj != '') {
            $scope.imageSrc = baseUrl + 'Download.aspx?type=profile&filepath=images/profile/' + Obj;
            $scope.modal.show();
            $event.stopPropagation();
        }
    };

    $scope.closeModal = function () {
        $scope.modal.hide();
    };
    $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
        if ($scope.modal.isShown()) {
            event.preventDefault();
            $scope.closeModal();
        }
    });
    $scope.doRefresh = function () {
        //simulate async response
        $scope.searchCM();
    };
});
app.controller('SocRulesCtrl', function ($scope, $http, $location) {
    $scope.Rules = {};
    $scope.showReadMore = false;
    setTimeout(function () {
        $scope.searchSocRules();
    }, 100);
    $scope.searchSocRules = function () {
        $http({
            method: 'GET',
            url: 'api/Rules/1'
        }).success(function (Rules) {
            $scope.Rules = Rules;
            $scope.Rules.AllDetails = $scope.Rules.Details;
            if ($scope.Rules.Details != null && $scope.Rules.Details.length > 150) {
                $scope.Rules.Details = $scope.Rules.Details.substr(0, 150);
                $scope.showReadMore = true;
            }
            $scope.$broadcast('scroll.refreshComplete');
        });
    };
    $scope.doRefresh = function () {
        //simulate async response
        $scope.searchSocRules();
    };
    $scope.showMore = function () {
        $scope.Rules.Details = $scope.Rules.AllDetails;
        $scope.showReadMore = false;
    };
    $scope.toMarkup = function (text) {
        return toMarkup(text);
    };
});
