var app = angular.module('starter');

app.controller('ALListCtrl', function ($scope, $http, $location, $state) {
    $scope.AL = {};
    $scope.filter = { ALID: 0, filterText: '' };
    $scope.ALs = [];
    $scope.showModal = false;
    $scope.ALSubmitted = false;
    $scope.baseUrl = baseUrl;
    $scope.images = [];
    var baseImageUrl = baseUrl + 'Download.aspx?fileID=';
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.searchAL = function () {
        $http({
            method: 'POST',
            url: 'api/ALList/',
            data: JSON.stringify($scope.filter)
        }).success(function (ALs) {
            $scope.ALs = ALs;
            $scope.$broadcast('scroll.refreshComplete');
        });
    };

    $scope.newAL = function () {
        $scope.AL = {};
        $('#modalA').modal('show');
    };
    $scope.renameAL = function (itm) {
        $scope.AL = angular.copy(itm);
        $scope.modalTitle = 'Rename Album';
        $('#modalA').modal('show');
    };

    $scope.deleteAL = function (ALID) {
        $http({
            method: 'POST',
            url: 'api/AL/DeleteAL/',
            data: JSON.stringify({ ALID: ALID })
        }).success(function (result) {
            if (result.indexOf('Error:') > -1) {
                swal({ title: result, type: "error", showConfirmButton: true });
            }
            else {
                swal({ title: "Album Deleted successfully!", type: "success", timer: 1000, showConfirmButton: false });
                $scope.searchAL();
            }
        });
    };
    $scope.deleteImage = function (imgID, imageUrl) {
        $http({
            method: 'POST',
            url: 'api/AL/DeleteImage/',
            data: JSON.stringify({ ImgID: imgID, ImageUrl: imageUrl })
        }).success(function (result) {
            $scope.searchImg();
        });
    };
    $scope.saveAL = function () {

        $http.post('api/AL', $scope.AL, config)
       .success(function (data, status, headers, config) {
           var result = JSON.parse(data);
           if ($.isArray(result))
               $scope.ErrorMessages = result;
           else {
               $scope.ErrorMessages = [];
               swal({ title: "Album Saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
               $('#modalA').modal('hide');
               $scope.searchAL();
           }
       })
       .error(function (data, status, header, config) {
           alert('error');
       });
    };
    $scope.addFiles = function () {
        openImageUploader($scope.fileUploaded, 'FileUploadHandler.ashx?ALID=' + $scope.filter.ALID);
    };
    $scope.fileUploaded = function (result) {
        $scope.searchImg();
    };
    $scope.navigateAL = function (itm) {
        $scope.filter.ALID = itm.ALID;
        $scope.ALName = itm.ALName;
        //$scope.searchImg();
        $state.go('app.ALView', { 'ALID': itm.ALID, 'ALName': itm.ALName });
    };

    $scope.searchImg = function () {
        $http({
            method: 'POST',
            url: 'api/AL/ImgList/',
            data: JSON.stringify($scope.filter)
        }).success(function (Imgs) {
            $scope.Imgs = Imgs;
            $scope.images = [];
            for (var j = 0; j < Imgs.length; j++) {
                var objImg = Imgs[j];
                $scope.images.push({ thumb: baseImageUrl + objImg.ImageUrl, img: baseImageUrl + objImg.ImageUrl });
            }
        });
    };

    $scope.searchAL();
    $scope.doRefresh = function () {
        //simulate async response
        $scope.searchAL();
    };
});


app.controller('ALViewCtrl', function ($scope, $http, $stateParams, $rootScope) {
    var ALID = $stateParams.ALID;
    $scope.ALName = $stateParams.ALName;
    $scope.baseUrl = baseUrl;
    $scope.Imgs = [];
    var baseImageUrl = baseUrl + 'Download.aspx?fileID=';


    $scope.searchImg = function () {
        
        $http({
            method: 'POST',
            url: 'api/AL/ImgList/',
            data: JSON.stringify({ ALID: ALID })
        }).success(function (Imgs) {
            for (var j = 0; j < Imgs.length; j++) {
                Imgs[j].src = baseUrl + 'Download.aspx?fileid=' + Imgs[j].ImageUrl + '&type=image';
            }
            $scope.Imgs = Imgs;
        });
    };

    $scope.searchImg();

});