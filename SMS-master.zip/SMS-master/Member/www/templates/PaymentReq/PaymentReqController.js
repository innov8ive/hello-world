var app = angular.module('starter');

app.controller('PaymentReqListCtrl', function ($scope, $http, $location, $state) {

    $scope = readyAngularGrid($scope, $http, 'api/PaymentReqList', 'ReqID', 'PaymentReq');
    $scope.totalPages = 1;
    $scope.pagingOptions.pageSize = 5;
    $scope.searchPaymentReq = function () {
        $scope.pagingOptions.currentPage = 1;
        $scope.totalPages = 1;
        $scope.allData = [];
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };

    window.setTimeout(function () { $scope.searchPaymentReq(); }, 200);

    $scope.editPaymentReq = function (ReqID, RoomID) {
        $state.go('app.PaymentReqEdit', { 'ReqID': ReqID, 'RoomID': RoomID });
    };

})
.controller('PaymentReqCtrl', function ($scope, $http, $location, $stateParams) {

    var PaymentID = 0;
    var BillID = $stateParams.BillID;
    var RoomID = $stateParams.RoomID;
    var ReqID = $stateParams.ReqID;
    $scope.BillID = BillID;
    $scope.Payments = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.PaymentsSubmitted = false;
    $scope.showRejectRemarks = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.Update = function () {
        $scope.Payments.Approved = false;
        $scope.update();
    };
    $scope.UpdateApproved = function () {
        $scope.Payments.Approved = true;
        $scope.update();
    };
    $scope.update = function () {

        $scope.PaymentsSubmitted = true;
        if ($scope.formPayments.$invalid == true) return;

        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        var BillIDs = '';
        var BillList = [];
        for (var j = 0; j < $scope.Payments.BillPaymentsList.length; j++) {
            BillList.push($scope.Payments.BillPaymentsList[j]);
            BillIDs += ',' + $scope.Payments.BillPaymentsList[j].BillID;
        }
        if (BillList.length > 0)
            BillIDs = BillIDs.substring(1, BillIDs.length - 1);
        $scope.Payments.Amount = $scope.TotalBillAmt;
        //if (($scope.Payments.PaymentID <= 0 || $scope.Payments.PaymentID == null)
        //    && BillList.length == 0) {
        //    swal({ title: "Please select Bill(s)!", type: "error", timer: 1000, showConfirmButton: false });
        //}
        if (($scope.Payments.PaymentID <= 0 || $scope.Payments.PaymentID == null)
            && $scope.Payments.Amount != $scope.TotalBillAmt) {
            swal({ title: "The entered Amount should be equal to Total Bill Amount", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }

        $http({
            method: 'POST',
            url: 'api/Payments',
            data: JSON.stringify($scope.Payments)
        }).success(function (data) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.Payments = result;
                if ($scope.Payments.PaidToGLID != null)
                    $scope.Payments.PaidToGLID = $scope.Payments.PaidToGLID.toString();
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
                if ($scope.Payments.Approved == true) {
                    if (BillID > 0)
                        $location.path('/OutstandingBills');
                    else
                        $location.path('/PaidBills');
                }
            }
        }).error(function (data, status, header, config) {
            alert('error');
        });

    };

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/Payments/' + PaymentID + '/' + RoomID + '/' + ReqID
        }).success(function (Payments) {
            $scope.Payments = JSON.parse(Payments);
            if ($scope.Payments.PaidToGLID != null)
                $scope.Payments.PaidToGLID = $scope.Payments.PaidToGLID.toString();
            $scope.bindCreditTo();
        });
    }, 100);

    $scope.credittolist = [];
    $scope.modelist = [];
    $scope.bindCreditTo = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetContraGLList', Data: null })
        }).success(function (data) {
            $scope.credittolist = data;
        });
        $scope.modelist.push({ Value: 'Cash', Key: 'Cash', Selected: false });
        $scope.modelist.push({ Value: 'Cheque', Key: 'Cheque', Selected: false });
        $scope.modelist.push({ Value: 'NEFT', Key: 'NEFT', Selected: false });
    };

    $scope.TotalBillAmt = 0;
    $scope.$watch('Payments.BillPaymentsList', function (newVal, oldVal) {
        if (newVal !== oldVal) {
            $scope.TotalBillAmt = 0;
            for (var j = 0; j < $scope.Payments.BillPaymentsList.length; j++) {
                $scope.TotalBillAmt += parseFloatEx($scope.Payments.BillPaymentsList[j].PaidAmount);
            }
            $scope.TotalBillAmt = $scope.TotalBillAmt.toFixed(2);
        }
    }, true);

    $scope.approvePaymentReq = function () {
        $http({
            method: 'POST',
            url: 'api/PaymentReq/Approve/',
            data: JSON.stringify({ ReqID: ReqID })
        }).success(function (result) {
            swal({ title: "Payment approved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            history.back(1);
        });

    };

    $scope.rejectPaymentReq = function () {

        if ($scope.Payments.RejectRemarks == null || $scope.Payments.RejectRemarks == '') {
            $scope.showRejectRemarks = true;
            alert('Please enter Remarks');
            return;
        }

        $http({
            method: 'POST',
            url: 'api/PaymentReq/Reject/',
            data: JSON.stringify({
                ReqID: ReqID,
                Remarks: $scope.Payments.RejectRemarks
            })
        }).success(function (result) {
            swal({ title: "Payment rejected successfully!", type: "success", timer: 1000, showConfirmButton: false });
            history.back(1);
        });

    };
});
