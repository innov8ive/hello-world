var app = angular.module('starter');

app.controller('ChatListCtrl', function ($scope, $http, $location, $state, $ionicModal, $ionicFilterBar) {
    $scope.filterOptions = { filterText: '' };
    $scope.baseUrl = baseUrl;
    $scope.ChatUserList = [];
    $scope.ShowList = false;
    $scope.ToUserName = '';
    $scope.ChatList = [];
    var ThisUserID = localStorage["UserID"];
    var FromUserID = ThisUserID;
    var ToUser;
    var IsGroup;
    var GroupName;
    var pageCount;
    var pageNumber;
    $scope.backToChatList = function () {
        $scope.ShowList = false;
    };
    $scope.getChatUserList = function () {
        $http({
            method: 'POST',
            url: 'api/Chat/ChatList/',
            data: JSON.stringify({ text: $scope.filterOptions.filterText })
        }).success(function (result) {
            $scope.ChatUserList = result;
            $scope.$broadcast('scroll.refreshComplete');
        });
    };
    $scope.doRefresh = function () {
        //simulate async response
        $scope.getChatUserList();
    };
    $scope.getChatUserList();

    $scope.userSelected = function (UserID, Obj) {
        $state.go('app.Details', { 'ToUserID': UserID });
    };

    $scope.othersMessageRecieved = function (groupName) {

        if (groupName != GroupName) {
            var chList = $scope.ChatList;
            for (var j = 0; j < chList.length; j++) {
                if (chList[j].GroupGUID == groupName) {
                    chList[j].LastChatDate = new Date();
                }
            }
            $scope.ChatList = chList;
        }
    };

    $scope.loadMore = function () {
        pageNumber++;
        $scope.bindUserChat(true);
    };
    $scope.othersComesOnline = function (fromUserID) {
        if (fromUserID != FromUserID) {
            $("#ulUsers li[userid='" + fromUserID + "']").find('.label-status').css('color', 'green');
        }
    };
    $scope.othersGoesOffline = function (fromUserID) {
        if (fromUserID != FromUserID) {
            $("#ulUsers li[userid='" + fromUserID + "']").find('.label-status').css('color', 'gray');
        }
    };

    $ionicModal.fromTemplateUrl('image-modal.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        $scope.modal = modal;
    });

    $scope.openModal = function (Obj, $event) {
        if (Obj != '' && Obj != null) {
            $scope.imageSrc = baseUrl + 'Download.aspx?type=profile&filepath=images/profile/' + Obj;
            $scope.modal.show();
            $event.stopPropagation();
        }
    };

    $scope.closeModal = function () {
        $scope.modal.hide();
    };
    $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
        if ($scope.modal.isShown()) {
            event.preventDefault();
            $scope.closeModal();
        }
    });
    $scope.showFilterBar = function () {
        filterBarInstance = $ionicFilterBar.show({
            items: null,
            update: function (a, b) {
                if (b != null) {
                    $scope.filterOptions.filterText = b;
                    $scope.getChatUserList();
                }
            },
            delay: 500
        });
        window.setTimeout(function () { $('.filter-bar-search').val($scope.filterOptions.filterText); }, 200);
    };
});
app.controller('ChatCtrl', function ($scope, $http, $location, $stateParams, $ionicScrollDelegate, $timeout) {
    var ToUserID = $stateParams.ToUserID;
    groupHub = $.connection.chatHub;
    $scope.baseUrl = baseUrl;
    $scope.ShowList = false;
    $scope.ToUserName = '';
    $scope.ChatList = [];
    var ThisUserID = localStorage["UserID"];
    var FromUserID = ThisUserID;
    var ToUser;
    var IsGroup;
    var GroupName;
    var pageCount;
    var pageNumber;

    $scope.getUserDetails = function () {
        $http({
            method: 'POST',
            url: 'api/Chat/GetUserDetails/',
            data: JSON.stringify({ GroupID: ToUserID })
        }).success(function (result) {

            IsGroup = result[0].IsGroup;
            GroupName = result[0].GroupGUID;
            var toUserID = result[0].UserID;
            pageCount = 0;
            pageNumber = 1;
            $scope.ToUserName = result[0].UserName;
            ToUserID = toUserID;
            groupHub.server.joinChat(ThisUserID, toUserID, GroupName);
            $(".xlist-group-item.text-center").hide().prependTo('body');
            $('#chatBody').html('');
            $(".xlist-group-item.text-center").prependTo('#chatBody');
            $scope.bindUserChat(false);
        });
    };
    $scope.getUserDetails();

    $scope.bindUserChat = function (scrollToTop) {

        var FromUserID = ThisUserID;
        $http({
            method: 'POST',
            url: 'api/Chat/UserChats/',
            data: JSON.stringify({ toUserID: ToUserID, pageNumber: pageNumber, groupID: GroupName }),
        }).success(function (result) {
            var resultObj = result;
            var messages = resultObj.data;
            pageCount = resultObj.TotalPages;
            var html = '';
            var readUnRead = '';
            for (var j = messages.length - 1; j >= 0 ; j--) {
                var dateString = '<time class=\"timeago\" datetime=\"' + messages[j].ChatDateString + '\"></time>';

                var deleteString = '';
                if (messages[j].IsDeleted == true)
                    deleteString = '';
                else
                    deleteString = '<span class=\"fa fa-trash pull-right\" onclick=\"deleteChat(this);\"></span>';

                if (IsGroup == '0') {
                    if (messages[j].IsRead == 'Read')
                        readUnRead = '<i class=\"fa fa-check read\"></i>';
                    else
                        readUnRead = '<i class=\"fa fa-check\"></i>';
                }

                var sender = '';
                sender = '<p class=\"user-group\">' + messages[j].SentByName + '</p>';

                if (messages[j].FromID == FromUserID)
                    html += '<li UniqueID=\"' + messages[j].UniqueID + '\" class=\"list-group-item text-right\">' + sender + toMarkup(messages[j].Msg) + dateString + deleteString + readUnRead + '</li>';
                else
                    html += '<li UniqueID=\"' + messages[j].UniqueID + '\" class=\"list-group-item\">' + sender + toMarkup(messages[j].Msg) + dateString + '</li>';

            }
            $('#chatBody').prepend(html);
            $(".xlist-group-item.text-center").prependTo("#chatBody");
            if (pageNumber < pageCount)
                $(".xlist-group-item.text-center").show();
            else
                $(".xlist-group-item.text-center").hide();


            if (scrollToTop == false)
                $timeout(function () {
                    $ionicScrollDelegate.scrollBottom();
                }, 50);
            else
                $timeout(function () {
                    $ionicScrollDelegate.scrollTop();
                }, 50);

            jQuery("time.timeago").timeago();
        });

    };
    $scope.SendMessage = function () {

        var message = $('#txtMessage').val();
        if (message.length > 0) {
            groupHub.server.sendMessage(message, ThisUserID, ToUserID, GroupName);
            //addMyChat(message);
            $('#txtMessage').val('');
        }
    };
    $scope.addMyChat = function (Msg, isMychat, uniqueID, groupName, sentBy) {
        var deleteString = '<span class=\"fa fa-trash pull-right\" onclick=\"deleteChat(this);\"></span>';
        var readUnRead = '<i class=\"fa fa-check\"></i>';
        var dateString = '<time class=\"timeago\" datetime=\"' + (new Date()).toISOString() + '\"></time>';
        sender = '<p class=\"user-group\">' + sentBy + '</p>';
        if (IsGroup == '1') {
            readUnRead = '';
        }
        if (isMychat == false)
            $('#chatBody').append('<li UniqueID=\"' + uniqueID + '\" class=\"list-group-item\">' + sender + toMarkup(Msg) + dateString + '</li>');
        else
            $('#chatBody').append('<li UniqueID=\"' + uniqueID + '\" class=\"list-group-item text-right\">' + sender + toMarkup(Msg) + dateString + deleteString + readUnRead + '</li>');
        jQuery("time.timeago").timeago();
    };
    $scope.saveLastRead = function () {
        $http({
            method: 'POST',
            url: 'api/Chat/SaveLastRead/',
            data: JSON.stringify({ userID: ThisUserID, groupName: GroupName })
        }).success(function (result) {

        });
    };

    $scope.messageSent = function (Msg, fromUser, toUser, uniqueID, groupName, sentBy) {
        if (fromUser == ToUserID) {
            groupHub.server.messageOpened(fromUser, toUser, GroupName);
            $scope.addMyChat(Msg, false, uniqueID, groupName, sentBy);
        }
        else if (fromUser == ThisUserID)
            $scope.addMyChat(Msg, true, uniqueID, groupName, sentBy);
        else if (groupName == GroupName)
            $scope.addMyChat(Msg, (fromUser == ThisUserID), uniqueID, groupName, sentBy);
        $scope.saveLastRead();
        var objDiv = document.getElementById("chatBody").parentNode;
        objDiv.scrollTop = objDiv.scrollHeight;
        $timeout(function () {
            $ionicScrollDelegate.scrollBottom();
        }, 50);
    };

    $scope.messageDeleted = function (uniqueID, fromUser, toUser) {
        $("[UniqueID='" + uniqueID + "']").html('<span class="remarkLog">This message has been removed.</span>');
    };
    $scope.messageRead = function (fromUserID, toUserID) {
        if (ThisUserID == toUserID && ToUserID == fromUserID)
            $('.fa-check').addClass('read');
    };
    $scope.messageOpened = function (fromUserID, toUserID) {
        if (ThisUserID == fromUserID && ToUserID == toUserID)
            $('.fa-check').addClass('read');
    };

    $scope.othersMessageRecieved = function (groupName) {

        if (groupName != GroupName) {
            var chList = $scope.ChatList;
            for (var j = 0; j < chList.length; j++) {
                if (chList[j].GroupGUID == groupName) {
                    chList[j].LastChatDate = new Date();
                }
            }
            $scope.ChatList = chList;
            $ionicScrollDelegate.scrollBottom();
        }
    };

    $scope.loadMore = function () {
        pageNumber++;
        $scope.bindUserChat(true);
    };
    $scope.othersComesOnline = function (fromUserID) {
        if (fromUserID != FromUserID) {
            $("#ulUsers li[userid='" + fromUserID + "']").find('.label-status').css('color', 'green');
        }
    };
    $scope.othersGoesOffline = function (fromUserID) {
        if (fromUserID != FromUserID) {
            $("#ulUsers li[userid='" + fromUserID + "']").find('.label-status').css('color', 'gray');
        }
    };
   
});