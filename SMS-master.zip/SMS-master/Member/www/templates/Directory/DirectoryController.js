var app = angular.module('starter');

app.controller('DirectoryListCtrl', function ($scope, $http, $location, $state, $ionicFilterBar) {
    $scope.baseUrl = baseUrl;
    $scope.filterOptions = { filterText: '' };
    $scope.UserID = parseInt(localStorage["UserID"]);
    $scope.searchDirectory = function () {
        $http({
            method: 'POST',
            url: 'api/DirectoryList/',
            data: JSON.stringify({ searchText: $scope.filterOptions.filterText })
        }).success(function (result) {
            $scope.allData = result;
            $scope.$broadcast('scroll.refreshComplete');
        });
    };
    $scope.doRefresh = function () {
        //simulate async response
        $scope.searchDirectory();
    };
    window.setTimeout(function () { $scope.searchDirectory(); }, 200);

    $scope.newDirectory = function () {
        $state.go('app.DirectoryEdit', { 'ID': 0 });
    };
    $scope.editDirectory = function (ID, AddedBy) {
        $state.go('app.DirectoryEdit', { 'ID': ID });
    };
    $scope.showFilterBar = function () {
        filterBarInstance = $ionicFilterBar.show({
            items: null,
            update: function (a, b) {
                if (b != null) {
                    $scope.filterOptions.filterText = b;
                    $scope.searchDirectory();
                }
            },
            delay: 500
        });
        window.setTimeout(function () { $('.filter-bar-search').val($scope.filterOptions.filterText); }, 200);
    };
})

.controller('DirectoryCtrl', function ($scope, $http, $location, $stateParams, $state) {
    var ID = $stateParams.ID;
    $scope.UserID = parseInt(localStorage["UserID"]);
    $scope.Directory = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.DirectorySubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.DirectorySubmitted = true;
        if ($scope.formDirectory.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/Directory', $scope.Directory, config)
        .success(function (data, status, headers, config) {
            var result = data;
            if (result.ErrorCode == 1)
                $scope.ErrorMessages = result.data;
            else {
                $scope.ErrorMessages = [];
                $scope.Directory = result.data;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/DirectoryList');
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/Directory/' + ID
        }).success(function (Directory) {
            $scope.Directory = Directory;
        });
    }, 100);
    $scope.deleteDirectory = function () {
        if (confirm('Are you sure want to delete?') == true) {
            $http({
                method: 'DELETE',
                url: 'api/Directory/' + $scope.Directory.ID
            }).success(function (result) {
                if (result == true) {
                    $state.go('app.Directory');
                    swal({ title: "Data deleted successfully!", type: "success", timer: 1000, showConfirmButton: false });
                }
            });
        }
    };
});
