angular.module('starter.controllers', ['starter.services', 'pascalprecht.translate'])

.controller('AppCtrl', function ($scope, $ionicModal, $timeout, Globals, $translate) {


    $scope.g = Globals;
    //$scope.g.SocName = $scope.g.SocName.length > 35 ? $scope.g.SocName.substr(0, 35) + '...' : $scope.g.SocName;

    //$scope.curLanguage = Globals.curLanguage;
    //$scope.changeLanguage = function (Obj) {
    //    Globals.curLanguage = Obj.curLanguage;
    //    $translate.use(Globals.curLanguage);
    //};
    //$translate.use(Globals.curLanguage);
})
.controller('FPController', function ($scope, $http, $state) {
    $scope.FP = { UserName: '' };
    $scope.submitFP = function () {
        if ($scope.FP.UserName == '') {
            swal({ title: "Please enter Username!", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        $http({
            method: 'POST',
            url: 'api/Common/ForgotPassword',
            data: JSON.stringify({ UserName: $scope.FP.UserName })
        }).success(function (result) {
            if (result == "Success") {
                swal({
                    title: "New Password has been sent to your Registered Email/Mobile!", type: "success",
                    showConfirmButton: true
                });
                $state.go('app.login');
            }
            else {
                swal({ title: result, type: "error", timer: 1000, showConfirmButton: false });
            }
            $scope.FPShow = false;
        });
    };
})
.controller('CPController', function ($scope, $http, $state) {
    $scope.CP = { OldPassword: '', NewPassword: '', ConfirmPassword: '', UserID: 0 };
    $scope.changePassword = function () {
        $scope.CPSubmitted = true;
        if ($scope.formCP.$invalid == true) return;
        if ($scope.CP.NewPassword != $scope.CP.ConfirmPassword) {
            swal({ title: "New Password and Confirmn Password must be same!", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        $scope.CP.UserID = parseInt(localStorage["UserID"]);
        $http({
            method: 'POST',
            url: 'api/Common/ChangePassword',
            data: JSON.stringify($scope.CP)
        }).success(function (result) {
            if (result == "Invalid") {
                swal({ title: "Invalid Old Password, Password not changed!", type: "error", timer: 1000, showConfirmButton: false });
            }
            else if (result == "Changed") {
                swal({ title: "Password changed successfully!", type: "success", showConfirmButton: true });
                $state.go('app.profile');
            }
        });
    };
})
.controller('MainCtrl', function ($scope, Help, $http, $state, $ionicHistory, Globals) {
    $scope.doRefresh = function () {
        //simulate async response
        $scope.loadData();
    };
    $scope.loadDBItem = function () {
        if (navigator.splashscreen != null) {
            navigator.splashscreen.hide();
        }
        if (localStorage["DB"] != null) {
            $scope.bindData(JSON.parse(localStorage["DB"]));
        }
        if (localStorage["user"] != null && localStorage["pass"] != null) {
            if (loginDone == false)
                loginUser(localStorage["user"], localStorage["pass"]);
            else
                $scope.loadData();
        }
    };

    $scope.loadData = function () {
        $http({
            method: 'POST',
            url: 'api/Home/AllDashBoard'
        }).success(function (result) {
            $scope.bindData(result);
            localStorage["DB"] = JSON.stringify(result);
            $scope.$broadcast('scroll.refreshComplete');
        });
    };
    $scope.bindData = function (result) {
        $scope.TotalFlats = result.TotalFlats;
        $scope.TotalOutstanding = result.TotalOutstanding;
        $scope.Vehicles = result.Vehicles;
        $scope.TotalFM = result.TotalFM;
        $scope.TotalStaff = result.TotalStaff;
        $scope.TotalNB = result.TotalNB;
        $scope.Polls = result.Polls;
        $scope.RecentForum = result.RecentForum;
    };
    var loginUser = function (email, password) {
        var url = 'api/Common/LoginMember/Login';
        $http({
            method: 'POST',
            url: url,
            data: JSON.stringify({ UserName: email, Password: password })
        }).success(function (User) {
            if (User == null) {
                alert('Login Failed!');

                localStorage.removeItem("user");
                localStorage.removeItem("pass");
                localStorage.removeItem("token");
                localStorage.removeItem("reqType");
            }
            else {
                $ionicHistory.nextViewOptions({
                    disableBack: true
                });
                //debugger;
                loginDone = true;
                localStorage["user"] = email;
                localStorage["Name"] = User.FirstName + ' ' + User.LastName;
                localStorage["ImageUrl"] = User.ImageUrl;
                localStorage["pass"] = password;
                localStorage["token"] = User.Token;
                localStorage["reqType"] = User.UserType;
                localStorage["UserID"] = User.UserID;
                localStorage["SocName"] = User.SocName;
                Globals.SocName = User.SocName;
                $scope.loadData();

            }
        }).error(function () {
            if (navigator.splashscreen != null) {
                navigator.notification.confirm("Internet Connection not found! Do you want to Retry or Exit?", function (button) {
                    if (button == 2) {//If User selected No, then we just do nothing
                        navigator.app.exitApp();// Otherwise we quit the app.
                    } else {
                        $scope.login();
                    }
                }, "Confirmation", "Retry,Exit");
            }
        });
    };
    window.setTimeout(function () { $scope.loadDBItem(); }, 200);

    $scope.getCarousel = function () {
        $http({
            method: 'POST',
            url: 'api/Carousel/GetCarousel/'
        }).success(function (result) {
            $scope.CarouselList = result;
            if ($scope.CarouselList != null && $scope.CarouselList.length > 0) {
                $state.go('app.slideshow');
            }
        });
    };
})
.controller('ddCtrl', function ($scope, $http, $state, $cordovaCamera) {
   
    $scope.UserID = localStorage["UserID"];
    $scope.UserName = localStorage["Name"];
    $scope.ImageUrl = baseUrl + '/Download.aspx?type=profile&filepath=images/profile/' + localStorage["ImageUrl"];

    $scope.hasImage = localStorage["ImageUrl"] != null && localStorage["ImageUrl"] != '';

    $scope.removePhoto = function () {
        if (confirm('Are you sure, want to remove photo?')) {
            $http({
                method: 'POST',
                url: 'api/Users/RemovePhoto/',
                data: JSON.stringify($scope.UserID + '.' + localStorage["ImageUrl"])
            }).success(function (result) {
                if (result == 'true') {
                    localStorage["ImageUrl"] = '';
                    $scope.ImageUrl = baseUrl + '/Download.aspx?type=profile&fileID=' + localStorage["ImageUrl"];
                    $scope.hasImage = false;
                }
            });
        }
    };
    $scope.takePhoto = function () {
        try {
            var options = {
                quality: 75,
                destinationType: Camera.DestinationType.DATA_URL,
                sourceType: Camera.PictureSourceType.CAMERA,
                allowEdit: true,
                encodingType: Camera.EncodingType.JPEG,
                targetWidth: 300,
                targetHeight: 300,
                popoverOptions: CameraPopoverOptions,
                saveToPhotoAlbum: false
            };

            $cordovaCamera.getPicture(options).then(function (imageData) {
                showLoading();
                $.post(baseUrl + 'FileUploadHandler.ashx',
                    {
                        type: 'ImageFile', data: imageData
                    , contentType: 'image/jpeg', DataID: $scope.UserID, DataType: 'User'
                    }, function (result, a, b, c) {
                        hideLoading();
                        fuResult = result.split('|');
                        if (fuResult.length == 3) {
                            var fileGUIDName = fuResult[0];
                            localStorage["ImageUrl"] = fileGUIDName;
                            $scope.ImageUrl = baseUrl + '/Download.aspx?type=profile&filepath=images/profile/' + localStorage["ImageUrl"];
                            $scope.hasImage = true;
                        }
                        else {
                            alert(result);
                            hideLoading();
                        }
                    });
            }, function (err) {
                alert(err);
            });
        } catch (e) { alert(e); }
    };

    $scope.choosePhoto = function () {
        try {
            var options = {
                quality: 75,
                destinationType: Camera.DestinationType.DATA_URL,
                sourceType: Camera.PictureSourceType.PHOTOLIBRARY,
                allowEdit: true,
                encodingType: Camera.EncodingType.JPEG,
                targetWidth: 300,
                targetHeight: 300,
                popoverOptions: CameraPopoverOptions,
                saveToPhotoAlbum: false
            };

            $cordovaCamera.getPicture(options).then(function (imageData) {
                showLoading();
                $.post(baseUrl + 'FileUploadHandler.ashx', {
                    type: 'ImageFile', data: imageData
                    , contentType: 'image/jpeg', DataID: $scope.UserID, DataType: 'User'
                }, function (result, a, b, c) {
                    hideLoading();
                    fuResult = result.split('|');
                    if (fuResult.length == 3) {
                        var fileGUIDName = fuResult[0];
                        localStorage["ImageUrl"] = fileGUIDName;
                        $scope.ImageUrl = baseUrl + '/Download.aspx?type=profile&filepath=images/profile/' + localStorage["ImageUrl"];
                        $scope.hasImage = true;
                    }
                    else {
                        alert(result);
                    }
                });
            }, function (err) {
                hideLoading();
                alert(err);
            });
        } catch (e) { alert(e); }
    };
    $scope.CP = function () {
        $state.go('app.CP');
    };

    $scope.Users = {};
    $scope.ErrorMessages = [];
    $scope.UsersSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.UsersSubmitted = true;
        if ($scope.formUsers.$invalid == true) return;
        $http.post('api/Users/UpdateProfile', $scope.Users, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.Users = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
                User.FirstName = $scope.Users.FirstName;
                User.LastName = $scope.Users.LastName;
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };
    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/UsersProfile'
        }).success(function (Users) {
            $scope.Users = JSON.parse(Users);
        });
    }, 100);
})
.controller('LogoutCtrl', function ($scope, $ionicHistory, Globals, $http) {
    $scope.logout = function (option) {
        if (option == 1) {
            $http({
                method: 'POST',
                url: 'api/Common/Logout/'
            }).success(function (result) {
                localStorage.removeItem("user");
                localStorage.removeItem("pass");
                localStorage.removeItem("token");
                window.location = 'index.html';
            });

        }
        else
            history.go(-1);
    };
});