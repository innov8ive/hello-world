﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;

namespace SampleAngular.Controllers
{
    public class ChatController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        [System.Web.Mvc.HttpPost]
        public ActionResult GetUserList()
        {
            LoggedUser objLoggedUser = Session["LoggedUser"] as LoggedUser;

            DataTable dt = Common.GetDBResultParameterized(@"select NULL as SignalRConnectID,CG.GroupID as UserID,CG.GroupName as UserName,
CG.ImageUrl,CG.GroupGUID,NULL as LastChatDate,1 as IsGroup,CG.CreatedBy,'' as UnitNo from ChatGroup CG 
where exists (select 1 from ChatGroupUsers CGU where CGU.GroupID=CG.GroupID and CGU.UserID=@UserID)
UNION ALL
Select SignalRConnectID,UserID,FirstName+ISNULL(' '+LastName,'') as UserName,ISNULL(ImageUrl,'') as ImageUrl,
Case when @UserID>UserID then CONVERT(varchar,UserID)+'-'+CONVERT(varchar,@UserID)
else CONVERT(varchar,@UserID)+'-'+CONVERT(varchar,UserID) end as GroupName,
VCR.LastChatDate,0 as IsGroup,NULL as CreatedBy,RoomNos
from VW_Users
left join VW_ChatRead VCR ON VCR.ToID=@UserID 
and Case when @UserID>UserID then CONVERT(varchar,UserID)+'-'+CONVERT(varchar,@UserID)
else CONVERT(varchar,@UserID)+'-'+CONVERT(varchar,UserID) end=VCR.GroupName
 where UserID<>@UserID and UserType=2
and LicID=@LicID Order By LastChatDate Desc;", "@UserID", SqlDbType.Int, objLoggedUser.UserID,
                 "@LicID", SqlDbType.Int, objLoggedUser.SocID);
            return Json(JsonConvert.SerializeObject(dt, Formatting.Indented));
        }

        [System.Web.Mvc.HttpPost]
        public ActionResult GetUserChats(int toUserID, int pageNumber, string groupID)
        {
            LoggedUser objLoggedUser = Session["LoggedUser"] as LoggedUser;

            Hashtable ht = Common.GetPagedData(@"Select case when (cr.LastRead IS NULL OR C.ChatDate < cr.LastRead) then 'Read' else 'UnRead' end as IsRead,
CONVERT(varchar(19),C.ChatDate,126)+'Z' as ChatDateString,
C.UniqueID,C.FromID,c.ChatDate,c.IsDeleted,c.Msg,C.ToID,cr.LastRead,U.FirstName+ISNULL(' '+U.LastName,'') as SentByName,C.GroupID from VW_Chat C
left join VW_Chatread cr on cr.ToID=@ToID
left join Users U ON C.FromID=U.UserID
where C.GroupID=@GroupID",
                "UniqueID", "ChatDate", "Desc", pageNumber, 20,
                "@FromID", SqlDbType.Int, objLoggedUser.UserID,
                 "@ToID", SqlDbType.Int, toUserID,
                 "@GroupID", SqlDbType.VarChar, groupID);


            return Json(JsonConvert.SerializeObject(ht, Formatting.Indented));
        }

        [System.Web.Mvc.HttpPost]
        public ActionResult SaveLastRead(int userID, string groupName)
        {
            LoggedUser objLoggedUser = Session["LoggedUser"] as LoggedUser;
            ChatHelper.SaveLastRead(userID, groupName);
            return Json(true);
        }

        [System.Web.Mvc.HttpPost]
        public ActionResult DeleteChat(string uniqueID)
        {
            Common.ExecuteNonQuery("update VW_Chat set Msg='<span class=\"remarkLog\">This message has been removed.</span>',IsDeleted=1 where UniqueID=@UniqueID",
                "@UniqueID", SqlDbType.VarChar, uniqueID);
            return Json(true);
        }

        [System.Web.Mvc.HttpPost]
        public ActionResult HasUnReadChat()
        {
            LoggedUser objLoggedUser = Session["LoggedUser"] as LoggedUser;
            int count = Common.ToInt(Common.GetDBScalar("select COUNT(*) from VW_ChatRead CR where CR.ToID=" + objLoggedUser.UserID));
            return Json(count);
        }
    }
}