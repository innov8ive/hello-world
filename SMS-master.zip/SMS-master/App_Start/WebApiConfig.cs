﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Http;
using System.Web.Http.Controllers;
using System.Web.Http.Cors;

namespace SampleAngular
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Web API configuration and services
            var cors = new EnableCorsAttribute(origins: "*", headers: "*", methods: "*");
            config.EnableCors(cors);
            // Web API routes
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );
        }
    }

    public class CustomAuthorizeAttribute : System.Web.Http.AuthorizeAttribute
    {
        public string Region { get; set; }
        protected override bool IsAuthorized(HttpActionContext actionContext)
        {
            LoggedUser objLoggedUser = HttpContext.Current.Session["LoggedUser"] as LoggedUser;
            if (objLoggedUser == null)
            {
                throw new HttpResponseException(HttpStatusCode.Unauthorized);
                return false;
            }
            return true;
        }
    }
}
