﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SampleAngular
{
    public partial class Download : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string fileGUID = Common.ToString(Request.QueryString["fileID"]);
                if (fileGUID.Length > 0)
                {
                    DataTable dt = Common.GetDBResultParameterized("Select * from Files where FileGUID='" + fileGUID.Replace("'", "''") + "'");
                    if (dt.Rows.Count > 0)
                    {
                        try
                        {
                            string fileName = Common.ToString(dt.Rows[0]["FileName"]);
                            string mimeType = System.Web.MimeMapping.GetMimeMapping(fileName);
                            //Convert the memorystream to an array of bytes.
                            byte[] byteArray = File.ReadAllBytes(Server.MapPath("~/AttachedFiles/" + fileGUID));
                            // Clear all content output from the buffer stream
                            Response.Clear();
                            // Add a HTTP header to the output stream that specifies the default filename
                            // for the browser's download dialog
                            if (Request.QueryString["download"] != null)
                            {
                                Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName.Replace(" ", "_"));
                            }
                            else
                            {
                                Response.AddHeader("Content-Disposition", "inline; filename=" + fileName.Replace(" ", "_"));
                            }
                            // Add a HTTP header to the output stream that contains the
                            // content length(File Size). This lets the browser know how much data is being transfered
                            Response.AddHeader("Content-Length", byteArray.Length.ToString());
                            // Set the HTTP MIME type of the output stream
                            Response.ContentType = mimeType;
                            // Write the data out to the client.
                            Response.BinaryWrite(byteArray);
                        }
                        catch
                        {
                            if (Common.ToString(Request.QueryString["type"]) == "profile")
                            {
                                DownloadFile("images/profile/profile.png");
                            }
                            else
                            {
                                Page.ClientScript.RegisterStartupScript(this.GetType(), "mess", "alert('The file is not found!');", true);
                            }

                        }
                    }
                    else
                    {
                        try
                        {
                            string fileName = fileGUID;
                            string mimeType = System.Web.MimeMapping.GetMimeMapping(fileName);
                            //Convert the memorystream to an array of bytes.
                            byte[] byteArray = File.ReadAllBytes(Server.MapPath("~/AttachedFiles/" + fileGUID));
                            // Clear all content output from the buffer stream
                            Response.Clear();
                            // Add a HTTP header to the output stream that specifies the default filename
                            // for the browser's download dialog
                            if (Request.QueryString["download"] != null)
                            {
                                Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName.Replace(" ", "_"));
                            }
                            else
                            {
                                Response.AddHeader("Content-Disposition", "inline; filename=" + fileName.Replace(" ", "_"));
                            }
                            // Add a HTTP header to the output stream that contains the
                            // content length(File Size). This lets the browser know how much data is being transfered
                            Response.AddHeader("Content-Length", byteArray.Length.ToString());
                            // Set the HTTP MIME type of the output stream
                            Response.ContentType = mimeType;
                            // Write the data out to the client.
                            Response.BinaryWrite(byteArray);
                        }
                        catch
                        {
                            if (Common.ToString(Request.QueryString["type"]) == "profile")
                            {
                                DownloadFile("images/profile/profile.png");
                            }
                            else
                            {
                                Page.ClientScript.RegisterStartupScript(this.GetType(), "mess", "alert('The file is not found!');", true);
                            }
                        }
                    }
                }
                else
                {
                    string filePath = Common.ToString(Request.QueryString["filepath"]);
                    if (filePath.Length > 0)
                    {
                        try
                        {
                            DownloadFile(filePath);
                        }
                        catch
                        {
                            if (Common.ToString(Request.QueryString["type"]) == "profile")
                            {
                                DownloadFile("images/profile/profile.png");
                            }
                            if (Common.ToString(Request.QueryString["type"]) == "image")
                            {
                                DownloadFile("images/profile/image.png");
                            }
                            Page.ClientScript.RegisterStartupScript(this.GetType(), "mess", "alert('The file is not found!');", true);
                        }
                    }
                    else
                    {
                        if (Common.ToString(Request.QueryString["type"]) == "profile")
                        {
                            DownloadFile("images/profile/profile.png");
                        }
                        if (Common.ToString(Request.QueryString["type"]) == "image")
                        {
                            DownloadFile("images/profile/image.png");
                        }
                    }
                }
            }
        }

        private void DownloadFile(string filePath)
        {
            string mimeType = System.Web.MimeMapping.GetMimeMapping(filePath);
            //Convert the memorystream to an array of bytes.
            byte[] byteArray = File.ReadAllBytes(Server.MapPath("~/" + filePath));
            // Clear all content output from the buffer stream
            Response.Clear();
            // Add a HTTP header to the output stream that specifies the default filename
            // for the browser's download dialog
            if (Request.QueryString["download"] != null)
            {
                Response.AddHeader("Content-Disposition", "attachment; filename=" + filePath);
            }
            else
            {
                Response.AddHeader("Content-Disposition", "inline; filename=" + filePath);
            }
            // Add a HTTP header to the output stream that contains the
            // content length(File Size). This lets the browser know how much data is being transfered
            Response.AddHeader("Content-Length", byteArray.Length.ToString());
            // Set the HTTP MIME type of the output stream
            Response.ContentType = mimeType;
            // Write the data out to the client.
            Response.BinaryWrite(byteArray);
        }
    }
}