﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNet.SignalR;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace SampleAngular
{
    public class ChatHub : Hub
    {
        public void Send(string Name, string Message)
        {
            Clients.All.BroadCastMsg(Name, Message);
        }
        public void UpdateQT(string Name, string groupName)
        {
            Clients.Group(groupName).quoteUpdated(Name);
        }
        public Task Join(string groupName)
        {
            return Groups.Add(Context.ConnectionId, groupName);
        }
        public override Task OnConnected()
        {
            return base.OnConnected();
        }
        public override Task OnDisconnected(bool stopCalled)
        {
            //get Offline UserID
            int userID = Common.ToInt(Common.GetDBScalar("Select UserID from Users where SignalRConnectID=@SignalRConnectID",
                   "@SignalRConnectID", SqlDbType.VarChar, Context.ConnectionId));

            //Update User Status as Offline
            Common.ExecuteNonQuery("Update Users set SignalRConnectID=NULL where SignalRConnectID=@SignalRConnectID",
                "@SignalRConnectID", SqlDbType.VarChar, Context.ConnectionId);

            //Find all online except this user and notify them that this user gone offline
//            DataTable dt = Common.GetDBResultParameterized(@"Select US.UserID from Users US where 
//exists(select 1 from Users U where U.SocID=US.SocID and U.UserID=@UserID)
//and US.UserID<>@UserID and US.SignalRConnectID is not null", "@UserID", SqlDbType.Int, userID);

            DataTable dt = Common.GetDBResultParameterized(@"Select US.UserID from Users US where 
exists (
select 1 from Soc S where 
UserID=(select ISNULL(CreatedBy,UserID) from Users U where 
U.UserID=@UserID) and (S.UserID=US.UserID OR US.CreatedBy=S.UserID))
and US.UserID<>@UserID and US.SignalRConnectID is not null", "@UserID", SqlDbType.Int, userID);
            foreach (DataRow dr in dt.Rows)
            {
                Clients.Group(Common.ToString(dr["UserID"])).notifyUserGoesOffline(userID);
            }

            return base.OnDisconnected(stopCalled);
        }


        public Task JoinChatNotification(int userID)
        {
            string userName = Common.ToString(Common.GetDBScalar("Select FirstName+ISNULL(' '+LastName,'') as Name from Users where UserID=@UserID",
                "@UserID", SqlDbType.Int, userID));
            //Update User Status as Online
            Common.ExecuteNonQuery("Update Users set SignalRConnectID=@SignalRConnectID where UserID=@UserID",
                "@SignalRConnectID", SqlDbType.VarChar, Context.ConnectionId,
                "@UserID", SqlDbType.Int, userID);

            //Find all online except this user and notify them that this user come online
            DataTable dt = Common.GetDBResultParameterized(@"Select US.UserID from Users US where 
exists(select 1 from Users U where U.UserID=@UserID)
and US.UserID<>@UserID and US.SignalRConnectID is not null", "@UserID", SqlDbType.Int, userID);
            foreach (DataRow dr in dt.Rows)
            {
                Clients.Group(Common.ToString(dr["UserID"])).notifyUserComesOnline(userID, userName);
            }

            return Groups.Add(Context.ConnectionId, userID.ToString());
        }
        public Task JoinChat(int fromUserID, int toUserID, string groupName)
        {
            ChatHelper.SaveLastRead(fromUserID, groupName);
            Clients.Group(groupName).messageRead(fromUserID, toUserID);
            return Groups.Add(Context.ConnectionId, groupName);
        }
        public void SendMessage(string Msg, int fromUserID, int toUserID, string groupName)
        {
            string chatDateString = ChatHelper.InsertChat(Msg, fromUserID, toUserID, groupName);
            string sentBy = Common.ToString(Common.GetDBScalar("Select FirstName+ISNULL(' '+LastName,'') as UserName from Users where UserID=" + fromUserID));
            Clients.Group(groupName).messageSent(Msg, fromUserID, toUserID, chatDateString, groupName, sentBy);
            Common.SendChatPush(toUserID, sentBy + ":" + Msg);

            if (groupName.Length > 10)
            {
                //probably, it is a group message
                //notify to all users of the group
                DataTable dtUsersOfGroup = Common.GetDBResultParameterized(@"select * from ChatGroupUsers CGU where exists (
select 1 from ChatGroup CG where CG.GroupID=CGU.GroupID and CG.GroupGUID=@GroupID)",
 "@GroupID", SqlDbType.VarChar, groupName);
                foreach (DataRow dr in dtUsersOfGroup.Rows)
                {
                    Clients.Group(Common.ToString(dr["UserID"])).notify(groupName);
                }
            }
            else
            {
                Clients.Group(toUserID.ToString()).notify(groupName);
            }
            ChatHelper.SaveLastRead(fromUserID, groupName);
        }
        public void DeleteMessage(string uniqueID, int fromUserID, int toUserID, string groupName)
        {
            Clients.Group(groupName).messageDeleted(uniqueID, fromUserID, toUserID);
        }
        public void MessageOpened(int fromUserID, int toUserID, string groupName)
        {
            //Clients.Group(groupName).messageOpened(fromUserID, toUserID);
        }
    }

    public class ChatHelper
    {
        public static string GetUserGroupName(int user1, int user2)
        {
            if (user1 > user2)
                return user2 + "-" + user1;
            else
                return user1 + "-" + user2;
        }
        public static string InsertChat(string message, int fromUser, int toUser,string groupName)
        {
            SqlConnection con = new SqlConnection(Common.GetConString());
            SqlCommand cmd = new SqlCommand("Insert_Into_Chat", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@FromID", SqlDbType.Int).Value = fromUser;
            cmd.Parameters.Add("@ToID", SqlDbType.Int).Value = toUser;
            cmd.Parameters.Add("@ChatDate", SqlDbType.DateTime).Value = DateTime.UtcNow;
            cmd.Parameters.Add("@ChatDateString", SqlDbType.VarChar, 50).Value = String.Empty;
            cmd.Parameters.Add("@GroupID", SqlDbType.VarChar, 50).Value = groupName;
            cmd.Parameters["@ChatDateString"].Direction = ParameterDirection.InputOutput;
            cmd.Parameters.Add("@Msg", SqlDbType.NVarChar, 500).Value = message;

            con.Open();
            using (con)
            {
                cmd.ExecuteNonQuery();
                con.Close();
            }
            return Common.ToString(cmd.Parameters["@ChatDateString"].Value);
        }
        public static void SaveLastRead(int userID, string groupName)
        {
            Common.ExecuteNonQuery("Exec Insert_Update_ChatRead @GroupName,@LastRead,@UserID",
                "@GroupName", SqlDbType.VarChar, groupName,
                "@LastRead", SqlDbType.DateTime, DateTime.UtcNow,
                "@UserID", SqlDbType.Int, userID);
        }
    }
}