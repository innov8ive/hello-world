﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Net.Http;

namespace SampleAngular
{
    public class SarvHelper
    {
        private static string url = ConfigurationManager.AppSettings["sarv:url"];// "http://api.sarvmail.net/v1.0/messages/sendMail";
        private static string owner_id = ConfigurationManager.AppSettings["sarv:user_id"];//a valid Sarv User Id 
        private static string token = ConfigurationManager.AppSettings["sarv:token"];
        private static string smtp_user_name = ConfigurationManager.AppSettings["sarv:smtp_user_name"];//a valid smtp user name 

        public string SendEmail(string toEmail, string toName, string subject, string body)
        {



            WebClient client = new WebClient();
            using (client)
            {
                string postData2 = GetData();// JsonConvert.SerializeObject(objEmail);
                byte[] byteArray2 = Encoding.UTF8.GetBytes(postData2);
                var response2 = client.UploadData(url, "POST", byteArray2);

                var responseString = Encoding.Default.GetString(response2);
            }


            SarvEmail objEmail = new SarvEmail();
            objEmail.owner_id = owner_id;
            objEmail.smtp_user_name = smtp_user_name;
            objEmail.token = token;

            SarvMsg objMsg = new SarvMsg();
            objMsg.from_email = "test@mail.com";
            objMsg.from_name = "Test";
            objMsg.html = body;
            objMsg.subject = subject;
            List<SarvTo> to = new List<SarvTo>();
            to.Add(new SarvTo() { email = toEmail, type = "to", name = toName });
            objMsg.to = to;

            objEmail.message = objMsg;


            WebRequest request = WebRequest.Create(url);
            // Set the Method property of the request to POST.
            request.Method = "POST";
            // Create POST data and convert it to a byte array.
            request.ContentType = "text/json";
            string postData = GetData();// JsonConvert.SerializeObject(objEmail);
            byte[] byteArray = Encoding.UTF8.GetBytes(postData);

            // Set the ContentLength property of the WebRequest.
            //request.Headers.Add("OAuth-Token", HttpContext.Current.Application["token"].ToString());
            //request.Headers.Add("OAuth-Token", token);
            WebResponse response = null;
            Stream dataStream = null;
            // Get the response.
            try
            {
                // Set the ContentLength property of the WebRequest.
                request.ContentLength = byteArray.Length;
                // Get the request stream.
                dataStream = request.GetRequestStream();
                // Write the data to the request stream.
                dataStream.Write(byteArray, 0, byteArray.Length);
                // Close the Stream object.
                dataStream.Close();
                // Get the response.
                response = request.GetResponse();
            }
            catch
            {
            }
            // Display the status.
            Console.WriteLine(((HttpWebResponse)response).StatusDescription);
            // Get the stream containing content returned by the server.
            dataStream = response.GetResponseStream();
            // Open the stream using a StreamReader for easy access.
            StreamReader reader = new StreamReader(dataStream);
            // Read the content.
            string responseFromServer = reader.ReadToEnd();

            // Clean up the streams.
            reader.Close();
            dataStream.Close();
            response.Close();

            //Sync
            SarvResponse objSarvResponse = JsonConvert.DeserializeObject<SarvResponse>(responseFromServer);
            return objSarvResponse.status;
        }

        private string GetData()
        {
            string postDate = "{\"message\":{\"to\":[{\"email\":\"sanjay2@mailinator.com\",\"name\":\"Sanjay\",\"type\":\"to\"}],\"html\":\"est\",\"subject\":\"test sub\",\"from_email\":\"no-reply@societyinn.com\",\"from_name\":\"No-Reply SocietyInn\"},\"owner_id\":\"57905705\",\"token\":\"hkaNNiM9xRNu6BxEEYgV\",\"smtp_user_name\":\"smtp32116009\"}";
            return postDate;
        }
    }

    public class SarvResponse
    {
        public string status { get; set; }
        public int code { get; set; }
        public string name { get; set; }
        public string message { get; set; }
    }
    public class SarvEmail
    {
        public string owner_id { get; set; }
        public string token { get; set; }
        public string smtp_user_name { get; set; }
        public SarvMsg message { get; set; }
    }

    public class SarvMsg
    {
        public string html { get; set; }
        public string text { get; set; }
        public string subject { get; set; }
        public string from_email { get; set; }
        public string from_name { get; set; }
        public List<SarvTo> to { get; set; }
        public object headers { get; set; }
        public List<SarvAttachment> attachments { get; set; }
    }

    public class SarvTo
    {
        public string email { get; set; }
        public string name { get; set; }
        public string type { get; set; }
    }

    public class SarvAttachment
    {
        public string type { get; set; }
        public string name { get; set; }
        public string content { get; set; }
    }
}
