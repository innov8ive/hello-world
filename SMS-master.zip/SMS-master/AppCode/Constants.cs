﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SampleAngular
{
    public enum GLNo
    {
        Cash = 1,
        Sales = 2,
        OwnerEquity = 3,
        Purchase = 4,
        OwnerCapital = 5,
        SalesReturn = 6,
        PurchaseReturn = 7
    }

    public enum GroupNo
    {
        CapitalAccount = 1,
        CurrentAssets = 5,
        Bank = 6,
        Cash = 7,
        CurrentLiabilities = 11,
        Investments = 20,
        LoansLiability = 21,

        RepairMaintenance = 34,
        CommonAmenities = 35,
        DirectExpense = 15,

        DirectIncome = 16,
        IncomeFromProperty = 30,
        OtherIncome = 31,

        MembersContribution = 6,
        Debtors = 26,
        Creditors = 41,
        Interest = 16,
        CashAndBank = 17,
        MiscellaneousIncome = 13,
        FixedAsset = 28,
        AdministrativeExpenses = 15,
    }
    public static class Constants
    {
        public class Values
        {
            public const string WebsiteHost = "http://app.societyinn.com/#/";
        }
        public class Forms
        {
            //public const int User = 8;
            //public const int Soc = 9;
            //public const int Rooms = 10;
            //public const int Forum = 11;
            //public const int ForumList = 13;
            //public const int Category = 14;
            //public const int Carousel = 15;
            //public const int EditSP = 16;
            //public const int SP = 18;
            //public const int Listing = 19;
            //public const int MailSettings = 20;
            //public const int Pages = 25;
            //public const int GL = 27;
            //public const int Exp = 99;
            //public const int Income = 100;
            //public const int Contra = 101;
            //public const int Service = 8;
            //public const int NB = 37;
            //public const int PL = 39;
            //public const int PB = 41;
            //public const int OB = 45;
            //public const int VMGT = 63;

            public const int SystemAdmin = 8;
            public const int MailSettings = 20;
            public const int MeetingManager = 72;
            public const int SocietyRules = 68;
            public const int Marketplace = 35;
            public const int FileRepository = 48;
            public const int CommitteeMembers = 49;
            public const int ParkingManager = 51;
            public const int Directory = 73;
            public const int Gallery = 50;
            public const int Advertisement = 95;
            public const int ChartsofAccount = 28;
            public const int VoucherType = 29;
            public const int JournalEntryReports = 31;
            public const int TrialBalance = 32;
            public const int BalanceSheet = 33;
            public const int ProfitandExpenditure = 34;
            public const int PenaltyMethod = 71;
            public const int BillSetUp = 54;
            public const int GenerateBills = 41;
            public const int ViewPrintBills = 46;
            public const int PaymentReconcilation = 85;
            public const int MakePayment = 45;
            public const int MiscBills = 77;
            public const int Chat = 92;
            public const int Message = 57;
            public const int Forum = 13;
            public const int ComplaintBox = 58;
            public const int Polls = 39;
            public const int NoticeBoard = 37;
            public const int FacilityDetails = 66;
            public const int FacilityBooking = 67;
            public const int Society = 9;
            public const int BlockWing = 55;
            public const int Unit = 10;
            public const int Members = 8;
            public const int GateKeeper = 59;
            public const int FinacialYear = 70;
            public const int Vendors = 98;
            public const int Staffs = 103;
            public const int UserRoles = 104;
            public const int BillRegister = 97;
            public const int UnitStatement = 78;
            public const int Defaulters = 79;
            public const int VisitDetails = 61;
            public const int Expense = 99;
            public const int Income = 100;
            public const int FundTransfer = 101;
            public const int JournalEntryVoucherEntry = 102;

            public const int NormalUser = 36;
            public const int PayTMUser = 105;
        }

        public class UserType
        {
            public const int Normal = 1;
            public const int Admin = 2;
            public const int SysAdmin = 3;
            public const int SP = 4;
            public const int PayTM = 8;
            public const int GateKeeper = 9;
        }
    }
}