﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;

namespace SampleAngular
{
    public class PushNotification
    {
        public static string AndroidPush(string regId,string message,string subject,string key)
        {
            // applicationID means google Api key                                                                                                     
            var applicationID = "AIzaSyBQZRzfcMdfPTKGzai7g2bYQ7_SOvnAcVQ";//Server key (auto created by Google Service)
            // SENDER_ID is nothing but your ProjectID (from API Console- google code)//                                          
            var SENDER_ID = "145352986955";
            WebRequest tRequest;
            //https://fcm.googleapis.com/fcm/send
            //https://gcm-http.googleapis.com/gcm/send
            //https://android.googleapis.com/gcm/send
            tRequest = WebRequest.Create("https://android.googleapis.com/gcm/send");//https://fcm.googleapis.com/fcm/send
            //tRequest = WebRequest.Create("https://gcm-http.googleapis.com/gcm/send");//
            tRequest.Method = "post";
            tRequest.ContentType = " application/x-www-form-urlencoded;charset=UTF-8";
            tRequest.Headers.Add(string.Format("Authorization: key={0}", applicationID));
            tRequest.Headers.Add(string.Format("Sender: id={0}", SENDER_ID));
            //Data post to server                                                                                                                                         
            string postData =
                 "collapse_key=" + key + "&time_to_live=86400&delay_while_idle=60&priority=high&data.message="
                  + message + "&data.title=" + subject + "&data.time=" + System.DateTime.Now.AddMinutes(1).ToString() + "&registration_id=" +
                     regId + "";
            try
            {
                Byte[] byteArray = Encoding.UTF8.GetBytes(postData);
                tRequest.ContentLength = byteArray.Length;
                Stream dataStream = tRequest.GetRequestStream();
                dataStream.Write(byteArray, 0, byteArray.Length);
                dataStream.Close();
                WebResponse tResponse = tRequest.GetResponse();
                dataStream = tResponse.GetResponseStream();
                StreamReader tReader = new StreamReader(dataStream);
                String sResponseFromServer = tReader.ReadToEnd();   //Get response from GCM server.
                tReader.Close();
                dataStream.Close();
                tResponse.Close();
                return sResponseFromServer;
            }
            catch
            {
                return "Error";
            }
            
        }
        public static string AndroidPush(string regId, string message, string subject, string key,string serverUrl)
        {
            // applicationID means google Api key                                                                                                     
            var applicationID = "AIzaSyBQZRzfcMdfPTKGzai7g2bYQ7_SOvnAcVQ";//Server key (auto created by Google Service)
            // SENDER_ID is nothing but your ProjectID (from API Console- google code)//                                          
            var SENDER_ID = "145352986955";
            WebRequest tRequest;
            //https://fcm.googleapis.com/fcm/send
            //https://gcm-http.googleapis.com/gcm/send
            //https://android.googleapis.com/gcm/send
            tRequest = WebRequest.Create(serverUrl);//https://fcm.googleapis.com/fcm/send
            //tRequest = WebRequest.Create("https://gcm-http.googleapis.com/gcm/send");//
            tRequest.Method = "post";
            tRequest.ContentType = " application/x-www-form-urlencoded;charset=UTF-8";
            tRequest.Headers.Add(string.Format("Authorization: key={0}", applicationID));
            tRequest.Headers.Add(string.Format("Sender: id={0}", SENDER_ID));
            //Data post to server                                                                                                                                         
            string postData =
                 "collapse_key=" + key + "&time_to_live=86400&delay_while_idle=60&priority=high&data.message="
                  + message + "&data.title=" + subject + "&data.time=" + System.DateTime.Now.AddMinutes(1).ToString() + "&registration_id=" +
                     regId + "";
            try
            {
                Byte[] byteArray = Encoding.UTF8.GetBytes(postData);
                tRequest.ContentLength = byteArray.Length;
                Stream dataStream = tRequest.GetRequestStream();
                dataStream.Write(byteArray, 0, byteArray.Length);
                dataStream.Close();
                WebResponse tResponse = tRequest.GetResponse();
                dataStream = tResponse.GetResponseStream();
                StreamReader tReader = new StreamReader(dataStream);
                String sResponseFromServer = tReader.ReadToEnd();   //Get response from GCM server.
                tReader.Close();
                dataStream.Close();
                tResponse.Close();
                return sResponseFromServer;
            }
            catch
            {
                return "Error";
            }

        }
    }
}