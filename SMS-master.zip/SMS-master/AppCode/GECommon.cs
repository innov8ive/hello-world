using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using SampleAngularBL;
using SampleAngularOM;
//using SampleAngularTypeLib;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;

namespace SampleAngular
{
    public class GECommon
    {
        #region GEntry
        public static GE OrgGEntry(int orgID, decimal dr, decimal cr, int refID, string refNo, string comment, DateTime geDate, int companyID, int locationID, string refType)
        {
            return OrgGEntry(0, orgID, dr, cr, refID, refNo, comment, geDate, companyID, locationID, refType);
        }
        public static GE OrgGEntry(int geGroupID, int orgID, decimal dr, decimal cr, int refID, string refNo, string comment, DateTime geDate, int companyID, int locationID, string refType)
        {
            DataTable dt =
                Common.GetDBResult("Select AccountID from Accounts where OrgID=" + orgID);
            if (dt != null && dt.Rows.Count > 0)
            {
                return GEntry(geGroupID, Common.ToInt(dt.Rows[0]["AccountID"]), dr, cr, refID, refNo, comment, geDate, companyID,
                              locationID, 0, refType);
            }
            else
            {
                throw new Exception("No GL Found for organization!");
            }
        }
        public static GE ChgGEntry(int geGroupID, int chgID, decimal dr, decimal cr, int refID, string refNo, string comment, DateTime geDate, int companyID, int locationID, string refType)
        {
            DataTable dt =
                Common.GetDBResult("Select GLID from GL where ChgID=" + chgID);
            if (dt != null && dt.Rows.Count > 0)
            {
                return GEntry(geGroupID, Common.ToInt(dt.Rows[0]["GLID"]), dr, cr, refID, refNo, comment, geDate, companyID,
                              locationID, 0, refType);
            }
            else
            {
                throw new Exception("No GL Found for organization!");
            }
        }
        public static GE GEntry(int geGroupID, int glID, decimal dr, decimal cr, int refID, string refNo, string comment, DateTime geDate, int companyID, int locationID, string refType)
        {
            return GEntry(geGroupID, glID, dr, cr, refID, refNo, comment, geDate, companyID, locationID, 0, refType);
        }
        public static GE GEntry(int glID, decimal dr, decimal cr, int refID, string refNo, string comment, DateTime geDate, int companyID, int locationID, string refType)
        {
            return GEntry(0, glID, dr, cr, refID, refNo, comment, geDate, companyID, locationID, 0, refType);
        }
        public static GE GEntry(int geGroupID, int glID, decimal dr, decimal cr, int refID, string refNo, string comment, DateTime geDate, int companyID, int locationID, int groupNo, string refType)
        {
            GE objGE = new GE();
            objGE.Comment = comment;
            objGE.CompanyID = companyID;
            objGE.Cr = cr;
            objGE.Dr = dr;
            objGE.GEDate = geDate;
            objGE.GLID = glID;
            objGE.RefID = refID;
            objGE.RefNo = refNo;
            objGE.GroupNo = groupNo;
            objGE.GEGroupID = geGroupID;
            objGE.LocationID = locationID;
            objGE.EntryDate = DateTime.Now;
            objGE.TransType = refType;
            GEBL objGEBL = new GEBL(Common.GetConString());
            objGEBL.Data = objGE;
            objGEBL.Update();
            return objGEBL.Data;
        }
        public static GE GEntry(GLNo glNo, decimal dr, decimal cr, int refID, string refNo, string comment, DateTime geDate, int companyID, int locationID, int groupNo, string refType)
        {
            return GEntry(0, glNo, dr, cr, refID, refNo, comment, geDate, companyID, locationID, groupNo, refType);
        }
        public static GE GEntry(int geGroupID, GLNo glNo, decimal dr, decimal cr, int refID, string refNo, string comment, DateTime geDate, int companyID, int locationID, int groupNo, string refType)
        {
            DataTable dt = Common.GetDBResult("Select GLID from GL where GLNo=" + ((int)glNo) + " and CompanyID=" + companyID);
            if (dt != null && dt.Rows.Count > 0)
            {
                int glID = Common.ToInt(dt.Rows[0]["GLID"]);
                return GEntry(geGroupID, glID, dr, cr, refID, refNo, comment, geDate, companyID, locationID, groupNo, refType);
            }
            else
            {
                throw new Exception("No GL found:" + glNo.ToString());
            }
        }
        public static void UpdateGEEntry(int geID, decimal dr, decimal cr, int refID, string refNo)
        {
            SqlConnection con = new SqlConnection(Common.GetConString());
            SqlCommand cmd = new SqlCommand("Update GE set Dr=@DR,Cr=@CR,RefID=@RefID,RefNo=@RefNo where GEID=@GEID", con);
            cmd.Parameters.Add("@DR", SqlDbType.Decimal).Value = dr;
            cmd.Parameters.Add("@CR", SqlDbType.Decimal).Value = cr;
            cmd.Parameters.Add("@RefID", SqlDbType.Int).Value = refID;
            cmd.Parameters.Add("@RefNo", SqlDbType.VarChar, 100).Value = refNo;
            cmd.Parameters.Add("@GEID", SqlDbType.Int).Value = geID;
            con.Open();
            using (con)
            {
                cmd.ExecuteNonQuery();
            }
        }
        public static void DeleteGEEntry(int geID)
        {
            SqlConnection con = new SqlConnection(Common.GetConString());
            SqlCommand cmd = new SqlCommand("delete from GE where GEID=@GEID", con);
            cmd.Parameters.Add("@GEID", SqlDbType.Int).Value = geID;
            con.Open();
            using (con)
            {
                cmd.ExecuteNonQuery();
            }
        }
        public static void GEEntry(VE objVE)
        {
            List<VEDetails> objVEDetailsList = objVE.VEDetailsList;
            int GEGroupID = Common.ToInt(objVE.GEGroupID);
            Common.ExecuteNonQuery("delete from GE where CompanyID=" + objVE.SocID + " and GEGroupID=" + GEGroupID);
            foreach (VEDetails objVEDetails in objVEDetailsList.FindAll(Obj => Common.ToInt(Obj.DrID) > 0))
            {
                GE objGE = GEntry(GEGroupID, Common.ToInt(objVEDetails.DrID), Common.ToDecimal(objVEDetails.Dr)
                    , 0, Common.ToInt(objVE.VEID), Common.ToString(objVE.VENo), objVE.Remarks, Common.ToDate(objVE.VEDate), Common.ToInt(objVE.SocID), 0, 0, "VE");
                GEGroupID = Common.ToInt(objGE.GEGroupID);
            }
            foreach (VEDetails objVEDetails in objVEDetailsList.FindAll(Obj => Common.ToInt(Obj.CrID) > 0))
            {
                GE objGE = GEntry(GEGroupID, Common.ToInt(objVEDetails.CrID), 0, Common.ToDecimal(objVEDetails.Cr)
                   , Common.ToInt(objVE.VEID), Common.ToString(objVE.VENo), objVE.Remarks, Common.ToDate(objVE.VEDate), Common.ToInt(objVE.SocID), 0, 0, "VE");
                GEGroupID = Common.ToInt(objGE.GEGroupID);
            }
            objVE.GEGroupID = GEGroupID;
            Common.ExecuteNonQuery("Update VE set GEGroupID=" + GEGroupID + " where VEID=" + Common.ToInt(objVE.VEID));
        }
        public static void GEEntryBill(Bills objBills, LoggedUser objLoggedUser)
        {
            int GEGroupID = Common.ToInt(objBills.BillGEGroupID);
            decimal totalBill = Common.ToDecimal(objBills.Amount) + Common.ToDecimal(objBills.LF);
            Common.ExecuteNonQuery("delete from GE where CompanyID=" + objBills.SocID + " and GEGroupID=" + GEGroupID);
            GE objGE = GECommon.OrgGEntry(Common.ToInt(objBills.RoomID), totalBill, 0,
                                               Common.ToInt(objBills.BillID),
                                               Common.ToString(objBills.BillID), String.Empty, Common.ToDate(objBills.BillDate), objLoggedUser.SocID,
                                                0, "Bill");
            GEGroupID = Common.ToInt(objGE.GEGroupID);

            foreach (BChg objBSUChg in objBills.BChgList)
            {
                GECommon.GEntry(GEGroupID, Common.ToInt(objBSUChg.ChgID),
                                                0, Common.ToDecimal(objBSUChg.Amt),
                                               Common.ToInt(objBills.BillID),
                                               Common.ToString(objBills.BillID), String.Empty, Common.ToDate(objBills.BillDate),
                                               objLoggedUser.SocID,
                                               0, 0, "Bill");
            }

            if (Common.ToDecimal(objBills.LF) > 0)
            {
                //Get penalty ChgID
                int lfChgID = Common.ToInt(Common.GetDBScalar("Select AccountID from Accounts where AccountType='Penalty' and SocID=" + objBills.SocID));
                if (lfChgID > 0)
                {
                    //Post LF in Penalty
                    GECommon.GEntry(GEGroupID, lfChgID,
                                                    0, Common.ToDecimal(objBills.LF),
                                                   Common.ToInt(objBills.BillID),
                                                   Common.ToString(objBills.BillID), String.Empty, Common.ToDate(objBills.BillDate),
                                                   objLoggedUser.SocID,
                                                   0, 0, "Bill");
                }
            }

            objBills.BillGEGroupID = GEGroupID;
            Common.ExecuteNonQuery("Update Bills set BillGEGroupID=" + GEGroupID + " where BillID=" + Common.ToInt(objBills.BillID));


        }
        public static void GEEntryPayment(Bills objBills, LoggedUser objLoggedUser)
        {
            int GEGroupID = Common.ToInt(objBills.PaidGEGroupID);
            Common.ExecuteNonQuery("delete from GE where CompanyID=" + objBills.SocID + " and GEGroupID=" + GEGroupID);
            GE objGE = GECommon.GEntry(Common.ToInt(objBills.PaidToGLID),
                                       Common.ToDecimal(objBills.PaidAmount), 0,
                                       Common.ToInt(objBills.BillID),
                                       Common.ToString(objBills.BillID), objBills.Remarks, Common.ToDate(objBills.PaidDate),
                                       objLoggedUser.SocID,
                                       0, "Payment");

            GEGroupID = Common.ToInt(objGE.GEGroupID);

            GECommon.OrgGEntry(GEGroupID, Common.ToInt(objBills.RoomID), 0, Common.ToDecimal(objBills.PaidAmount),
                                          Common.ToInt(objBills.BillID),
                                          Common.ToString(objBills.BillID), objBills.Remarks, Common.ToDate(objBills.PaidDate),
                                          objLoggedUser.SocID,
                                          0, "Payment");
            objBills.PaidGEGroupID = GEGroupID;
            Common.ExecuteNonQuery("Update Bills set PaidGEGroupID=" + GEGroupID + " where BillID=" + Common.ToInt(objBills.BillID));
        }
        public static void GEEntryPayment(Payments objPayments, int SocID)
        {
            int GEGroupID = Common.ToInt(objPayments.PaidGEGroupID);
            Common.ExecuteNonQuery("delete from GE where CompanyID=" + objPayments.SocID + " and GEGroupID=" + GEGroupID);
            GE objGE = GECommon.GEntry(Common.ToInt(objPayments.PaidToGLID),
                                       Common.ToDecimal(objPayments.Amount), 0,
                                       Common.ToInt(objPayments.PaymentID),
                                       Common.ToString(objPayments.PaymentID), objPayments.Remarks, Common.ToDate(objPayments.PaymentDate),
                                       Common.ToInt( objPayments.SocID),
                                       0, "Payment");

            GEGroupID = Common.ToInt(objGE.GEGroupID);

            GECommon.OrgGEntry(GEGroupID, Common.ToInt(objPayments.RoomID), 0, Common.ToDecimal(objPayments.Amount),
                                          Common.ToInt(objPayments.PaymentID),
                                          Common.ToString(objPayments.PaymentID), objPayments.Remarks, Common.ToDate(objPayments.PaymentDate),
                                          SocID,
                                          0, "Payment");
            objPayments.PaidGEGroupID = GEGroupID;

            Common.ExecuteNonQuery("Update Payments set PaidGEGroupID=" + GEGroupID + " where PaymentID=" + Common.ToInt(objPayments.PaymentID));
        }
        #endregion

        #region PDF
        private void ToPDF()
        {
            DataTable dt1 = GetData();
            DataTable dt2 = GetData2();
            FileStream fs = new FileStream(HttpContext.Current.Server.MapPath("a.pdf"), FileMode.Create, FileAccess.Write, FileShare.None);
            Rectangle rec2 = new Rectangle(PageSize.A4);
            Document doc = new Document(rec2, 36, 36, 36, 36);
            PdfWriter writer = PdfWriter.GetInstance(doc, fs);
            doc.Open();
            PdfPTable table = new PdfPTable(2);
            //actual width of table in points
            //table.TotalWidth = 516f;
            //fix the absolute width of the table
            //table.LockedWidth = true;
            //relative col widths in proportions - 1/3 and 2/3
            // float[] widths = new float[] { 1f, 1f };
            //table.SetWidths(widths);
            PdfPCell cell = new PdfPCell(new Phrase("Header", FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 12)));
            cell.HorizontalAlignment = 1;
            cell.Colspan = 2;
            cell.Border = 0;
            cell.Padding = 10f;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase("(From 01-Mar-2014 to 31-04-2015)"));
            cell.Colspan = 2;
            cell.Border = 0;
            cell.Padding = 5f;
            cell.HorizontalAlignment = 1;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase("Col 1"));
            cell.HorizontalAlignment = 1;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase("Col 2"));
            cell.HorizontalAlignment = 1;
            table.AddCell(cell);
            table.AddCell(DataTableToPdfTable(dt1, false, false));
            table.AddCell(DataTableToPdfTable(dt2, false, false));
            cell = new PdfPCell(new Phrase("2800.00"));
            cell.HorizontalAlignment = 2;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase("2800.00"));
            cell.HorizontalAlignment = 2;
            table.AddCell(cell);
            doc.Add(table);
            doc.Close();
        }
        private PdfPTable DataTableToPdfTable(DataTable dt, bool printHeader, bool printBorder)
        {
            PdfPTable table = new PdfPTable(dt.Columns.Count);
            if (printHeader)
            {
                PdfPCell cell = null;
                foreach (DataColumn dc in dt.Columns)
                {
                    cell = new PdfPCell(new Phrase(dc.Caption));
                    cell.HorizontalAlignment = 1;//0=Left, 1=Centre, 2=Right
                    if (!printBorder) cell.Border = 0;
                    table.AddCell(cell);
                }
            }
            foreach (DataRow dr in dt.Rows)
            {
                PdfPCell cell = null;
                foreach (DataColumn dc in dt.Columns)
                {
                    int align = 0;
                    string ColVal = String.Empty;
                    if (!Convert.IsDBNull(dr[dc.ColumnName]))
                    {
                        if (dc.DataType == typeof(string))
                        {
                            align = 0;//0=Left, 1=Centre, 2=Right
                            ColVal = Common.ToString(dr[dc.ColumnName]);
                        }
                        else if (dc.DataType == typeof(decimal))
                        {
                            align = 2;//0=Left, 1=Centre, 2=Right
                            ColVal = Common.ToDecimal(dr[dc.ColumnName]).ToString("0.00");
                        }
                        else if (dc.DataType == typeof(int))
                        {
                            align = 2;//0=Left, 1=Centre, 2=Right
                            ColVal = Common.ToInt(dr[dc.ColumnName]).ToString();
                        }
                    }
                    cell = new PdfPCell(new Phrase(ColVal));
                    cell.HorizontalAlignment = align;
                    if (!printBorder) cell.Border = 0;
                    table.AddCell(cell);
                }
            }
            return table;
        }
        private DataTable GetData()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Desc", typeof(string));
            dt.Columns.Add("Amount", typeof(decimal));
            dt.Rows.Add("sdfsdg:", 200);
            dt.Rows.Add("sdf fsdjfs:", 500);
            dt.Rows.Add("fewg fsdjfs:", 300);
            dt.Rows.Add("sdf fddf:", 1500);
            dt.Rows.Add("sdffddf:", 400);
            dt.Rows.Add("sdf fddf:", 1500);
            return dt;
        }
        private DataTable GetData2()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Desc", typeof(string));
            dt.Columns.Add("Amount", typeof(decimal));
            dt.Rows.Add("sdf fsdjfs:", 500);
            dt.Rows.Add("fewg fsdjfs:", 300);
            dt.Rows.Add("sdf fddf:", 1500);
            dt.Rows.Add("", null);
            dt.Rows.Add("sdffddf:", 400);
            return dt;
        }
        #endregion

        #region GE Print
        public static HttpResponseMessage PrintGE(DateTime? fromDate, DateTime? toDate, LoggedUser objSetting)
        {
            if (fromDate == null)
            {
                fromDate = objSetting.StartDate;
                toDate = objSetting.EndDate;
            }
            toDate = toDate.Value.AddDays(1).AddMinutes(-1);
            DataTable dt =
                Common.GetDBResultParameterized(
                    @"select GE.GEDate,GE.Comment,
                    GL.AccountName as GLName,GE.Dr,GE.Cr,GE.GEGroupID,GE.TransType from GE
                    left outer join Accounts GL ON GE.GLID=GL.AccountID
                    and GE.CompanyID=GL.SocID
                    where GEDate between @FromDate and @ToDate and GE.CompanyID=@SocID order by GE.GEDate,GE.GEGroupID",
            "@FromDate", SqlDbType.DateTime, fromDate,
            "@ToDate", SqlDbType.DateTime, toDate,
            "@SocID", SqlDbType.Int, objSetting.SocID);

            DataTable dtNew = new DataTable();
            dtNew.Columns.Add("Date", typeof(string));
            dtNew.Columns.Add("Journal Entry", typeof(string));
            dtNew.Columns.Add("Remarks", typeof(string));
            dtNew.Columns.Add("Dr", typeof(string));
            dtNew.Columns.Add("Cr", typeof(string));

            DataRow dr = null;
            DataView view = new DataView(dt);
            DataTable distinctValues = view.ToTable(true, "GEGroupID", "TransType");
            double total = Common.ToDouble(dt.Compute("SUM(Dr)", ""));
            StringBuilder sbTemp = new StringBuilder();
            StringBuilder sbTemp2 = new StringBuilder();
            foreach (DataRow drGE in distinctValues.Rows)
            {
                DataRow[] drDr = dt.Select("GEGroupID=" + Common.ToInt(drGE["GEGroupID"]) + " and TransType='" + Common.ToString(drGE["TransType"]) + "' and Dr<>0");
                DataRow[] drCr = dt.Select("GEGroupID=" + Common.ToInt(drGE["GEGroupID"]) + " and TransType='" + Common.ToString(drGE["TransType"]) + "' and Cr<>0");
                if (drDr.Length > 0 && drCr.Length > 0)
                {
                    dr = dtNew.NewRow();
                    dr["Date"] = Common.ToDate(drDr[0]["GEDate"]).ToString(objSetting.DateTimeFormat);

                    sbTemp = new StringBuilder();
                    foreach (var drRow in drDr)
                    {
                        sbTemp.Append("`").Append(drRow["GLName"].ToString());
                    }
                    foreach (var drRow in drCr)
                    {
                        sbTemp.Append("`     To ").Append(drRow["GLName"].ToString());
                    }
                    dr["Journal Entry"] = sbTemp.ToString().Substring(1);
                    dr["Remarks"] = drDr[0]["Comment"].ToString();

                    sbTemp = new StringBuilder();
                    sbTemp2 = new StringBuilder();
                    foreach (var drRow in drDr)
                    {
                        sbTemp.Append("`").Append(drRow["Dr"].ToString());
                        sbTemp2.Append("`");
                    }
                    dr["Dr"] = sbTemp.ToString().Substring(1);

                    sbTemp = new StringBuilder();
                    foreach (var drRow in drCr)
                    {
                        sbTemp.Append("`").Append(drRow["Cr"].ToString());
                    }
                    dr["Cr"] = sbTemp2.ToString() + sbTemp.ToString().Substring(1);

                    dtNew.Rows.Add(dr);
                }
            }
            dr = dtNew.NewRow();
            dr["Journal Entry"] = "Total";
            dr["Dr"] = total.ToString("0.00");
            dr["Cr"] = total.ToString("0.00");
            dtNew.Rows.Add(dr);

            DataTableToPDF obj = new DataTableToPDF();
            obj.Header = "Journal Entry - " + objSetting.SocName;

            obj.SubHeader = "(" + fromDate.Value.ToString(objSetting.DateTimeFormat) + " To " +
                           toDate.Value.ToString(objSetting.DateTimeFormat) + ")";

            obj.PageTopMargin = 40f;
            return obj.DataTableToPdf(dtNew, new float[] { 15f, 33f, 33f, 15f, 15f });
        }
        #endregion

        #region Trial Balance Print
        public static DataTable GetTrialBalance(DateTime asOnDate, LoggedUser objSetting)
        {
            asOnDate = asOnDate.AddDays(1).AddMinutes(-1);
            DataTable dt = Common.GetDBResult(@"SELECT GL.AccountID as GLID,GL.AccountName as GLName
,ISNULL(GL.DrAmount,0)-ISNULL(GL.CrAmount,0)+ISNULL(LB.Balance,0) as Balance FROM Accounts GL
LEFT OUTER JOIN LedgerBalance('" + asOnDate.ToString("yyyy-MM-dd HH:mm") + "') LB ON GL.AccountID=LB.GLID and GL.SocID=LB.CompanyID where GL.SocID=" + objSetting.SocID);
            DataTable dtNew = new DataTable();
            dtNew.Columns.Add("GLID", typeof(int));
            dtNew.Columns.Add("Account Name", typeof(string));
            dtNew.Columns.Add("Dr", typeof(double));
            dtNew.Columns.Add("Cr", typeof(double));
            DataRow drNew = null;
            foreach (DataRow dr in dt.Rows)
            {
                drNew = dtNew.NewRow();
                drNew["GLID"] = dr["GLID"];
                drNew["Account Name"] = dr["GLName"];
                if (Common.ToDouble(dr["Balance"]) >= 0)
                {
                    drNew["Dr"] = Common.ToDouble(dr["Balance"]);
                    drNew["Cr"] = "0.00";
                }
                else
                {
                    drNew["Dr"] = "0.00";
                    drNew["Cr"] = Common.ToDouble(dr["Balance"]) * -1;
                }
                dtNew.Rows.Add(drNew);
            }
            //Add Total
            drNew = dtNew.NewRow();
            drNew["GLID"] = 0;
            drNew["Account Name"] = "Total";
            drNew["Dr"] = Common.ToDouble(dtNew.Compute("SUM(Dr)", ""));
            drNew["Cr"] = Common.ToDouble(dtNew.Compute("SUM(Cr)", ""));
            dtNew.Rows.Add(drNew);
            return dtNew;
        }
        public static HttpResponseMessage PrintTrialBalance(DateTime date, LoggedUser objSetting)
        {
            DataTable dt = GetTrialBalance(date, objSetting);
            dt.Columns.Remove("GLID");
            dt.AcceptChanges();
            DataTableToPDF obj = new DataTableToPDF();
            obj.Header = "Trial Balance - " + objSetting.SocName;
            obj.SubHeader = "(on " + date.ToString(objSetting.DateTimeFormat) + ")";
            obj.PageTopMargin = 40f;
            return obj.DataTableToPdf(dt, new float[] { 40f, 10f, 10f });
        }
        #endregion

        #region Ledger Print
        public static void PrintLedger(DateTime fromDate, DateTime toDate, int glID, LoggedUser objSetting)
        {
            toDate = toDate.AddDays(1).AddMinutes(-1);
            //Find Closing on fromDate
            decimal opening = 0;
            string glName = String.Empty;
            DataTable dt = Common.GetDBResult("SELECT GL.GLName,DBO.GetLedgerClosingBalance('" + fromDate.ToString("yyyy-MM-dd") + "',GL.GLID) as Bal from GL where GL.GLID=" + glID);
            if (dt.Rows.Count > 0)
            {
                opening = Common.ToDecimal(dt.Rows[0]["Bal"]);
                glName = dt.Rows[0]["GLName"].ToString();
            }
            DataTable dtDr = Common.GetDBResult(@"SELECT GE1.GEDate,'To '+GL.GLName as GLName ,GE1.Cr FROM GE GE1 LEFT OUTER JOIN GL ON GE1.GLID=GL.GLID WHERE GE1.GEGroupID IN
(SELECT GE2.GEGroupID FROM GE GE2 WHERE  GE2.GLID =" + glID + " and GE2.Dr>0) AND GE1.GLID <>" + glID + " AND GE1.GEDate BETWEEN '" + fromDate.ToString("yyyy-MM-dd") + "' and '" + toDate.ToString("yyyy-MM-dd HH:mm") + "'");
            DataTable dtCr = Common.GetDBResult(@"SELECT GE1.GEDate,'By '+GL.GLName as GLName,GE1.Dr FROM GE GE1 LEFT OUTER JOIN GL ON GE1.GLID=GL.GLID WHERE GE1.GEGroupID IN
(SELECT GE2.GEGroupID FROM GE GE2 WHERE  GE2.GLID =" + glID + " and GE2.Cr>0) AND GE1.GLID <>" + glID + " AND GE1.GEDate BETWEEN '" + fromDate.ToString("yyyy-MM-dd") + "' and '" + toDate.ToString("yyyy-MM-dd HH:mm") + "'");
            //add opening bal
            if (opening > 0)
            {
                DataRow dr = dtDr.NewRow();
                dr[1] = "To Opening Balance";
                dr[2] = opening;
                dtDr.Rows.InsertAt(dr, 0);
            }
            else if (opening < 0)
            {
                DataRow dr = dtCr.NewRow();
                dr[1] = "By Opening Balance";
                dr[2] = opening * -1;
                dtCr.Rows.InsertAt(dr, 0);
            }
            //Add Balance c/d as difference
            double totalDr = Common.ToDouble(dtDr.Compute("SUM(Cr)", ""));
            double totalCr = Common.ToDouble(dtCr.Compute("SUM(Dr)", ""));
            double biggerAmount = totalDr > totalCr ? totalDr : totalCr;
            double diff = totalDr - totalCr;
            if (diff > 0)
            {
                DataRow dr = dtCr.NewRow();
                dr[1] = "By Balance c/d";
                dr[2] = diff;
                dtCr.Rows.Add(dr);
            }
            else if (diff < 0)
            {
                DataRow dr = dtDr.NewRow();
                dr[1] = "To Balance c/d";
                dr[2] = diff * -1;
                dtDr.Rows.Add(dr);
            }
            //start printing the document
            DataTableToPDF objDataTableToPDF = new DataTableToPDF();
            HttpResponse response = HttpContext.Current.Response;
            response.ContentType = "application/pdf";
            response.AddHeader("content-disposition", "inline;filename=Panel.pdf");
            response.Cache.SetCacheability(HttpCacheability.NoCache);
            Document doc = new Document(PageSize.A4, 36, 36, 36, 36);
            PdfWriter writer = PdfWriter.GetInstance(doc, response.OutputStream);
            writer.PageEvent = new ITextEvents(glName, "(" + fromDate.ToString(objSetting.DateTimeFormat) + " To " + toDate.ToString(objSetting.DateTimeFormat) + ")");
            doc.Open();
            PdfPTable table = new PdfPTable(4);
            table.WidthPercentage = 100;
            table.HeaderRows = 2;
            //print blank header 1 for top margin
            PdfPCell cell = new PdfPCell(new Phrase(""));
            cell.HorizontalAlignment = 1;
            cell.Colspan = 4;
            cell.Border = 0;
            table.AddCell(cell);
            //print header row 2
            cell = new PdfPCell(new Phrase("Dr."));
            cell.HorizontalAlignment = 1;
            cell.Padding = 4;
            cell.Colspan = 2;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase("Cr."));
            cell.HorizontalAlignment = 1;
            cell.Colspan = 2;
            table.AddCell(cell);
            //print data (Dr, Cr)
            cell = new PdfPCell(objDataTableToPDF.DataTableToPdfTable(dtDr, false, false, new float[] { 20f, 30f, 15f }));
            cell.Colspan = 2;
            cell.HorizontalAlignment = 1;
            table.AddCell(cell);
            cell = new PdfPCell(objDataTableToPDF.DataTableToPdfTable(dtCr, false, false, new float[] { 20f, 30f, 15f }));
            cell.Colspan = 2;
            cell.HorizontalAlignment = 1;
            table.AddCell(cell);
            //print Total
            cell = new PdfPCell(new Phrase("Total"));
            cell.HorizontalAlignment = 0;
            cell.Padding = 4;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase(biggerAmount.ToString("0.00")));
            cell.HorizontalAlignment = 2;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase("Total"));
            cell.HorizontalAlignment = 0;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase(biggerAmount.ToString("0.00")));
            cell.HorizontalAlignment = 2;
            table.AddCell(cell);
            //print closing balance
            if (diff > 0)
            {
                cell = new PdfPCell(new Phrase("To Balance b/d"));
                cell.Padding = 4;
                cell.HorizontalAlignment = 0;
                table.AddCell(cell);
                cell = new PdfPCell(new Phrase(diff.ToString("0.00")));
                cell.HorizontalAlignment = 2;
                table.AddCell(cell);
                cell = new PdfPCell(new Phrase(""));
                table.AddCell(cell);
                cell = new PdfPCell(new Phrase(""));
                table.AddCell(cell);
            }
            else if (diff < 0)
            {
                cell = new PdfPCell(new Phrase(""));
                table.AddCell(cell);
                cell = new PdfPCell(new Phrase(""));
                table.AddCell(cell);
                cell = new PdfPCell(new Phrase("By Balance b/d"));
                cell.HorizontalAlignment = 0;
                cell.Padding = 4;
                table.AddCell(cell);
                cell = new PdfPCell(new Phrase((diff * -1).ToString("0.00")));
                cell.HorizontalAlignment = 2;
                table.AddCell(cell);
            }
            doc.Add(table);
            doc.Close();
            response.Write(doc);
            response.End();
        }
        #endregion

        #region Trading Account Print
        public static double GetClosingBal(DateTime date, string method)
        {
            return 0;
            SqlConnection con = new SqlConnection(Common.GetConString());
            SqlCommand cmd = new SqlCommand("GetClosingBal", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@AsOnDate", SqlDbType.DateTime).Value = date;
            cmd.Parameters.Add("@Method", SqlDbType.VarChar, 20).Value = method;
            DataTable dt = new DataTable();
            con.Open();
            using (con)
            {
                dt.Load(cmd.ExecuteReader());
            }
            if (dt.Rows.Count > 0)
            {
                return Common.ToDouble(dt.Rows[0][0]);
            }
            else
            {
                return 0;
            }
        }
        public static double PrintTradeAC(DateTime fromDate, DateTime toDate, bool getGrossProfit, LoggedUser objSetting)
        {
            toDate = toDate.AddDays(1).AddMinutes(-1);
            //Declared variables
            double openingStock = GetClosingBal(fromDate.AddMinutes(-1), "F");
            double totalPurchase = 0;
            double totalPurReturn = 0;
            double totalDirExp = 0;
            double totalSales = 0;
            double totalSalesReturn = 0;
            double closingStock = GetClosingBal(toDate, "F");
            double totalDirIncome = 0;
            //TODO: find Opening Stock
            //TODO: find Total Purchase return

            //Find Total SalesReturn
            DataTable dtSalesReturn =
                Common.GetDBResult(
                    @"select SUM(Dr) as Total from GE where GLID in (Select GLID from GL where GLNo=" +
                    ((int)GLNo.SalesReturn) + " and CompanyID=" + objSetting.SocID + @")
AND GEDate between '" +
                    fromDate.ToString("yyyy-MM-dd") + "' and '" + toDate.ToString("yyyy-MM-dd HH:mm") + "' and CompanyID=" +
                    objSetting.SocID);
            if (dtSalesReturn != null && dtSalesReturn.Rows.Count > 0)
            {
                totalSalesReturn = Common.ToDouble(dtSalesReturn.Rows[0]["Total"]);
            }

            //Find Total PurchaseReturn
            DataTable dtPurReturn =
                Common.GetDBResult(
                    @"select SUM(Cr) as Total from GE where GLID in (Select GLID from GL where GLNo=" +
                    ((int)GLNo.PurchaseReturn) + " and CompanyID=" + objSetting.SocID + @")
AND GEDate between '" +
                    fromDate.ToString("yyyy-MM-dd") + "' and '" + toDate.ToString("yyyy-MM-dd HH:mm") + "' and CompanyID=" +
                    objSetting.SocID);
            if (dtPurReturn != null && dtSalesReturn.Rows.Count > 0)
            {
                totalPurReturn = Common.ToDouble(dtPurReturn.Rows[0]["Total"]);
            }

            //Find Total Purchase
            DataTable dt =
                Common.GetDBResult(
                    @"select SUM(Dr) as Total from GE where GLID in (Select GLID from GL where GLNo=" +
                    ((int)GLNo.Purchase) + " and CompanyID=" + objSetting.SocID + @")
AND GEDate between '" +
                    fromDate.ToString("yyyy-MM-dd") + "' and '" + toDate.ToString("yyyy-MM-dd HH:mm") + "' and CompanyID=" +
                    objSetting.SocID);
            if (dt != null && dt.Rows.Count > 0)
            {
                totalPurchase = Common.ToDouble(dt.Rows[0]["Total"]);
            }
            //Find Direct Expenses
            DataTable dtDirectExp = Common.GetDBResult(@"SELECT GL1.GLName,SUM(GE.Cr) AS Total from GE LEFT OUTER JOIN GL GL1 ON GE.GLID=GL1.GLID
WHERE GL1.GLID IN (SELECT GL2.GLID FROM GL GL2 WHERE GL2.GroupID=" + ((int)GroupNo.DirectExpense) + " and GL2.CompanyID=" + objSetting.SocID + ") AND GEDate between '" + fromDate.ToString("yyyy-MM-dd") + "' and '" + toDate.ToString("yyyy-MM-dd HH:mm") + @"' and GE.CompanyID=" + objSetting.SocID + @"
GROUP BY GL1.GLName");
            totalDirExp = Common.ToDouble(dtDirectExp.Compute("SUM(Total)", ""));
            //Find Total Sales
            dt = Common.GetDBResult(@"select SUM(Cr) as Total from GE where GLID in (Select GLID from GL where GLNo=" +
                    ((int)GLNo.Sales) + " and CompanyID=" + objSetting.SocID + @") AND GEDate between '"
                    + fromDate.ToString("yyyy-MM-dd") + "' and '" + toDate.ToString("yyyy-MM-dd HH:mm") +
                      "' and CompanyID=" + objSetting.SocID);
            if (dt != null && dt.Rows.Count > 0)
            {
                totalSales = Common.ToDouble(dt.Rows[0]["Total"]);
            }
            //TODO: find Total Sales return
            //Find Direct Income
            DataTable dtDirectIncome =
                Common.GetDBResult(
                    @"SELECT GL1.GLName,SUM(GE.Cr) AS Total from GE LEFT OUTER JOIN GL GL1 ON GE.GLID=GL1.GLID
            WHERE GL1.GLID IN (SELECT GL2.GLID FROM GL GL2 WHERE GL2.GroupID=" +
                    ((int)GroupNo.DirectIncome)
                    + " and GL2.CompanyID=" + objSetting.SocID + ") AND GEDate between '" +
                    fromDate.ToString("yyyy-MM-dd") + "' and '"
                    + toDate.ToString("yyyy-MM-dd HH:mm") + @"' and GE.CompanyID=" + objSetting.SocID +
                    " GROUP BY GL1.GLName");
            totalDirIncome = Common.ToDouble(dtDirectIncome.Compute("SUM(Total)", ""));
            //Calculation
            double totalDr = openingStock + totalPurchase - totalPurReturn + totalDirExp;
            double totalCr = totalSales - totalSalesReturn + totalDirIncome + closingStock;
            double grossProfit = totalCr - totalDr;
            double biggerAmount = totalDr > totalCr ? totalDr : totalCr;
            if (getGrossProfit) return grossProfit;
            //Create DataTable for Dr side
            DataTable dtDr = new DataTable();
            dtDr.Columns.Add("Particular", typeof(string));
            dtDr.Columns.Add("Amount", typeof(double));
            //Add Opening Stock
            DataRow drNew = dtDr.NewRow();
            drNew["Particular"] = "To Opening Stock";
            drNew["Amount"] = openingStock;
            dtDr.Rows.Add(drNew);
            //Add Purchase
            drNew = dtDr.NewRow();
            drNew["Particular"] = "To Purchase";
            drNew["Amount"] = totalPurchase;
            dtDr.Rows.Add(drNew);
            drNew = dtDr.NewRow();
            drNew["Particular"] = "    Purchase Return(Less)";
            drNew["Amount"] = totalPurReturn;
            dtDr.Rows.Add(drNew);
            if (totalDirExp > 0)
            {
                //Add Direct Expense
                drNew = dtDr.NewRow();
                drNew["Particular"] = "To Direct Expenses : ";
                drNew["Amount"] = DBNull.Value;
                dtDr.Rows.Add(drNew);
                foreach (DataRow dr in dtDirectExp.Rows)
                {
                    drNew = dtDr.NewRow();
                    drNew["Particular"] = "    " + dr["GLName"].ToString();
                    drNew["Amount"] = Common.ToDouble(dr["Total"]);
                    dtDr.Rows.Add(drNew);
                }
            }
            //Create DataTable for Cr side
            DataTable dtCr = new DataTable();
            dtCr.Columns.Add("Particular", typeof(string));
            dtCr.Columns.Add("Amount", typeof(double));
            //Add total Sales
            drNew = dtCr.NewRow();
            drNew["Particular"] = "By Sales";
            drNew["Amount"] = totalSales;
            dtCr.Rows.Add(drNew);
            drNew = dtCr.NewRow();
            drNew["Particular"] = "    Sales Return(Less)";
            drNew["Amount"] = totalSalesReturn;
            dtCr.Rows.Add(drNew);
            if (totalDirIncome > 0)
            {
                //Add Direct Income
                drNew = dtCr.NewRow();
                drNew["Particular"] = "To Direct Income : ";
                drNew["Amount"] = DBNull.Value;
                dtCr.Rows.Add(drNew);
                foreach (DataRow dr in dtDirectIncome.Rows)
                {
                    drNew = dtCr.NewRow();
                    drNew["Particular"] = "    " + dr["GLName"].ToString();
                    drNew["Amount"] = Common.ToDouble(dr["Total"]);
                    dtCr.Rows.Add(drNew);
                }
            }
            //Add Closing Stock
            drNew = dtCr.NewRow();
            drNew["Particular"] = "By Closing Stock";
            drNew["Amount"] = closingStock;
            dtCr.Rows.Add(drNew);
            if (grossProfit >= 0)
            {
                drNew = dtDr.NewRow();
                drNew["Particular"] = "";
                dtDr.Rows.Add(drNew);
                drNew = dtDr.NewRow();
                drNew["Particular"] = "To Gross Profit c/d";
                drNew["Amount"] = grossProfit;
                dtDr.Rows.Add(drNew);
            }
            else
            {
                drNew = dtCr.NewRow();
                drNew["Particular"] = "By Gross Loss c/d";
                drNew["Amount"] = grossProfit * -1;
                dtCr.Rows.Add(drNew);
            }
            //start printing the document
            DataTableToPDF objDataTableToPDF = new DataTableToPDF();
            HttpResponse response = HttpContext.Current.Response;
            response.ContentType = "application/pdf";
            response.AddHeader("content-disposition", "inline;filename=Panel.pdf");
            response.Cache.SetCacheability(HttpCacheability.NoCache);
            Document doc = new Document(PageSize.A4, 36, 36, 46, 36);
            PdfWriter writer = PdfWriter.GetInstance(doc, response.OutputStream);
            writer.PageEvent = new ITextEvents("Trading Account", "(" + fromDate.ToString("dd-MMM-yyyy") + " To " + toDate.ToString("dd-MMM-yyyy") + ")");
            doc.Open();
            PdfPTable table = new PdfPTable(4);
            table.WidthPercentage = 100;
            table.HeaderRows = 1;
            table.SetWidths(new float[] { 15f, 5f, 15f, 5f });
            //print header
            PdfPCell cell = new PdfPCell(new Phrase("Particular"));
            cell.HorizontalAlignment = 0;
            cell.Padding = 4;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase("Amount"));
            cell.HorizontalAlignment = 1;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase("Particular"));
            cell.HorizontalAlignment = 0;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase("Amount"));
            cell.HorizontalAlignment = 1;
            table.AddCell(cell);
            //print data (Dr, Cr)
            cell = new PdfPCell(objDataTableToPDF.DataTableToPdfTable(dtDr, false, false, new float[] { 15f, 5f }));
            cell.Colspan = 2;
            cell.HorizontalAlignment = 1;
            table.AddCell(cell);
            cell = new PdfPCell(objDataTableToPDF.DataTableToPdfTable(dtCr, false, false, new float[] { 15f, 5f }));
            cell.Colspan = 2;
            cell.HorizontalAlignment = 1;
            table.AddCell(cell);
            //print Total
            cell = new PdfPCell(new Phrase(""));
            cell.HorizontalAlignment = 0;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase(biggerAmount.ToString("0.00")));
            cell.HorizontalAlignment = 2;
            cell.Padding = 4;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase(""));
            cell.HorizontalAlignment = 0;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase(biggerAmount.ToString("0.00")));
            cell.HorizontalAlignment = 2;
            table.AddCell(cell);
            doc.Add(table);
            doc.Close();
            response.Write(doc);
            response.End();
            return grossProfit;
        }
        #endregion

        #region PNL Print
        public static object PrintPNL(DateTime fromDate, DateTime toDate, bool getNettProfit, LoggedUser objSetting)
        {
            toDate = toDate.AddDays(1).AddMinutes(-1);
            double grossProfit = PrintTradeAC(fromDate, toDate, true, objSetting);
            toDate = toDate.AddDays(1).AddMinutes(-1);
            double totalExp = 0;
            double totalIncome = 0;

            //Find Expenses
            DataTable dtExp = Common.GetDBResult(@"SELECT GL1.GLName,SUM(GE.Dr) AS Total from GE LEFT OUTER JOIN GL GL1 ON GE.GLID=GL1.GLID
            WHERE GL1.GLID IN (SELECT GL2.GLID FROM GL GL2 WHERE GL2.GroupID=" +
            ((int)GroupNo.DirectExpense) + " and GL2.CompanyID=" + objSetting.SocID
            + ") AND GEDate between '" + fromDate.ToString("yyyy-MM-dd") + "' and '"
            + toDate.ToString("yyyy-MM-dd HH:mm") + "' and GE.CompanyID=" + objSetting.SocID + " GROUP BY GL1.GLName");
            totalExp = Common.ToDouble(dtExp.Compute("SUM(Total)", ""));

            //Find Income
            DataTable dtIncome = Common.GetDBResult(@"SELECT GL1.GLName,SUM(GE.Cr) AS Total from GE LEFT OUTER JOIN GL GL1 ON GE.GLID=GL1.GLID
WHERE GL1.GLID IN (SELECT GL2.GLID FROM GL GL2 WHERE GL2.GroupID=" +
            ((int)GroupNo.DirectIncome) + " and GL2.CompanyID=" + objSetting.SocID
            + ") AND GEDate between '" + fromDate.ToString("yyyy-MM-dd") + "' and '" + toDate.ToString("yyyy-MM-dd HH:mm") + @"' and GE.CompanyID="
            + objSetting.SocID + " GROUP BY GL1.GLName");
            totalIncome = Common.ToDouble(dtIncome.Compute("SUM(Total)", ""));

            //Calculation
            double grandIncome = grossProfit + totalIncome;
            double nettProfit = grandIncome - totalExp;
            double biggerAmount = grandIncome > totalExp ? grandIncome : totalExp;
            if (getNettProfit) return nettProfit;
            //Create DataTable for Dr side
            DataTable dtDr = new DataTable();
            dtDr.Columns.Add("Particular", typeof(string));
            dtDr.Columns.Add("Amount", typeof(double));
            //Add Expenses
            DataRow drNew = null;
            foreach (DataRow dr in dtExp.Rows)
            {
                drNew = dtDr.NewRow();
                drNew["Particular"] = "To " + dr["GLName"].ToString();
                drNew["Amount"] = Common.ToDouble(dr["Total"]);
                dtDr.Rows.Add(drNew);
            }
            //Create DataTable for Cr side
            DataTable dtCr = new DataTable();
            dtCr.Columns.Add("Particular", typeof(string));
            dtCr.Columns.Add("Amount", typeof(double));
            //Add Income
            foreach (DataRow dr in dtIncome.Rows)
            {
                drNew = dtCr.NewRow();
                drNew["Particular"] = "By " + dr["GLName"].ToString();
                drNew["Amount"] = Common.ToDouble(dr["Total"]);
                dtCr.Rows.Add(drNew);
            }
            //Add Gross Profit/Loss
            if (grossProfit >= 0)
            {
                drNew = dtCr.NewRow();
                drNew["Particular"] = "By Gross Profit (Trading A/C)";
                drNew["Amount"] = grossProfit;
                dtCr.Rows.InsertAt(drNew, 0);
            }
            else
            {
                drNew = dtDr.NewRow();
                drNew["Particular"] = "By Gross Loss (Trading A/C)";
                drNew["Amount"] = grossProfit * -1;
                dtDr.Rows.InsertAt(drNew, 0);
            }
            //Add Nett Profit
            if (nettProfit >= 0)
            {
                drNew = dtDr.NewRow();
                drNew["Particular"] = "To Nett Profit (Capital A/C)";
                drNew["Amount"] = nettProfit;
                dtDr.Rows.Add(drNew);
            }
            else
            {
                drNew = dtCr.NewRow();
                drNew["Particular"] = "By Nett Loss (Capital A/C)";
                drNew["Amount"] = nettProfit * -1;
                dtCr.Rows.Add(drNew);
            }
            //start printing the document
            DataTableToPDF objDataTableToPDF = new DataTableToPDF();
            System.IO.MemoryStream ms = new System.IO.MemoryStream();
            HttpResponseMessage response = new HttpResponseMessage();
            Document doc = new Document(PageSize.A4, 36, 36, 46, 36);
            PdfWriter writer = PdfWriter.GetInstance(doc, ms);
            writer.PageEvent = new ITextEvents("Profit & Loss Account", "(" + fromDate.ToString("dd-MMM-yyyy") + " To " + toDate.ToString("dd-MMM-yyyy") + ")");
            doc.Open();
            PdfPTable table = new PdfPTable(4);
            table.WidthPercentage = 100;
            table.HeaderRows = 1;
            table.SetWidths(new float[] { 15f, 5f, 15f, 5f });
            //print header
            PdfPCell cell = new PdfPCell(new Phrase("Particular"));
            cell.HorizontalAlignment = 0;
            cell.Padding = 4;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase("Amount"));
            cell.HorizontalAlignment = 1;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase("Particular"));
            cell.HorizontalAlignment = 0;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase("Amount"));
            cell.HorizontalAlignment = 1;
            table.AddCell(cell);
            //print data (Dr, Cr)
            cell = new PdfPCell(objDataTableToPDF.DataTableToPdfTable(dtDr, false, false, new float[] { 15f, 5f }));
            cell.Colspan = 2;
            cell.HorizontalAlignment = 1;
            table.AddCell(cell);
            cell = new PdfPCell(objDataTableToPDF.DataTableToPdfTable(dtCr, false, false, new float[] { 15f, 5f }));
            cell.Colspan = 2;
            cell.HorizontalAlignment = 1;
            table.AddCell(cell);
            //print Total
            cell = new PdfPCell(new Phrase(""));
            cell.HorizontalAlignment = 0;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase(biggerAmount.ToString("0.00")));
            cell.HorizontalAlignment = 2;
            cell.Padding = 4;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase(""));
            cell.HorizontalAlignment = 0;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase(biggerAmount.ToString("0.00")));
            cell.HorizontalAlignment = 2;
            table.AddCell(cell);
            doc.Add(table);
            doc.Close();
            byte[] pdfBytes = ms.ToArray();
            response.Content = new ByteArrayContent(pdfBytes);
            response.Content.Headers.ContentType = new MediaTypeHeaderValue("application/pdf");
            return response;
            //return nettProfit;
        }
        #endregion

        #region PNL Income Expense
        public static object PrintIncomeExpense(DateTime toDate, bool getNettProfit, LoggedUser objSetting)
        {
            toDate = toDate.AddDays(1).AddMinutes(-1);
            DateTime endDateOfFinancial = new DateTime(toDate.Year, 3, 31);
            DateTime toDatePrev = endDateOfFinancial;
            if (toDate.Date == endDateOfFinancial.Date)
            {
                toDatePrev = endDateOfFinancial.AddYears(-1);
            }
            else if (toDate.Date > endDateOfFinancial.Date)
            {
                toDatePrev = endDateOfFinancial;
            }
            else if (toDate.Date < endDateOfFinancial.Date)
            {
                toDatePrev = endDateOfFinancial.AddYears(-1);
            }
            double totalPreExp = 0;
            double totalExp = 0;
            double totalPreIncome = 0;
            double totalIncome = 0;

            //Find Expenses
            DataTable dtExp = Common.GetDBResultParameterized(@"
select ISNULL(P.ScheduleName,G.ScheduleName) as GroupName,
case when P.ScheduleName IS null then '' else G.ScheduleName end as SubGroupName,
GL.AccountID as GLID,'' as GLNo,GL.AccountName as GLName
,ISNULL(LBPre.Balance,0) +ISNULL(GL.DrAmount,0)-ISNULL(GL.CrAmount,0) as PreBalance
,ISNULL(LB.Balance,0)+ISNULL(GL.DrAmount,0)-ISNULL(GL.CrAmount,0) as Balance
,G.ScheduleID as GroupNo
from Accounts GL
left outer join Schedule G ON G.ScheduleID=GL.ScheduleID and G.SocID=GL.SocID
left outer join Schedule P ON G.MasterScheduleID=P.ScheduleID and G.SocID=P.SocID
left outer join dbo.LedgerBalance(@DatePre) LBPre ON LBPre.GLID=GL.AccountID and GL.SocID=LBPre.CompanyID
left outer join dbo.LedgerBalance(@Date) LB ON LB.GLID=GL.AccountID and GL.SocID=LB.CompanyID
where GL.SocID=" + objSetting.SocID + " and G.BPT='PNL' and G.Nature='EXPENSES' order by AccountName",
                               "@DatePre", SqlDbType.DateTime, toDatePrev,
                               "@Date", SqlDbType.DateTime, toDate);

            totalPreExp = Common.ToDouble(dtExp.Compute("SUM(PreBalance)", ""));
            totalExp = Common.ToDouble(dtExp.Compute("SUM(Balance)", ""));

            //Find Income
            DataTable dtIncome = Common.GetDBResultParameterized(@"select ISNULL(P.ScheduleName,G.ScheduleName) as GroupName,
case when P.ScheduleName IS null then '' else G.ScheduleName end as SubGroupName,
GL.AccountID as GLID,'' as GLNo,GL.AccountName as GLName
,(ISNULL(LBPre.Balance,0) +ISNULL(GL.DrAmount,0)-ISNULL(GL.CrAmount,0))*-1 as PreBalance
,(ISNULL(LB.Balance,0)+ISNULL(GL.DrAmount,0)-ISNULL(GL.CrAmount,0))*-1 as Balance
 from Accounts GL
left outer join Schedule G ON G.ScheduleID=GL.ScheduleID and G.SocID=GL.SocID
left outer join Schedule P ON G.MasterScheduleID=P.ScheduleID and G.SocID=P.SocID
left outer join dbo.LedgerBalance(@DatePre) LBPre ON LBPre.GLID=GL.AccountID and GL.SocID=LBPre.CompanyID
left outer join dbo.LedgerBalance(@Date) LB ON LB.GLID=GL.AccountID and GL.SocID=LB.CompanyID
where GL.SocID=" + objSetting.SocID + " and G.BPT='PNL' and G.Nature='INCOME' order by AccountName",
                               "@DatePre", SqlDbType.DateTime, toDatePrev,
                               "@Date", SqlDbType.DateTime, toDate);

            totalPreIncome = Common.ToDouble(dtIncome.Compute("SUM(PreBalance)", ""));
            totalIncome = Common.ToDouble(dtIncome.Compute("SUM(Balance)", ""));

            double nettProfit = totalIncome - totalExp;
            if (getNettProfit)
                return nettProfit;

            //Create DataTable for dtExp side
            DataTable dtDr = new DataTable();
            dtDr.Columns.Add("Previous Year", typeof(decimal));
            dtDr.Columns.Add("Expenditure", typeof(string));
            dtDr.Columns.Add("Current Year", typeof(decimal));

            string curRow = String.Empty;
            DataRow drNew;
            foreach (DataRow dr in dtExp.Rows)
            {
                if (curRow != Common.ToString(dr["SubGroupName"]))
                {
                    curRow = Common.ToString(dr["SubGroupName"]);
                    drNew = dtDr.NewRow();
                    drNew["Expenditure"] = curRow;
                    dtDr.Rows.Add(drNew);
                }
                else
                {
                    drNew = dtDr.NewRow();
                    drNew["Expenditure"] = "To " + dr["GLName"].ToString();
                    drNew["Previous Year"] = Common.ToDecimal(dr["PreBalance"]);
                    drNew["Current Year"] = Common.ToDecimal(dr["Balance"]);
                    dtDr.Rows.Add(drNew);
                }
            }


            //Create DataTable for dtIncome side
            DataTable dtCr = new DataTable();
            dtCr.Columns.Add("Previous Year", typeof(decimal));
            dtCr.Columns.Add("Income", typeof(string));
            dtCr.Columns.Add("Current Year", typeof(decimal));

            curRow = String.Empty;
            foreach (DataRow dr in dtIncome.Rows)
            {
                if (curRow != Common.ToString(dr["SubGroupName"]))
                {
                    curRow = Common.ToString(dr["SubGroupName"]);
                    drNew = dtCr.NewRow();
                    drNew["Income"] = curRow;
                    dtCr.Rows.Add(drNew);
                }
                else
                {
                    drNew = dtCr.NewRow();
                    drNew["Income"] = "By " + dr["GLName"].ToString();
                    drNew["Previous Year"] = Common.ToDecimal(dr["PreBalance"]);
                    drNew["Current Year"] = Common.ToDecimal(dr["Balance"]);
                    dtCr.Rows.Add(drNew);
                }
            }
            dtCr.AcceptChanges();


            //add nettprofit/nettloss in datatable
            if (nettProfit < 0)
            {
                drNew = dtCr.NewRow();
                drNew["Income"] = "By Net Profit carried to B/S";
                drNew["Previous Year"] = "0.00";
                drNew["Current Year"] = (nettProfit * -1).ToString("0.00");
                dtCr.Rows.Add(drNew);
            }
            else
            {
                drNew = dtDr.NewRow();
                drNew["Expenditure"] = "To Net Profit carried to B/S";
                drNew["Previous Year"] = "0.00";
                drNew["Current Year"] = nettProfit.ToString("0.00");
                dtDr.Rows.Add(drNew);
            }
            if (nettProfit > 0)
                totalExp = totalIncome;
            else
                totalIncome = totalExp;

            //start printing the document
            DataTableToPDF objDataTableToPDF = new DataTableToPDF();
            System.IO.MemoryStream ms = new System.IO.MemoryStream();
            HttpResponseMessage response = new HttpResponseMessage();
            Document doc = new Document(PageSize.A4, 36, 36, 46, 36);
            PdfWriter writer = PdfWriter.GetInstance(doc, ms);
            writer.PageEvent = new ITextEvents("Profit & Loss Account", "(" + toDate.ToString("dd-MMM-yyyy") + ")");
            doc.Open();
            PdfPTable table = new PdfPTable(6);
            table.WidthPercentage = 100;
            table.HeaderRows = 0;
            table.SetWidths(new float[] { 5f, 15f, 5f, 5f, 15f, 5f });
            //print data (Dr, Cr)
            PdfPCell cell;
            cell = new PdfPCell(objDataTableToPDF.DataTableToPdfTable(dtDr, true, false, new float[] { 5f, 15f, 5f }));
            cell.Colspan = 3;
            cell.HorizontalAlignment = 1;
            table.AddCell(cell);
            cell = new PdfPCell(objDataTableToPDF.DataTableToPdfTable(dtCr, true, false, new float[] { 5f, 15f, 5f }));
            cell.HorizontalAlignment = 1;
            cell.Colspan = 3;
            table.AddCell(cell);

            iTextSharp.text.Font fontTitle = FontFactory.GetFont("Arial", 8, iTextSharp.text.Font.BOLD);
            cell = new PdfPCell(new Phrase(totalPreExp.ToString("0.00"), fontTitle));
            cell.HorizontalAlignment = 2;
            cell.Padding = 4;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase(String.Empty));
            cell.HorizontalAlignment = 0;
            cell.Padding = 4;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase(totalExp.ToString("0.00"), fontTitle));
            cell.HorizontalAlignment = 2;
            cell.Padding = 4;
            table.AddCell(cell);

            cell = new PdfPCell(new Phrase(totalPreIncome.ToString("0.00"), fontTitle));
            cell.HorizontalAlignment = 2;
            cell.Padding = 4;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase(String.Empty));
            cell.HorizontalAlignment = 0;
            cell.Padding = 4;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase(totalIncome.ToString("0.00"), fontTitle));
            cell.HorizontalAlignment = 2;
            cell.Padding = 4;
            table.AddCell(cell);

            doc.Add(table);
            doc.Close();
            byte[] pdfBytes = ms.ToArray();
            response.Content = new ByteArrayContent(pdfBytes);
            response.Content.Headers.ContentType = new MediaTypeHeaderValue("application/pdf");
            return response;
            //return nettProfit;
        }
        #endregion

        #region Balance Sheet Print
        public static HttpResponseMessage PrintBalanceSheet(DateTime toDate, LoggedUser objSetting)
        {
            double nettProfit = (double)PrintIncomeExpense(toDate, true, objSetting);
            //double closingStock = GetClosingBal(toDate.AddDays(1).AddMinutes(-1), "F");
            toDate = toDate.AddDays(1).AddMinutes(-1);
            //Create DataTable for Dr side
            DataTable dtDr = new DataTable();
            dtDr.Columns.Add("Particular", typeof(string));
            dtDr.Columns.Add("Amount", typeof(double));

            DataTable dtAccBalance = Common.GetDBResultParameterized(@"select A.ScheduleID,A.AccountName,A.AccountID
,ISNULL(T.Dr,0)-ISNULL(T.Cr,0) as Balance from Accounts A 
left join Get_AccountBalanceSchduleWise(0,@SocID,@Date) T ON T.AccountID=A.AccountID
where A.SocID=@SocID",
                     "@SocID", SqlDbType.Int, objSetting.SocID,
"@Date", SqlDbType.VarChar, toDate.ToString("yyyy-MM-dd HH:mm"));

            #region Current Assets

            //Current Assets
            DataRow drNew = dtDr.NewRow();
            //Find Current Assets
            DataTable dtCurrentAssets =
                Common.GetDBResultParameterized(@"WITH ret AS(
        SELECT  ScheduleID,ScheduleName,SocID,MasterScheduleID,0 as Level
        FROM    Schedule
        WHERE   (ScheduleID = @ScheduleID) and SocID=@SocID
        UNION ALL
        SELECT  t.ScheduleID,t.ScheduleName as ScheduleName,t.SocID,t.MasterScheduleID,Level + 1
        FROM    Schedule t INNER JOIN
                ret r ON t.MasterScheduleID = r.ScheduleID and t.SocID=r.SocID
)
select *,T.Dr-T.Cr as Balance from ret
CROSS APPLY Get_SchduleBalance(ret.ScheduleID,ret.SocID,@Date) T 
where T.ScheduleID=ret.ScheduleID",
"@SocID", SqlDbType.Int, objSetting.SocID,
"@ScheduleID", SqlDbType.Int, 3,
"@Date", SqlDbType.VarChar, toDate.ToString("yyyy-MM-dd HH:mm"));

            //Add Current Assets
            double totalCurAssets = Common.ToDouble(dtCurrentAssets.Select("ScheduleID=" + 3)[0]["Balance"]);
            NewMethod(dtDr, dtCurrentAssets, 3, dtAccBalance);
            #endregion

            //Create DataTable for Dr side
            DataTable dtCr = new DataTable();
            dtCr.Columns.Add("Particular", typeof(string));
            dtCr.Columns.Add("Amount", typeof(double));

            #region Current Liabilities

            //Find Current Liabilities
            DataTable dtCurrentLib =
                Common.GetDBResultParameterized(
                    @"WITH ret AS(
        SELECT  ScheduleID,ScheduleName,SocID,MasterScheduleID,0 as Level
        FROM    Schedule
        WHERE   (ScheduleID = @ScheduleID) and SocID=@SocID
        UNION ALL
        SELECT  t.ScheduleID,t.ScheduleName as ScheduleName,t.SocID,t.MasterScheduleID,Level + 1
        FROM    Schedule t INNER JOIN
                ret r ON t.MasterScheduleID = r.ScheduleID and t.SocID=r.SocID
)
select *,T.Dr-T.Cr as Balance from ret
CROSS APPLY Get_SchduleBalance(ret.ScheduleID,ret.SocID,@Date) T 
where T.ScheduleID=ret.ScheduleID",
"@SocID", SqlDbType.Int, objSetting.SocID,
"@ScheduleID", SqlDbType.Int, 5,
"@Date", SqlDbType.VarChar, toDate.ToString("yyyy-MM-dd HH:mm"));

            //Add Total of Current Liabilities
            double totalCurLib = Common.ToDouble(dtCurrentLib.Select("ScheduleID=" + 5)[0]["Balance"]);
            NewMethod(dtCr, dtCurrentLib, 5, dtAccBalance);
            #endregion

            #region Nett Profit

            //Add Nett Profit
            if (nettProfit < 0)
            {
                drNew = dtDr.NewRow();
                drNew["Particular"] = "(Nett Loss)";
                drNew["Amount"] = (nettProfit * -1);
                dtDr.Rows.Add(drNew);
            }
            else
            {
                drNew = dtCr.NewRow();
                drNew["Particular"] = "Nett Profit";
                drNew["Amount"] = nettProfit;
                dtCr.Rows.Add(drNew);
            }
            #endregion

            //Calculation
            double totalAssets = totalCurAssets;
            double totalLiab = nettProfit - totalCurLib;

            //start printing the document
            iTextSharp.text.Font fontTitle = FontFactory.GetFont("Arial", 9, iTextSharp.text.Font.NORMAL);
            System.IO.MemoryStream ms = new System.IO.MemoryStream();
            HttpResponseMessage response = new HttpResponseMessage();
            DataTableToPDF objDataTableToPDF = new DataTableToPDF();
            Document doc = new Document(PageSize.A4, 36, 36, 46, 36);
            PdfWriter writer = PdfWriter.GetInstance(doc, ms);
            writer.PageEvent = new ITextEvents("Balance Sheet", "(on " + toDate.ToString("dd-MMM-yyyy") + ")");
            doc.Open();
            PdfPTable table = new PdfPTable(4);
            table.WidthPercentage = 100;
            table.HeaderRows = 2;
            table.SetWidths(new float[] { 15f, 5f, 15f, 5f });

            //print header
            PdfPCell cell = new PdfPCell(new Phrase("Liabilities", fontTitle));
            cell.HorizontalAlignment = 1;
            cell.Padding = 4;
            cell.Colspan = 2;
            table.AddCell(cell); cell = new PdfPCell(new Phrase("Assets", fontTitle));
            cell.HorizontalAlignment = 1;
            cell.Padding = 4;
            cell.Colspan = 2;
            table.AddCell(cell);

            cell = new PdfPCell(new Phrase("Particular", fontTitle));
            cell.HorizontalAlignment = 0;
            cell.Padding = 4;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase("Amount", fontTitle));
            cell.HorizontalAlignment = 1;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase("Particular", fontTitle));
            cell.HorizontalAlignment = 0;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase("Amount", fontTitle));
            cell.HorizontalAlignment = 1;
            table.AddCell(cell);

            //print data (Dr, Cr)
            cell = new PdfPCell(objDataTableToPDF.DataTableToPdfTable(dtCr, false, false, new float[] { 15f, 5f }));
            cell.Colspan = 2;
            cell.HorizontalAlignment = 1;
            table.AddCell(cell);
            cell = new PdfPCell(objDataTableToPDF.DataTableToPdfTable(dtDr, false, false, new float[] { 15f, 5f }));
            cell.Colspan = 2;
            cell.HorizontalAlignment = 1;
            table.AddCell(cell);

            //print Total
            cell = new PdfPCell(new Phrase(""));
            cell.HorizontalAlignment = 0;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase(totalLiab.ToString("0.00"), fontTitle));
            cell.HorizontalAlignment = 2;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase(""));
            cell.HorizontalAlignment = 0;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase(totalAssets.ToString("0.00"), fontTitle));
            cell.HorizontalAlignment = 2;
            cell.Padding = 4;
            table.AddCell(cell);
            doc.Add(table);
            doc.Close();
            byte[] pdfBytes = ms.ToArray();
            response.Content = new ByteArrayContent(pdfBytes);
            response.Content.Headers.ContentType = new MediaTypeHeaderValue("application/pdf");
            return response;
        }

        private static void NewMethod(DataTable dtDr, DataTable dtCurrentAssets, int masterScheduleID, DataTable dtAccBalance)
        {
            DataRow drNew;
            int num = 1;
            foreach (DataRow dr in dtCurrentAssets.Select("MasterScheduleID=" + masterScheduleID))
            {
                int level = Common.ToInt(dr["Level"]);
                drNew = dtDr.NewRow();
                StringBuilder particular = new StringBuilder();
                for (int i = 1; i < level; i++)
                    particular.Append(" ");
                particular.Append(PrintNum(num, level));
                particular.Append(dr["ScheduleName"].ToString());
                drNew["Particular"] = particular.ToString();
                drNew["Amount"] = Common.ToDouble(dr["Balance"]);
                dtDr.Rows.Add(drNew);
                int numInner = 1;
                if (Common.ToInt(dr["ScheduleID"]) != (int)GroupNo.Debtors && Common.ToInt(dr["ScheduleID"]) != (int)GroupNo.Creditors)
                {
                    foreach (DataRow drAcc in dtAccBalance.Select("ScheduleID=" + Common.ToInt(dr["ScheduleID"])))
                    {
                        drNew = dtDr.NewRow();
                        particular = new StringBuilder();
                        for (int i = 1; i <= level; i++)
                            particular.Append(" ");
                        particular.Append(PrintNum(numInner, 9));
                        particular.Append(drAcc["AccountName"].ToString());
                        drNew["Particular"] = particular.ToString();
                        drNew["Amount"] = Common.ToDouble(drAcc["Balance"]);
                        dtDr.Rows.Add(drNew);
                        numInner++;
                    }
                }
                NewMethod(dtDr, dtCurrentAssets, Common.ToInt(dr["ScheduleID"]), dtAccBalance);
                num++;
            }
        }
        public static HttpResponseMessage PrintBalanceSheet2(DateTime toDate, LoggedUser objSetting)
        {
            double nettProfit = (double)PrintIncomeExpense(toDate, true, objSetting);
            //double closingStock = GetClosingBal(toDate.AddDays(1).AddMinutes(-1), "F");
            toDate = toDate.AddDays(1).AddMinutes(-1);
            //Create DataTable for Dr side
            DataTable dtDr = new DataTable();
            dtDr.Columns.Add("Particular", typeof(string));
            dtDr.Columns.Add("Amount", typeof(double));

            #region Current Assets

            //Current Assets
            DataRow drNew = dtDr.NewRow();
            drNew["Particular"] = "Current Assets";
            dtDr.Rows.Add(drNew);
            //Find Current Assets
            DataTable dtCurrentAssets =
                Common.GetDBResult(
                    @"select  GR.GroupID,GR.GroupName,T.Balance from Groups GR
left outer join
(
select GL.GroupID,SUM(dbo.GetLedgerClosingBalance('" +
                    toDate.ToString("yyyy-MM-dd HH:mm") +
                    @"',GL.GLID)) as Balance from GL
Group BY GL.GroupID
) T ON T.GroupID=GR.GroupID
where GR.ParentGroupID in ( Select GroupID from Groups where GroupNo=" +
                    ((int)GroupNo.CurrentAssets) + " and CompanyID=" + objSetting.SocID + ")");

            //Add Current Assets
            foreach (DataRow dr in dtCurrentAssets.Rows)
            {
                drNew = dtDr.NewRow();
                drNew["Particular"] = "    " + dr["GroupName"].ToString();
                drNew["Amount"] = Common.ToDouble(dr["Balance"]);
                dtDr.Rows.Add(drNew);
            }

            //Add Total of Current Assets
            double totalCurAssets = Common.ToDouble(dtCurrentAssets.Compute("SUM(Balance)", ""));
            drNew = dtDr.NewRow();
            drNew["Particular"] = "        Total Current Assets";
            drNew["Amount"] = totalCurAssets;
            dtDr.Rows.Add(drNew);
            drNew = dtDr.NewRow();
            drNew["Particular"] = "";
            dtDr.Rows.Add(drNew);

            #endregion

            #region Investment

            //Add Investment
            DataTable dtInvestment = Common.GetDBResult(@"select GR.GroupName, SUM(dbo.GetLedgerClosingBalance('" +
                                                           toDate.ToString("yyyy-MM-dd HH:mm") +
                                                           @"',GL.GLID)) as Balance from Groups GR
left join GL ON GR.GroupID=GL.GroupID
where GR.GroupID =" +
                                                           ((int)GroupNo.Investments) + " and GR.CompanyID=" +
                                                           objSetting.SocID + " Group BY GR.GroupName");
            foreach (DataRow dr in dtInvestment.Rows)
            {
                drNew = dtDr.NewRow();
                drNew["Particular"] = dr["GroupName"].ToString();
                drNew["Amount"] = Common.ToDouble(dr["Balance"]);
                dtDr.Rows.Add(drNew);
            }
            drNew = dtDr.NewRow();
            drNew["Particular"] = "";
            dtDr.Rows.Add(drNew);
            double totalInvestment = Common.ToDouble(dtInvestment.Compute("SUM(Balance)", ""));

            #endregion

            #region Fixed Assets

            //Fixed Assets
            drNew = dtDr.NewRow();
            drNew["Particular"] = "Fixed Assets";
            dtDr.Rows.Add(drNew);

            //Find Fixed Assets
            DataTable dtFixedAssets =
                Common.GetDBResult(
                    @"select GL.GLName,SUM(dbo.GetLedgerClosingBalance('" +
                    toDate.ToString("yyyy-MM-dd HH:mm") +
                    @"',GL.GLID)) as Balance from GL where GL.GroupID in ( Select GroupID from Groups where GroupNo=" +
                    ((int)GroupNo.FixedAsset) + " and CompanyID=" + objSetting.SocID + ") Group BY GL.GLName");

            //Add Fixed Assets
            foreach (DataRow dr in dtFixedAssets.Rows)
            {
                drNew = dtDr.NewRow();
                drNew["Particular"] = "    " + dr["GLName"].ToString();
                drNew["Amount"] = Common.ToDouble(dr["Balance"]);
                dtDr.Rows.Add(drNew);
            }

            //Add Total of Current Assets
            double totalFixedAssets = Common.ToDouble(dtFixedAssets.Compute("SUM(Balance)", ""));
            drNew = dtDr.NewRow();
            drNew["Particular"] = "        Total Fixed Assets";
            drNew["Amount"] = totalFixedAssets;
            dtDr.Rows.Add(drNew);
            drNew = dtDr.NewRow();
            drNew["Particular"] = "";
            dtDr.Rows.Add(drNew);

            #endregion

            //Create DataTable for Dr side
            DataTable dtCr = new DataTable();
            dtCr.Columns.Add("Particular", typeof(string));
            dtCr.Columns.Add("Amount", typeof(double));

            #region Current Liabilities

            //Current Liabilities
            drNew = dtCr.NewRow();
            drNew["Particular"] = "Current Liabilities";
            dtCr.Rows.Add(drNew);

            //Find Current Liabilities
            DataTable dtCurrentLib =
                Common.GetDBResult(
                    @"select  GR.GroupID,GR.GroupName,T.Balance from Groups GR
left outer join
(
select GL.GroupID,SUM(dbo.GetLedgerClosingBalance('" +
                    toDate.ToString("yyyy-MM-dd HH:mm") +
                    @"',GL.GLID)) as Balance from GL
Group BY GL.GroupID
) T ON T.GroupID=GR.GroupID
where GR.ParentGroupID in ( Select GroupID from Groups where GroupNo=" +
                    ((int)GroupNo.CurrentLiabilities) + " and CompanyID=" + objSetting.SocID + ")");

            //Add Current Liabilities
            foreach (DataRow dr in dtCurrentLib.Rows)
            {
                drNew = dtCr.NewRow();
                drNew["Particular"] = "    " + dr["GroupName"].ToString();
                drNew["Amount"] = Common.ToDouble(dr["Balance"]) * -1;
                dtCr.Rows.Add(drNew);
            }

            //Add Total of Current Liabilities
            double totalCurLib = Common.ToDouble(dtCurrentLib.Compute("SUM(Balance)", ""));
            drNew = dtCr.NewRow();
            drNew["Particular"] = "        Total Current Liabilities";
            drNew["Amount"] = totalCurLib * -1;
            dtCr.Rows.Add(drNew);
            drNew = dtCr.NewRow();
            drNew["Particular"] = "";
            dtCr.Rows.Add(drNew);

            #endregion

            #region Long Term Liabilities

            //Long Term Liabilities
            drNew = dtCr.NewRow();
            drNew["Particular"] = "Long-Term Liabilities";
            dtCr.Rows.Add(drNew);

            //Find Long Term Liabilities
            DataTable dtLongLib =
                Common.GetDBResult(
                    @"select  GR.GroupID,GR.GroupName,T.Balance from Groups GR
left outer join
(
select GL.GroupID,SUM(dbo.GetLedgerClosingBalance('" +
                    toDate.ToString("yyyy-MM-dd HH:mm") +
                    @"',GL.GLID)) as Balance from GL
Group BY GL.GroupID
) T ON T.GroupID=GR.GroupID
where GR.ParentGroupID in ( Select GroupID from Groups where GroupNo=" +
                    ((int)GroupNo.LoansLiability) + " and CompanyID=" + objSetting.SocID + ")");

            //Add Long Term Liabilities
            foreach (DataRow dr in dtLongLib.Rows)
            {
                drNew = dtCr.NewRow();
                drNew["Particular"] = "    " + dr["GroupName"].ToString();
                drNew["Amount"] = Common.ToDouble(dr["Balance"]) * -1;
                dtCr.Rows.Add(drNew);
            }

            //Add Total of Long Term Liabilities
            double totalLongLib = Common.ToDouble(dtLongLib.Compute("SUM(Balance)", ""));
            drNew = dtCr.NewRow();
            drNew["Particular"] = "        Total Long-Term Liabilities";
            drNew["Amount"] = totalLongLib * -1;
            dtCr.Rows.Add(drNew);
            drNew = dtCr.NewRow();
            drNew["Particular"] = "";
            dtCr.Rows.Add(drNew);

            #endregion

            #region Stockholder's Equity

            //Stockholder's Equity
            drNew = dtCr.NewRow();
            drNew["Particular"] = "Stockholder's Equity";
            dtCr.Rows.Add(drNew);
            //Find Stockholder's Equity
            DataTable dtEq =
                Common.GetDBResult(
                    @"select  GR.GroupID,GR.GroupName,(T.Balance*-1) AS Balance from Groups GR
left outer join
(
select GL.GroupID,SUM(dbo.GetLedgerClosingBalance('" +
                    toDate.ToString("yyyy-MM-dd HH:mm") +
                    @"',GL.GLID)) as Balance from GL
Group BY GL.GroupID
) T ON T.GroupID=GR.GroupID
where GR.ParentGroupID in ( Select GroupID from Groups where GroupNo=" +
                    ((int)GroupNo.CapitalAccount) + " and CompanyID=" + objSetting.SocID + ")");

            //Add Stockholder's Equity
            foreach (DataRow dr in dtEq.Rows)
            {
                drNew = dtCr.NewRow();
                drNew["Particular"] = "    " + dr["GroupName"].ToString();
                drNew["Amount"] = Common.ToDouble(dr["Balance"]);
                dtCr.Rows.Add(drNew);
            }
            //Add Total of Stockholder's Equity
            double totalEq = Common.ToDouble(dtEq.Compute("SUM(Balance)", ""));
            drNew = dtCr.NewRow();
            drNew["Particular"] = "        Total Stockholder's Equity";
            drNew["Amount"] = totalEq;
            dtCr.Rows.Add(drNew);
            drNew = dtCr.NewRow();
            drNew["Particular"] = "";
            dtCr.Rows.Add(drNew);

            #endregion

            #region Nett Profit

            //Add Nett Profit
            drNew = dtCr.NewRow();
            if (nettProfit < 0)
            {

                drNew["Particular"] = "(Nett Loss)";
                drNew["Amount"] = nettProfit * -1;
            }
            else
            {
                drNew["Particular"] = "Nett Profit";
                drNew["Amount"] = nettProfit;
            }
            dtCr.Rows.Add(drNew);
            #endregion

            //Calculation
            double totalAssets = totalCurAssets + totalFixedAssets + totalInvestment;
            double totalLiab = totalEq + nettProfit - totalCurLib - totalLongLib;

            //start printing the document
            iTextSharp.text.Font fontTitle = FontFactory.GetFont("Arial", 9, iTextSharp.text.Font.NORMAL);
            System.IO.MemoryStream ms = new System.IO.MemoryStream();
            HttpResponseMessage response = new HttpResponseMessage();
            DataTableToPDF objDataTableToPDF = new DataTableToPDF();
            Document doc = new Document(PageSize.A4, 36, 36, 46, 36);
            PdfWriter writer = PdfWriter.GetInstance(doc, ms);
            writer.PageEvent = new ITextEvents("Balance Sheet", "(on " + toDate.ToString("dd-MMM-yyyy") + ")");
            doc.Open();
            PdfPTable table = new PdfPTable(4);
            table.WidthPercentage = 100;
            table.HeaderRows = 2;
            table.SetWidths(new float[] { 15f, 5f, 15f, 5f });

            //print header
            PdfPCell cell = new PdfPCell(new Phrase("Liabilities", fontTitle));
            cell.HorizontalAlignment = 1;
            cell.Padding = 4;
            cell.Colspan = 2;
            table.AddCell(cell); cell = new PdfPCell(new Phrase("Assets", fontTitle));
            cell.HorizontalAlignment = 1;
            cell.Padding = 4;
            cell.Colspan = 2;
            table.AddCell(cell);

            cell = new PdfPCell(new Phrase("Particular", fontTitle));
            cell.HorizontalAlignment = 0;
            cell.Padding = 4;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase("Amount", fontTitle));
            cell.HorizontalAlignment = 1;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase("Particular", fontTitle));
            cell.HorizontalAlignment = 0;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase("Amount", fontTitle));
            cell.HorizontalAlignment = 1;
            table.AddCell(cell);

            //print data (Dr, Cr)
            cell = new PdfPCell(objDataTableToPDF.DataTableToPdfTable(dtCr, false, false, new float[] { 15f, 5f }));
            cell.Colspan = 2;
            cell.HorizontalAlignment = 1;
            table.AddCell(cell);
            cell = new PdfPCell(objDataTableToPDF.DataTableToPdfTable(dtDr, false, false, new float[] { 15f, 5f }));
            cell.Colspan = 2;
            cell.HorizontalAlignment = 1;
            table.AddCell(cell);

            //print Total
            cell = new PdfPCell(new Phrase(""));
            cell.HorizontalAlignment = 0;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase(totalLiab.ToString("0.00"), fontTitle));
            cell.HorizontalAlignment = 2;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase(""));
            cell.HorizontalAlignment = 0;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase(totalAssets.ToString("0.00"), fontTitle));
            cell.HorizontalAlignment = 2;
            cell.Padding = 4;
            table.AddCell(cell);
            doc.Add(table);
            doc.Close();
            byte[] pdfBytes = ms.ToArray();
            response.Content = new ByteArrayContent(pdfBytes);
            response.Content.Headers.ContentType = new MediaTypeHeaderValue("application/pdf");
            return response;
        }
        private static string PrintNum(int num, int level)
        {
            if (level == 1)
                return ToRoman(num) + ". ";
            else if (level == 2)
                return ToAlpha(num) + ". ";
            else if (level == 3)
                return "(" + ToRoman(num) + ") ";
            else if (level == 9)
                return "(" + num.ToString() + ") ";
            return String.Empty;
        }
        public static string ToRoman(int number)
        {
            if ((number < 0) || (number > 500)) throw new ArgumentOutOfRangeException("insert value betwheen 1 and 500");
            if (number < 1) return string.Empty;
            if (number >= 500) return "D" + ToRoman(number - 500);
            if (number >= 400) return "CD" + ToRoman(number - 400);
            if (number >= 100) return "C" + ToRoman(number - 100);
            if (number >= 90) return "XC" + ToRoman(number - 90);
            if (number >= 50) return "L" + ToRoman(number - 50);
            if (number >= 40) return "XL" + ToRoman(number - 40);
            if (number >= 10) return "X" + ToRoman(number - 10);
            if (number >= 9) return "IX" + ToRoman(number - 9);
            if (number >= 5) return "V" + ToRoman(number - 5);
            if (number >= 4) return "IV" + ToRoman(number - 4);
            if (number >= 1) return "I" + ToRoman(number - 1);
            throw new ArgumentOutOfRangeException("something bad happened");
        }
        public static string ToAlpha(int number)
        {
            if ((number < 0) || (number > 26)) throw new ArgumentOutOfRangeException("insert value betwheen 1 and 26");
            string[] alphabets = "a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z".Split(',');
            return alphabets[number - 1];
        }
        #endregion
    }
}
