﻿<%@ Page Language="C#" AutoEventWireup="True" CodeBehind="PrintReciept.aspx.cs" Inherits="SampleAngular.PrintReciept" EnableViewState="false" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title></title>
    <style type="text/css">
        table
        {
            font-size: 12px;
        }

            table.details td
            {
                border-bottom: solid 1px black;
                border-right: solid 1px black;
            }

            table.tblFooter td
            {
                padding-top: 15px;
            }

            table.noborder td
            {
                border-bottom: solid 0px black;
                border-right: solid 0px black;
            }
    </style>
</head>
<body style="font-family: Arial; font-size: 12px;">
    <form id="form1" runat="server">
        <div>
            <asp:Repeater ID="Repeater1" runat="server" OnItemDataBound="Repeater1_ItemDataBound">
                <ItemTemplate>
                    <table  style="width: 100%; border-collapse: collapse; border-left: solid 1px black; border-top: solid 1px black;" cellpadding="3" class="details" cellspacing="0">
                        <tr>
                            <td style="text-align: center;border-right: solid 0px black" width="100">
                                 <asp:Image id="imgLogo"  runat="server" width="100"/>
                            </td>
                            <td style="text-align: center;border-right: solid 0px black">
                                <asp:HiddenField ID="hdnBillID" runat="server" Value='<%#Eval("BillID") %>' />
                                <asp:HiddenField ID="hdnPaymentID" runat="server" Value='<%#Eval("PaymentID") %>' /> 
                                <asp:HiddenField ID="hdnReqID" runat="server" Value='<%#Eval("ReqID") %>' /> 
                                <table cellpadding="5" cellspacing="0" class="noborder" style="width: 100%; font-size: 10px;">
                                    <tr>
                                        <td style="font-size: 18px">
                                            <asp:Label ID="lbSocName" runat="server" Text='<%#Eval("SocName") %>'></asp:Label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <asp:Label ID="lbSocAddress" runat="server" Text='<%#Eval("SocAddress1") %>'></asp:Label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <asp:Label ID="lbSocAddress1" runat="server" Text='<%#Eval("SocAddress2") %>'></asp:Label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <asp:Label ID="lbSocAddress2" runat="server" Text='<%#Eval("City")+" - "+Eval("ZipCode")+", "+Eval("StateName") %>'></asp:Label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <asp:Label ID="lbContact" runat="server" Text='<%# "Contact No: "+ Eval("ContactNo")%>'></asp:Label>, <asp:Label ID="lbEmail" runat="server" Text='<%# "Email: "+ Eval("SocEmail")%>'></asp:Label>
                                        </td>
                                    </tr>
                                     <tr>
                                        <td>
                                           Registration No. <asp:Label ID="lbRegNo" runat="server" Font-Bold="true" Text='<%#Eval("RegNo")%>'></asp:Label>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                            <td style="border-left: solid 0px black" width="100">
                                
                            </td>
                        </tr>
                        <tr>
                            <td style="text-align: center;" colspan="3">
                                <b>
                                    <asp:Label ID="lbBillName" Style="text-transform: uppercase" runat="server" Text='<%#Eval("BillName") %>'></asp:Label></b>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="3">
                                <table style="width: 100%;" class="noborder" cellpadding="5">
                                    <tr>
                                        <td width="50">
                                            <b>
                                                <asp:Label ID="lbRecNo" runat="server" Text="Reciept No:"></asp:Label>
                                            </b>
                                        </td>
                                        <td>
                                            <asp:Label ID="lbBillNo" runat="server" Text='<%#Eval("PaymentID") %>'></asp:Label>
                                        </td>
                                        <td style="text-align: right;">
                                            <b>Bill No:
                                            </b>
                                        </td>
                                        <td>
                                            <asp:Label ID="Label5" runat="server" Text='<%#Eval("BillID") %>'></asp:Label>
                                        </td>
                                        <td style="text-align: right;">
                                            <b>Payment Date:
                                            </b>
                                        </td>
                                        <td width="50">
                                            <asp:Label ID="lbBillDate" runat="server"
                                                Text='<%#DataBinder.Eval(Container.DataItem, "PaymentDate", "{0:dd-MMM-yyyy}")%>'>
                                            </asp:Label>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                   
                    <table style="width: 100%;border: solid 1px black;" cellpadding="5">

                        <tr>
                            <td>
                                <p>
                                    Recieved with thanks from Mr./Mrs./Miss: 
                                <i><b>
                                    <asp:Label ID="lbName" runat="server" Text='<%#Eval("Name") %>'></asp:Label></b></i>.
                                </p>
                                <p>
                                    the sum of Rupees  <i><b>
                                        <asp:Label ID="lbTotalInWords" runat="server"></asp:Label></b></i>
                                </p>
                                <p>
                                    by
                                <asp:Label ID="lbPaymentMode" runat="server" Text='<%#Eval("PaymentMode") %>'></asp:Label>
                                     <asp:Label ID="lbPaymentRefNo" runat="server"
                                          Text='<%# SampleAngular.Common.ToString(Eval("PaidRefNo"))==""?"":"("+ SampleAngular.Common.ToString(Eval("PaidRefNo"))+")" %>'></asp:Label>
                                    <i><b>
                                        <asp:Label ID="lbPaidRefNo" runat="server" Text='<%# SampleAngular.Common.ToString(Eval("PaidRefNo")) + Eval("PaymentMode")=="Cash"?"":" dated " %>'></asp:Label></b></i> <i><b>
                                            <asp:Label ID="Label1" runat="server"
                                                Text='<%#DataBinder.Eval(Container.DataItem, "PaidRefDate", "{0:dd-MMM-yyyy}")%>'></asp:Label></b></i>
                                </p>
                                <p>
                                    towards Bill No.
                                <i><b>
                                    <asp:Label ID="Label2" runat="server" Text='<%#Eval("BillID") %>'></asp:Label></b></i>
                                    named <i><b>
                                        <asp:Label ID="Label3" Style="text-transform: uppercase" runat="server" Text='<%#Eval("BillName") %>'></asp:Label></b></i>
                                </p>
                                <p>
                                    of Unit No. <i><b>
                                        <asp:Label ID="lbUnitNo" runat="server" Text='<%#Eval("RoomNo") %>'></asp:Label></b></i> area 
                                <i><b>
                                    <asp:Label ID="lbSQFT" runat="server" Text='<%#Eval("Area") %>'></asp:Label></b></i>
                                    in the proposed Building <i><b>
                                        <asp:Label ID="Label4" runat="server" Text='<%#Eval("SocName") %>'></asp:Label></b></i>
                                </p>
                                <p>
                                    <b>Remarks: </b> <asp:Label ID="lbRemarks" runat="server" Text='<%#Eval("Remarks") %>'></asp:Label>
                                </p>
                            </td>
                            <td>
                                 <asp:Image id="imgPaid"  runat="server" height="100"/>
                            </td>
                        </tr>
                    </table>
                    <table style="background-position: right; width: 100%; border-collapse: collapse; border-left: solid 1px black; " cellpadding="5" class="details">
                        <tr>
                            <td>Rs.
                                <i><b>
                                    <asp:Label ID="lbAmount" runat="server" Text='<%#Eval("Amount","{0:0.00}") %>'></asp:Label>
                                </b></i>
                            </td>
                            <td style="text-align: right;">
                                <h4>For 
                                    <asp:Label ID="lbSocName2" runat="server" Text='<%#Eval("SocName") %>'></asp:Label>
                                </h4>
                                Chairman / Secretary / Treasure
                            </td>
                        </tr>
                    </table>
                    <div id="divPagegap" runat="server" height='<%#Eval("RecGap") %>'>&nbsp;</div>
                    <div id="divPageBreak" runat="server">&nbsp;</div>
                </ItemTemplate>
            </asp:Repeater>
        </div>
    </form>
</body>
</html>
