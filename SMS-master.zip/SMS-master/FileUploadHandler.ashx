﻿<%@ WebHandler Language="C#" CodeBehind="FileUploadHandler.ashx.cs" Class="SampleAngular.FileUploadHandler" %>
