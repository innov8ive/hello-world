var app = angular.module('starter');

app.controller('ALListCtrl', function ($scope, $http, $location, $state, $ionicModal) {
    $scope.AL = {};
    $scope.filter = { ALID: 0, filterText: '' };
    $scope.ALs = [];
    $scope.showModal = false;
    $scope.ALSubmitted = false;
    $scope.baseUrl = baseUrl;
    $scope.images = [];
    var baseImageUrl = baseUrl + 'Download.aspx?fileID=';
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.searchAL = function () {
        $http({
            method: 'POST',
            url: 'api/ALList/',
            data: JSON.stringify($scope.filter)
        }).success(function (ALs) {
            $scope.ALs = ALs;
            $scope.$broadcast('scroll.refreshComplete');
        });
    };
    $ionicModal.fromTemplateUrl('album-modal.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        $scope.modal = modal;
    });
    $scope.newAL = function () {
        $scope.AL = {};
        $scope.modal.show();
    };
    $scope.renameAL = function (itm) {
        $scope.AL = angular.copy(itm);
        $scope.modalTitle = 'Rename Album';
        $scope.modal.show();
    };
    $scope.closeAL = function () {
        $scope.modal.hide();
    };
    $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
        if ($scope.modal.isShown()) {
            event.preventDefault();
            $scope.closeAL();
        }
    });

    $scope.saveAL = function () {
        if ($scope.AL.ALName == null || $scope.AL.ALName == '') {
            alert('Please enter Album Name');
            return;
        }
        $http.post('api/AL', $scope.AL, config)
       .success(function (data, status, headers, config) {
           var result = JSON.parse(data);
           if ($.isArray(result))
               $scope.ErrorMessages = result;
           else {
               $scope.ErrorMessages = [];
               swal({ title: "Album Saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
               $('#modalA').modal('hide');
               $scope.searchAL();
           }
       })
       .error(function (data, status, header, config) {
           alert('error');
       });
    };

    $scope.navigateAL = function (itm) {
        $scope.filter.ALID = itm.ALID;
        $scope.ALName = itm.ALName;
        //$scope.searchImg();
        $state.go('app.ALView', { 'ALID': itm.ALID, 'ALName': itm.ALName });
    };

    $scope.searchImg = function () {
        $http({
            method: 'POST',
            url: 'api/AL/ImgList/',
            data: JSON.stringify($scope.filter)
        }).success(function (Imgs) {
            $scope.Imgs = Imgs;
            $scope.images = [];
            for (var j = 0; j < Imgs.length; j++) {
                var objImg = Imgs[j];
                $scope.images.push({ thumb: baseImageUrl + objImg.ImageUrl, img: baseImageUrl + objImg.ImageUrl });
            }
        });
    };

    $scope.searchAL();
    $scope.doRefresh = function () {
        //simulate async response
        $scope.searchAL();
    };
});


app.controller('ALViewCtrl', function ($scope, $http, $ionicSlideBoxDelegate, $stateParams, $ionicModal, $state, $cordovaFileTransfer) {
    var ALID = $stateParams.ALID;
    $scope.ALName = '';
    $scope.baseUrl = baseUrl;
    $scope.Imgs = [];
    var baseImageUrl = baseUrl + 'Download.aspx?fileID=';
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };

    $scope.searchImg = function () {

        $http({
            method: 'POST',
            url: 'api/AL/ImgList/',
            data: JSON.stringify({ ALID: ALID })
        }).success(function (Imgs) {
            $scope.Imgs = Imgs;

            $ionicSlideBoxDelegate.update();
        });

        $http({
            method: 'GET',
            url: 'api/AL/' + ALID
        }).success(function (AL) {
            $scope.AL = JSON.parse(AL);
            $scope.ALName = $scope.AL.ALName;
        });
    };

    $scope.searchImg();

    $ionicModal.fromTemplateUrl('album-modal.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        $scope.modal = modal;
    });
    $scope.renameAL = function () {
        $scope.modalTitle = 'Rename Album';
        $scope.modal.show();
    };
    $scope.closeAL = function () {
        $scope.modal.hide();
    };
    $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
        if ($scope.modal.isShown()) {
            event.preventDefault();
            $scope.closeAL();
        }
    });
    $scope.saveAL = function () {
        if ($scope.AL.ALName == null || $scope.AL.ALName == '') {
            alert('Please enter Album Name');
            return;
        }
        $http.post('api/AL', $scope.AL, config)
       .success(function (data, status, headers, config) {
           var result = JSON.parse(data);
           if ($.isArray(result))
               $scope.ErrorMessages = result;
           else {
               $scope.ErrorMessages = [];
               $scope.ALName = $scope.AL.ALName;
               swal({ title: "Album Saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
           }
       })
       .error(function (data, status, header, config) {
           alert('error');
       });
    };
    $scope.deleteAL = function () {
        $http({
            method: 'POST',
            url: 'api/AL/DeleteAL/',
            data: JSON.stringify({ ALID: $scope.AL.ALID })
        }).success(function (result) {
            if (result.indexOf('Error:') > -1) {
                swal({ title: result, type: "error", timer: 2000, showConfirmButton: false });
            }
            else {
                swal({ title: "Album Deleted successfully!", type: "success", timer: 1000, showConfirmButton: false });
                $state.go('app.AL');
            }
        });
    };
    $scope.deleteImage = function (imgID, imageUrl) {
        $http({
            method: 'POST',
            url: 'api/AL/DeleteImage/',
            data: JSON.stringify({ ImgID: imgID, ImageUrl: imageUrl })
        }).success(function (result) {
            $scope.searchImg();
        });
    };
    $scope.addFiles = function () {
        fileChooser.open(function (uri) {

            // Destination URL 
            var url = baseUrl + 'FileUploadHandler.ashx?ALID=' + $scope.AL.ALID;

            //File for Upload
            var targetPath = uri;

            // File name only
            var filename = targetPath.split("/").pop();

            var options = {
                fileKey: "file",
                fileName: filename,
                params: { 'directory': 'upload', 'fileName': filename }
            };
            showLoading();
            $cordovaFileTransfer.upload(url, targetPath, options).then(function (result) {
                hideLoading();
                var r = result.response.split('|');
                if (r.length <= 1) {
                    swal({ title: result.response, type: "error", timer: 2000, showConfirmButton: false });
                }
                $scope.fileUploaded('');
            }, function (err) {
                alert(err);
                hideLoading();
            }, function (progress) {
                // PROGRESS HANDLING GOES HERE
            });
        });

    };
    $scope.fileUploaded = function (result) {
        $scope.searchImg();
    };
});