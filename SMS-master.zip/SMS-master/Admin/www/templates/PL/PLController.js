var app = angular.module('starter');

app.controller('PLListCtrl', function ($scope, $http, $location, $state, $ionicFilterBar) {
    $scope = readyAngularGrid($scope, $http, 'api/PLList', 'PLID', 'PL');
    $scope.totalPages = 1;
    $scope.pagingOptions.pageSize = 10;
    $scope.searchPL = function () {
        $scope.pagingOptions.currentPage = 1;
        $scope.totalPages = 1;
        $scope.allData = [];
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };

    window.setTimeout(function () { $scope.searchPL(); }, 200);

    $scope.newPL = function () {
        $state.go('app.PLEdit', { 'PLID': 0 });
    };
    $scope.editPL = function (PLID) {
        $state.go('app.PLEdit', { 'PLID': PLID });
    };


    $scope.showResultPL = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            saveGridData($scope, GridData, 'PL');
            $location.path('/PLResult/' + selected[0].PLID);
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.showFilterBar = function () {
        filterBarInstance = $ionicFilterBar.show({
            items: null,
            update: function (a, b) {
                if (b != null) {
                    $scope.filterOptions.filterText = b;
                    $scope.searchPL();
                }
            },
            delay: 500
        });
        window.setTimeout(function () { $('.filter-bar-search').val($scope.filterOptions.filterText); }, 200);
    };
    $scope.doRefresh = function () {
        //simulate async response
        $scope.searchPL();
    };
});
app.controller('PLListingCtrl', function ($scope, $http, $location) {
    $scope.PLs = [];
    setTimeout(function () {
        $http({
            method: 'POST',
            url: 'api/PL/GetAllPLs'
        }).success(function (NBs) {
            var PLs = NBs;
            for (var j = 0; j < PLs.length; j++) {
                PLs[j].SelectedOptions = [];
                PLs[j].SelectedOption = null;
            }
            $scope.PLs = PLs;
        });
    }, 100);

    $scope.toMarkup = function (text) {
        return toMarkup(text);
    };

    $scope.submitCast = function (itm) {
        if (itm.MultiOptions == true && itm.SelectedOptions.length == 0) {
            itm.PLSubmitted = true;
            return;
        }
        if (itm.MultiOptions != true && itm.SelectedOption == null || itm.SelectedOption == '') {
            itm.PLSubmitted = true;
            return;
        }
        $http({
            method: 'POST',
            url: 'api/PL/SubmitCast',
            data: JSON.stringify(itm)
        }).success(function (data) {
            itm.ShowResult = true;
            itm.Casted = true;
            $scope.showPLResult(itm);
        });
    };
    $scope.showPLResult = function (itm) {
        $http({
            method: 'POST',
            url: 'api/PL/GetPLResult',
            data: JSON.stringify({ PLID: itm.PLID })
        }).success(function (data) {
            itm.Result = data;
        });
    };
    $scope.backToPL = function (itm) {
        itm.ShowResult = false;
    };
    $scope.showResult = function (itm) {
        itm.ShowResult = true;
        $scope.showPLResult(itm);
    };
   
})
app.controller('PLResultCtrl', function ($scope, $http, $location, $stateParams) {
    $scope.PL = {};
    var PLID = $stateParams.PLID;
    $scope.toMarkup = function (text) {
        return toMarkup(text);
    };


    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/PL/' + PLID
        }).success(function (PL) {
            $scope.PL = JSON.parse(PL);
            $http({
                method: 'POST',
                url: 'api/PL/GetPLResult',
                data: JSON.stringify({ PLID: $scope.PL.PLID })
            }).success(function (data) {
                $scope.PL.Result = data;
            });
        });
    }, 100);

})
.controller('PLCtrl', function ($scope, $http, $location, $stateParams, $state) {
    var PLID = $stateParams.PLID;
    $scope.PL = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.PLSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.PLSubmitted = true;
        //if ($scope.formPL.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/PL', $scope.PL, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.PL = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/PLList');
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/PL/' + PLID
        }).success(function (PL) {
            $scope.PL = JSON.parse(PL);
        });
    }, 100);
    $scope.PLOption = {};
    $scope.PLOptionSubmitted = false;
    var PLOption = [];
    $scope.editPLOption = function (indx) {
        $scope.EditMode = true;
        $scope.PLOption = $scope.PL.PLOptionList[indx];
        PLOption = angular.copy($scope.PL.PLOptionList);
    };
    $scope.deletePLOption = function (indx) {
        if (confirm('Are you sure want to delete?') == true) {
            $scope.PL.PLOptionList.splice(indx, 1);
        }
    };
    $scope.newPLOption = function () {
        $scope.EditMode = true;
        $scope.PLOptionSubmitted = false;
        PLOption = angular.copy($scope.PL.PLOptionList);
        $scope.PLOption = {};
        $scope.PL.PLOptionList.push($scope.PLOption);
    };
    $scope.cancelPLOption = function () {
        $scope.EditMode = false;
        $scope.PLOption = {};
        angular.copy(PLOption, $scope.PL.PLOptionList);
    };
    $scope.updatePLOption = function (indx) {
        $scope.PLOptionSubmitted = true;
        if ($scope.PLOption.OptionText == '') {
            alert('Please enter Option.');
            return;
        }
        $scope.EditMode = false;
        $scope.PLOption = {};
    };
    $scope.viewPL = function () {
        $state.go('app.PLView', { 'PLID': $scope.PL.PLID });
    };
    $scope.deletePL = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        $http({
            method: 'DELETE',
            url: 'api/PL/' + $scope.PL.PLID
        }).success(function (result) {
            if (result == true)
                $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
        });
    };
});
app.directive('ploption', function () {
    return {
        restrict: 'E',
        replace: true,
        templateUrl: 'templates/PL/PLOption.html'
    }
});
