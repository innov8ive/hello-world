	$(document).ready(function(c) {
		$('.fechar.001').on('click', function(c){
			$('.alert001').fadeOut('slow', function(c){
				$('.alert001').remove();
			});
		});	  
	});

	$(document).ready(function(c) {
		$('.fechar.002').on('click', function(c){
			$('.alert002').fadeOut('slow', function(c){
				$('.alert002').remove();
			});
		});	  
	});

	$(document).ready(function(c) {
		$('.fechar.003').on('click', function(c){
			$('.alert003').fadeOut('slow', function(c){
				$('.alert003').remove();
			});
		});	  
	});

	$(document).ready(function(c) {
		$('.fechar.004').on('click', function(c){
			$('.alert004').fadeOut('slow', function(c){
				$('.alert004').remove();
			});
		});	  
	});

	$(document).ready(function(c) {
		$('.fechar.005').on('click', function(c){
			$('.alert005').fadeOut('slow', function(c){
				$('.alert005').remove();
			});
		});	  
	});
	
	$(document).ready(function(c) {
		$('.fechar.006').on('click', function(c){
			$('.alert006').fadeOut('slow', function(c){
				$('.alert006').remove();
			});
		});	  
	});
	
	$(document).ready(function(c) {
		$('.fechar.007').on('click', function(c){
			$('.alert007').fadeOut('slow', function(c){
				$('.alert007').remove();
			});
		});	  
	});
	
	$(document).ready(function(c) {
		$('.fechar.008').on('click', function(c){
			$('.alert008').fadeOut('slow', function(c){
				$('.alert008').remove();
			});
		});	  
	});
	
	$(document).ready(function(c) {
		$('.fechar.009').on('click', function(c){
			$('.alert009').fadeOut('slow', function(c){
				$('.alert009').remove();
			});
		});	  
	});
	
	$(document).ready(function(c) {
		$('.fechar.010').on('click', function(c){
			$('.alert010').fadeOut('slow', function(c){
				$('.alert010').remove();
			});
		});	  
	});
	
	$(document).ready(function(c) {
		$('.fechar.011').on('click', function(c){
			$('.alert011').fadeOut('slow', function(c){
				$('.alert011').remove();
			});
		});	  
	});
	
	$(document).ready(function(c) {
		$('.fechar.012').on('click', function(c){
			$('.alert012').fadeOut('slow', function(c){
				$('.alert012').remove();
			});
		});	  
	});