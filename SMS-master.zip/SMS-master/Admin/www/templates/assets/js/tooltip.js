	$(document).ready(function() {
	// Tooltip only Text
	$('.masterTooltip').hover(function(){
			// Hover over code
			var title = $(this).attr('title');
			$(this).data('tipText', title).removeAttr('title');
			$('<p class="tooltip-help"></p>')
			.text(title)
			.appendTo('body')
			.fadeIn('medium');
	}, function() {
			// Hover out code
			$(this).attr('title', $(this).data('tipText'));
			$('.tooltip-help').remove();
	}).mousemove(function(e) {
			var mousex = e.pageX - 80; //Get X coordinates
			var mousey = e.pageY + 30; //Get Y coordinates
			$('.tooltip-help')
			.css({ top: mousey, left: mousex })
	});
	});