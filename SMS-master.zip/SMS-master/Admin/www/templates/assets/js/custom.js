﻿$(document).ready(function () {

    /*====================================
           MENU 
     ======================================*/

    $('#main-menu').metisMenu();

    /*======================================
    CARREGAR O TAMANHO DO MENU DE ACORDO COM O TAMANHO DA TELA
    ========================================*/

    $(window).bind("load resize", function () {
        if ($(this).width() < 768) {
            $('div.sidebar-collapse').addClass('collapse')
        } else {
            $('div.sidebar-collapse').removeClass('collapse')
        }
    });
    /*======================================
   Outros Sripts
   ========================================*/
   
   

});
      