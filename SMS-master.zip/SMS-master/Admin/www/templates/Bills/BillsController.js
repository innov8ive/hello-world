﻿var app = angular.module('starter');

app.controller('BillsListCtrl', function ($scope, $http, $location, $state, $ionicFilterBar, $filter) {
    $scope = readyAngularGrid($scope, $http, 'api/BillsList', 'BillID', 'Bills');
    
    $scope.totalPages = 1;
    $scope.pagingOptions.pageSize = 10;
    $scope.searchBills = function () {
        $scope.pagingOptions.currentPage = 1;
        $scope.totalPages = 1;
        $scope.allData = [];
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };

    window.setTimeout(function () { $scope.searchBills(); }, 200);

    $scope.editBills = function (BillID) {
        $state.go('app.BillsEdit', { 'BillID': BillID });
    };
    $scope.showFilterBar = function () {
        filterBarInstance = $ionicFilterBar.show({
            items: null,
            update: function (a, b) {
                if (b != null) {
                    $scope.filterOptions.filterText = b;
                    $scope.searchBills();
                }
            },
            delay: 500
        });
        window.setTimeout(function () { $('.filter-bar-search').val($scope.filterOptions.filterText); }, 200);
    };
    $scope.doRefresh = function () {
        //simulate async response
        $scope.searchBills();
    };
    $scope.generateBill = function () {
        $state.go('app.PendingBills');
    };
});

app.controller('BillsCtrl', function ($scope, $http, $location, $stateParams, $state) {

    var ID = $stateParams.BillID;
    $scope.Bills = {};


    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/Bills/' + ID
        }).success(function (Bills) {
            $scope.Bills = JSON.parse(Bills);
        });
    }, 100);
    $scope.openPR = function () {
        $state.go('app.PR', { 'BillID': $scope.Bills.BillID, 'RoomID': $scope.Bills.RoomID, 'ReqID': $scope.Bills.ReqID });
    };

    $scope.printBill = function () {
        var url = baseUrl + 'PrintBill.aspx?BillID=' + $scope.Bills.BillID + '&bill=/Bill_' + $scope.Bills.BillID + '.pdf';

        cordova.plugins.DownloadManager.download(url, function (data) {
            console.log("success");
            window.plugins.toast.show('Bill Downloading...', 2000, 'top');
        }, function (message) {
            alert(message);
        });
        //$cordovaInAppBrowser.open(url, '_blank', { 'location': 'no' });
    };
    $scope.printRec = function () {
        var url = baseUrl + 'PrintReciept.aspx?BillID=' + $scope.Bills.BillID + '&bill=/Rec_' + $scope.Bills.BillID + '.pdf';
        cordova.plugins.DownloadManager.download(url, function (data) {
            console.log("success");
            window.plugins.toast.show('Receipt Downloading...', 2000, 'top');
        }, function (message) {
            alert(message);
        });
        //$cordovaInAppBrowser.open(url, '_blank', { 'location': 'no' });
    };
});

app.controller('PRCtrl', function ($scope, $http, $location, $stateParams, $state) {

    var BillID = $stateParams.BillID;
    var RoomID = $stateParams.RoomID;
    var ReqID = $stateParams.ReqID;
    $scope.Payments = {};


    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/Payments/' + 0 + '/' + RoomID + '/' + ReqID
        }).success(function (Payments) {
            $scope.Payments = JSON.parse(Payments);
            $scope.bindCreditTo();
        });
    }, 100);
    $scope.credittolist = [];
    $scope.bindCreditTo = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetContraGLList', Data: null })
        }).success(function (data) {
            $scope.credittolist = data;
            $scope.modelist = [{ Value: 'Cash', Key: 'Cash' }, { Value: 'Cheque', Key: 'Cheque' }, { Value: 'NEFT', Key: 'NEFT' }]

        });
    };

    $scope.TotalBillAmt = 0;
    $scope.$watch('Payments.BillPaymentsList', function (newVal, oldVal) {
        if (newVal !== oldVal) {
            $scope.TotalBillAmt = 0;
            for (var j = 0; j < $scope.Payments.BillPaymentsList.length; j++) {
                $scope.TotalBillAmt += parseFloatEx($scope.Payments.BillPaymentsList[j].PaidAmount);
            }
            $scope.TotalBillAmt = $scope.TotalBillAmt.toFixed(2);
        }
    }, true);
    $scope.UpdateApproved = function () {
        $scope.Payments.Approved = true;
        $scope.update();
    };
    $scope.update = function () {

        $scope.PaymentsSubmitted = true;
        if ($scope.formPayments.$invalid == true) return;

        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        var BillIDs = '';
        var BillList = [];
        for (var j = 0; j < $scope.Payments.BillPaymentsList.length; j++) {
            BillList.push($scope.Payments.BillPaymentsList[j]);
            BillIDs += ',' + $scope.Payments.BillPaymentsList[j].BillID;
        }
        if (BillList.length > 0)
            BillIDs = BillIDs.substring(1, BillIDs.length - 1);
        $scope.Payments.Amount = $scope.TotalBillAmt;
        //if (($scope.Payments.PaymentID <= 0 || $scope.Payments.PaymentID == null)
        //    && BillList.length == 0) {
        //    swal({ title: "Please select Bill(s)!", type: "error", timer: 1000, showConfirmButton: false });
        //}
        if (($scope.Payments.PaymentID <= 0 || $scope.Payments.PaymentID == null)
            && $scope.Payments.Amount != $scope.TotalBillAmt) {
            swal({ title: "The entered Amount should be equal to Total Bill Amount", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }

        $http({
            method: 'POST',
            url: 'api/Payments',
            data: JSON.stringify($scope.Payments)
        }).success(function (data) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.Payments = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
                $state.go('app.Bills');
            }
        }).error(function (data, status, header, config) {
            alert('error');
        });

        //$http.post('api/Payments', $scope.Payments, config)
        //.success(function (data, status, headers, config) {
        //    var result = JSON.parse(data);
        //    if ($.isArray(result))
        //        $scope.ErrorMessages = result;
        //    else {
        //        $scope.ErrorMessages = [];
        //        $scope.Payments = result;
        //        swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
        //    }
        //})
        //.error(function (data, status, header, config) {
        //    alert('error');
        //});
    };
});

app.controller('DefaultersCtrl', function ($scope, $http, $location, $state, $ionicFilterBar, $filter) {
    $scope = readyAngularGrid($scope, $http, 'api/Bills/Defaulters', 'RoomID', 'Defaulters');
    $scope.totalPages = 1;
    $scope.pagingOptions.pageSize = 10;
    $scope.searchBills = function () {
        $scope.pagingOptions.currentPage = 1;
        $scope.totalPages = 1;
        $scope.allData = [];
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };

    window.setTimeout(function () { $scope.searchBills(); }, 200);

    $scope.showFilterBar = function () {
        filterBarInstance = $ionicFilterBar.show({
            items: null,
            update: function (a, b) {
                if (b != null) {
                    $scope.filterOptions.filterText = b;
                    $scope.searchBills();
                }
            },
            delay: 500
        });
        window.setTimeout(function () { $('.filter-bar-search').val($scope.filterOptions.filterText); }, 200);
    };
    $scope.doRefresh = function () {
        //simulate async response
        $scope.searchBills();
    };
    $scope.sendEmail = function () {
        if (confirm('Are you sure want to Send Email Reminder?') == true) {
            $http({
                method: 'POST',
                url: 'api/Msg/SendEmailReminder/',
                data: JSON.stringify({ val: $scope.myData })
            }).success(function (res) {
                $scope.DefaulterList = JSON.parse(res);
            });
        }
    };
    $scope.sendSMS = function () {
        if (confirm('Are you sure want to Send SMS Reminder?') == true) {
            $http({
                method: 'POST',
                url: 'api/Msg/SendSMSReminder/',
                data: JSON.stringify({ val: $scope.myData })
            }).success(function (res) {
                $scope.DefaulterList = JSON.parse(res);
            });
        }
    };
});

app.controller('PendingBillsController', function ($scope, $http, $location, $state, $filter) {
    $scope.bill = { filterText: $filter('date')(new Date(), '01-MMM-yyyy') };
    $scope.BillList = [];
    setTimeout(function () {
        $scope.searchBills();
    }, 100);
    $scope.searchBills = function () {
        $http({
            method: 'POST',
            url: 'api/Bills/GetPendingBills/',
            data: JSON.stringify({ month: $scope.bill.filterText })
        }).success(function (res) {
            var result = JSON.parse(res);
            if ($.isArray(result))
                $scope.BillList = result;
            else {
                alert(JSON.parse(res).Error);
            }
        });
    };
    $scope.generateBill = function () {
        if (confirm('Are you sure, you want to Generate Bills?') == true) {

            $http({
                method: 'POST',
                url: 'api/Bills/GenerateBills3/',
                data: JSON.stringify({ month: $scope.bill.filterText })
            }).success(function (result) {
                if (result.length > 0) {
                    alert(result);
                }
                else {
                    alert('Bill Generated Successfully!');
                    $scope.searchBills();
                }
            });
        }
    };
});



