var app = angular.module('starter');

app.controller('BookingsCtrl', function ($scope, $http, $location, $stateParams,$state) {
    
    var BookingID = $stateParams.BookingID;
    $scope.Bookings = {FromTime: ' '};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.BookingsSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.BookingsSubmitted = true;
        if ($scope.formBookings.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        if ($scope.Bookings.FCID == null || $scope.Bookings.FCID == '' || $scope.Bookings.FCID == ' ') {
            swal({ title: "Please select Facility.", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        if ($scope.Bookings.RoomID == null || $scope.Bookings.RoomID == '' || $scope.Bookings.RoomID == ' ') {
            swal({ title: "Please select Unit.", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        if ($scope.Bookings.InTime == null || $scope.Bookings.InTime == '' || $scope.Bookings.InTime == ' ') {
            swal({ title: "Please select From Time.", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        if ($scope.Bookings.OutTime == null || $scope.Bookings.OutTime == '' || $scope.Bookings.OutTime == ' ') {
            swal({ title: "Please select To Time.", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        $http.post('api/Bookings', $scope.Bookings, config)
        .success(function (data, status, headers, config) {
            var result = data;
            if (result.ErrorCode == 1)
                $scope.ErrorMessages = result.data;
            else {
                $scope.ErrorMessages = [];
                $scope.Bookings = result.data;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
                $state.go('app.Bookings');
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

   

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/Bookings/' + BookingID
        }).success(function (Bookings) {
            $scope.Bookings = Bookings;
            $scope.Bookings = { FCID: ' ', RoomID: ' ', InTime: ' ', OutTime: ' ' };
        });
    }, 100);

    $scope.timelist = [];
    $scope.bindTime = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetTimeList', Data: null })
        }).success(function (data) {
            $scope.timelist = data;
        });
    }
    $scope.bindTime();

    $scope.fclist = [];
    $scope.bindFC = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetFCList', Data: null })
        }).success(function (data) {
            $scope.fclist = data;
        });
    }
    $scope.bindFC();

    $scope.roomlist = [];
    $scope.bindRoom = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetMyRoomList', Data: null })
        }).success(function (data) {
            $scope.roomlist = data;
        });
    }
    $scope.bindRoom();

    
});
app.controller('BookingsListingCtrl', function ($scope, $http, $location, $state, $ionicFilterBar) {

    $scope.filter = { filterText: '' };
    $scope.BookingList = [];
    $scope.searchBookings = function () {
        $http({
            method: 'POST',
            url: 'api/Bookings/BookingsListUser/',
            data: JSON.stringify({ filterText: $scope.filter.filterText })
        }).success(function (data) {
            $scope.BookingList = data;
        });
    };
    window.setTimeout(function () { $scope.searchBookings(); }, 200);
    $scope.newBookings = function () {
        $state.go('app.BookingsEdit', { 'BookingID': 0 });
    };
    $scope.showFilterBar = function () {
        filterBarInstance = $ionicFilterBar.show({
            items: null,
            update: function (a, b) {
                if (b != null) {
                    $scope.filter.filterText = b;
                    $scope.searchBookings();
                }
            },
            delay: 500
        });
        window.setTimeout(function () { $('.filter-bar-search').val($scope.filter.filterText); }, 200);
    };
})