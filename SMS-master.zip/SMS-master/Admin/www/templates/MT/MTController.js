var app = angular.module('starter');

app.controller('MTListCtrl', function ($scope, $http, $location, $state, $ionicFilterBar) {
    $scope = readyAngularGrid($scope, $http, 'api/MTList', 'MTID', 'MT');
    $scope.totalPages = 1;
    $scope.pagingOptions.pageSize = 10;
    $scope.searchMT = function () {
        $scope.pagingOptions.currentPage = 1;
        $scope.totalPages = 1;
        $scope.allData = [];
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };

    window.setTimeout(function () { $scope.searchMT(); }, 200);

    $scope.newMT = function () {
        $state.go('app.MTEdit', { 'MTID': 0 });
    };
    $scope.editMT = function (MTID) {
        $state.go('app.MTEdit', { 'MTID': MTID });
    };

    $scope.showFilterBar = function () {
        filterBarInstance = $ionicFilterBar.show({
            items: null,
            update: function (a, b) {
                if (b != null) {
                    $scope.filterOptions.filterText = b;
                    $scope.searchMT();
                }
            },
            delay: 500
        });
        window.setTimeout(function () { $('.filter-bar-search').val($scope.filterOptions.filterText); }, 200);
    };
    $scope.doRefresh = function () {
        //simulate async response
        $scope.searchMT();
    };
})
.controller('MTCtrl', function ($scope, $http, $location, $stateParams, $state) {
    var MTID = $stateParams.MTID;
    $scope.MT = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.MTSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.MTSubmitted = true;
        if ($scope.formMT.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/MT', $scope.MT, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.MT = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/MTList');
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/MT/' + MTID
        }).success(function (MT) {
            $scope.MT = JSON.parse(MT);
            $scope.ATName = $scope.MT.AT == 'ALLCOM' ? 'Committee Members' : 'All Members';
            $scope.bindTime();
        });
    }, 100);
    $scope.MTUsers = {};
    $scope.MTUsersSubmitted = false;
    var MTUsers = [];
    $scope.editMTUsers = function (indx) {
        $scope.EditMode = true;
        $scope.MTUsers = $scope.MT.MTUsersList[indx];
        MTUsers = angular.copy($scope.MT.MTUsersList);
    };
    $scope.deleteMTUsers = function (indx) {
        if (confirm('Are you sure want to delete?') == true) {
            $scope.MT.MTUsersList.splice(indx, 1);
        }
    };
    $scope.newMTUsers = function () {
        $scope.EditMode = true;
        $scope.MTUsersSubmitted = false;
        MTUsers = angular.copy($scope.MT.MTUsersList);
        $scope.MTUsers = {};
        $scope.MT.MTUsersList.push($scope.MTUsers);
    };
    $scope.cancelMTUsers = function () {
        $scope.EditMode = false;
        $scope.MTUsers = {};
        angular.copy(MTUsers, $scope.MT.MTUsersList);
    };
    $scope.updateMTUsers = function (indx) {
        $scope.MTUsersSubmitted = true;
        if ($scope.formMTUsers.$invalid == true) return;
        $scope.EditMode = false;
        $scope.MTUsers = {};
    };

    $scope.sendNotification = function () {
        $http({
            method: 'POST',
            url: 'api/MT/SendNotification',
            data: JSON.stringify($scope.MT)
        }).success(function (data) {
            swal({ title: "Invitation Sent Successfully!", type: "success", timer: 1000, showConfirmButton: false });
        });
    };
    $scope.sendNotificationEmail = function () {
        $http({
            method: 'POST',
            url: 'api/MT/SendNotificationEmail',
            data: JSON.stringify($scope.MT)
        }).success(function (data) {
            swal({ title: "Invitation Sent Successfully!", type: "success", timer: 1000, showConfirmButton: false });
        });
    };
    $scope.timelist = [];
    $scope.atlist = [];
    $scope.bindTime = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetTimeList', Data: null })
        }).success(function (data) {
            $scope.timelist = data;
            $scope.atlist.push({ Value: 'All Members', Key: 'ALLRES', Selected: false });
            $scope.atlist.push({ Value: 'Committee Members', Key: 'ALLCOM', Selected: false });
        });
    }

    $scope.viewMOM = function () {
        $state.go('app.MOM', { 'MTID': $scope.MT.MTID });
    };
})
.controller('MOMCtrl', function ($scope, $http, $location, $stateParams, $cordovaFileTransfer) {
    var MTID = $stateParams.MTID;
    $scope.MT = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.MTSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.MTSubmitted = true;
        if ($scope.formMT.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }

        $http({
            method: 'POST',
            url: 'api/MT/UpdateMOM',
            data: JSON.stringify($scope.MT)
        }).success(function (MT) {
            swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
        });
    };

    $scope.cancel = function () {
        $location.path('/MTList');
    }

    $scope.userlist = [];
    $scope.bindUser = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetUserListByType', Data: null, query: $scope.MT.AT })
        }).success(function (data) {
            $scope.userlist = data;
        });
    };

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/MT/' + MTID
        }).success(function (MT) {
            $scope.MT = JSON.parse(MT);
            $scope.bindUser();
        });
    }, 100);
    $scope.MTUsers = {};
    $scope.MTUsersSubmitted = false;
    var MTUsers = [];
    $scope.editMTUsers = function (indx) {
        $scope.EditMode = true;
        $scope.MTUsers = $scope.MT.MTUsersList[indx];
        MTUsers = angular.copy($scope.MT.MTUsersList);
    };
    $scope.deleteMTUsers = function (indx) {
        if (confirm('Are you sure want to delete?') == true) {
            $scope.MT.MTUsersList.splice(indx, 1);
        }
    };
    $scope.newMTUsers = function () {
        $scope.EditMode = true;
        $scope.MTUsersSubmitted = false;
        MTUsers = angular.copy($scope.MT.MTUsersList);
        $scope.MTUsers = {};
        $scope.MT.MTUsersList.push($scope.MTUsers);
    };
    $scope.cancelMTUsers = function () {
        $scope.EditMode = false;
        $scope.MTUsers = {};
        angular.copy(MTUsers, $scope.MT.MTUsersList);
    };
    $scope.updateMTUsers = function (indx) {
        $scope.MTUsersSubmitted = true;
        if ($scope.formMTUsers.$invalid == true) return;
        $scope.EditMode = false;
        $scope.MTUsers = {};
    };
    $scope.sendNotification = function () {
        $http({
            method: 'POST',
            url: 'api/MT/SendMOM',
            data: JSON.stringify($scope.MT)
        }).success(function (data) {
            swal({ title: "Minutes of Meeting Sent Successfully!", type: "success", timer: 1000, showConfirmButton: false });
        });
    };
    $scope.sendNotificationSMS = function () {
        $http({
            method: 'POST',
            url: 'api/MT/SendMOMSMS',
            data: JSON.stringify($scope.MT)
        }).success(function (data) {
            if (data == "Success") {
                swal({ title: "Minutes of Meeting SMS Sent Successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
            else {
                swal({ title: "Minutes of Meeting SMS not Sent Successfully!", type: "error", timer: 1000, showConfirmButton: false });
            }
        });
    };


    $scope.fileDelete = function () {
        if (confirm('Are you sure want to delete file?') == true) {
            $http({
                method: 'POST',
                url: 'api/MT/DeleteMOM',
                data: JSON.stringify($scope.MT)
            }).success(function (MT) {
                $scope.MT.FileGUID = '';
                $scope.MT.MOMFileID = 0;
                swal({ title: "File deleted successfully!", type: "success", timer: 1000, showConfirmButton: false });
            });
        }
    };
    $scope.fileUploaded = function (result) {
        var resultArr = result.response.split('|');
        if (resultArr.length > 1) {
            $scope.MT.FileGUID = resultArr[0];
            $scope.MT.FileName = resultArr[1];
            $scope.MT.MOMFileID = resultArr[2];
        }
        else {
            swal({ title: resultArr[0], type: "error", showConfirmButton: true, timer: 2000 });
        }
    };
    $scope.fileDownload = function (fileName, fileFullName) {
        // File for download
        var url = baseUrl + 'Download.aspx?download=1&fileID=' + fileName + '&file=/' + fileFullName;
        cordova.plugins.DownloadManager.download(url, function (data) {
            console.log("success");
            window.plugins.toast.show('File Downloading...', 2000, 'top');
        }, function (message) {
            alert(message);
        });
        //cordova.InAppBrowser.open(url, '_system', 'location=no');
    };
    $scope.fileUpload = function () {
        fileChooser.open(function (uri) {
            // Destination URL 
            var url = baseUrl + 'FileUploadHandler.ashx?MTID=' + $scope.MT.MTID;

            //File for Upload
            var targetPath = uri;

            // File name only
            var filename = targetPath.split("/").pop();

            var options = {
                fileKey: "file",
                fileName: filename,
                params: { 'directory': 'upload', 'fileName': filename }
            };
            showLoading();
            $cordovaFileTransfer.upload(url, targetPath, options).then(function (result) {
                hideLoading();
                $scope.fileUploaded(result);
            }, function (err) {
                alert(err);
                hideLoading();
            }, function (progress) {
                // PROGRESS HANDLING GOES HERE
            });
        });

    };
});

