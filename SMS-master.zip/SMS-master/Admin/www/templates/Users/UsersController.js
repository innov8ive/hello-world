var app = angular.module('starter');
app.controller('UsersListCtrl', function ($scope, $http, $location, $state, $ionicFilterBar, $ionicModal) {
    $scope = readyAngularGrid($scope, $http, 'api/UsersList', 'UserID', 'Users');
    $scope.totalPages = 1;
    $scope.pagingOptions.pageSize = 10;
    $scope.baseUrl = baseUrl;
    $scope.searchUsers = function () {
        $scope.pagingOptions.currentPage = 1;
        $scope.totalPages = 1;
        $scope.allData = [];
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };

    window.setTimeout(function () { $scope.searchUsers(); }, 200);

    $scope.newUsers = function () {
        $state.go('app.UsersEdit', { 'UserID': 0 });
    };
    $scope.editUsers = function (UserID) {
        $state.go('app.UsersEdit', { 'UserID': UserID });
    };

    $scope.showFilterBar = function () {
        filterBarInstance = $ionicFilterBar.show({
            items: null,
            update: function (a, b) {
                if (b != null) {
                    $scope.filterOptions.filterText = b;
                    $scope.searchUsers();
                }
            },
            delay: 500
        });
        window.setTimeout(function () { $('.filter-bar-search').val($scope.filterOptions.filterText); }, 200);
    };

    $ionicModal.fromTemplateUrl('image-modal.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        $scope.modal = modal;
    });
    $scope.openModal = function (Obj, $event) {
        if (Obj != null && Obj != '') {
            $scope.imageSrc = baseUrl + 'Download.aspx?type=profile&filepath=images/profile/' + Obj;
            $scope.modal.show();
            $event.stopPropagation();
        }
    };

    $scope.closeModal = function () {
        $scope.modal.hide();
    };
    $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
        if ($scope.modal.isShown()) {
            event.preventDefault();
            $scope.closeModal();
        }
    });
    $scope.doRefresh = function () {
        //simulate async response
        $scope.searchUsers();
    };
}).controller('UsersCtrl', function ($scope, $http, $location, $stateParams, $window, $cordovaCamera) {
    $scope.baseUrl = baseUrl;
    var UserID = $stateParams.UserID;
    $scope.Users = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.UsersSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.UsersSubmitted = true;
        if ($scope.formUsers.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        if ($scope.Users.UserID <= 0 && $scope.UsernameAvailable == 'false') return;
        $http.post('api/Users', $scope.Users, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.Users = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        // $location.path('/UsersList');
        $window.history.back();
    };
    $scope.userAvailable = function () {
        $http({
            method: 'POST',
            url: 'api/Users/Available/',
            data: JSON.stringify($scope.Users.UserName)
        }).success(function (result) {
            $scope.UsernameAvailable = result;
        });
    };
    $scope.removePhoto = function () {
        if (confirm('Are you sure, want to remove photo?')) {
            $http({
                method: 'POST',
                url: 'api/Users/RemovePhoto/',
                data: JSON.stringify($scope.Users.UserID + '.' + $scope.Users.ImageUrl)
            }).success(function (result) {
                if (result == 'true')
                    $scope.Users.ImageUrl = '';
            });
        }
    };

    $scope.choosePhoto = function () {
        try {
            var options = {
                quality: 75,
                destinationType: Camera.DestinationType.DATA_URL,
                sourceType: Camera.PictureSourceType.PHOTOLIBRARY,
                allowEdit: true,
                encodingType: Camera.EncodingType.JPEG,
                targetWidth: 300,
                targetHeight: 300,
                popoverOptions: CameraPopoverOptions,
                saveToPhotoAlbum: false
            };

            $cordovaCamera.getPicture(options).then(function (imageData) {
                showLoading();
                $.post(baseUrl + 'FileUploadHandler.ashx', {
                    type: 'ImageFile', data: imageData
                    , contentType: 'image/jpeg', DataID: $scope.Users.UserID, DataType: 'User'
                }, function (result, a, b, c) {
                    hideLoading();
                    fuResult = result.split('|');
                    if (fuResult.length == 3) {
                        var fileGUIDName = fuResult[0];
                        $scope.Users.ImageUrl = fileGUIDName;
                        $scope.hasImage = true;
                    }
                    else {
                        alert(result);
                    }
                });
            }, function (err) {
                hideLoading();
                alert(err);
            });
        } catch (e) { alert(e); }
    };
    setTimeout(function () {

        $http({
            method: 'GET',
            url: 'api/Users/' + UserID
        }).success(function (Users) {
            $scope.Users = JSON.parse(Users);
            $scope.bindRoom();
            $scope.Users.IsActive = $scope.Users.IsActive == null ? true : $scope.Users.IsActive;
        });
    }, 100);

    $scope.roomlist = [];
    $scope.membertypelist = [];
    $scope.bindRoom = function () {
        $scope.membertypelist = [];
        $scope.membertypelist.push({ Key: 'Owner', Value: 'Owner', Selected: false });
        $scope.membertypelist.push({ Key: 'Tenant', Value: 'Tenant', Selected: false });

        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetRoomList', Data: null })
        }).success(function (data) {
            $scope.roomlist = data;
        });
    }

    $scope.deleteUsers = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        $http({
            method: 'DELETE',
            url: 'api/Users/' + $scope.Users.UserID
        }).success(function (result) {
            if (result == '')
                $state.go('app.Users');
            else
                alert(result);
        });
    };
})
.controller('ProfileCtrl', ['$scope', '$http', '$location', '$stateParams', '$window', 'User', function ($scope, $http, $location, $stateParams, $window, User) {
    $scope.Users = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.UsersSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.UsersSubmitted = true;
        if ($scope.formUsers.$invalid == true) return;
        $http.post('api/Users/UpdateProfile', $scope.Users, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.Users = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
                User.FirstName = $scope.Users.FirstName;
                User.LastName = $scope.Users.LastName;
                User.CityID = $scope.Users.CityID;
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        // $location.path('/UsersList');
        $window.history.back();
    };
    $scope.removePhoto = function () {
        if (confirm('Are you sure, want to remove photo?')) {
            $http({
                method: 'POST',
                url: 'api/Users/RemovePhoto/',
                data: JSON.stringify($scope.Users.UserID + '.' + $scope.Users.ImageUrl)
            }).success(function (result) {
                if (result == 'true') {
                    $scope.Users.ImageUrl = '';
                    User.ImageUrl = '';
                }
            });
        }
    };
    $scope.uploadPhoto = function () {
        AttachImage($scope.photoUploaded);
    };
    $scope.photoUploaded = function (fileGUIDName, fileName, fileID) {
        $scope.Users.ImageUrl = fileGUIDName;
        $http({
            method: 'POST',
            url: 'api/Users/AttachPhoto/',
            data: JSON.stringify($scope.Users.UserID + '.' + $scope.Users.ImageUrl)
        }).success(function (result) {
            User.ImageUrl = $scope.Users.ImageUrl;
        });
    };
    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/UsersProfile'
        }).success(function (Users) {
            $scope.Users = JSON.parse(Users);
        });
    }, 100);

    $scope.citylist = [];
    $scope.bindCity = function () {
        $http({
            method: 'POST',
            url: 'api/Common/',
            data: JSON.stringify({ MethodName: 'GetAllCityList', Data: null })
        }).success(function (data) {
            $scope.citylist = data;
        });
    };
    $scope.bindCity();
}])
.controller('GKListCtrl', ['$scope', '$http', '$location', 'GridData', function ($scope, $http, $location, GridData) {

    $scope = readyAngularGrid($scope, $http, 'api/GKList', 'UserID', GridData, 'Users');
    $scope.gridOptions.columnDefs = [
    { displayName: 'FirstName', field: 'FirstName' },
    { displayName: 'LastName', field: 'LastName' },
    { displayName: 'UserName', field: 'UserName' },
    { displayName: 'EmailID', field: 'EmailID' },
    ];
    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, '');

    $scope.searchUsers = function () {
        $scope.filterOptions.filterText = $scope.filter.filterText;
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };
    $scope.newUsers = function () {
        saveGridData($scope, GridData, 'Users');
        $location.path('/GK/0');
    };
    $scope.editUsers = function () {
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            saveGridData($scope, GridData, 'Users');
            $location.path('/GK/' + selected[0].UserID);
        }
        else {
            alert('Please select a record to edit.');
        }
    };

    $scope.deleteUsers = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        var selected = $scope.gridOptions.ngGrid.config.selectedItems;
        if (selected.length > 0) {
            $http({
                method: 'DELETE',
                url: 'api/GKDelete/' + selected[0].UserID
            }).success(function (result) {
                if (result == true)
                    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
            });
        }
        else {
            alert('Please select a record to edit.');
        }
    };
}]);
