var app = angular.module('starter');

app.controller('FMListCtrl', function ($scope, $http, $location, $state) {
    $scope = readyAngularGrid($scope, $http, 'api/FMList', 'FMID', 'FM');
    $scope.totalPages = 1;
    $scope.pagingOptions.pageSize = 5;
    $scope.searchFM = function () {
        $scope.pagingOptions.currentPage = 1;
        $scope.totalPages = 1;
        $scope.allData = [];
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };

    window.setTimeout(function () { $scope.searchFM(); }, 200);

   
    $scope.newFM = function () {
        $state.go('app.FMEdit', { 'FMID': 0 });
    };
    $scope.editFM = function (FMID) {
        $state.go('app.FMEdit', { 'FMID': FMID });
    };
    //$ionicView.enter
})

.controller('FMCtrl', function ($scope, $http, $location, $stateParams, $rootScope) {
    var FMID = $stateParams.FMID;
    
    $scope.FM = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.FMSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.FMSubmitted = true;
        if ($scope.formFM.$invalid == true) {
            swal({ title: "There are some error(s) on the page!", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/FM', $scope.FM, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.FM = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/FMList');
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/FM/' + FMID
        }).success(function (FM) {
            $scope.FM = JSON.parse(FM);
            $scope.rellist = [{ Key: 'Father', Value: 'Father' }, { Key: 'Mother', Value: 'Mother' }]
        });
    }, 100);

    $scope.currentDate = new Date();
    $scope.minDate = new Date(2015, 10, 30);
    $scope.maxDate = new Date(2017, 10, 30);

});
