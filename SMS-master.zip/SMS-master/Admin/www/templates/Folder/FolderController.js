var app = angular.module('starter');

app.controller('FolderListCtrl', function ($scope, $http, $location, $ionicFilterBar, $ionicModal, $cordovaFileTransfer) {

    $scope.path = [];
    $scope.modalTitle = '';
    $scope.filter = { filterText: '', FolderID: 0 };
    $scope.showModal = false;
    $scope.Folder = {};
    $scope.FolderSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.searchFolder = function () {
        $http({
            method: 'POST',
            url: 'api/FolderList/',
            data: JSON.stringify($scope.filter)
        }).success(function (Folder) {
            $scope.Folders = JSON.parse(Folder);
            $scope.$broadcast('scroll.refreshComplete');
        });

        $http({
            method: 'POST',
            url: 'api/FileList/',
            data: JSON.stringify($scope.filter)
        }).success(function (Folder) {
            $scope.Files = JSON.parse(Folder);
        });
    };
    $ionicModal.fromTemplateUrl('folder-modal.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        $scope.modal = modal;
    });
    $scope.newFolder = function () {
        $scope.Folder = {};
        $scope.modalTitle = 'Create a New Folder';
        $scope.modal.show();
    };
    $scope.renameFolder = function (itm) {
        $scope.Folder = itm;
        $scope.modalTitle = 'Rename Folder';
        $scope.modal.show();
    };
    $scope.closeFolder = function () {
        $scope.modal.hide();
    };
    $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
        if ($scope.modal.isShown()) {
            event.preventDefault();
            $scope.closeFolder();
        }
    });
    $scope.deleteFolder = function (FolderID) {
        $http({
            method: 'POST',
            url: 'api/Folder/DeleteFolder/',
            data: JSON.stringify({ FolderID: FolderID })
        }).success(function (result) {
            if (result.indexOf('Error:') > -1) {
                swal({ title: result, type: "error", showConfirmButton: true, timer: 2000 });
            }
            else {
                swal({ title: "Folder Deleted successfully!", type: "success", timer: 1000, showConfirmButton: false });
                $scope.searchFolder();
            }
        });
    };

    $scope.deleteFile = function (FileID, FileGUID) {
        if (confirm('Are you sure want to delete this file?') == true) {
            $http({
                method: 'POST',
                url: 'api/Folder/DeleteFile/',
                data: JSON.stringify({ FileID: FileID, FileGUID: FileGUID })
            }).success(function (result) {
                swal({ title: "File Deleted successfully!", type: "success", timer: 1000, showConfirmButton: false });
                $scope.searchFolder();
            });
        }
    };
    $scope.saveFolder = function () {
        if ($scope.Folder.FolderName == null || $scope.Folder.FolderName == '') {
            alert('Please enter Folder Name');
            return;
        }
        $scope.Folder.ParentFolderID = $scope.filter.FolderID;
        $http.post('api/Folder', $scope.Folder, config)
       .success(function (data, status, headers, config) {
           var result = JSON.parse(data);
           if ($.isArray(result))
               $scope.ErrorMessages = result;
           else {
               $scope.ErrorMessages = [];
               swal({ title: "Folder Saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
               $('#modalF').modal('hide');
               $scope.searchFolder();
           }
       })
       .error(function (data, status, header, config) {
           alert('error');
       });
    };
    $scope.navigateFolder = function (itm) {
        $scope.filter.FolderID = itm.FolderID;
        $scope.path.push({ FolderID: itm.FolderID, FolderName: itm.FolderName, toString: function () { return this.FolderName; } });
        $scope.searchFolder();
    };
    $scope.backFolder = function () {
        $scope.path.pop();
        if ($scope.path.length > 0)
            $scope.filter.FolderID = $scope.path[$scope.path.length - 1].FolderID;
        else
            $scope.filter.FolderID = 0;
        $scope.searchFolder();
    };
    $scope.pathToShow = function () {
        return $scope.path.join('/');
    };
    $scope.addFiles = function () {
        fileChooser.open(function (uri) {
            // Destination URL 
            var url = baseUrl + 'FileUploadHandler.ashx?FolderID=' + $scope.filter.FolderID;

            //File for Upload
            var targetPath = uri;

            // File name only
            var filename = targetPath.split("/").pop();

            var options = {
                fileKey: "file",
                fileName: filename,
                params: { 'directory': 'upload', 'fileName': filename }
            };
            showLoading();
            $cordovaFileTransfer.upload(url, targetPath, options).then(function (result) {
                hideLoading();
                var r = result.response.split('|');
                if (r.length <= 1) {
                    swal({ title: result.response, type: "error", timer: 2000, showConfirmButton: false });
                }
                $scope.fileUploaded('');

            }, function (err) {
                alert(err);
                hideLoading();
            }, function (progress) {
                // PROGRESS HANDLING GOES HERE
            });
        });
    };
    $scope.fileUploaded = function (result) {
        $scope.searchFolder();
    };
    $scope.getFileCss = function (fileName) {
        var ext = fileName.substring(fileName.lastIndexOf('.') + 1).toLowerCase();
        switch (ext) {
            case 'png':
            case 'jpg':
            case 'jpeg':
            case 'gif':
            case 'bmp':
                return 'fa fa-file-image-o';
            case 'xls':
            case 'xlsx':
            case 'csv':
                return 'fa fa-file-excel-o';
            case 'doc':
            case 'docx':
                return 'fa fa-file-word-o';
            case 'txt':
                return 'fa fa-file-text-o';
            case 'pdf':
                return 'fa fa-file-pdf-o';
            case 'zip':
            case 'rar':
                return 'fa fa-file-zip-o';
        }
        return 'fa fa-file-o';
    };
    $scope.openFile = function (FileGUID, fileFullName) {
        var url = baseUrl + 'Download.aspx?download=1&fileID=' + FileGUID + '&file=/' + fileFullName;
        cordova.plugins.DownloadManager.download(url, function (data) {
            console.log("success");
            window.plugins.toast.show('File Downloading...', 2000, 'top');
        }, function (message) {
            alert(message);
        });
        //if (window.cordova)
        //    cordova.InAppBrowser.open(url, '_system', 'location=no');
        //else
        //    window.open(url, '_system', 'location=no');
    };
    $scope.searchFolder();

    $scope.showFilterBar = function () {
        filterBarInstance = $ionicFilterBar.show({
            items: null,
            update: function (a, b) {
                if (b != null) {
                    $scope.filterOptions.filterText = b;
                    $scope.searchFolder();
                }
            },
            delay: 500
        });
        window.setTimeout(function () { $('.filter-bar-search').val($scope.filterOptions.filterText); }, 200);
    };
    $scope.doRefresh = function () {
        //simulate async response
        $scope.searchFolder();
    };
    $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
        if ($scope.pathToShow() != '') {
            event.preventDefault();
            $scope.backFolder();
        }
    });
});