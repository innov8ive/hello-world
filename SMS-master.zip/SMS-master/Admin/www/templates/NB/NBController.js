var app = angular.module('starter');

app.controller('NBListCtrl', function ($scope, $http, $location, $state, $ionicFilterBar) {
    $scope = readyAngularGrid($scope, $http, 'api/NBList', 'NBID', 'NB');
    $scope.totalPages = 1;
    $scope.pagingOptions.pageSize = 10;
    $scope.searchNB = function () {
        $scope.pagingOptions.currentPage = 1;
        $scope.totalPages = 1;
        $scope.allData = [];
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };

    window.setTimeout(function () { $scope.searchNB(); }, 200);

    $scope.newNB = function () {
        $state.go('app.NBEdit', { 'NBID': 0 });
    };
    $scope.editNB = function (NBID) {
        $state.go('app.NBEdit', { 'NBID': NBID });
    };

    $scope.showFilterBar = function () {
        filterBarInstance = $ionicFilterBar.show({
            items: null,
            update: function (a, b) {
                if (b != null) {
                    $scope.filterOptions.filterText = b;
                    $scope.searchNB();
                }
            },
            delay: 500
        });
        window.setTimeout(function () { $('.filter-bar-search').val($scope.filterOptions.filterText); }, 200);
    };
    $scope.doRefresh = function () {
        //simulate async response
        $scope.searchNB();
    };
})
.controller('NBCtrl', function ($scope, $http, $location, $stateParams, $state) {
    var NBID = $stateParams.NBID;
    $scope.NB = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.NBSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.NBSubmitted = true;
        if ($scope.formNB.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/NB', $scope.NB, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.NB = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/NBList');
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/NB/' + NBID
        }).success(function (NB) {
            $scope.NB = JSON.parse(NB);
        });
    }, 100);

    $scope.toMarkup = function (text) {
        return toMarkup(text);
    };
    $scope.deleteNB = function () {
        if (confirm('Are you sure want to delete?') == false) return;
        $http({
            method: 'DELETE',
            url: 'api/NB/' + $scope.NB.NBID
        }).success(function (result) {
            if (result == true)
                $state.go('app.NB');
        });
    };
});
app.controller('VLController', function ($scope, $http, $location, $state, $ionicFilterBar) {
    $scope = readyAngularGrid($scope, $http, 'api/CPList', 'CPID', 'CP');
    $scope.totalPages = 1;
    $scope.pagingOptions.pageSize = 10;
    $scope.searchCP = function () {
        $scope.pagingOptions.currentPage = 1;
        $scope.totalPages = 1;
        $scope.allData = [];
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };

    window.setTimeout(function () { $scope.searchCP(); }, 200);

    $scope.showFilterBar = function () {
        filterBarInstance = $ionicFilterBar.show({
            items: null,
            update: function (a, b) {
                if (b != null) {
                    $scope.filterOptions.filterText = b;
                    $scope.searchCP();
                }
            },
            delay: 500
        });
        window.setTimeout(function () { $('.filter-bar-search').val($scope.filterOptions.filterText); }, 200);
    };
    $scope.doRefresh = function () {
        //simulate async response
        $scope.searchCP();
    };
    $scope.getDetails = function (CPID) {
        $state.go('app.VLDetails', { 'CPID': CPID });
    };
})
app.controller('VLDetailsController', function ($scope, $http, $location, $state, $stateParams) {
    var CPID = $stateParams.CPID;
    $scope.CP = {};
    $scope.searchCP = function () {
        $http({
            method: 'POST',
            url: 'api/CPDetails/',
            data: JSON.stringify({ CPID: CPID })
        }).success(function (result) {
            if (result.length > 0)
                $scope.CP = result[0];
        });
    };

    window.setTimeout(function () { $scope.searchCP(); }, 200);
})