var app = angular.module('starter');

app.controller('RoomsListCtrl', function ($scope, $http, $location, $state, $ionicFilterBar) {
    $scope = readyAngularGrid($scope, $http, 'api/RoomsList', 'RoomID', 'Rooms');
    $scope.totalPages = 1;
    $scope.pagingOptions.pageSize = 10;
    $scope.searchRooms = function () {
        $scope.pagingOptions.currentPage = 1;
        $scope.totalPages = 1;
        $scope.allData = [];
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };

    window.setTimeout(function () { $scope.searchRooms(); }, 200);

    $scope.viewRooms = function (RMID) {
        $state.go('app.RoomsView', { 'RoomID': RMID });
    };

    $scope.showFilterBar = function () {
        filterBarInstance = $ionicFilterBar.show({
            items: null,
            update: function (a, b) {
                if (b != null) {
                    $scope.filterOptions.filterText = b;
                    $scope.searchRooms();
                }
            },
            delay: 500
        });
        window.setTimeout(function () { $('.filter-bar-search').val($scope.filterOptions.filterText); }, 200);
    };
    $scope.doRefresh = function () {
        //simulate async response
        $scope.searchRooms();
    };

});

app.controller('RoomsViewCtrl', function ($scope, $http, $location, $state, $ionicFilterBar, $stateParams) {
    var RoomID = $stateParams.RoomID;
    $scope.Filter = { RoomID: RoomID };
    $scope = readyAngularGrid($scope, $http, 'api/Rooms/GetStatement', 'BillID', 'RoomStatement');
    $scope.totalPages = 1;
    $scope.pagingOptions.pageSize = 10;
    $scope.searchStatement = function () {
        $scope.pagingOptions.currentPage = 1;
        $scope.totalPages = 1;
        $scope.allData = [];
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };

    window.setTimeout(function () { $scope.searchStatement(); $scope.fetchOutstanding(); $scope.fetchRoomDetails(); }, 200);

    $scope.showFilterBar = function () {
        filterBarInstance = $ionicFilterBar.show({
            items: null,
            update: function (a, b) {
                if (b != null) {
                    $scope.filterOptions.filterText = b;
                    $scope.searchStatement();
                }
            },
            delay: 500
        });
        window.setTimeout(function () { $('.filter-bar-search').val($scope.filterOptions.filterText); }, 200);
    };
    $scope.doRefresh = function () {
        //simulate async response
        $scope.searchStatement();
        $scope.fetchOutstanding();
        $scope.fetchRoomDetails();
    };
    $scope.fetchOutstanding = function () {
        $http({
            method: 'POST',
            url: 'api/Rooms/TotalOutstanding',
            data: JSON.stringify({ RoomID: $scope.Filter.RoomID })
        }).success(function (data) {
            $scope.Outstanding = parseFloat(data);
        });
    };
    $scope.fetchRoomDetails = function () {
        $http({
            method: 'GET',
            url: 'api/Rooms/' + RoomID
        }).success(function (data) {
            $scope.Rooms = JSON.parse(data);
        });
    };
    $scope.printBill = function (billID, Type) {
        var url = '';
        if (Type == 'Reciept')
            url = 'PrintReciept.aspx?BillID=' + billID;
        else
            url = 'PrintBill.aspx?BillID=' + billID;
        var url = 'https://docs.google.com/gview?url=' + baseUrl + url + '&embedded=true';
        cordova.InAppBrowser.open(url, '_blank', 'location=no');
    };
});
