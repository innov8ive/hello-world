var app = angular.module('starter');

app.controller('VMListCtrl', function ($scope, $http, $location, $state, $ionicFilterBar) {
    $scope = readyAngularGrid($scope, $http, 'api/VMList', 'VMID', 'VM');
    $scope.totalPages = 1;
    $scope.pagingOptions.pageSize = 10;
    $scope.searchVM = function () {
        $scope.pagingOptions.currentPage = 1;
        $scope.totalPages = 1;
        $scope.allData = [];
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
    };

    window.setTimeout(function () { $scope.searchVM(); }, 200);
    $scope.showFilterBar = function () {
        filterBarInstance = $ionicFilterBar.show({
            items: null,
            update: function (a, b) {
                if (b != null) {
                    $scope.filterOptions.filterText = b;
                    $scope.searchVM();
                }
            },
            delay: 500
        });
        window.setTimeout(function () { $('.filter-bar-search').val($scope.filterOptions.filterText); }, 200);
    };
    $scope.doRefresh = function () {
        //simulate async response
        $scope.searchVM();
    };
    $scope.getDetails = function (VMID) {
        $state.go('app.VMDetails', { 'VMID': VMID });
    };
})

.controller('VMCtrl', function ($scope, $http, $location, $stateParams) {
    var ID = $stateParams.ID;
    $scope.VM = {};
    $scope.ErrorMessages = [];
    $scope.dateOptions = { changeYear: true, changeMonth: true, dateFormat: 'dd-MM-yy' };
    $scope.EditMode = false;
    $scope.VMSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.VMSubmitted = true;
        if ($scope.formVM.$invalid == true) return;
        if ($scope.EditMode == true) { alert('Please update current tab data'); return; }
        $http.post('api/VM', $scope.VM, config)
        .success(function (data, status, headers, config) {
            var result = data;
            if (result.ErrorCode == 1)
                $scope.ErrorMessages = result.data;
            else {
                $scope.ErrorMessages = [];
                $scope.VM = result.data;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };

    $scope.cancel = function () {
        $location.path('/VMList');
    }

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/VM/' + ID
        }).success(function (VM) {
            $scope.VM = VM;
        });
    }, 100);
});

app.controller('VMDetailsCtrl', function ($scope, $http, $location, $state, $stateParams) {
    var VMID = $stateParams.VMID;
    $scope.VM = {};
    $scope.searchCP = function () {
        $http({
            method: 'POST',
            url: 'api/VMDetails/',
            data: JSON.stringify({ VMID: VMID })
        }).success(function (result) {
            if (result.length > 0)
                $scope.VM = result[0];
        });
    };

    window.setTimeout(function () { $scope.searchCP(); }, 200);
})