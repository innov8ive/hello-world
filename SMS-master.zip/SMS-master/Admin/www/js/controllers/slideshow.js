/**
 * Slideshow controller
 */
(function() {
angular
	.module('starter')

	.controller('SlideshowController', [
		'$ionicHistory',
		'$window',
		'$state',
		'$scope',
		'$http',
        '$ionicSlideBoxDelegate',
		function ($ionicHistory, $window, $state, $scope, $http, $ionicSlideBoxDelegate) {
		    $scope.CarouselList = [];
		    $scope.baseUrl = baseUrl;
		    $scope.skipIntro = function () {
		        $window.localStorage.setItem('showIntro', false);
		        $ionicHistory.nextViewOptions({
		            disableBack: true
		        });
		        
		        $state.go('app.main');
		    };
		    $scope.getCarousel = function () {
		        $http({
		            method: 'POST',
		            url: 'api/Carousel/GetCarousel/'
		        }).success(function (result) {
		            $scope.CarouselList = result;
		            $ionicSlideBoxDelegate.update();
		       if (navigator.splashscreen != null) {
                        navigator.splashscreen.hide();
                    }
		           
		        });
		    };
		    window.setTimeout(function () { $scope.getCarousel(); }, 200);
		}
	]);

})();
