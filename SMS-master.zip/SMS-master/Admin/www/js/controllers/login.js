/**
 * Login controller
 */
(function () {
    angular
        .module('starter')

        .controller('LoginController', [
            '$ionicSideMenuDelegate',
            '$state',
            '$ionicHistory', '$scope', '$http', 'Globals',
            function ($ionicSideMenuDelegate, $state, $ionicHistory, $scope, $http, Globals) {

                $ionicSideMenuDelegate.canDragContent(false);
                $scope.U = { email: '', password: '' };

                $scope.U.email = '';
                $scope.U.password = '';
                $scope.login = function () {
                    loginUser($scope.U.email, $scope.U.password);
                };
                var loginUser = function (email, password) {


                    var url = 'api/Common/LoginAdmin/Login';
                    $http({
                        method: 'POST',
                        url: url,
                        data: JSON.stringify({ UserName: email, Password: password, DeviceID: uniqueID })
                    }).success(function (User) {

                        if (User == null) {
                            alert('Login Failed!');

                            localStorage.removeItem("user");
                            localStorage.removeItem("pass");
                            localStorage.removeItem("token");
                            localStorage.removeItem("reqType");
                        }
                        else {
                            $ionicHistory.nextViewOptions({
                                disableBack: true
                            });
                            loginDone = true;


                            localStorage["user"] = $scope.U.email;
                            localStorage["Name"] = User.FirstName + ' ' + User.LastName;
                            localStorage["ImageUrl"] = User.ImageUrl;
                            localStorage["pass"] = $scope.U.password;
                            localStorage["token"] = User.Token;
                            localStorage["reqType"] = User.UserType;
                            localStorage["UserID"] = User.UserID;
                            localStorage["SocName"] = User.SocName;
                            Globals.SocName = User.SocName;

                            initsignalr();
                            $ionicHistory.nextViewOptions({
                                disableBack: true
                            });

                            $state.go('app.main');

                        }
                    }).error(function () {
                        if (navigator.splashscreen != null) {
                            navigator.splashscreen.hide();
                        }
                        navigator.notification.confirm("Internet Connection not found! Do you want to Retry or Exit?", function (button) {
                            if (button == 2) {//If User selected No, then we just do nothing
                                navigator.app.exitApp();// Otherwise we quit the app.
                            } else {
                                $scope.login();
                            }
                        }, "Confirmation", "Retry,Exit");

                    });
                }

                $scope.loadData = function () {

                    if (localStorage["user"] != null && localStorage["pass"] != null) {
                        $scope.U.email = localStorage["user"];
                        $scope.U.password = localStorage["pass"];

                        loginUser($scope.U.email, $scope.U.password);
                        //$state.go('app.main');
                    }
                    else {
                        if (navigator.splashscreen != null) {
                            navigator.splashscreen.hide();
                        }
                    }
                };
                $scope.loadData();

            }
        ]);

})();
