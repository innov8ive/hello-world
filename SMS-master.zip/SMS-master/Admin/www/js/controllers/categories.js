/**
 * Categories controller
 */
(function () {
    angular
        .module('starter')

        .controller('CategoriesController',
        ['categoriesService', '$scope', '$state',
            function (categoriesSvc, $scope, $state) {

                $scope.categories = [];
                categoriesSvc.getCategories().then(setCategories);

                function setCategories(categories) {
                    $scope.categories = categories;
                }

                $scope.openCat = function (id) {
                    $state.go('app.CatView', { 'CatID': id });
                };

            }
        ]);

})();
var app = angular.module('starter');
app.controller('CatViewCtrl', function ($scope, $http, $location, $state, $stateParams) {
    var CatID = $stateParams.CatID;
    $scope.Cat = {};

    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/Services/' + CatID
        }).success(function (result) {
            $scope.Cat = JSON.parse(result);
            
        });
    }, 100);
});