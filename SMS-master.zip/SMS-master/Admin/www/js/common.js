﻿function showLoading() {
    $('.loading').show();
    $('.loading-mask').show();
};
function hideLoading() {
    $('.loading').hide();
    $('.loading-mask').hide();
};
function parseFloatEx(val) {
    if (val == null || val == undefined || val == NaN || val == '')
        return 0;
    return parseFloat(val);
};
function readyAngularGrid($scope, $http, searchUrl, keyField, GridName) {
    $scope.loading = false;
    $scope.allData = [];
    $scope.filter = { filterText: '' };
    $scope.filterOptions = { filterText: "" };
    $scope.totalServerItems = 0;
    $scope.pagingOptions = {
        pageSizes: [10, 20, 30],
        pageSize: 10,
        currentPage: 1
    };
    $scope.sortInfo = { fields: [keyField], directions: ['desc'] };

    var searchHistory = window.searched;
    if (searchHistory != null && searchHistory.GridName == GridName) {
        //$scope.filterOptions.filterText = searchHistory.Text;
    }

    $scope.getPagedDataAsync = function (pageSize, page, searchText) {
        if (page == null) return;
        setTimeout(function () {
            var sortBy = $scope.sortInfo.fields[0];
            var sortDir = $scope.sortInfo.directions[0];
            var page = $scope.pagingOptions.currentPage;
            var pageSize = $scope.pagingOptions.pageSize;
            $scope.loading = true;
            window.searched = { GridName: GridName, Text: searchText };
            $http({
                method: 'POST',
                url: searchUrl,
                data: JSON.stringify({ PageSize: pageSize, CurrentPage: page, SearchText: searchText, SortBy: sortBy, SortDir: sortDir, OtherFilter: $scope.Filter })
            }).success(function (largeLoad) {
                $scope.totalServerItems = largeLoad.TotalRecords;
                $scope.totalPages = largeLoad.TotalPages;
                $scope.setPagingData(JSON.parse(largeLoad.Data), page, pageSize);
                $scope.loading = false;
                hideLoading();
                $scope.$broadcast('scroll.refreshComplete');
            });
        }, 100);
    };

    $scope.setPagingData = function (data, page, pageSize) {
        $scope.myData = data;
        for (var j = 0; j < $scope.myData.length; j++) {
            $scope.allData.push($scope.myData[j]);
        }
        if (!$scope.$$phase) {
            $scope.$apply();
        }
    };

    $scope.$watch('pagingOptions', function (newVal, oldVal) {
        if (newVal !== oldVal || newVal.currentPage !== oldVal.currentPage) {
            $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
        }
    }, true);

    $scope.loadMore = function () {
        if ($scope.pagingOptions.currentPage < $scope.totalPages) {
            $scope.pagingOptions.currentPage = $scope.pagingOptions.currentPage + 1;
        }
    };
    return $scope;
};

function readyNgGrid($scope, GridData) {
    $scope.GridData = GridData;
    $scope.totalServerItems = 0;
    $scope.pagingOptions = {
        pageSizes: [10, 20, 30],
        pageSize: 10,
        currentPage: 1
    };

    $scope.setPagingData = function (pageSize, page) {
        var data = $scope.GridData;
        var pagedData = data.slice((page - 1) * pageSize, page * pageSize);
        $scope.myData = pagedData;
        $scope.totalServerItems = data.length;
        if (!$scope.$$phase) {
            $scope.$apply();
        }
    };

    $scope.$watch('pagingOptions', function (newVal, oldVal) {
        if (newVal !== oldVal || newVal.currentPage !== oldVal.currentPage) {
            $scope.setPagingData($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage);
        }
    }, true);

    $scope.gridOptions = {
        data: 'myData',
        enablePaging: true,
        enableSorting: false,
        showFooter: true,
        multiSelect: false,
        totalServerItems: 'totalServerItems',
        pagingOptions: $scope.pagingOptions
    };
    $scope.setPagingData(10, 1);
    return $scope;
};

function sizeChanged() {
    setTimeout(function () {
        $('.gridStyle').trigger('resize');
    }, 500);
};
function findByValue(arr, prop, findValue, topRows) {
    var result = [];
    for (j = 0; j < arr.length; j++) {
        if (arr[j][prop] == findValue) {
            result.push(arr[j]);
        }
        if (topRows != null && topRows > 0 && result.length >= topRows)
            break;
    }
    return result;
};
function deleteByValue(arr, prop, findValue) {
    for (j = 0; j < arr.length; j++) {
        if (arr[j][prop] == findValue) {
            arr.splice(j, 1);
            break;
        }
    }
    return arr;
};

var objJCrop = null;
var imageName = '';
var callBackFunction = null;
var desiredDim = {};
function AttachImage(func, dd) {
    document.getElementById('FileUpload1').click();
    callBackFunction = func;
    desiredDim = dd;
    return false;
};
function uploadImage() {
    var x1 = $('#imgX1').val();
    var y1 = $('#imgY1').val();
    var width = $('#imgWidth').val();
    var height = $('#imgHeight').val();
    var canvas = $("#canvas")[0];
    var context = canvas.getContext('2d');

    //if ((desiredDim != null && desiredDim.width != width) || (desiredDim != null && desiredDim.height != height)) {
    //    alert('Please crop/choose ' + desiredDim.width + 'X' + desiredDim.height + ' image.');
    //    return;
    //}

    var img = new Image();
    img.onload = function () {
        canvas.height = height;
        canvas.width = width;
        context.drawImage(img, x1, y1, width, height, 0, 0, width, height);
        $('#imgCropped').val(canvas.toDataURL());

        var arr = canvas.toDataURL().split(",");
        var imageData = arr[1]; // raw base64
        var contentType = arr[0].split(";")[0].split(":")[1];
        $('#modalImageUploader').modal('hide');
        //beginReq('Uploading File...');
        $.post(baseUrl + 'FileUploadHandler.ashx', { type: 'ImageFile', data: imageData, contentType: contentType }, function (result, a, b, c) {
            fuResult = result.split('|');
            if (fuResult.length == 3) {
                var fileGUIDName = fuResult[0];
                var fileName = fuResult[1];
                var fileID = fuResult[2];
                if (callBackFunction != null)
                    callBackFunction(fileGUIDName, fileName, fileID);
                //endReq();
            }
            else {
                alert(result);
            }
        });
    }
    img.src = $('#Image1').attr("src");
};

function fileSelected(Obj) {

    var fileUpload = $(Obj).get(0);
    var files = fileUpload.files;
    if (!hasExtension(files[0].name, ['.png', '.jpg', '.jpeg', '.gif', '.bmp', '.ttf'])) {
        alert('Please select only image files.');
        return;
    }
    var img = files[0].size;
    var imgsize = img / 1024;
    if (imgsize > 1024) {
        alert('Please only image having less than 1 MB in size.');
        return;
    }

    $('#modalImageUploader').modal({ show: true, backdrop: false });
    var opt = {
        onChange: SetCoordinates,
        onSelect: SetCoordinates
    };
    if (desiredDim != null && desiredDim.width != null) {
        $('#modalImageUploader .modal-title').html('Crop Image  (' + desiredDim.width + 'X' + desiredDim.height + ')');
        opt.setSelect = [0, 0, desiredDim.width, desiredDim.height];
        opt.allowResize = false;
        opt.allowSelect = false;
    }

    imageName = files[0].name;
    if (objJCrop != null) {
        $('#Image1').replaceWith('<img id="Image1" src=""/>');
        objJCrop.destroy();
    }

    $('#Image1').hide();
    var reader = new FileReader();
    reader.onload = function (e) {
        var desiredwidth = 0;
        if (desiredDim != null && desiredDim.width != null)
            desiredwidth = desiredDim.width;
        var arr = e.target.result.split(",");
        var imageData = arr[1]; // raw base64
        var contentType = arr[0].split(";")[0].split(":")[1];
        showLoading();
        $.post(baseUrl + 'FileUploadHandler.ashx', { type: 'RawImageFile', data: imageData, contentType: contentType, width: desiredwidth }, function (result, a, b, c) {
            hideLoading();
            $('#Image1').show();
            $('#Image1').attr("src", result);
            $('#Image1').Jcrop(opt, function () {
                objJCrop = this;
            });
            //desiredDim = null;
            var image = new Image();
            image.src = result;

            //Validate the File Height and Width.
            image.onload = function () {
                $('#imgWidth').val(this.width);
                $('#imgHeight').val(this.height);
            };
        });
    }
    reader.readAsDataURL(files[0]);
};
function SetCoordinates(c) {
    $('#imgX1').val(c.x);
    $('#imgY1').val(c.y);
    $('#imgWidth').val(c.w);
    $('#imgHeight').val(c.h);
};
function hasExtension(fileName, exts) {
    return (new RegExp('(' + exts.join('|').replace(/\./g, '\\.') + ')$')).test(fileName);
};
function toMarkup(text) {
    if (text == null) return '';
    text = text.replace(/\*\*\*(.*?)\*\*\*/g, "<h1>$1</h1>");
    text = text.replace(/\*\*(.*?)\*\*/g, "<h3>$1</h3>");
    text = text.replace(/\*(.*?)\*/g, "<b>$1</b>");
    text = text.replace(/_(.*?)_/g, "<u>$1</u>");
    text = text.replace(/~(.*?)~/g, "<i>$1</i>");
    text = text.replace(/--(.*?)--/g, "<del>$1</del>");
    text = text.replace(/<<(.*?)\|(.*?)>>/g, "<a href='$1'>$2</a>");
    text = text.replace(/\n(.*?)/g, "<br/>$1");
    return text;
};
//Dropzone.autoDiscover = false;
//var callBackFileUpload = null;
//$(function () {
//    var myDropzone = new Dropzone('#divDropFiles', {
//        maxFilesize: 2, uploadMultiple: false
//        , acceptedFiles: '.doc,.docx,.pdf,.xls,.xlsx,.png,.jpg,.jpeg,.gif,.bmp,.ttf,.ppt,.pptx,.txt,.eml,.emlx,.msg,.vdsx,.vsd'
//        , url: 'FileUploadHandler.ashx'
//    });
//    myDropzone.on("success", function (file, result) {
//        if (callBackFileUpload != null)
//            callBackFileUpload(result);
//        myDropzone.removeAllFiles(true); $('#fileUploadedMessage').html('File uploaded successfully!');
//        //endReq();
//    });
//    myDropzone.on("sending", function (file, xhr, formData) {
//        debugger;
//        //beginReq('Uploading File...'); $('#fileUploadedMessage').html('File Uploading...');
//    });
//    myDropzone.on("error", function (file, error) {
//        alert(error);
//        //endReq();
//        myDropzone.removeAllFiles(true); $('#fileUploadedMessage').html('');
//    });
//});

function openFileUploader(callBack, url) {
    debugger;
    Dropzone.forElement("#divDropFiles").options.url = url;
    callBackFileUpload = callBack;
    $("#modalDropFile").modal({ show: true, backdrop: false });
};
function openImageUploader(callBack, url) {
    Dropzone.forElement("#divDropFiles").options.url = url;
    Dropzone.forElement("#divDropFiles").options.acceptedFiles = '.png,.jpg,.jpeg,.gif,.bmp';
    callBackFileUpload = callBack;
    $("html, body", window.parent.document).animate({ scrollTop: 0 }, 500); $("#modalDropFile").modal({ show: true, backdrop: false });
};
