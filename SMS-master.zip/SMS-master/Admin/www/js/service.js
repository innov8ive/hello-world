﻿angular.module('starter.services', [])
.factory('Globals', function () {
    var getParameterByName = function (name) {
        name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
        var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
        return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
    };

    return {
        curLanguage: 'br',
        token: getParameterByName('token'),
        UserName: localStorage["user"],
        ImageUrl: localStorage["ImageUrl"],
        UserType: localStorage["reqType"],
        UserID: localStorage["UserID"],
        Name: localStorage["Name"],
        logout: function () {
        }
    };
})
.factory('Help', function ($http) {

    return {
        userName: '',
        logout: function () {
        }
    };
});
