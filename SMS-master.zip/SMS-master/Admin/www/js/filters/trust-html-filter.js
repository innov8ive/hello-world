/**
 * trustHtml filter
 */	
(function() {
angular
	.module('starter')

	.filter('trustHtml', [
		'$sce',
		function ($sce) {
			'use strict';

			return function (input) {
				return $sce.trustAsHtml(input);
			};
		}
	]);
})();