angular.module('starter.controllers', ['starter.services', 'pascalprecht.translate'])

.controller('AppCtrl', function ($scope, $ionicModal, $timeout, Globals, $translate) {

    window.setTimeout(function () {
        $scope.g = Globals;
    }, 2000);
    $scope.$watch('Globals.SocName', function (newVal, oldVal) {
        $scope.g = Globals;
    });
})
.controller('FPController', function ($scope, $http, $state) {
    $scope.FP = { UserName: '' };
    $scope.submitFP = function () {
        if ($scope.FP.UserName == '') {
            swal({ title: "Please enter Username!", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        $http({
            method: 'POST',
            url: 'api/Common/ForgotPassword',
            data: JSON.stringify({ UserName: $scope.FP.UserName })
        }).success(function (result) {
            if (result == "Success") {
                swal({
                    title: "New Password has been sent to your Registered Email/Mobile!", type: "success",
                    showConfirmButton: true
                });
                $state.go('app.login');
            }
            else {
                swal({ title: result, type: "error", timer: 1000, showConfirmButton: false });
            }
            $scope.FPShow = false;
        });
    };
})
.controller('CPController', function ($scope, $http, $state) {
    $scope.CP = { OldPassword: '', NewPassword: '', ConfirmPassword: '', UserID: 0 };
    $scope.changePassword = function () {
        $scope.CPSubmitted = true;
        if ($scope.formCP.$invalid == true) return;
        if ($scope.CP.NewPassword != $scope.CP.ConfirmPassword) {
            swal({ title: "New Password and Confirmn Password must be same!", type: "error", timer: 1000, showConfirmButton: false });
            return;
        }
        $scope.CP.UserID = parseInt(localStorage["UserID"]);
        $http({
            method: 'POST',
            url: 'api/Common/ChangePassword',
            data: JSON.stringify($scope.CP)
        }).success(function (result) {
            if (result == "Invalid") {
                swal({ title: "Invalid Old Password, Password not changed!", type: "error", timer: 1000, showConfirmButton: false });
            }
            else if (result == "Changed") {
                swal({ title: "Password changed successfully!", type: "success", showConfirmButton: true });
                $state.go('app.profile');
            }
        });
    };
})
.controller('MainCtrl', function ($scope, Help, $http, $state, $ionicHistory, Globals) {
    $scope.loadData = function () {
        if (sessionStorage["dashboard"] != null) {
            var result = JSON.parse(sessionStorage["dashboard"]);
            $scope.setData(result);           
        }
        else {
            $http({
                method: 'POST',
                url: 'api/AdminHome/AllDashBoard'
            }).success(function (result) {              
                sessionStorage["dashboard"] = JSON.stringify(result);
                $scope.setData(result);
               
            }).error(function () {
                sessionStorage.removeItem("dashboard");
                if (navigator.splashscreen != null) {
                    navigator.splashscreen.hide();
                }
                $scope.$broadcast('scroll.refreshComplete');
            });
        }
    };
    $scope.setData = function (result) {
        $scope.TotalFlats = result.TotalFlats;
        $scope.Vehicles = result.Vehicles;
        $scope.SMSCredit = result.SMSCredit;
        $scope.Polls = result.Polls;
        $scope.Meetings = result.Meetings;
        $scope.TotalUsers = result.TotalUsers;
        $scope.TotalCollection = result.TotalCollection;
        $scope.TotalBills = result.TotalBills;
        $scope.RecentForum = JSON.parse(result.RecentForum);
        if (navigator.splashscreen != null) {
            navigator.splashscreen.hide();
        }
        $scope.$broadcast('scroll.refreshComplete');
        if ($scope.TotalFlats == 0) {
            window.plugins.toast.show('There is no any Unit defined, please visit app.societyinn.com for full Unit and Bill Setup.', 5000, 'bottom');
        }
    };
    $scope.doRefresh = function () {
        //simulate async response
        sessionStorage.removeItem("dashboard");
        $scope.loadData();
    };
    window.setTimeout(function () { $scope.loadData() }, 200);

    $scope.newSMS = function () {
        $state.go('app.sendSMS');
    };
    $scope.newEmail = function () {
        $state.go('app.sendEmail');
    };
})
.controller('ddCtrl', function ($scope, $http, $state, $cordovaCamera) {
    $scope.UserID = localStorage["UserID"];
    $scope.UserName = localStorage["Name"];
    $scope.ImageUrl = baseUrl + '/Download.aspx?type=profile&filepath=images/profile/' + localStorage["ImageUrl"];

    $scope.hasImage = localStorage["ImageUrl"] != null && localStorage["ImageUrl"] != '';

    $scope.removePhoto = function () {
        if (confirm('Are you sure, want to remove photo?')) {
            $http({
                method: 'POST',
                url: 'api/Users/RemovePhoto/',
                data: JSON.stringify($scope.UserID + '.' + localStorage["ImageUrl"])
            }).success(function (result) {
                if (result == 'true') {
                    localStorage["ImageUrl"] = '';
                    $scope.ImageUrl = baseUrl + '/Download.aspx?type=profile&fileID=' + localStorage["ImageUrl"];
                    $scope.hasImage = false;
                }
            });
        }
    };
    $scope.takePhoto = function () {
        try {
            var options = {
                quality: 75,
                destinationType: Camera.DestinationType.DATA_URL,
                sourceType: Camera.PictureSourceType.CAMERA,
                allowEdit: true,
                encodingType: Camera.EncodingType.JPEG,
                targetWidth: 300,
                targetHeight: 300,
                popoverOptions: CameraPopoverOptions,
                saveToPhotoAlbum: false
            };

            $cordovaCamera.getPicture(options).then(function (imageData) {
                showLoading();
                $.post(baseUrl + 'FileUploadHandler.ashx',
                    {
                        type: 'ImageFile', data: imageData
                    , contentType: 'image/jpeg', DataID: $scope.UserID, DataType: 'User'
                    }, function (result, a, b, c) {
                        hideLoading();
                        fuResult = result.split('|');
                        if (fuResult.length == 3) {
                            var fileGUIDName = fuResult[0];
                            localStorage["ImageUrl"] = fileGUIDName;
                            $scope.ImageUrl = baseUrl + '/Download.aspx?type=profile&filepath=images/profile/' + localStorage["ImageUrl"];
                            $scope.hasImage = true;
                        }
                        else {
                            alert(result);
                            hideLoading();
                        }
                    });
            }, function (err) {
                alert(err);
            });
        } catch (e) { alert(e); }
    };

    $scope.choosePhoto = function () {
        try {
            var options = {
                quality: 75,
                destinationType: Camera.DestinationType.DATA_URL,
                sourceType: Camera.PictureSourceType.PHOTOLIBRARY,
                allowEdit: true,
                encodingType: Camera.EncodingType.JPEG,
                targetWidth: 300,
                targetHeight: 300,
                popoverOptions: CameraPopoverOptions,
                saveToPhotoAlbum: false
            };

            $cordovaCamera.getPicture(options).then(function (imageData) {
                showLoading();
                $.post(baseUrl + 'FileUploadHandler.ashx', {
                    type: 'ImageFile', data: imageData
                    , contentType: 'image/jpeg', DataID: $scope.UserID, DataType: 'User'
                }, function (result, a, b, c) {
                    hideLoading();
                    fuResult = result.split('|');
                    if (fuResult.length == 3) {
                        var fileGUIDName = fuResult[0];
                        localStorage["ImageUrl"] = fileGUIDName;
                        $scope.ImageUrl = baseUrl + '/Download.aspx?type=profile&filepath=images/profile/' + localStorage["ImageUrl"];
                        $scope.hasImage = true;
                    }
                    else {
                        alert(result);
                    }
                });
            }, function (err) {
                hideLoading();
                alert(err);
            });
        } catch (e) { alert(e); }
    };
    $scope.CP = function () {
        $state.go('app.CP');
    };

    $scope.Users = {};
    $scope.ErrorMessages = [];
    $scope.UsersSubmitted = false;
    var config = {
        headers: {
            'Content-Type': 'application/json'
        }
    };
    $scope.update = function () {
        $scope.UsersSubmitted = true;
        if ($scope.formUsers.$invalid == true) return;
        $http.post('api/Users/UpdateProfile', $scope.Users, config)
        .success(function (data, status, headers, config) {
            var result = JSON.parse(data);
            if ($.isArray(result))
                $scope.ErrorMessages = result;
            else {
                $scope.ErrorMessages = [];
                $scope.Users = result;
                swal({ title: "Data saved successfully!", type: "success", timer: 1000, showConfirmButton: false });
                User.FirstName = $scope.Users.FirstName;
                User.LastName = $scope.Users.LastName;
            }
        })
        .error(function (data, status, header, config) {
            alert('error');
        });
    };
    setTimeout(function () {
        $http({
            method: 'GET',
            url: 'api/UsersProfile'
        }).success(function (Users) {
            $scope.Users = JSON.parse(Users);
        });
    }, 100);
})
.controller('LogoutCtrl', function ($scope, $ionicHistory, Globals, $http) {
    $scope.logout = function (option) {
        if (option == 1) {
            $http({
                method: 'POST',
                url: 'api/Common/Logout/'
            }).success(function (result) {
                localStorage.removeItem("user");
                localStorage.removeItem("pass");
                localStorage.removeItem("token");
                window.location = 'index.html';
            });
           
        }
        else
            history.go(-1);
    };
});