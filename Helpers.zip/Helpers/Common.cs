﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;


namespace WebAppProxy
{
    public class Common
    {
        public static DataTable GetDBResult(string query, string keyName = "Main")
        {
            SqlConnection con = new SqlConnection(GetConString(keyName));
            SqlCommand cmd = new SqlCommand(query, con);
            DataTable dt = new DataTable();
            con.Open();
            using (con)
            {
                dt.Load(cmd.ExecuteReader());
            }
            return dt;
        }

        public static string GetConString(string keyName = "Main")
        {
            return Environment.GetEnvironmentVariable("DefaultConnection");
        }
        public static DataTable GetDBResultParameterized(string query, params object[] argument)
        {
            SqlConnection con = new SqlConnection(GetConString());
            SqlCommand cmd = new SqlCommand(query, con);

            for (var i = 0; i < argument.Length; i = i + 3)
            {
                cmd.Parameters.Add(ToString(argument[i]), (SqlDbType)argument[i + 1]).Value = argument[i + 2];
            }
            DataTable dt = new DataTable();
            con.Open();
            using (con)
            {
                dt.Load(cmd.ExecuteReader());
            }
            return dt;
        }
        public static DataTable GetDBResultParameterized2(string query, string conString, params object[] argument)
        {
            SqlConnection con = new SqlConnection(conString);
            SqlCommand cmd = new SqlCommand(query, con);

            for (var i = 0; i < argument.Length; i = i + 3)
            {
                cmd.Parameters.Add(ToString(argument[i]), (SqlDbType)argument[i + 1]).Value = argument[i + 2];
            }
            DataTable dt = new DataTable();
            con.Open();
            using (con)
            {
                dt.Load(cmd.ExecuteReader());
            }
            return dt;
        }
        public static int ExecuteNonQuery(string query, params object[] argument)
        {
            SqlConnection con = new SqlConnection(GetConString());
            SqlCommand cmd = new SqlCommand(query, con);
            if (argument != null)
                for (var i = 0; i < argument.Length; i = i + 3)
                {
                    cmd.Parameters.Add(ToString(argument[i]), (SqlDbType)argument[i + 1]).Value = argument[i + 2];
                }
            con.Open();
            using (con)
            {
                return cmd.ExecuteNonQuery();
            }
        }
        public static object GetDBScalar(string query, params object[] argument)
        {
            SqlConnection con = new SqlConnection(GetConString());
            SqlCommand cmd = new SqlCommand(query, con);
            if (argument != null)
                for (var i = 0; i < argument.Length; i = i + 3)
                {
                    cmd.Parameters.Add(ToString(argument[i]), (SqlDbType)argument[i + 1]).Value = argument[i + 2];
                }
            con.Open();
            using (con)
            {
                return cmd.ExecuteScalar();
            }
        }
        public static string MakeLink(string txt)
        {
            Regex regx = new Regex("(http|https)://([\\w+?\\.\\w+])+([a-zA-Z0-9\\~\\!\\@\\#\\$\\%\\^\\&\\*\\(\\)_\\-\\=\\+\\\\\\/\\?\\.\\:\\;\\'\\,]*)?", RegexOptions.IgnoreCase);
            MatchCollection mactches = regx.Matches(txt);
            foreach (Match match in mactches)
            {
                txt = txt.Replace(match.Value, "<a target='_blank' href='" + match.Value + "'>" + match.Value + "</a>");
            }
            return txt;
        }
        private static string ConvertToString(object data)
        {
            string result = "NULL";
            if (data != null && Convert.IsDBNull(data) == false)
            {
                if (data.GetType() == typeof(DateTime))
                {
                    result = Convert.ToDateTime(data).ToString("yyyy-MM-dd");
                }
                else if (data.GetType() == typeof(Int32) && Convert.ToInt32(data) > 0)
                {
                    result = data.ToString();
                }
                else if (data.GetType() == typeof(string) && data != "")
                {
                    result = "N'" + data.ToString().Replace("'", "''") + "'";
                }
                else if (data.GetType() == typeof(bool))
                {
                    result = (bool)data == true ? "1" : "0";
                }
                else
                {
                    result = Convert.ToString(data);
                }
            }
            return result;
        }
        public static string SafeSubstring(string input, int startIndex, int length)
        {
            // Todo: Check that startIndex + length does not cause an arithmetic overflow
            if (input.Length >= (startIndex + length))
            {
                return input.Substring(startIndex, length);
            }
            else
            {
                if (input.Length > startIndex)
                {
                    return input.Substring(startIndex);
                }
                else
                {
                    return string.Empty;
                }
            }
        }
        #region Value Conversions with null value check
        /// <summary>
        /// Convert any value to its boolean equivalent
        /// </summary>
        /// <param name="theValue"></param>
        /// <returns>A boolean value</returns>
        public static bool ToBool(object theValue)
        {
            try
            {
                if (Convert.IsDBNull(theValue)) return false;
                if (theValue is string)
                {
                    switch (theValue.ToString().ToLower())
                    {
                        case "yes":
                        case "on":
                            return true;
                    }
                    if (IsNumeric(theValue))
                        return Convert.ToBoolean((Convert.ToDouble(theValue)));
                }
                return Convert.ToBoolean(theValue);
            }
            catch
            {
                return false;
            }
        }
        public static bool IsNumeric(object theValue)
        {
            try
            {
                double theNum;
                if (Convert.IsDBNull(theValue))
                    return false;
                return double.TryParse(theValue.ToString(), out theNum);
            }
            catch
            {
                return false;
            }
        }
        public static string ToString(object theValue)
        {
            if (Convert.IsDBNull(theValue))
                return "";
            else
                return Convert.ToString(theValue);
        }
        public static string ConvToDateToString(object theValue, string Format)
        {
            if (Convert.IsDBNull(theValue) || theValue == null)
                return "";
            else
                return ToDate(theValue).ToString(Format);
        }
        public static double ToDouble(object theValue)
        {
            double theResult = 0;
            if (theValue == null || Convert.IsDBNull(theValue) || !double.TryParse(theValue.ToString(), out theResult))
                theResult = 0;
            return theResult;
        }
        public static double? ToDouble(object theValue, double? defaultValue)
        {
            double theResult = 0;
            if (theValue == null || Convert.IsDBNull(theValue) || !double.TryParse(theValue.ToString(), out theResult))
                return defaultValue;
            return theResult;
        }
        public static int ToInt(object theValue)
        {
            int theResult = 0;
            if (theValue == null || Convert.IsDBNull(theValue) || !int.TryParse(theValue.ToString(), out theResult))
                theResult = 0;
            return theResult;
        }
        public static Int16 ToInt16(object theValue)
        {
            Int16 theResult = 0;
            if (theValue == null || Convert.IsDBNull(theValue) || !Int16.TryParse(theValue.ToString(), out theResult))
                theResult = 0;
            return theResult;
        }
        public static int? ToInt(object theValue, int? defaultValue)
        {
            int theResult = 0;
            if (theValue == null || Convert.IsDBNull(theValue) || !int.TryParse(theValue.ToString(), out theResult))
                return defaultValue;
            return theResult;
        }
        public static float ToFloat(object theValue)
        {
            float theResult = 0;
            if (theValue == null || Convert.IsDBNull(theValue) || !float.TryParse(theValue.ToString(), out theResult))
                theResult = 0;
            return theResult;
        }
        public static float? ToFloat(object theValue, float? defaultValue)
        {
            float theResult = 0;
            if (theValue == null || Convert.IsDBNull(theValue) || !float.TryParse(theValue.ToString(), out theResult))
                return defaultValue;
            return theResult;
        }
        public static decimal ToDecimal(object theValue)
        {
            decimal theResult = 0;
            if (theValue == null || Convert.IsDBNull(theValue) || !decimal.TryParse(theValue.ToString(), out theResult))
                theResult = 0;
            return theResult;
        }
        public static decimal? ToDecimal(object theValue, decimal? defaultValue)
        {
            decimal theResult = 0;
            if (theValue == null || Convert.IsDBNull(theValue) || !decimal.TryParse(theValue.ToString(), out theResult))
                return defaultValue;
            return theResult;
        }
        public static DateTime ToDate(object theValue)
        {
            DateTime theResult;
            if (theValue == null || Convert.IsDBNull(theValue) || !DateTime.TryParse(theValue.ToString(), out theResult))
                theResult = DateTime.UtcNow;
            return theResult;
        }
        public static DateTime? ToDate(object theValue, DateTime? defaultval)
        {
            DateTime theResult;
            if (theValue == null || Convert.IsDBNull(theValue) || !DateTime.TryParse(theValue.ToString(), out theResult))
                return defaultval;
            return theResult;
        }
        #endregion

        public static List<string[]> ConvertDataTableToArray(DataTable dt)
        {
            var result = new List<string[]>();

            foreach (DataRow dr in dt.Rows)
            {
                var values = new string[dt.Columns.Count];

                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    object value = dr[i];

                    if (value == DBNull.Value || value == null)
                    {
                        values[i] = ""; // or "NULL"
                    }
                    else if (value is DateTime dtVal)
                    {
                        values[i] = dtVal.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
                    }
                    else
                    {
                        values[i] = value.ToString();
                    }
                }

                result.Add(values);
            }

            return result;
        }
        public static List<DataTableColumn> ConvertDataTableColumnsToArray(DataTable dt)
        {
            var sb = new List<DataTableColumn>();
            foreach (DataColumn col in dt.Columns)
            {
                sb.Add(new DataTableColumn() { title = ToReadableString(col.ColumnName) });
            }
            return sb;
        }
        public static List<string[]> ConvertDataTableToEncryptedArray(DataTable dt)
        {
            var result = new List<string[]>();

            foreach (DataRow dr in dt.Rows)
            {
                var values = new string[dt.Columns.Count];

                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    object value = dr[i];

                    if (value == DBNull.Value || value == null)
                    {
                        values[i] = ""; // or "NULL"
                    }
                    else if (value is DateTime dtVal)
                    {
                        values[i] = dtVal.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
                    }
                    else if (value is string s && s.Length > 0)
                    {
                        values[i] = "enc`" + SimpleEncrypter.EncryptDecrypt(s);
                    }
                    else
                    {
                        values[i] = value.ToString();
                    }
                }

                result.Add(values);
            }

            return result;
        }
        public static bool IsNullOrEmpty(JToken token)
        {
            if (token == null || token.Type == JTokenType.Null || string.IsNullOrEmpty(token.ToString()))
            {
                return true;
            }
            return false;
        }
        public static string ToReadableString(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
                return input;

            // Insert space before each capital letter (but not at the start)
            return Regex.Replace(input, "(?<!^)([A-Z])", " $1");
        }
        public static void ProcessJObject(JToken token)
        {
            if (token.Type == JTokenType.Object)
            {
                foreach (var prop in token.Children<JProperty>())
                {
                    ProcessJObject(prop.Value);
                }
            }
            else if (token.Type == JTokenType.Array)
            {
                foreach (var item in token.Children())
                {
                    ProcessJObject(item);
                }
            }
            else if (token.Type == JTokenType.String)
            {
                string str = token.Value<string>();
                if (str.StartsWith("enc`"))
                {
                    // Example manipulation: remove "enc-" prefix
                    ((JValue)token).Value = SimpleEncrypter.EncryptDecrypt(str.Substring(4));
                }
            }
        }
        public static void UpdateUserUsage(int userId, Int16 usedToken)
        {
            /*
             
Create table UserOpenAPITokenUsage
(
	Id int primary key identity(1,1),
	UserId int,
	UsageDate date,
	UsedToken smallint
)
GO

CREATE PROCEDURE UpdateUserOpenAPITokenUsage
    @UserId INT,
    @UsageDate DATE,
    @UsedToken INT
AS
BEGIN
    SET NOCOUNT ON;

    -- Check if a row exists for the user and date
    IF EXISTS (
        SELECT 1
        FROM UserOpenAPITokenUsage
        WHERE UserId = @UserId
          AND UsageDate = @UsageDate
    )
    BEGIN
        -- Update the existing row by adding the new UsedToken
        UPDATE UserOpenAPITokenUsage
        SET UsedToken = UsedToken + @UsedToken
        WHERE UserId = @UserId
          AND UsageDate = @UsageDate;
    END
    ELSE
    BEGIN
        -- Insert a new row
        INSERT INTO UserOpenAPITokenUsage(UserId, UsageDate, UsedToken)
        VALUES (@UserId, @UsageDate, @UsedToken);
    END
END
            */
            ExecuteNonQuery("EXEC UpdateUserOpenAPITokenUsage @UserId, @UsageDate, @UsedToken",
                "@UserId", SqlDbType.Int, userId,
                "@UsageDate", SqlDbType.DateTime, DateTime.Today,
                "@UsedToken", SqlDbType.SmallInt, usedToken);

        }
    }
  
}
