﻿using Microsoft.Extensions.Primitives;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace WebAppProxy
{
    class AzueOpenAIHelper
    {
        public Int16 TotalTokenUsed { get; set; }
        public int LocationId { get; set; }
        public Object Call(string query)
        {
            var toolId = Call(query, "IdentifyTool", String.Empty);
            if (toolId != null && toolId is JObject || toolId is JArray)
            {
                JObject toolIdentification;
                if (toolId is JArray)
                {
                    JArray jArray = (JArray)toolId;
                    toolIdentification = jArray[0] as JObject;
                }
                else
                {
                    toolIdentification = toolId as JObject;
                }
                if (toolIdentification != null && toolIdentification?["toolName"] != null)
                {
                    string toolName = toolIdentification["toolName"].Value<string>();
                    var toolAPIResult = Call(query, toolName, "Rules: Generate SQL queries: one SELECT only, careful with GROUP BY/ORDER BY, default TOP 50, always add WHERE, no '*', list columns. Do not include Id column in SELECT");
                    JObject toolResult = null;
                    if (toolAPIResult is JObject)
                    {
                        toolResult = (JObject)toolAPIResult;
                    }
                    else
                    {
                        return toolAPIResult;
                    }
                    if (toolResult != null)
                    {
                        DataTable dataTable = new DataTable();
                        DataTableResponse dataTableResponse = new DataTableResponse();
                        StringBuilder sqlQuery = CreateSelectQuery(toolName, toolResult);
                        try
                        {
                            dataTable = Common.GetDBResult(sqlQuery.ToString(), "ReadOnlyMain");
                            dataTableResponse.DataItems = Common.ConvertDataTableToArray(dataTable);
                            dataTableResponse.Columns = Common.ConvertDataTableColumnsToArray(dataTable);
                        }
                        catch (Exception Ex)
                        {
                            return "I’m sorry, but I wasn’t able to process your request. Could you please rephrase, simplify, or provide more details so I can better assist you?"
                                + "` SQL Query: " + sqlQuery
                                + "` Error: " + Ex.Message + " " + Ex.StackTrace;
                        }

                        string outputType = toolIdentification["outputType"]?.Value<string>();
                        string reportTitle = toolIdentification["reportTitle"]?.Value<string>();
                        if (outputType == "Visual")
                        {
                            List<string[]> strings = Common.ConvertDataTableToEncryptedArray(dataTable);
                            query = "Give me config option for '" + reportTitle + "' data " + JsonConvert.SerializeObject(strings);
                            var visualAPIResult = Call(query, "GenerateChartIntent", String.Empty);
                            JObject visualResult = null;
                            if (visualAPIResult is JObject)
                            {
                                visualResult = (JObject)visualAPIResult;
                                Common.ProcessJObject(visualResult);
                                return visualResult;
                            }
                            else
                            {
                                return toolAPIResult;
                            }
                        }
                        else
                        {
                            dataTableResponse.Title = reportTitle;
                            return dataTableResponse;
                        }
                    }
                    if (toolResult != null)
                    {
                        return toolResult;
                    }
                }
                if (toolId != null)
                {
                    return toolId;
                }
            }

            return toolId;
        }

        private StringBuilder CreateSelectQuery(string toolName, JObject toolResult)
        {
            StringBuilder sqlQuery = new StringBuilder();
            if (!Common.IsNullOrEmpty(toolResult?["selectColumns"]) || !Common.IsNullOrEmpty(toolResult?["filterQuery"]))
            {
                sqlQuery.Append("Select ");
                if (!Common.IsNullOrEmpty(toolResult?["topClause"]))
                {
                    string topClause = toolResult["topClause"].Value<string>().ToLower();
                    sqlQuery.Append(topClause.Contains("top") ? "" : " TOP ").Append(topClause).Append(" ");
                }
                if (!Common.IsNullOrEmpty(toolResult?["selectColumns"]))
                {
                    sqlQuery.Append(toolResult["selectColumns"].Value<string>());
                }
                else
                {
                    sqlQuery.Append("*");
                }
                sqlQuery.Append(" FROM ").Append(toolName);
                if (!Common.IsNullOrEmpty(toolResult?["filterQuery"]))
                {
                    sqlQuery.Append(" WHERE ").Append(toolResult["filterQuery"].Value<string>());
                }
                if (sqlQuery.ToString().IndexOf("WHERE", StringComparison.OrdinalIgnoreCase) != -1)
                {
                    sqlQuery.Replace("WHERE", "WHERE LocationId=" + LocationId);
                }
                else
                {
                    sqlQuery.Append(" WHERE LocationId=" + LocationId);
                }
                if (!Common.IsNullOrEmpty(toolResult?["groupByClause"]))
                {
                    string groupByClause = toolResult["groupByClause"].Value<string>().ToLower();
                    sqlQuery.Append(groupByClause.Contains("group") ? "" : " GROUP BY ").Append(groupByClause);
                }
                if (!Common.IsNullOrEmpty(toolResult?["orderByQuery"]))
                {
                    string orderByClause = toolResult["orderByQuery"].Value<string>().ToLower();
                    sqlQuery.Append(orderByClause.Contains("order") ? "" : " ORDER BY ").Append(orderByClause);
                }
            }
            if (!Common.IsNullOrEmpty(toolResult?["sqlQuery"]))
            {
                string sql = toolResult["sqlQuery"].Value<string>().ToLower();
                sqlQuery.Append(sql.Contains("select ") ? "" : "Select ").Append(toolResult["sqlQuery"].Value<string>());
                if (sqlQuery.ToString().IndexOf("WHERE", StringComparison.OrdinalIgnoreCase) != -1)
                {
                    sqlQuery.Replace("WHERE", "WHERE LocationId=" + LocationId + " AND ");
                }
                else
                {
                    sqlQuery.Append(" WHERE LocationId=" + LocationId).Append(" ");
                }
            }

            return sqlQuery;
        }

        private Object Call(string query, string toolName, string systemPrompt)
        {

            string root = AppContext.BaseDirectory;
            // Combine with your relative path
            string path = Path.Combine(root, $"AITools/AzureOpenAI2/{toolName}.json");
            string functionSchemaJSON = File.ReadAllText(path);

            string Key1 = "1mWEsrfdoPVXROw0Pk2nIhW8mASCrfwWCL6MuRRN1q9ikf9iR15hJQQJ99BGAC77bzfXJ3w3AAABACOGTouD";
            string apiUrl = "https://form-gpt.openai.azure.com/openai/deployments/gpt-4.1-mini/chat/completions?api-version=2025-01-01-preview";
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Add("api-key", Key1);


            var request = new
            {
                model = "gpt-4.1-mini",
                messages = new List<object>()
                {
                    new { role = "user", content = query }
                },
                functions = new List<object>()
            };
            if (!string.IsNullOrEmpty(functionSchemaJSON))
            {
                var functionSchema = JsonConvert.DeserializeObject<JObject>(functionSchemaJSON);

                if (!Common.IsNullOrEmpty(functionSchema["function"]))
                {
                    request.functions.Add(functionSchema["function"]);
                }
                if (!Common.IsNullOrEmpty(functionSchema["schema"]))
                {
                    request.messages.Add(new { role = "system", content = "You are an assistant that generates SQL Server SELECT queries. Schema: " + functionSchema["schema"]?.Value<string>() });
                }
            }
            if (!string.IsNullOrEmpty(systemPrompt))
            {
                request.messages.Add(new { role = "system", content = systemPrompt });
            }


            var jsonRequest = JsonConvert.SerializeObject(request);
            var content = new StringContent(jsonRequest, Encoding.UTF8, "application/json");

            HttpResponseMessage response = client.PostAsync(apiUrl, content).Result;

            if (response.IsSuccessStatusCode)
            {

                string responseContent = response.Content.ReadAsStringAsync().Result;
                if (responseContent.StartsWith("["))
                {
                    return JArray.Parse(responseContent);
                }
                else if (responseContent.StartsWith("{"))
                {
                    JObject jObject = JObject.Parse(responseContent);
                    TotalTokenUsed += Common.ToInt16(jObject?["usage"]?["total_tokens"]?.Value<string>());
                    string text = jObject?["choices"]?[0]["message"]?["content"]?.Value<string>();
                    if (text != null)
                    {
                        if (text.StartsWith("{"))
                        {
                            return JObject.Parse(text);
                        }
                        else if (text.StartsWith("["))
                        {
                            return JArray.Parse(text);
                        }
                        return text;
                    }
                    var functionName = jObject?["choices"]?[0]["message"]?["function_call"]?["name"]?.Value<string>();
                    var args = jObject?["choices"]?[0]["message"]?["function_call"]?["arguments"]?.Value<string>();
                    if (!string.IsNullOrEmpty(args))
                    {
                        return JsonConvert.DeserializeObject<JObject>(args);
                    }
                    return args;
                }
                else
                {
                    return responseContent;
                }
            }
            else
            {
                string responseContent = response.Content.ReadAsStringAsync().Result;
                return $"Error performing search. Status code: {response.StatusCode}" + responseContent;
            }
        }
    }
}
