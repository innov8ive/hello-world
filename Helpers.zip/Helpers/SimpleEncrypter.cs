﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace WebAppProxy
{
    public class SimpleEncrypter
    {
        static string key = "MySecret!!!";
        public static string EncryptDecrypt(string input)
        {
            var output = new char[input.Length];

            for (int i = 0; i < input.Length; i++)
            {
                // XOR each char with corresponding key char
                output[i] = (char)(input[i] ^ key[i % key.Length]);
            }

            return new string(output);
        }
    }
}