﻿using System.Diagnostics;
using System.Net;
using Grpc.Core;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting.Internal;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using static Azure.Core.HttpHeader;
using System.Net.Http;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using static System.Net.WebRequestMethods;
using System.Text.RegularExpressions;
using Microsoft.Data.SqlClient;
using System.Data;
using System.Net.Http.Headers;
using System.Globalization;
using System.Text.Json;

namespace WebAppProxy
{
    public class Function1
    {
        private readonly ILogger _logger;

        public Function1(ILoggerFactory loggerFactory)
        {
            _logger = loggerFactory.CreateLogger<Function1>();
        }

        [Function("Function1")]
        public async Task<HttpResponseData> Run([HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = "aistage")] HttpRequestData req)
        {
            //var identity = GetClaimsIdentity(req);
            //int UserId = Convert.ToInt32(identity.FindFirst("UserId").Value);
            //UserId = 831;
            // Get the connection string from app settings and use it to create a connection.
            //var str = Environment.GetEnvironmentVariable("DefaultConnection");
            //DataTable dt = new DataTable();
            //using (SqlConnection conn = new SqlConnection(str))
            //{
            //    conn.Open();
            //    var text = "select * from Person";

            //    using (SqlCommand cmd = new SqlCommand(text, conn))
            //    {
            //        // Execute the command and log the # rows affected.
            //        dt.Load(cmd.ExecuteReader());
            //    }
            //}

            //_logger.LogInformation("C# HTTP trigger function processed a request.");

            //var response = req.CreateResponse(HttpStatusCode.OK);

            //response.Headers.Add("Content-Type", "application/json; charset=utf-8");
            //DataTableResponse dataTableResponse = new DataTableResponse();
            //dataTableResponse.DataItems = ConvertDataTableToArray(dt);
            //dataTableResponse.Columns = ConvertDataTableColumnsToArray(dt);

            //string output = Newtonsoft.Json.JsonConvert.SerializeObject(dataTableResponse);
            //response.WriteString(output);

            //return response;

            var response = req.CreateResponse(HttpStatusCode.OK);
            // Read request body
            var requestBody = await new StreamReader(req.Body).ReadToEndAsync();

            // Deserialize JSON
            var data = JsonSerializer.Deserialize<PromptRequest>(requestBody);

            if (data == null || string.IsNullOrWhiteSpace(data.Prompt))
            {
                response.StatusCode = System.Net.HttpStatusCode.BadRequest;
                await response.WriteStringAsync("Prompt is required.");
                return response;
            }
            else
            {
                AzueOpenAIHelper geminiAIHelper = new AzueOpenAIHelper();
                geminiAIHelper.LocationId = 1;
                var responseAI = geminiAIHelper.Call(data.Prompt);                
                PromptResponse promptResponse = new PromptResponse();
                promptResponse.Data = responseAI;
                promptResponse.TokenUsed = geminiAIHelper.TotalTokenUsed.ToString();
                Common.UpdateUserUsage(1, geminiAIHelper.TotalTokenUsed);
                string result = Newtonsoft.Json.JsonConvert.SerializeObject(promptResponse);

                response.StatusCode = System.Net.HttpStatusCode.OK;
                await response.WriteStringAsync(result);
                return response;
            }            
        }

        private ClaimsIdentity GetClaimsIdentity([HttpTrigger(AuthorizationLevel.Function, "get", "post")] HttpRequestData req)
        {
            if (req.Headers.FirstOrDefault(Obj => Obj.Key == "Authorization").Value == null)
            {
                throw new Exception("Identity is not valid");
            }
            var userTokenGroups = Regex.Match(((string[])req.Headers.FirstOrDefault(Obj => Obj.Key == "Authorization").Value)[0], @"^Bearer (\S+)$").Groups;
            if (userTokenGroups.Count < 2)
            {
                throw new Exception("Identity is not valid");
            }
            string tokenString = userTokenGroups[1].Value;

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(System.Environment.GetEnvironmentVariable("Secret") ?? ""));
            var handler = new JwtSecurityTokenHandler();
            var validations = new TokenValidationParameters
            {
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = key,
                ValidateIssuer = true,
                ValidIssuer = System.Environment.GetEnvironmentVariable("ValidIssuer") ?? "",
                ValidateAudience = true,
                ValidAudience = System.Environment.GetEnvironmentVariable("ValidAudience") ?? ""
            };

            var identity = handler.ValidateToken(tokenString, validations, out var tokenSecure).Identity as ClaimsIdentity;
            if (identity == null)
            {
                throw new Exception("Identity is not valid");
            }

            return identity;
        }

        static List<string[]> ConvertDataTableToArray(DataTable dt)
        {
            var result = new List<string[]>();

            foreach (DataRow dr in dt.Rows)
            {
                var values = new string[dt.Columns.Count];

                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    object value = dr[i];

                    if (value == DBNull.Value || value == null)
                    {
                        values[i] = ""; // or "NULL"
                    }
                    else if (value is DateTime dtVal)
                    {
                        values[i] = dtVal.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
                    }
                    else
                    {
                        values[i] = value.ToString();
                    }
                }

                result.Add(values);
            }

            return result;
        }
        static List<DataTableColumn> ConvertDataTableColumnsToArray(DataTable dt)
        {
            var sb = new List<DataTableColumn>();
            foreach (DataColumn col in dt.Columns)
            {
                sb.Add(new DataTableColumn() { title = col.ColumnName });
            }
            return sb;
        }
    }

    public class DataTableResponse
    {
        public List<string[]>? DataItems { get; set; }
        public List<DataTableColumn>? Columns { get; set; }
        public string Title { get; set; }
    }

    public class DataTableColumn
    {
        public string? title { get; set; }

    }
    public class PromptRequest
    {
        public string Prompt { get; set; } = string.Empty;
    }
    public class PromptResponse
    {
        public Object Data { get; set; }
        public string TokenUsed { get; set; }
    }
}
