import { NgbDateStruct } from "@ng-bootstrap/ng-bootstrap";

export class Common {
    public ISOToBootstrapDate(date: string): any {
        if (date == null || date == '') return null;
        var resultDate = new Date(date);
        var result = {
            "year": resultDate.getFullYear(),
            "month": resultDate.getMonth() + 1,
            "day": resultDate.getDate()
        };
        return result;
    }
  
    public BootstrapDateToISO(date: any): string {
        if (date == null || date == '') return null;
        var result = new Date(date.year, date.month-1, date.day+1);
        return result.toISOString();
    }
    public ParseISODate(obj: any): any {
        for (var key in obj) {
            if (obj[key] != null && (typeof obj[key] === 'string')) {
                var res = obj[key].match(/^(-?(?:[1-9][0-9]*)?[0-9]{4})-(1[0-2]|0[1-9])-(3[01]|0[1-9]|[12][0-9])T(2[0-3]|[01][0-9]):([0-5][0-9]):([0-5][0-9])(.[0-9]+)?(Z)?$/g);
                if (res != null && res.length > 0)
                    obj[key] = this.ISOToBootstrapDate(obj[key]);
            }
        }
    }
    public ToISODate(obj: any): any {
        for (var key in obj) {
            if (obj[key] != null && obj[key].hasOwnProperty('year')) {
                obj[key] = this.BootstrapDateToISO(obj[key]);
            }
        }
    }
}