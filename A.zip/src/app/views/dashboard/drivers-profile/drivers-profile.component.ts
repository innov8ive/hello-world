import { Component, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TableComponent } from '../../gridbase/table.component';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Message, MessageService } from 'primeng/api';


@Component({
  templateUrl: 'drivers-profile.component.html',
  styleUrl: 'drivers-profile.component.scss',
  providers: [MessageService]
})
export class DriversProfileComponent {
  loading = false;
  driverData: any;
  driverRides: any;
  userId: number;
  baseUrl = 'https://localhost:44339/';
  remarkEditing = false;
  constructor(private _router: Router, private route: ActivatedRoute, private http: HttpClient, private messageService: MessageService) {
    this.userId = route.snapshot.params['UserId'];
  }
  @ViewChild('rideTable') myTable: TableComponent;
  @ViewChild('txnTable') txnTable: TableComponent;
  cols = [
    { field: 'Rider', header: 'Rider' },
    { field: 'StatusDetails', header: 'Status' },
    { field: 'Distance', header: 'Distance (KM)' },
    { field: 'Fare', header: 'Fare (₹)' },
    { field: 'PaidMode', header: 'Payment Mode' },
    { field: 'StartLocationText', header: 'Start Location' },
    { field: 'EndLocationText', header: 'End Location' },
    { field: 'PickTime', header: 'Pickup Time', format: 'dd-MMM-yyyy hh:MM a' },
    { field: 'EndTime', header: 'Drop Time', format: 'hh:MM a' }
  ];

  txnCols = [
    { field: 'TxnId', header: 'Transaction Id' },
    { field: 'Type', header: 'Type' },
    { field: 'Commission', header: 'Commission (₹)' },
    { field: 'Payment', header: 'Payment (₹)' },
    { field: 'TxnDate', header: 'Transaction Time', format: 'dd-MMM-yyyy hh:MM a' },
    { field: 'PlatformBillId', header: 'Transaction Ref No.' },
    { field: 'Remarks', header: 'Remarks' }
  ];


  ngOnInit(): void {
    this.loadData(this.userId);
  }
  loadData(userId: number) {
    this.loading = true;
    this.http.get('api/Admin/getUser/' + userId).subscribe(data => {
      this.driverData = data
      this.loading = false;

    });
  }
  loadDriverRides() {
    window.setTimeout(() => {
      this.myTable.loadData(this.userId.toString());
    }, 100);
  }
  loadDriverPayments() {
    window.setTimeout(() => {
      this.txnTable.loadData(this.userId.toString());
    }, 100);
  }
  getColor(status: string) {
    if (status == 'Approved') {
      return 'success';
    } else if (status == 'Pending') {
      return 'warning';
    } else if (status == 'Rejected') {
      return 'danger';
    } else {
      return 'secondary';
    }
  }

  getImgPath(fileGUID: string) {
    return fileGUID.startsWith('http') ? fileGUID : this.baseUrl + fileGUID;
  }

  openImage(fileGUID: string) {
    const path = fileGUID.startsWith('http') ? fileGUID : this.baseUrl + fileGUID;
    window.open(path, '_blank');
  }

  approveDocument(doc: any) {
    this.loading = true;
    this.http.post('api/Admin/approveDocument', { DriverDocId: doc.driverDocId }).subscribe(data => {
      this.loading = false;
      let result = data as any;
      if (result.text == 'Success') {
        doc.statusDetails = 'Approved';
        this.messageService.add({
          severity: 'success',
          summary: 'Success Message',
          detail: 'Document Approved Successfully!',
        });
      }
    });
  }

  rejectDocument(doc: any) {
    this.loading = true;
    this.http.post('api/Admin/rejectDocument', { DriverDocId: doc.driverDocId }).subscribe(data => {
      this.loading = false;
      let result = data as any;
      if (result.text == 'Success') {
        doc.statusDetails = 'Rejected';
        this.messageService.add({
          severity: 'success',
          summary: 'Success Message',
          detail: 'Document Rejected Successfully!',
        });
      }
    });
  }

  approveDriver() {
    this.loading = true;
    this.http.post('api/Admin/approveDriver', { UserId: this.userId }).subscribe(data => {
      this.loading = false;
      let result = data as any;
      if (result.text == 'Success') {
        this.driverData.statusDetails = 'Approved';
        this.messageService.add({
          severity: 'success',
          summary: 'Success Message',
          detail: 'Driver Approved Successfully!',
        });
      }
    });
  }

  rejectDriver() {
    if (!this.driverData.userDetails.approvalRemarks) {
      alert('Please enter Rejection Remarks!');
      this.remarkEditing = true;
      return;
    }
    this.loading = true;
    this.http.post('api/Admin/rejectDriver', { UserId: this.userId, ApprovalRemarks: this.driverData.userDetails.approvalRemarks }).subscribe(data => {
      this.loading = false;
      let result = data as any;
      if (result.text == 'Success') {
        this.driverData.statusDetails = 'Rejected';
        this.messageService.add({
          severity: 'success',
          summary: 'Success Message',
          detail: 'Driver Rejected Successfully!',
        });
      }
    });
  }

  setActiveInActive(isActive: boolean) {
    let apiName = isActive == false ? 'api/Admin/activateUser' : 'api/Admin/deactivateUser';
    this.loading = true;
    this.http.post(apiName, { UserId: this.userId }).subscribe(data => {
      this.loading = false;
      let result = data as any;
      if (result.text == 'Success') {
        this.driverData.userDetails.isActive = !this.driverData.userDetails.isActive;
        this.messageService.add({
          severity: 'success',
          summary: 'Success Message',
          detail: 'Driver Status Updated Successfully!',
        });
      }
    });
  }
}
