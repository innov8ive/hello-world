import { Component, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { TableComponent } from '../../gridbase/table.component';
import { Message } from 'primeng/api';

@Component({
    templateUrl: 'FaresListComponent.html'
})
export class FaresListComponent {
    @ViewChild('myTable') myTable: TableComponent;
    cols = [
        { field: 'VehicleType', header: 'Vehicle Type' },
        { field: 'FareType', header: 'Fare Type' },
        { field: 'BaseFare', header: 'Base Fare (₹)' },
        { field: 'PerKMFare', header: 'Per/KM Fare (₹)' },
        { field: 'WaitingPerMinuteFare', header: 'Trip/Minute Fare (₹)' },
        { field: 'EffectiveTill', header: 'EffectiveTill', format: 'dd-MMM-yyyy' }];
    dataKey: string = 'Id';
    searchText: string = '';
    msgs: Message[] = [];

    constructor(private _router: Router, private http: HttpClient) { }
    searchFares() {
        this.myTable.loadData(this.searchText);
    }
    newFares() {
        this._router.navigate(['/dashboard/Fares', 0]);
    }
    editFares() {

        if (this.myTable.selectedRow == null) {
            alert('Please select a row to edit');
            return;
        }
        this._router.navigate(['/dashboard/Fares', this.myTable.selectedRow.Id]);
    }
    deleteFares() {
        if (this.myTable.selectedRow == null) {
            alert('Please select a row to edit');
            return;
        }
        this.http.delete('api/Fares/' + this.myTable.selectedRow.Id).subscribe(
            result => {
                this.msgs.push({ severity: 'success', summary: 'Success Message', detail: 'Data Deleted Successfully!' });
                this.searchFares();
            },
            error => {
                this.msgs.push({
                    severity: 'error', summary: 'Error Message', detail: 'Data not Deleted!\n'
                        + error.message
                });
            }
        );
    }
}
