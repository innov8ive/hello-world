import { Component, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { Message } from 'primeng/api';
import { Common } from '../../gridbase/Common';

@Component({
    templateUrl: 'FaresComponent.html'
})
export class FaresComponent {
    Id: any;
    Fares: any = {};
    msgs: Message[] = [];
    formFaresSubmitted: boolean = false;
    common: Common = new Common();
    fareTypes = [
        { text: 'Local', value: 'Local' },
        { text: 'Outstation', value: 'Outstation' },
        { text: 'Hire', value: 'Hire' }
    ];
    vehicleTypes = [
        { text: 'Hatchback', value: 1 },
        { text: 'Sedan', value: 2 },
        { text: 'SUV', value: 3 },
        { text: 'Taxi', value: 4 },
        { text: 'Auto', value: 3 }
    ];
    constructor(private route: ActivatedRoute, private router: Router, private http: HttpClient) {
        this.Id = route.snapshot.params['Id'];
        this.loadFares();
    }

    loadFares() {
        this.http.get('api/Fares/' + this.Id).subscribe(result => {
            this.Fares = result;
            this.common.ParseISODate(this.Fares);
        });
    }
    saveFares(formFares: NgForm) {
        this.formFaresSubmitted = true;
        if (formFares.invalid == true) return;
        this.common.ToISODate(this.Fares);
        this.http.post('api/Fares/', this.Fares).subscribe(
            result => {

                result = JSON.parse(result as string);
                if (result instanceof Array) {
                    for (var j = 0; j < result.length; j++) {
                        this.msgs.push({
                            severity: 'error', summary: 'Error Message', detail: result[j].ErrorMessage
                        });
                    }
                }
                else {
                    this.msgs.push({ severity: 'success', summary: 'Success Message', detail: 'Data Saved Successfully!' });
                    this.Fares = result;
                    this.common.ParseISODate(this.Fares);
                }
            },
            error => {
                this.msgs.push({
                    severity: 'error', summary: 'Error Message', detail: 'Data not Saved Successfully!\n' + error.error.ExceptionMessage
                });
            }
        );
    }
    goBack() {
        this.router.navigate(['/dashboard/FaresList']);
    }
}
