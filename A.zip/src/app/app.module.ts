import { Injectable, NgModule } from '@angular/core';
import { HashLocationStrategy, LocationStrategy, PathLocationStrategy } from '@angular/common';
import { BrowserModule, Title } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule } from '@angular/forms';
import { LoadingIndicatorService } from './LoadingIndicatorService';
import { FormsModule } from '@angular/forms';

import { NgScrollbarModule } from 'ngx-scrollbar';

import { TableModule } from 'primeng/table';
import { PaginatorModule } from 'primeng/paginator';
import { ToastModule } from 'primeng/toast';
import { CalendarModule } from 'primeng/calendar';

import { Observable, throwError } from 'rxjs';
import { catchError, finalize, tap } from "rxjs/operators";

// Import routing module
import { AppRoutingModule } from './app-routing.module';

// Import app component
import { AppComponent } from './app.component';
import { Router, RouterModule } from '@angular/router';

// Import containers
import { DefaultFooterComponent, DefaultHeaderComponent, DefaultLayoutComponent } from './containers';

import { TableComponent } from './views/gridbase/table.component';

@Injectable()
export class APIInterceptor implements HttpInterceptor {
  constructor(private loadingIndicatorService: LoadingIndicatorService, private router: Router) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    this.loadingIndicatorService.onStarted(req);
    let token = sessionStorage.getItem('token');
    const apiReq = req.clone({
      url: `https://localhost:44339/${req.url}`,
      headers: req.headers.set('Authorization', `Bearer ${token}`)
    });
    return next.handle(apiReq).pipe(
      catchError((error) => {
        if (error.status === 401) {
          // Token expired, redirect to login page
          window.location.href = "#/login";
        }
        alert(error.error);
        return throwError(error);
      })
    );
    
  };

}

import {
  AvatarModule,
  BadgeModule,
  BreadcrumbModule,
  ButtonGroupModule,
  ButtonModule,
  CardModule,
  DropdownModule,
  FooterModule,
  FormModule,
  GridModule,
  HeaderModule,
  ListGroupModule,
  NavModule,
  ProgressModule,
  SharedModule,
  SidebarModule,
  TabsModule,
  UtilitiesModule
} from '@coreui/angular';

import { IconModule, IconSetService } from '@coreui/icons-angular';
import { HTTP_INTERCEPTORS, HttpClientModule, HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { DriversComponent } from './views/dashboard/drivers/drivers.component';


const APP_CONTAINERS = [
  DefaultFooterComponent,
  DefaultHeaderComponent,
  DefaultLayoutComponent
];

@NgModule({
  declarations: [AppComponent, ...APP_CONTAINERS],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    AvatarModule,
    BreadcrumbModule,
    FooterModule,
    DropdownModule,
    GridModule,
    HeaderModule,
    SidebarModule,
    IconModule,
    NavModule,
    ButtonModule,
    FormModule,
    UtilitiesModule,
    ButtonGroupModule,
    ReactiveFormsModule,
    SidebarModule,
    SharedModule,
    TabsModule,
    ListGroupModule,
    ProgressModule,
    BadgeModule,
    ListGroupModule,
    CardModule,
    NgScrollbarModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([]),
    TableModule,
    PaginatorModule,
    ToastModule,
    CalendarModule
  ],
  providers: [
    {
      provide: LocationStrategy,
      useClass: HashLocationStrategy
    },
    IconSetService,
    Title, LoadingIndicatorService, {
      provide: HTTP_INTERCEPTORS,
      useFactory: (service: LoadingIndicatorService,router: Router) => new APIInterceptor(service,router),
      multi: true,
      deps: [LoadingIndicatorService]
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
}
